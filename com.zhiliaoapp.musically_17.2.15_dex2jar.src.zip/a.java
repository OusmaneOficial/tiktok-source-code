import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  static
  {
    CoverageLogger.Log(79015936);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a
 * JD-Core Version:    0.6.2
 */