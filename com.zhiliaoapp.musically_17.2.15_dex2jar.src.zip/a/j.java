package a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class j<TResult>
{
  public final i<TResult> a = new i();

  static
  {
    CoverageLogger.Log(77500416);
  }

  public final boolean a()
  {
    return this.a.i();
  }

  public final boolean a(Exception paramException)
  {
    return this.a.b(paramException);
  }

  public final boolean a(TResult paramTResult)
  {
    return this.a.b(paramTResult);
  }

  public final void b()
  {
    if (a())
      return;
    throw new IllegalStateException("Cannot cancel a completed task.");
  }

  public final void b(Exception paramException)
  {
    if (a(paramException))
      return;
    throw new IllegalStateException("Cannot set the error on a completed task.");
  }

  public final void b(TResult paramTResult)
  {
    if (a(paramTResult))
      return;
    throw new IllegalStateException("Cannot set the result of a completed task.");
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.j
 * JD-Core Version:    0.6.2
 */