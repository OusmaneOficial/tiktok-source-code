package a;

import android.os.Build.VERSION;
import com.ss.android.ugc.aweme.bn.g;
import com.ss.android.ugc.aweme.bn.l;
import com.ss.android.ugc.aweme.bn.l.a;
import com.ss.android.ugc.aweme.bn.o;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

final class c
{
  static final c a = new c();
  final Executor b;
  private final ExecutorService c;
  private final ScheduledExecutorService d;

  static
  {
    CoverageLogger.Log(77387776);
  }

  private c()
  {
    String str = System.getProperty("java.runtime.name");
    boolean bool;
    if (str == null)
      bool = false;
    else
      bool = str.toLowerCase(Locale.US).contains("android");
    Object localObject;
    if (!bool)
    {
      localObject = Executors.newCachedThreadPool();
    }
    else
    {
      int i = b.c;
      int j = b.d;
      TimeUnit localTimeUnit = TimeUnit.SECONDS;
      LinkedBlockingQueue localLinkedBlockingQueue = new LinkedBlockingQueue();
      localObject = new ThreadPoolExecutor(i, j, 1L, localTimeUnit, localLinkedBlockingQueue);
      if (Build.VERSION.SDK_INT >= 9)
        ((ThreadPoolExecutor)localObject).allowCoreThreadTimeOut(true);
    }
    this.c = ((ExecutorService)localObject);
    this.d = ((ScheduledExecutorService)g.a(l.a(o.SCHEDULED).a(1).a()));
    this.b = new a(null);
  }

  public static ExecutorService a()
  {
    return g.d();
  }

  static ScheduledExecutorService b()
  {
    return g.f();
  }

  static final class a
    implements Executor
  {
    private ThreadLocal<Integer> a = new ThreadLocal();

    static
    {
      CoverageLogger.Log(77389824);
    }

    private int a()
    {
      Integer localInteger = (Integer)this.a.get();
      if (localInteger == null)
        localInteger = Integer.valueOf(0);
      int i = -1 + localInteger.intValue();
      if (i == 0)
      {
        this.a.remove();
        return i;
      }
      this.a.set(Integer.valueOf(i));
      return i;
    }

    public final void execute(Runnable paramRunnable)
    {
      Integer localInteger = (Integer)this.a.get();
      if (localInteger == null)
        localInteger = Integer.valueOf(0);
      int i = 1 + localInteger.intValue();
      this.a.set(Integer.valueOf(i));
      if (i <= 15);
      try
      {
        paramRunnable.run();
        break label62;
        c.a().execute(paramRunnable);
        label62: return;
      }
      finally
      {
        a();
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.c
 * JD-Core Version:    0.6.2
 */