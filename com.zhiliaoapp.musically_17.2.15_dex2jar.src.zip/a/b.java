package a;

import android.os.Handler;
import android.os.Looper;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

final class b
{
  static final b a;
  static final int c = i + 1;
  static final int d = 1 + 2 * e;
  private static final int e;
  final Executor b = new a(null);

  static
  {
    CoverageLogger.Log(77451264);
    a = new b();
    int i = Runtime.getRuntime().availableProcessors();
    e = i;
  }

  static final class a
    implements Executor
  {
    static
    {
      CoverageLogger.Log(77447168);
    }

    public final void execute(Runnable paramRunnable)
    {
      new Handler(Looper.getMainLooper()).post(paramRunnable);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.b
 * JD-Core Version:    0.6.2
 */