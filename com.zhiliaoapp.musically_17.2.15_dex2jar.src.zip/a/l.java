package a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class l extends RuntimeException
{
  static
  {
    CoverageLogger.Log(77506560);
  }

  public l(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.l
 * JD-Core Version:    0.6.2
 */