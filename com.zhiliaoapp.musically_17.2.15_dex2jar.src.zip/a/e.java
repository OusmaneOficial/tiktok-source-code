package a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.Closeable;
import java.util.List;

public final class e
  implements Closeable
{
  private final Object a;
  private f b;
  private Runnable c;
  private boolean d;

  static
  {
    CoverageLogger.Log(77381632);
  }

  final void a()
  {
    synchronized (this.a)
    {
      if (!this.d)
      {
        this.c.run();
        close();
        return;
      }
      throw new IllegalStateException("Object already closed");
    }
  }

  public final void close()
  {
    synchronized (this.a)
    {
      if (this.d)
        return;
      this.d = true;
      f localf = this.b;
      synchronized (localf.a)
      {
        localf.d();
        localf.b.remove(this);
        this.b = null;
        this.c = null;
        return;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.e
 * JD-Core Version:    0.6.2
 */