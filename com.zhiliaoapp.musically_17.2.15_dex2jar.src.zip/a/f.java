package a;

import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

public final class f
  implements Closeable
{
  public final Object a = new Object();
  final List<e> b = new ArrayList();
  public ScheduledFuture<?> c;
  private final ScheduledExecutorService d = c.b();
  private boolean e;
  private boolean f;

  static
  {
    CoverageLogger.Log(77453312);
  }

  private static void a(List<e> paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      ((e)localIterator.next()).a();
  }

  private void e()
  {
    ScheduledFuture localScheduledFuture = this.c;
    if (localScheduledFuture != null)
    {
      localScheduledFuture.cancel(true);
      this.c = null;
    }
  }

  public final boolean a()
  {
    synchronized (this.a)
    {
      d();
      boolean bool = this.e;
      return bool;
    }
  }

  public final d b()
  {
    synchronized (this.a)
    {
      d();
      d locald = new d(this);
      return locald;
    }
  }

  public final void c()
  {
    synchronized (this.a)
    {
      d();
      if (this.e)
        return;
      e();
      this.e = true;
      ArrayList localArrayList = new ArrayList(this.b);
      a(localArrayList);
      return;
    }
  }

  public final void close()
  {
    synchronized (this.a)
    {
      if (this.f)
        return;
      e();
      Iterator localIterator = this.b.iterator();
      while (localIterator.hasNext())
        ((e)localIterator.next()).close();
      this.b.clear();
      this.f = true;
      return;
    }
    while (true)
      throw localObject2;
  }

  void d()
  {
    if (!this.f)
      return;
    throw new IllegalStateException("Object already closed");
  }

  public final String toString()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = getClass().getName();
    arrayOfObject[1] = Integer.toHexString(hashCode());
    arrayOfObject[2] = Boolean.toString(a());
    return a.a(localLocale, "%s@%s[cancellationRequested=%s]", arrayOfObject);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.f
 * JD-Core Version:    0.6.2
 */