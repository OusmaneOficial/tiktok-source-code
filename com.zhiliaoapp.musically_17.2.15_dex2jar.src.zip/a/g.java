package a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface g<TTaskResult, TContinuationResult>
{
  static
  {
    CoverageLogger.Log(77455360);
  }

  public abstract TContinuationResult then(i<TTaskResult> parami)
    throws Exception;
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.g
 * JD-Core Version:    0.6.2
 */