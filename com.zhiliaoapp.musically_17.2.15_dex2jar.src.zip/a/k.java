package a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class k
{
  i<?> a;

  static
  {
    CoverageLogger.Log(77504512);
  }

  public k(i<?> parami)
  {
    this.a = parami;
  }

  protected final void finalize()
    throws Throwable
  {
    try
    {
      i locali = this.a;
      if ((locali != null) && (i.a() != null))
        new l(locali.f());
      return;
    }
    finally
    {
      super.finalize();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.k
 * JD-Core Version:    0.6.2
 */