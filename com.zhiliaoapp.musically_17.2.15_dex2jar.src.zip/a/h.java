package a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class h extends RuntimeException
{
  static
  {
    CoverageLogger.Log(77377536);
  }

  public h(Exception paramException)
  {
    super("An exception was thrown by an Executor", paramException);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.h
 * JD-Core Version:    0.6.2
 */