package a;

import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Locale;

public final class d
{
  private final f a;

  static
  {
    CoverageLogger.Log(77383680);
  }

  d(f paramf)
  {
    this.a = paramf;
  }

  public final boolean a()
  {
    return this.a.a();
  }

  public final String toString()
  {
    Locale localLocale = Locale.US;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = getClass().getName();
    arrayOfObject[1] = Integer.toHexString(hashCode());
    arrayOfObject[2] = Boolean.toString(this.a.a());
    return a.a(localLocale, "%s@%s[cancellationRequested=%s]", arrayOfObject);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.d
 * JD-Core Version:    0.6.2
 */