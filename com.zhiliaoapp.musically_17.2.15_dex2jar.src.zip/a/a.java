package a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class a extends Exception
{
  private static final long serialVersionUID = 1L;
  private List<Throwable> a;

  static
  {
    CoverageLogger.Log(77402112);
  }

  public a(String paramString, List<? extends Throwable> paramList)
  {
    super(paramString, localThrowable);
    this.a = Collections.unmodifiableList(paramList);
  }

  public a(String paramString, Throwable[] paramArrayOfThrowable)
  {
    this(paramString, Arrays.asList(paramArrayOfThrowable));
  }

  public a(List<? extends Throwable> paramList)
  {
    this("There were multiple errors.", paramList);
  }

  public final Throwable[] getCauses()
  {
    List localList = this.a;
    return (Throwable[])localList.toArray(new Throwable[localList.size()]);
  }

  public final List<Exception> getErrors()
  {
    ArrayList localArrayList = new ArrayList();
    List localList = this.a;
    if (localList == null)
      return localArrayList;
    Iterator localIterator = localList.iterator();
    while (localIterator.hasNext())
    {
      Throwable localThrowable = (Throwable)localIterator.next();
      if ((localThrowable instanceof Exception))
        localArrayList.add((Exception)localThrowable);
      else
        localArrayList.add(new Exception(localThrowable));
    }
    return localArrayList;
  }

  public final List<Throwable> getInnerThrowables()
  {
    return this.a;
  }

  public final void printStackTrace(PrintStream paramPrintStream)
  {
    super.printStackTrace(paramPrintStream);
    Iterator localIterator = this.a.iterator();
    int i = -1;
    while (localIterator.hasNext())
    {
      Throwable localThrowable = (Throwable)localIterator.next();
      paramPrintStream.append("\n");
      paramPrintStream.append("  Inner throwable #");
      i++;
      paramPrintStream.append(Integer.toString(i));
      paramPrintStream.append(": ");
      com.google.c.a.a.a.a.a.a(localThrowable, paramPrintStream);
      paramPrintStream.append("\n");
    }
  }

  public final void printStackTrace(PrintWriter paramPrintWriter)
  {
    super.printStackTrace(paramPrintWriter);
    Iterator localIterator = this.a.iterator();
    int i = -1;
    while (localIterator.hasNext())
    {
      Throwable localThrowable = (Throwable)localIterator.next();
      paramPrintWriter.append("\n");
      paramPrintWriter.append("  Inner throwable #");
      i++;
      paramPrintWriter.append(Integer.toString(i));
      paramPrintWriter.append(": ");
      com.google.c.a.a.a.a.a.a(localThrowable, paramPrintWriter);
      paramPrintWriter.append("\n");
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     a.a
 * JD-Core Version:    0.6.2
 */