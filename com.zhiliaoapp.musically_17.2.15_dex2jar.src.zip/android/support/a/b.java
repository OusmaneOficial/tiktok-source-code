package android.support.a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public abstract interface b extends IInterface
{
  static
  {
    CoverageLogger.Log(115234816);
  }

  public abstract int a(a parama, String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract Bundle a(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract boolean a(long paramLong)
    throws RemoteException;

  public abstract boolean a(a parama)
    throws RemoteException;

  public abstract boolean a(a parama, int paramInt, Uri paramUri, Bundle paramBundle)
    throws RemoteException;

  public abstract boolean a(a parama, Uri paramUri)
    throws RemoteException;

  public abstract boolean a(a parama, Uri paramUri, Bundle paramBundle, List<Bundle> paramList)
    throws RemoteException;

  public abstract boolean a(a parama, Bundle paramBundle)
    throws RemoteException;

  public static abstract class a extends Binder
    implements b
  {
    static
    {
      CoverageLogger.Log(115456000);
    }

    public a()
    {
      attachInterface(this, "android.support.customtabs.ICustomTabsService");
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      if (paramInt1 != 1598968902)
      {
        switch (paramInt1)
        {
        default:
          return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
        case 9:
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          a locala5 = a.a.a(paramParcel1.readStrongBinder());
          int i7 = paramParcel1.readInt();
          Uri localUri3;
          if (paramParcel1.readInt() != 0)
            localUri3 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          else
            localUri3 = null;
          int i8 = paramParcel1.readInt();
          Bundle localBundle6 = null;
          if (i8 != 0)
            localBundle6 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          int i9 = a(locala5, i7, localUri3, localBundle6);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i9);
          return true;
        case 8:
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          a locala4 = a.a.a(paramParcel1.readStrongBinder());
          String str2 = paramParcel1.readString();
          int i5 = paramParcel1.readInt();
          Bundle localBundle5 = null;
          if (i5 != 0)
            localBundle5 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          int i6 = a(locala4, str2, localBundle5);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i6);
          return true;
        case 7:
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          a locala3 = a.a.a(paramParcel1.readStrongBinder());
          int i3 = paramParcel1.readInt();
          Uri localUri2 = null;
          if (i3 != 0)
            localUri2 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          int i4 = a(locala3, localUri2);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i4);
          return true;
        case 6:
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          a locala2 = a.a.a(paramParcel1.readStrongBinder());
          int i1 = paramParcel1.readInt();
          Bundle localBundle4 = null;
          if (i1 != 0)
            localBundle4 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          int i2 = a(locala2, localBundle4);
          paramParcel2.writeNoException();
          paramParcel2.writeInt(i2);
          return true;
        case 5:
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          String str1 = paramParcel1.readString();
          int n = paramParcel1.readInt();
          Bundle localBundle2 = null;
          if (n != 0)
            localBundle2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          Bundle localBundle3 = a(str1, localBundle2);
          paramParcel2.writeNoException();
          if (localBundle3 != null)
          {
            paramParcel2.writeInt(1);
            localBundle3.writeToParcel(paramParcel2, 1);
            return true;
          }
          paramParcel2.writeInt(0);
          return true;
        case 4:
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          a locala1 = a.a.a(paramParcel1.readStrongBinder());
          Uri localUri1;
          if (paramParcel1.readInt() != 0)
            localUri1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
          else
            localUri1 = null;
          int k = paramParcel1.readInt();
          Bundle localBundle1 = null;
          if (k != 0)
            localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          int m = a(locala1, localUri1, localBundle1, paramParcel1.createTypedArrayList(Bundle.CREATOR));
          paramParcel2.writeNoException();
          paramParcel2.writeInt(m);
          return true;
        case 3:
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
          int j = a(a.a.a(paramParcel1.readStrongBinder()));
          paramParcel2.writeNoException();
          paramParcel2.writeInt(j);
          return true;
        case 2:
        }
        paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsService");
        int i = a(paramParcel1.readLong());
        paramParcel2.writeNoException();
        paramParcel2.writeInt(i);
        return true;
      }
      paramParcel2.writeString("android.support.customtabs.ICustomTabsService");
      return true;
    }

    public static final class a
      implements b
    {
      private IBinder a;

      static
      {
        CoverageLogger.Log(115245056);
      }

      public a(IBinder paramIBinder)
      {
        this.a = paramIBinder;
      }

      public final int a(a parama, String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              localParcel1.writeString(paramString);
              if (paramBundle != null)
              {
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              this.a.transact(8, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              return i;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final Bundle a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          Bundle localBundle;
          if (localParcel2.readInt() != 0)
            localBundle = (Bundle)Bundle.CREATOR.createFromParcel(localParcel2);
          else
            localBundle = null;
          return localBundle;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final boolean a(long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
          localParcel1.writeLong(paramLong);
          this.a.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final boolean a(a parama)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              this.a.transact(3, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int i = localParcel2.readInt();
              boolean bool = false;
              if (i != 0)
                bool = true;
              return bool;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final boolean a(a parama, int paramInt, Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              localParcel1.writeInt(paramInt);
              int i = 1;
              if (paramUri != null)
              {
                localParcel1.writeInt(i);
                paramUri.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              if (paramBundle != null)
              {
                localParcel1.writeInt(i);
                paramBundle.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              this.a.transact(9, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int j = localParcel2.readInt();
              if (j == 0)
                i = 0;
              return i;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final boolean a(a parama, Uri paramUri)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              int i = 1;
              if (paramUri != null)
              {
                localParcel1.writeInt(i);
                paramUri.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              this.a.transact(7, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int j = localParcel2.readInt();
              if (j == 0)
                i = 0;
              return i;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final boolean a(a parama, Uri paramUri, Bundle paramBundle, List<Bundle> paramList)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              int i = 1;
              if (paramUri != null)
              {
                localParcel1.writeInt(i);
                paramUri.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              if (paramBundle != null)
              {
                localParcel1.writeInt(i);
                paramBundle.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              localParcel1.writeTypedList(paramList);
              this.a.transact(4, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int j = localParcel2.readInt();
              if (j == 0)
                i = 0;
              return i;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final boolean a(a parama, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsService");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              int i = 1;
              if (paramBundle != null)
              {
                localParcel1.writeInt(i);
                paramBundle.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              this.a.transact(6, localParcel1, localParcel2, 0);
              localParcel2.readException();
              int j = localParcel2.readInt();
              if (j == 0)
                i = 0;
              return i;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final IBinder asBinder()
      {
        return this.a;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.a.b
 * JD-Core Version:    0.6.2
 */