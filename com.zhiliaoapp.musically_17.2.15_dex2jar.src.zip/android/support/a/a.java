package android.support.a;

import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a extends IInterface
{
  static
  {
    CoverageLogger.Log(115240960);
  }

  public abstract void a(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle)
    throws RemoteException;

  public abstract void a(int paramInt, Bundle paramBundle)
    throws RemoteException;

  public abstract void a(Bundle paramBundle)
    throws RemoteException;

  public abstract void a(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract void b(String paramString, Bundle paramBundle)
    throws RemoteException;

  public static abstract class a extends Binder
    implements a
  {
    static
    {
      CoverageLogger.Log(115451904);
    }

    public a()
    {
      attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
    }

    public static a a(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.support.customtabs.ICustomTabsCallback");
      if ((localIInterface != null) && ((localIInterface instanceof a)))
        return (a)localIInterface;
      return new a(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      if (paramInt1 != 2)
      {
        if (paramInt1 != 3)
        {
          if (paramInt1 != 4)
          {
            if (paramInt1 != 5)
            {
              if (paramInt1 != 6)
              {
                if (paramInt1 != 1598968902)
                  return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
                paramParcel2.writeString("android.support.customtabs.ICustomTabsCallback");
                return true;
              }
              paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
              int i1 = paramParcel1.readInt();
              Uri localUri;
              if (paramParcel1.readInt() != 0)
                localUri = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
              else
                localUri = null;
              boolean bool;
              if (paramParcel1.readInt() != 0)
                bool = true;
              else
                bool = false;
              int i2 = paramParcel1.readInt();
              Bundle localBundle5 = null;
              if (i2 != 0)
                localBundle5 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
              a(i1, localUri, bool, localBundle5);
              paramParcel2.writeNoException();
              return true;
            }
            paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
            String str2 = paramParcel1.readString();
            int n = paramParcel1.readInt();
            Bundle localBundle4 = null;
            if (n != 0)
              localBundle4 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            b(str2, localBundle4);
            paramParcel2.writeNoException();
            return true;
          }
          paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
          int m = paramParcel1.readInt();
          Bundle localBundle3 = null;
          if (m != 0)
            localBundle3 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          a(localBundle3);
          paramParcel2.writeNoException();
          return true;
        }
        paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
        String str1 = paramParcel1.readString();
        int k = paramParcel1.readInt();
        Bundle localBundle2 = null;
        if (k != 0)
          localBundle2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
        a(str1, localBundle2);
        paramParcel2.writeNoException();
        return true;
      }
      paramParcel1.enforceInterface("android.support.customtabs.ICustomTabsCallback");
      int i = paramParcel1.readInt();
      int j = paramParcel1.readInt();
      Bundle localBundle1 = null;
      if (j != 0)
        localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
      a(i, localBundle1);
      paramParcel2.writeNoException();
      return true;
    }

    static final class a
      implements a
    {
      private IBinder a;

      static
      {
        CoverageLogger.Log(115447808);
      }

      a(IBinder paramIBinder)
      {
        this.a = paramIBinder;
      }

      public final void a(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          int i;
          try
          {
            localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
            localParcel1.writeInt(paramInt);
            if (paramUri != null)
            {
              localParcel1.writeInt(1);
              paramUri.writeToParcel(localParcel1, 0);
            }
            else
            {
              localParcel1.writeInt(0);
              break label135;
              localParcel1.writeInt(i);
              if (paramBundle != null)
              {
                localParcel1.writeInt(1);
                paramBundle.writeToParcel(localParcel1, 0);
              }
              else
              {
                localParcel1.writeInt(0);
              }
              this.a.transact(6, localParcel1, localParcel2, 0);
              localParcel2.readException();
              return;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          label135: if (paramBoolean)
            i = 1;
          else
            i = 0;
        }
      }

      public final void a(int paramInt, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          localParcel1.writeInt(paramInt);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final IBinder asBinder()
      {
        return this.a;
      }

      public final void b(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.a.a
 * JD-Core Version:    0.6.2
 */