package android.support.v4.media;

import android.media.browse.MediaBrowser.MediaItem;
import android.os.Bundle;
import android.support.v4.media.session.MediaSessionCompat;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

final class b
{
  static
  {
    CoverageLogger.Log(58701824);
  }

  static abstract interface a extends a.c
  {
    static
    {
      CoverageLogger.Log(58699776);
    }

    public abstract void a(String paramString, List<?> paramList, Bundle paramBundle);
  }

  static final class b<T extends b.a> extends a.d<T>
  {
    static
    {
      CoverageLogger.Log(58607616);
    }

    b(T paramT)
    {
      super();
    }

    public final void onChildrenLoaded(String paramString, List<MediaBrowser.MediaItem> paramList, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
      ((b.a)this.a).a(paramString, paramList, paramBundle);
    }

    public final void onError(String paramString, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.b
 * JD-Core Version:    0.6.2
 */