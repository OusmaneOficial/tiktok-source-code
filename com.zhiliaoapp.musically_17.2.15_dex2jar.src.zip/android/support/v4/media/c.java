package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class c
{
  static
  {
    CoverageLogger.Log(58595328);
  }

  public static String a(Object paramObject)
  {
    return ((MediaDescription)paramObject).getMediaId();
  }

  public static CharSequence b(Object paramObject)
  {
    return ((MediaDescription)paramObject).getTitle();
  }

  public static CharSequence c(Object paramObject)
  {
    return ((MediaDescription)paramObject).getSubtitle();
  }

  public static CharSequence d(Object paramObject)
  {
    return ((MediaDescription)paramObject).getDescription();
  }

  public static Bitmap e(Object paramObject)
  {
    return ((MediaDescription)paramObject).getIconBitmap();
  }

  public static Uri f(Object paramObject)
  {
    return ((MediaDescription)paramObject).getIconUri();
  }

  public static Bundle g(Object paramObject)
  {
    return ((MediaDescription)paramObject).getExtras();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.c
 * JD-Core Version:    0.6.2
 */