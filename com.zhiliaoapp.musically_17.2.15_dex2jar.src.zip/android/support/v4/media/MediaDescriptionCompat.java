package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.media.MediaDescription.Builder;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.media.session.MediaSessionCompat;
import android.text.TextUtils;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class MediaDescriptionCompat
  implements Parcelable
{
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new Parcelable.Creator()
  {
    static
    {
      CoverageLogger.Log(58707968);
    }
  };
  public final String a;
  public final CharSequence b;
  public final CharSequence c;
  public final CharSequence d;
  public final Bitmap e;
  public final Uri f;
  public final Bundle g;
  public final Uri h;
  private Object i;

  static
  {
    CoverageLogger.Log(58605568);
  }

  MediaDescriptionCompat(Parcel paramParcel)
  {
    this.a = paramParcel.readString();
    this.b = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.c = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.d = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    ClassLoader localClassLoader = getClass().getClassLoader();
    this.e = ((Bitmap)paramParcel.readParcelable(localClassLoader));
    this.f = ((Uri)paramParcel.readParcelable(localClassLoader));
    this.g = paramParcel.readBundle(localClassLoader);
    this.h = ((Uri)paramParcel.readParcelable(localClassLoader));
  }

  MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2)
  {
    this.a = paramString;
    this.b = paramCharSequence1;
    this.c = paramCharSequence2;
    this.d = paramCharSequence3;
    this.e = paramBitmap;
    this.f = paramUri1;
    this.g = paramBundle;
    this.h = paramUri2;
  }

  public static MediaDescriptionCompat a(Object paramObject)
  {
    MediaDescriptionCompat localMediaDescriptionCompat = null;
    if (paramObject != null)
    {
      int j = Build.VERSION.SDK_INT;
      localMediaDescriptionCompat = null;
      if (j >= 21)
      {
        a locala = new a();
        locala.a(c.a(paramObject));
        locala.a(c.b(paramObject));
        locala.b(c.c(paramObject));
        locala.c(c.d(paramObject));
        locala.a(c.e(paramObject));
        locala.a(c.f(paramObject));
        Bundle localBundle1 = c.g(paramObject);
        Uri localUri;
        if (localBundle1 != null)
        {
          MediaSessionCompat.a(localBundle1);
          localUri = (Uri)localBundle1.getParcelable("android.support.v4.media.description.MEDIA_URI");
        }
        else
        {
          localUri = null;
        }
        Bundle localBundle2;
        if (localUri != null)
        {
          if ((localBundle1.containsKey("android.support.v4.media.description.NULL_BUNDLE_FLAG")) && (localBundle1.size() == 2))
          {
            localBundle2 = null;
          }
          else
          {
            localBundle1.remove("android.support.v4.media.description.MEDIA_URI");
            localBundle1.remove("android.support.v4.media.description.NULL_BUNDLE_FLAG");
          }
        }
        else
          localBundle2 = localBundle1;
        locala.a(localBundle2);
        if (localUri != null)
          locala.b(localUri);
        else if (Build.VERSION.SDK_INT >= 23)
          locala.b(d.a(paramObject));
        localMediaDescriptionCompat = locala.a();
        localMediaDescriptionCompat.i = paramObject;
      }
    }
    return localMediaDescriptionCompat;
  }

  public final int describeContents()
  {
    return 0;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.b);
    localStringBuilder.append(", ");
    localStringBuilder.append(this.c);
    localStringBuilder.append(", ");
    localStringBuilder.append(this.d);
    return localStringBuilder.toString();
  }

  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    if (Build.VERSION.SDK_INT < 21)
    {
      paramParcel.writeString(this.a);
      TextUtils.writeToParcel(this.b, paramParcel, paramInt);
      TextUtils.writeToParcel(this.c, paramParcel, paramInt);
      TextUtils.writeToParcel(this.d, paramParcel, paramInt);
      paramParcel.writeParcelable(this.e, paramInt);
      paramParcel.writeParcelable(this.f, paramInt);
      paramParcel.writeBundle(this.g);
      paramParcel.writeParcelable(this.h, paramInt);
      return;
    }
    Object localObject;
    if ((this.i == null) && (Build.VERSION.SDK_INT >= 21))
    {
      MediaDescription.Builder localBuilder1 = new MediaDescription.Builder();
      String str = this.a;
      MediaDescription.Builder localBuilder2 = (MediaDescription.Builder)localBuilder1;
      localBuilder2.setMediaId(str);
      localBuilder2.setTitle(this.b);
      localBuilder2.setSubtitle(this.c);
      localBuilder2.setDescription(this.d);
      localBuilder2.setIconBitmap(this.e);
      localBuilder2.setIconUri(this.f);
      Bundle localBundle = this.g;
      if ((Build.VERSION.SDK_INT < 23) && (this.h != null))
      {
        if (localBundle == null)
        {
          localBundle = new Bundle();
          localBundle.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
        }
        localBundle.putParcelable("android.support.v4.media.description.MEDIA_URI", this.h);
      }
      localBuilder2.setExtras(localBundle);
      if (Build.VERSION.SDK_INT >= 23)
        localBuilder2.setMediaUri(this.h);
      this.i = localBuilder2.build();
      localObject = this.i;
    }
    else
    {
      localObject = this.i;
    }
    ((MediaDescription)localObject).writeToParcel(paramParcel, paramInt);
  }

  public static final class a
  {
    private String a;
    private CharSequence b;
    private CharSequence c;
    private CharSequence d;
    private Bitmap e;
    private Uri f;
    private Bundle g;
    private Uri h;

    static
    {
      CoverageLogger.Log(58601472);
    }

    public final a a(Bitmap paramBitmap)
    {
      this.e = paramBitmap;
      return this;
    }

    public final a a(Uri paramUri)
    {
      this.f = paramUri;
      return this;
    }

    public final a a(Bundle paramBundle)
    {
      this.g = paramBundle;
      return this;
    }

    public final a a(CharSequence paramCharSequence)
    {
      this.b = paramCharSequence;
      return this;
    }

    public final a a(String paramString)
    {
      this.a = paramString;
      return this;
    }

    public final MediaDescriptionCompat a()
    {
      MediaDescriptionCompat localMediaDescriptionCompat = new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
      return localMediaDescriptionCompat;
    }

    public final a b(Uri paramUri)
    {
      this.h = paramUri;
      return this;
    }

    public final a b(CharSequence paramCharSequence)
    {
      this.c = paramCharSequence;
      return this;
    }

    public final a c(CharSequence paramCharSequence)
    {
      this.d = paramCharSequence;
      return this;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.MediaDescriptionCompat
 * JD-Core Version:    0.6.2
 */