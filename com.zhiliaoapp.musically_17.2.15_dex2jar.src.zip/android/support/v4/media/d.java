package android.support.v4.media;

import android.media.MediaDescription;
import android.net.Uri;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class d
{
  static
  {
    CoverageLogger.Log(58712064);
  }

  public static Uri a(Object paramObject)
  {
    return ((MediaDescription)paramObject).getMediaUri();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.d
 * JD-Core Version:    0.6.2
 */