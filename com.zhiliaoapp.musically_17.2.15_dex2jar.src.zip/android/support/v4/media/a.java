package android.support.v4.media;

import android.media.browse.MediaBrowser;
import android.media.browse.MediaBrowser.ConnectionCallback;
import android.media.browse.MediaBrowser.MediaItem;
import android.media.browse.MediaBrowser.SubscriptionCallback;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

final class a
{
  static
  {
    CoverageLogger.Log(58613760);
  }

  public static Object a(Object paramObject)
  {
    return ((MediaBrowser)paramObject).getSessionToken();
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(58689536);
    }

    public abstract void a();

    public abstract void b();

    public abstract void c();
  }

  static final class b<T extends a.a> extends MediaBrowser.ConnectionCallback
  {
    protected final T a;

    static
    {
      CoverageLogger.Log(58619904);
    }

    public b(T paramT)
    {
      this.a = paramT;
    }

    public final void onConnected()
    {
      this.a.a();
    }

    public final void onConnectionFailed()
    {
      this.a.c();
    }

    public final void onConnectionSuspended()
    {
      this.a.b();
    }
  }

  static abstract interface c
  {
    static
    {
      CoverageLogger.Log(58617856);
    }

    public abstract void a(String paramString, List<?> paramList);
  }

  static class d<T extends a.c> extends MediaBrowser.SubscriptionCallback
  {
    protected final T a;

    static
    {
      CoverageLogger.Log(58691584);
    }

    public d(T paramT)
    {
      this.a = paramT;
    }

    public void onChildrenLoaded(String paramString, List<MediaBrowser.MediaItem> paramList)
    {
      this.a.a(paramString, paramList);
    }

    public void onError(String paramString)
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.a
 * JD-Core Version:    0.6.2
 */