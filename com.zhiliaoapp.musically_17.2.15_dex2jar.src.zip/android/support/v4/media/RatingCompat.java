package android.support.v4.media;

import android.media.Rating;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class RatingCompat
  implements Parcelable
{
  public static final Parcelable.Creator<RatingCompat> CREATOR = new Parcelable.Creator()
  {
    static
    {
      CoverageLogger.Log(58716160);
    }
  };
  public final int a;
  private final float b;
  private Object c;

  static
  {
    CoverageLogger.Log(58587136);
  }

  RatingCompat(int paramInt, float paramFloat)
  {
    this.a = paramInt;
    this.b = paramFloat;
  }

  public static RatingCompat a(Object paramObject)
  {
    Object localObject = null;
    if (paramObject != null)
    {
      int i = Build.VERSION.SDK_INT;
      localObject = null;
      if (i >= 19)
      {
        Rating localRating = (Rating)paramObject;
        int j = localRating.getRatingStyle();
        if (localRating.isRated())
        {
          float f1 = 1.0F;
          RatingCompat localRatingCompat;
          switch (j)
          {
          default:
            return null;
          case 6:
            float f4 = localRating.getPercentRating();
            boolean bool2 = f4 < 0.0F;
            localObject = null;
            if (bool2)
              break label333;
            if (f4 > 100.0F)
              localObject = null;
            else
              localObject = new RatingCompat(6, f4);
            break;
          case 3:
          case 4:
          case 5:
            float f2 = localRating.getStarRating();
            float f3;
            if (j != 3)
            {
              if (j != 4)
              {
                if (j != 5)
                {
                  localObject = null;
                  break label333;
                }
                f3 = 5.0F;
              }
              else
              {
                f3 = 4.0F;
              }
            }
            else
              f3 = 3.0F;
            boolean bool1 = f2 < 0.0F;
            localObject = null;
            if (bool1)
              break label333;
            if (f2 > f3)
              localObject = null;
            else
              localObject = new RatingCompat(j, f2);
            break;
          case 2:
            if (!localRating.isThumbUp())
              f1 = 0.0F;
            localRatingCompat = new RatingCompat(2, f1);
            break;
          case 1:
            if (!localRating.hasHeart())
              f1 = 0.0F;
            localRatingCompat = new RatingCompat(1, f1);
          }
          localObject = localRatingCompat;
        }
        else
        {
          switch (j)
          {
          default:
            localObject = null;
            break;
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
            localObject = new RatingCompat(j, -1.0F);
          }
        }
        label333: ((RatingCompat)localObject).c = paramObject;
      }
    }
    return localObject;
  }

  public final int describeContents()
  {
    return this.a;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("Rating:style=");
    localStringBuilder.append(this.a);
    localStringBuilder.append(" rating=");
    float f = this.b;
    String str;
    if (f < 0.0F)
      str = "unrated";
    else
      str = String.valueOf(f);
    localStringBuilder.append(str);
    return localStringBuilder.toString();
  }

  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.a);
    paramParcel.writeFloat(this.b);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.RatingCompat
 * JD-Core Version:    0.6.2
 */