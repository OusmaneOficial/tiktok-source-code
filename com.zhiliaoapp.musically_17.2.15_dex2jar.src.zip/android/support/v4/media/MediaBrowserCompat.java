package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.media.browse.MediaBrowser;
import android.media.browse.MediaBrowser.ConnectionCallback;
import android.media.browse.MediaBrowser.MediaItem;
import android.os.Binder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import androidx.media.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class MediaBrowserCompat
{
  static final boolean a = Log.isLoggable("MediaBrowserCompat", 3);
  public final d b;

  static
  {
    CoverageLogger.Log(58685440);
  }

  public MediaBrowserCompat(Context paramContext, ComponentName paramComponentName, b paramb, Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 26)
    {
      this.b = new g(paramContext, paramComponentName, paramb, null);
      return;
    }
    if (Build.VERSION.SDK_INT >= 23)
    {
      this.b = new f(paramContext, paramComponentName, paramb, null);
      return;
    }
    if (Build.VERSION.SDK_INT >= 21)
    {
      this.b = new e(paramContext, paramComponentName, paramb, null);
      return;
    }
    this.b = new h(paramContext, paramComponentName, paramb, null);
  }

  public final void a()
  {
    this.b.d();
  }

  static class CustomActionResultReceiver extends ResultReceiver
  {
    private final MediaBrowserCompat.c d;

    static
    {
      CoverageLogger.Log(58669056);
    }

    public final void a(int paramInt, Bundle paramBundle)
    {
      if (this.d == null)
        return;
      MediaSessionCompat.a(paramBundle);
    }
  }

  static class ItemReceiver extends ResultReceiver
  {
    static
    {
      CoverageLogger.Log(58667008);
    }

    public final void a(int paramInt, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
      if ((paramInt == 0) && (paramBundle != null))
      {
        if (!paramBundle.containsKey("media_item"))
          return;
        paramBundle.getParcelable("media_item");
      }
    }
  }

  public static class MediaItem
    implements Parcelable
  {
    public static final Parcelable.Creator<MediaItem> CREATOR = new Parcelable.Creator()
    {
      static
      {
        CoverageLogger.Log(58638336);
      }
    };
    public final int a;
    public final MediaDescriptionCompat b;

    static
    {
      CoverageLogger.Log(58662912);
    }

    MediaItem(Parcel paramParcel)
    {
      this.a = paramParcel.readInt();
      this.b = ((MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel));
    }

    private MediaItem(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt)
    {
      if (paramMediaDescriptionCompat != null)
      {
        if (!TextUtils.isEmpty(paramMediaDescriptionCompat.a))
        {
          this.a = paramInt;
          this.b = paramMediaDescriptionCompat;
          return;
        }
        throw new IllegalArgumentException("description must have a non-empty media id");
      }
      throw new IllegalArgumentException("description cannot be null");
    }

    public static List<MediaItem> a(List<?> paramList)
    {
      if (paramList != null)
      {
        if (Build.VERSION.SDK_INT < 21)
          return null;
        ArrayList localArrayList = new ArrayList(paramList.size());
        Iterator localIterator = paramList.iterator();
        while (localIterator.hasNext())
        {
          Object localObject = localIterator.next();
          MediaItem localMediaItem;
          if ((localObject != null) && (Build.VERSION.SDK_INT >= 21))
          {
            MediaBrowser.MediaItem localMediaItem1 = (MediaBrowser.MediaItem)localObject;
            int i = localMediaItem1.getFlags();
            localMediaItem = new MediaItem(MediaDescriptionCompat.a(localMediaItem1.getDescription()), i);
          }
          else
          {
            localMediaItem = null;
          }
          localArrayList.add(localMediaItem);
        }
        return localArrayList;
      }
      return null;
    }

    public int describeContents()
    {
      return 0;
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("MediaItem{");
      localStringBuilder.append("mFlags=");
      localStringBuilder.append(this.a);
      localStringBuilder.append(", mDescription=");
      localStringBuilder.append(this.b);
      localStringBuilder.append('}');
      return localStringBuilder.toString();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeInt(this.a);
      this.b.writeToParcel(paramParcel, paramInt);
    }
  }

  static class SearchResultReceiver extends ResultReceiver
  {
    static
    {
      CoverageLogger.Log(58675200);
    }

    public final void a(int paramInt, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
      if ((paramInt == 0) && (paramBundle != null))
      {
        if (!paramBundle.containsKey("search_results"))
          return;
        Parcelable[] arrayOfParcelable = paramBundle.getParcelableArray("search_results");
        if (arrayOfParcelable != null)
        {
          ArrayList localArrayList = new ArrayList();
          int i = arrayOfParcelable.length;
          for (int j = 0; j < i; j++)
            localArrayList.add((MediaBrowserCompat.MediaItem)arrayOfParcelable[j]);
        }
      }
    }
  }

  static final class a extends Handler
  {
    private final WeakReference<MediaBrowserCompat.i> a;
    private WeakReference<Messenger> b;

    static
    {
      CoverageLogger.Log(58945536);
    }

    a(MediaBrowserCompat.i parami)
    {
      this.a = new WeakReference(parami);
    }

    final void a(Messenger paramMessenger)
    {
      this.b = new WeakReference(paramMessenger);
    }

    // ERROR //
    public final void handleMessage(Message paramMessage)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 32	android/support/v4/media/MediaBrowserCompat$a:b	Ljava/lang/ref/WeakReference;
      //   4: astore_2
      //   5: aload_2
      //   6: ifnull +198 -> 204
      //   9: aload_2
      //   10: invokevirtual 40	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
      //   13: ifnull +191 -> 204
      //   16: aload_0
      //   17: getfield 29	android/support/v4/media/MediaBrowserCompat$a:a	Ljava/lang/ref/WeakReference;
      //   20: invokevirtual 40	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
      //   23: ifnonnull +4 -> 27
      //   26: return
      //   27: aload_1
      //   28: invokevirtual 46	android/os/Message:getData	()Landroid/os/Bundle;
      //   31: astore_3
      //   32: aload_3
      //   33: invokestatic 51	android/support/v4/media/session/MediaSessionCompat:a	(Landroid/os/Bundle;)V
      //   36: aload_0
      //   37: getfield 29	android/support/v4/media/MediaBrowserCompat$a:a	Ljava/lang/ref/WeakReference;
      //   40: invokevirtual 40	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
      //   43: checkcast 53	android/support/v4/media/MediaBrowserCompat$i
      //   46: astore 4
      //   48: aload_0
      //   49: getfield 32	android/support/v4/media/MediaBrowserCompat$a:b	Ljava/lang/ref/WeakReference;
      //   52: invokevirtual 40	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
      //   55: checkcast 55	android/os/Messenger
      //   58: astore 5
      //   60: aload_1
      //   61: getfield 59	android/os/Message:what	I
      //   64: istore 6
      //   66: iload 6
      //   68: iconst_1
      //   69: if_icmpeq +78 -> 147
      //   72: iload 6
      //   74: iconst_2
      //   75: if_icmpeq +62 -> 137
      //   78: iload 6
      //   80: iconst_3
      //   81: if_icmpeq +4 -> 85
      //   84: return
      //   85: aload_3
      //   86: ldc 61
      //   88: invokevirtual 67	android/os/Bundle:getBundle	(Ljava/lang/String;)Landroid/os/Bundle;
      //   91: astore 8
      //   93: aload 8
      //   95: invokestatic 51	android/support/v4/media/session/MediaSessionCompat:a	(Landroid/os/Bundle;)V
      //   98: aload_3
      //   99: ldc 69
      //   101: invokevirtual 67	android/os/Bundle:getBundle	(Ljava/lang/String;)Landroid/os/Bundle;
      //   104: astore 9
      //   106: aload 9
      //   108: invokestatic 51	android/support/v4/media/session/MediaSessionCompat:a	(Landroid/os/Bundle;)V
      //   111: aload 4
      //   113: aload 5
      //   115: aload_3
      //   116: ldc 71
      //   118: invokevirtual 75	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
      //   121: aload_3
      //   122: ldc 77
      //   124: invokevirtual 81	android/os/Bundle:getParcelableArrayList	(Ljava/lang/String;)Ljava/util/ArrayList;
      //   127: aload 8
      //   129: aload 9
      //   131: invokeinterface 84 6 0
      //   136: return
      //   137: aload 4
      //   139: aload 5
      //   141: invokeinterface 86 2 0
      //   146: return
      //   147: aload_3
      //   148: ldc 88
      //   150: invokevirtual 67	android/os/Bundle:getBundle	(Ljava/lang/String;)Landroid/os/Bundle;
      //   153: astore 7
      //   155: aload 7
      //   157: invokestatic 51	android/support/v4/media/session/MediaSessionCompat:a	(Landroid/os/Bundle;)V
      //   160: aload 4
      //   162: aload 5
      //   164: aload_3
      //   165: ldc 71
      //   167: invokevirtual 75	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
      //   170: aload_3
      //   171: ldc 90
      //   173: invokevirtual 94	android/os/Bundle:getParcelable	(Ljava/lang/String;)Landroid/os/Parcelable;
      //   176: checkcast 96	android/support/v4/media/session/MediaSessionCompat$Token
      //   179: aload 7
      //   181: invokeinterface 99 5 0
      //   186: return
      //   187: aload_1
      //   188: getfield 59	android/os/Message:what	I
      //   191: iconst_1
      //   192: if_icmpne +12 -> 204
      //   195: aload 4
      //   197: aload 5
      //   199: invokeinterface 86 2 0
      //   204: return
      //
      // Exception table:
      //   from	to	target	type
      //   60	66	187	android/os/BadParcelableException
      //   85	136	187	android/os/BadParcelableException
      //   137	146	187	android/os/BadParcelableException
      //   147	186	187	android/os/BadParcelableException
    }
  }

  public static class b
  {
    final Object a;
    public a b;

    static
    {
      CoverageLogger.Log(58673152);
    }

    public b()
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        this.a = new a.b(new b());
        return;
      }
      this.a = null;
    }

    public void a()
    {
    }

    public void b()
    {
    }

    public void c()
    {
    }

    static abstract interface a
    {
      static
      {
        CoverageLogger.Log(58949632);
      }

      public abstract void a();

      public abstract void b();
    }

    final class b
      implements a.a
    {
      static
      {
        CoverageLogger.Log(58953728);
      }

      b()
      {
      }

      public final void a()
      {
        if (MediaBrowserCompat.b.this.b != null)
          MediaBrowserCompat.b.this.b.a();
        MediaBrowserCompat.b.this.a();
      }

      public final void b()
      {
        if (MediaBrowserCompat.b.this.b != null)
          MediaBrowserCompat.b.this.b.b();
        MediaBrowserCompat.b.this.b();
      }

      public final void c()
      {
        MediaBrowserCompat.b.this.c();
      }
    }
  }

  public static abstract class c
  {
    static
    {
      CoverageLogger.Log(58671104);
    }
  }

  public static abstract interface d
  {
    static
    {
      CoverageLogger.Log(58664960);
    }

    public abstract void c();

    public abstract void d();

    public abstract MediaSessionCompat.Token e();
  }

  static class e
    implements MediaBrowserCompat.b.a, MediaBrowserCompat.d, MediaBrowserCompat.i
  {
    final Context a;
    protected final Object b;
    protected final Bundle c;
    protected final MediaBrowserCompat.a d = new MediaBrowserCompat.a(this);
    protected int e;
    protected MediaBrowserCompat.j f;
    protected Messenger g;
    private final androidx.c.a<String, MediaBrowserCompat.k> h = new androidx.c.a();
    private MediaSessionCompat.Token i;
    private Bundle j;

    static
    {
      CoverageLogger.Log(58959872);
    }

    e(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.b paramb, Bundle paramBundle)
    {
      this.a = paramContext;
      Bundle localBundle1;
      if (paramBundle != null)
        localBundle1 = new Bundle(paramBundle);
      else
        localBundle1.<init>();
      this.c = localBundle1;
      this.c.putInt("extra_client_version", 1);
      paramb.b = this;
      Object localObject = paramb.a;
      Bundle localBundle2 = this.c;
      this.b = new MediaBrowser(paramContext, paramComponentName, (MediaBrowser.ConnectionCallback)localObject, localBundle2);
    }

    // ERROR //
    public final void a()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 87	android/support/v4/media/MediaBrowserCompat$e:b	Ljava/lang/Object;
      //   4: checkcast 80	android/media/browse/MediaBrowser
      //   7: invokevirtual 93	android/media/browse/MediaBrowser:getExtras	()Landroid/os/Bundle;
      //   10: astore_1
      //   11: aload_1
      //   12: ifnonnull +4 -> 16
      //   15: return
      //   16: aload_0
      //   17: aload_1
      //   18: ldc 95
      //   20: iconst_0
      //   21: invokevirtual 99	android/os/Bundle:getInt	(Ljava/lang/String;I)I
      //   24: putfield 101	android/support/v4/media/MediaBrowserCompat$e:e	I
      //   27: aload_1
      //   28: ldc 103
      //   30: invokestatic 108	androidx/core/app/d:a	(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/IBinder;
      //   33: astore_2
      //   34: aload_2
      //   35: ifnull +110 -> 145
      //   38: aload_0
      //   39: new 110	android/support/v4/media/MediaBrowserCompat$j
      //   42: dup
      //   43: aload_2
      //   44: aload_0
      //   45: getfield 65	android/support/v4/media/MediaBrowserCompat$e:c	Landroid/os/Bundle;
      //   48: invokespecial 113	android/support/v4/media/MediaBrowserCompat$j:<init>	(Landroid/os/IBinder;Landroid/os/Bundle;)V
      //   51: putfield 115	android/support/v4/media/MediaBrowserCompat$e:f	Landroid/support/v4/media/MediaBrowserCompat$j;
      //   54: aload_0
      //   55: new 117	android/os/Messenger
      //   58: dup
      //   59: aload_0
      //   60: getfield 50	android/support/v4/media/MediaBrowserCompat$e:d	Landroid/support/v4/media/MediaBrowserCompat$a;
      //   63: invokespecial 120	android/os/Messenger:<init>	(Landroid/os/Handler;)V
      //   66: putfield 122	android/support/v4/media/MediaBrowserCompat$e:g	Landroid/os/Messenger;
      //   69: aload_0
      //   70: getfield 50	android/support/v4/media/MediaBrowserCompat$e:d	Landroid/support/v4/media/MediaBrowserCompat$a;
      //   73: aload_0
      //   74: getfield 122	android/support/v4/media/MediaBrowserCompat$e:g	Landroid/os/Messenger;
      //   77: invokevirtual 125	android/support/v4/media/MediaBrowserCompat$a:a	(Landroid/os/Messenger;)V
      //   80: aload_0
      //   81: getfield 115	android/support/v4/media/MediaBrowserCompat$e:f	Landroid/support/v4/media/MediaBrowserCompat$j;
      //   84: astore 4
      //   86: aload_0
      //   87: getfield 57	android/support/v4/media/MediaBrowserCompat$e:a	Landroid/content/Context;
      //   90: astore 5
      //   92: aload_0
      //   93: getfield 122	android/support/v4/media/MediaBrowserCompat$e:g	Landroid/os/Messenger;
      //   96: astore 6
      //   98: new 59	android/os/Bundle
      //   101: dup
      //   102: invokespecial 63	android/os/Bundle:<init>	()V
      //   105: astore 7
      //   107: aload 7
      //   109: ldc 127
      //   111: aload 5
      //   113: invokevirtual 133	android/content/Context:getPackageName	()Ljava/lang/String;
      //   116: invokevirtual 137	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
      //   119: aload 7
      //   121: ldc 139
      //   123: aload 4
      //   125: getfield 141	android/support/v4/media/MediaBrowserCompat$j:a	Landroid/os/Bundle;
      //   128: invokevirtual 145	android/os/Bundle:putBundle	(Ljava/lang/String;Landroid/os/Bundle;)V
      //   131: aload 4
      //   133: bipush 6
      //   135: aload 7
      //   137: aload 6
      //   139: invokevirtual 148	android/support/v4/media/MediaBrowserCompat$j:a	(ILandroid/os/Bundle;Landroid/os/Messenger;)V
      //   142: goto +3 -> 145
      //   145: aload_1
      //   146: ldc 150
      //   148: invokestatic 108	androidx/core/app/d:a	(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/IBinder;
      //   151: invokestatic 155	android/support/v4/media/session/b$a:a	(Landroid/os/IBinder;)Landroid/support/v4/media/session/b;
      //   154: astore_3
      //   155: aload_3
      //   156: ifnull +18 -> 174
      //   159: aload_0
      //   160: aload_0
      //   161: getfield 87	android/support/v4/media/MediaBrowserCompat$e:b	Ljava/lang/Object;
      //   164: invokestatic 160	android/support/v4/media/a:a	(Ljava/lang/Object;)Ljava/lang/Object;
      //   167: aload_3
      //   168: invokestatic 165	android/support/v4/media/session/MediaSessionCompat$Token:a	(Ljava/lang/Object;Landroid/support/v4/media/session/b;)Landroid/support/v4/media/session/MediaSessionCompat$Token;
      //   171: putfield 167	android/support/v4/media/MediaBrowserCompat$e:i	Landroid/support/v4/media/session/MediaSessionCompat$Token;
      //   174: return
      //
      // Exception table:
      //   from	to	target	type
      //   80	142	145	android/os/RemoteException
    }

    public final void a(Messenger paramMessenger)
    {
    }

    public final void a(Messenger paramMessenger, String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
    {
    }

    public final void a(Messenger paramMessenger, String paramString, List paramList, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (this.g != paramMessenger)
        return;
      MediaBrowserCompat.k localk = (MediaBrowserCompat.k)this.h.get(paramString);
      if (localk == null)
        return;
      if (localk.a(paramBundle1) != null)
        if (paramBundle1 == null)
        {
          if (paramList != null)
          {
            this.j = paramBundle2;
            this.j = null;
          }
        }
        else if (paramList != null)
        {
          this.j = paramBundle2;
          this.j = null;
        }
    }

    public final void b()
    {
      this.f = null;
      this.g = null;
      this.i = null;
      this.d.a(null);
    }

    public final void c()
    {
      ((MediaBrowser)this.b).connect();
    }

    public final void d()
    {
      MediaBrowserCompat.j localj = this.f;
      Messenger localMessenger;
      if (localj != null)
      {
        localMessenger = this.g;
        if (localMessenger == null);
      }
      try
      {
        localj.a(7, null, localMessenger);
      }
      catch (RemoteException localRemoteException)
      {
      }
      ((MediaBrowser)this.b).disconnect();
    }

    public final MediaSessionCompat.Token e()
    {
      if (this.i == null)
        this.i = MediaSessionCompat.Token.a(a.a(this.b), null);
      return this.i;
    }
  }

  static class f extends MediaBrowserCompat.e
  {
    static
    {
      CoverageLogger.Log(58963968);
    }

    f(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.b paramb, Bundle paramBundle)
    {
      super(paramComponentName, paramb, paramBundle);
    }
  }

  static final class g extends MediaBrowserCompat.f
  {
    static
    {
      CoverageLogger.Log(58660864);
    }

    g(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.b paramb, Bundle paramBundle)
    {
      super(paramComponentName, paramb, paramBundle);
    }
  }

  static final class h
    implements MediaBrowserCompat.d, MediaBrowserCompat.i
  {
    final Context a;
    final ComponentName b;
    final MediaBrowserCompat.b c;
    final Bundle d;
    final MediaBrowserCompat.a e = new MediaBrowserCompat.a(this);
    int f = 1;
    a g;
    MediaBrowserCompat.j h;
    Messenger i;
    private final androidx.c.a<String, MediaBrowserCompat.k> j = new androidx.c.a();
    private String k;
    private MediaSessionCompat.Token l;
    private Bundle m;
    private Bundle n;

    static
    {
      CoverageLogger.Log(58648576);
    }

    public h(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.b paramb, Bundle paramBundle)
    {
      if (paramContext != null)
      {
        if (paramComponentName != null)
        {
          if (paramb != null)
          {
            this.a = paramContext;
            this.b = paramComponentName;
            this.c = paramb;
            Bundle localBundle;
            if (paramBundle == null)
              localBundle = null;
            else
              localBundle = new Bundle(paramBundle);
            this.d = localBundle;
            return;
          }
          throw new IllegalArgumentException("connection callback must not be null");
        }
        throw new IllegalArgumentException("service component must not be null");
      }
      throw new IllegalArgumentException("context must not be null");
    }

    private boolean a(Messenger paramMessenger, String paramString)
    {
      if (this.i == paramMessenger)
      {
        int i1 = this.f;
        if ((i1 != 0) && (i1 != 1))
          return true;
      }
      return false;
    }

    final void a()
    {
      a locala = this.g;
      if (locala != null)
        this.a.unbindService(locala);
      this.f = 1;
      this.g = null;
      this.h = null;
      this.i = null;
      this.e.a(null);
      this.k = null;
      this.l = null;
    }

    public final void a(Messenger paramMessenger)
    {
      if (!a(paramMessenger, "onConnectFailed"))
        return;
      if (this.f != 2)
        return;
      a();
      this.c.c();
    }

    // ERROR //
    public final void a(Messenger paramMessenger, String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
    {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: ldc 121
      //   4: invokespecial 110	android/support/v4/media/MediaBrowserCompat$h:a	(Landroid/os/Messenger;Ljava/lang/String;)Z
      //   7: ifne +4 -> 11
      //   10: return
      //   11: aload_0
      //   12: getfield 62	android/support/v4/media/MediaBrowserCompat$h:f	I
      //   15: iconst_2
      //   16: if_icmpeq +4 -> 20
      //   19: return
      //   20: aload_0
      //   21: aload_2
      //   22: putfield 104	android/support/v4/media/MediaBrowserCompat$h:k	Ljava/lang/String;
      //   25: aload_0
      //   26: aload_3
      //   27: putfield 106	android/support/v4/media/MediaBrowserCompat$h:l	Landroid/support/v4/media/session/MediaSessionCompat$Token;
      //   30: aload_0
      //   31: aload 4
      //   33: putfield 123	android/support/v4/media/MediaBrowserCompat$h:m	Landroid/os/Bundle;
      //   36: aload_0
      //   37: iconst_3
      //   38: putfield 62	android/support/v4/media/MediaBrowserCompat$h:f	I
      //   41: aload_0
      //   42: getfield 68	android/support/v4/media/MediaBrowserCompat$h:c	Landroid/support/v4/media/MediaBrowserCompat$b;
      //   45: invokevirtual 124	android/support/v4/media/MediaBrowserCompat$b:a	()V
      //   48: aload_0
      //   49: getfield 60	android/support/v4/media/MediaBrowserCompat$h:j	Landroidx/c/a;
      //   52: invokevirtual 128	androidx/c/a:entrySet	()Ljava/util/Set;
      //   55: invokeinterface 134 1 0
      //   60: astore 5
      //   62: aload 5
      //   64: invokeinterface 140 1 0
      //   69: ifeq +163 -> 232
      //   72: aload 5
      //   74: invokeinterface 144 1 0
      //   79: checkcast 146	java/util/Map$Entry
      //   82: astore 6
      //   84: aload 6
      //   86: invokeinterface 149 1 0
      //   91: checkcast 151	java/lang/String
      //   94: astore 7
      //   96: aload 6
      //   98: invokeinterface 154 1 0
      //   103: checkcast 156	android/support/v4/media/MediaBrowserCompat$k
      //   106: astore 8
      //   108: aload 8
      //   110: getfield 159	android/support/v4/media/MediaBrowserCompat$k:a	Ljava/util/List;
      //   113: astore 9
      //   115: aload 8
      //   117: getfield 161	android/support/v4/media/MediaBrowserCompat$k:b	Ljava/util/List;
      //   120: astore 10
      //   122: iconst_0
      //   123: istore 11
      //   125: iload 11
      //   127: aload 9
      //   129: invokeinterface 167 1 0
      //   134: if_icmpge -72 -> 62
      //   137: aload_0
      //   138: getfield 99	android/support/v4/media/MediaBrowserCompat$h:h	Landroid/support/v4/media/MediaBrowserCompat$j;
      //   141: astore 12
      //   143: aload 9
      //   145: iload 11
      //   147: invokeinterface 171 2 0
      //   152: checkcast 173	android/support/v4/media/MediaBrowserCompat$l
      //   155: getfield 176	android/support/v4/media/MediaBrowserCompat$l:b	Landroid/os/IBinder;
      //   158: astore 13
      //   160: aload 10
      //   162: iload 11
      //   164: invokeinterface 171 2 0
      //   169: checkcast 70	android/os/Bundle
      //   172: astore 14
      //   174: aload_0
      //   175: getfield 89	android/support/v4/media/MediaBrowserCompat$h:i	Landroid/os/Messenger;
      //   178: astore 15
      //   180: new 70	android/os/Bundle
      //   183: dup
      //   184: invokespecial 177	android/os/Bundle:<init>	()V
      //   187: astore 16
      //   189: aload 16
      //   191: ldc 179
      //   193: aload 7
      //   195: invokevirtual 183	android/os/Bundle:putString	(Ljava/lang/String;Ljava/lang/String;)V
      //   198: aload 16
      //   200: ldc 185
      //   202: aload 13
      //   204: invokestatic 190	androidx/core/app/d:a	(Landroid/os/Bundle;Ljava/lang/String;Landroid/os/IBinder;)V
      //   207: aload 16
      //   209: ldc 192
      //   211: aload 14
      //   213: invokevirtual 196	android/os/Bundle:putBundle	(Ljava/lang/String;Landroid/os/Bundle;)V
      //   216: aload 12
      //   218: iconst_3
      //   219: aload 16
      //   221: aload 15
      //   223: invokevirtual 201	android/support/v4/media/MediaBrowserCompat$j:a	(ILandroid/os/Bundle;Landroid/os/Messenger;)V
      //   226: iinc 11 1
      //   229: goto -104 -> 125
      //   232: return
      //
      // Exception table:
      //   from	to	target	type
      //   48	62	232	android/os/RemoteException
      //   62	122	232	android/os/RemoteException
      //   125	226	232	android/os/RemoteException
    }

    public final void a(Messenger paramMessenger, String paramString, List paramList, Bundle paramBundle1, Bundle paramBundle2)
    {
      if (!a(paramMessenger, "onLoadChildren"))
        return;
      MediaBrowserCompat.k localk = (MediaBrowserCompat.k)this.j.get(paramString);
      if (localk == null)
        return;
      if (localk.a(paramBundle1) != null)
        if (paramBundle1 == null)
        {
          if (paramList != null)
          {
            this.n = paramBundle2;
            this.n = null;
          }
        }
        else if (paramList != null)
        {
          this.n = paramBundle2;
          this.n = null;
        }
    }

    public final void c()
    {
      int i1 = this.f;
      if ((i1 != 0) && (i1 != 1))
      {
        StringBuilder localStringBuilder1 = new StringBuilder("connect() called while neigther disconnecting nor disconnected (state=");
        int i2 = this.f;
        String str;
        if (i2 != 0)
        {
          if (i2 != 1)
          {
            if (i2 != 2)
            {
              if (i2 != 3)
              {
                if (i2 != 4)
                {
                  StringBuilder localStringBuilder2 = new StringBuilder("UNKNOWN/");
                  localStringBuilder2.append(i2);
                  str = localStringBuilder2.toString();
                }
                else
                {
                  str = "CONNECT_STATE_SUSPENDED";
                }
              }
              else
                str = "CONNECT_STATE_CONNECTED";
            }
            else
              str = "CONNECT_STATE_CONNECTING";
          }
          else
            str = "CONNECT_STATE_DISCONNECTED";
        }
        else
          str = "CONNECT_STATE_DISCONNECTING";
        localStringBuilder1.append(str);
        localStringBuilder1.append(")");
        throw new IllegalStateException(localStringBuilder1.toString());
      }
      this.f = 2;
      this.e.post(new Runnable()
      {
        static
        {
          CoverageLogger.Log(58658816);
        }

        // ERROR //
        public final void run()
        {
          // Byte code:
          //   0: aload_0
          //   1: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   4: getfield 34	android/support/v4/media/MediaBrowserCompat$h:f	I
          //   7: ifne +4 -> 11
          //   10: return
          //   11: aload_0
          //   12: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   15: iconst_2
          //   16: putfield 34	android/support/v4/media/MediaBrowserCompat$h:f	I
          //   19: getstatic 39	android/support/v4/media/MediaBrowserCompat:a	Z
          //   22: ifeq +53 -> 75
          //   25: aload_0
          //   26: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   29: getfield 43	android/support/v4/media/MediaBrowserCompat$h:g	Landroid/support/v4/media/MediaBrowserCompat$h$a;
          //   32: ifnonnull +6 -> 38
          //   35: goto +40 -> 75
          //   38: new 45	java/lang/StringBuilder
          //   41: dup
          //   42: ldc 47
          //   44: invokespecial 50	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
          //   47: astore 12
          //   49: aload 12
          //   51: aload_0
          //   52: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   55: getfield 43	android/support/v4/media/MediaBrowserCompat$h:g	Landroid/support/v4/media/MediaBrowserCompat$h$a;
          //   58: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
          //   61: pop
          //   62: new 56	java/lang/RuntimeException
          //   65: dup
          //   66: aload 12
          //   68: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
          //   71: invokespecial 61	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
          //   74: athrow
          //   75: aload_0
          //   76: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   79: getfield 65	android/support/v4/media/MediaBrowserCompat$h:h	Landroid/support/v4/media/MediaBrowserCompat$j;
          //   82: ifnonnull +185 -> 267
          //   85: aload_0
          //   86: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   89: getfield 69	android/support/v4/media/MediaBrowserCompat$h:i	Landroid/os/Messenger;
          //   92: ifnonnull +138 -> 230
          //   95: new 71	android/content/Intent
          //   98: dup
          //   99: ldc 73
          //   101: invokespecial 74	android/content/Intent:<init>	(Ljava/lang/String;)V
          //   104: astore_3
          //   105: aload_3
          //   106: aload_0
          //   107: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   110: getfield 78	android/support/v4/media/MediaBrowserCompat$h:b	Landroid/content/ComponentName;
          //   113: invokevirtual 82	android/content/Intent:setComponent	(Landroid/content/ComponentName;)Landroid/content/Intent;
          //   116: pop
          //   117: aload_0
          //   118: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   121: astore 5
          //   123: aload 5
          //   125: new 84	android/support/v4/media/MediaBrowserCompat$h$a
          //   128: dup
          //   129: aload 5
          //   131: invokespecial 86	android/support/v4/media/MediaBrowserCompat$h$a:<init>	(Landroid/support/v4/media/MediaBrowserCompat$h;)V
          //   134: putfield 43	android/support/v4/media/MediaBrowserCompat$h:g	Landroid/support/v4/media/MediaBrowserCompat$h$a;
          //   137: iconst_0
          //   138: istore 6
          //   140: aload_0
          //   141: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   144: getfield 89	android/support/v4/media/MediaBrowserCompat$h:a	Landroid/content/Context;
          //   147: astore 7
          //   149: aload_0
          //   150: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   153: getfield 43	android/support/v4/media/MediaBrowserCompat$h:g	Landroid/support/v4/media/MediaBrowserCompat$h$a;
          //   156: astore 8
          //   158: aload 7
          //   160: ifnull +29 -> 189
          //   163: aload 7
          //   165: instanceof 91
          //   168: ifeq +21 -> 189
          //   171: aload 7
          //   173: checkcast 91	android/content/Context
          //   176: aload_3
          //   177: invokestatic 96	com/ss/android/ugc/aweme/push/downgrade/d:a	(Landroid/content/Context;Landroid/content/Intent;)Z
          //   180: ifeq +9 -> 189
          //   183: iconst_1
          //   184: istore 6
          //   186: goto +21 -> 207
          //   189: aload 7
          //   191: aload_3
          //   192: aload 8
          //   194: iconst_1
          //   195: invokevirtual 100	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
          //   198: istore 9
          //   200: iload 9
          //   202: istore 6
          //   204: goto +3 -> 207
          //   207: iload 6
          //   209: ifne +20 -> 229
          //   212: aload_0
          //   213: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   216: invokevirtual 102	android/support/v4/media/MediaBrowserCompat$h:a	()V
          //   219: aload_0
          //   220: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   223: getfield 105	android/support/v4/media/MediaBrowserCompat$h:c	Landroid/support/v4/media/MediaBrowserCompat$b;
          //   226: invokevirtual 108	android/support/v4/media/MediaBrowserCompat$b:c	()V
          //   229: return
          //   230: new 45	java/lang/StringBuilder
          //   233: dup
          //   234: ldc 110
          //   236: invokespecial 50	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
          //   239: astore 10
          //   241: aload 10
          //   243: aload_0
          //   244: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   247: getfield 69	android/support/v4/media/MediaBrowserCompat$h:i	Landroid/os/Messenger;
          //   250: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
          //   253: pop
          //   254: new 56	java/lang/RuntimeException
          //   257: dup
          //   258: aload 10
          //   260: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
          //   263: invokespecial 61	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
          //   266: athrow
          //   267: new 45	java/lang/StringBuilder
          //   270: dup
          //   271: ldc 112
          //   273: invokespecial 50	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
          //   276: astore_1
          //   277: aload_1
          //   278: aload_0
          //   279: getfield 25	android/support/v4/media/MediaBrowserCompat$h$1:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   282: getfield 65	android/support/v4/media/MediaBrowserCompat$h:h	Landroid/support/v4/media/MediaBrowserCompat$j;
          //   285: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
          //   288: pop
          //   289: new 56	java/lang/RuntimeException
          //   292: dup
          //   293: aload_1
          //   294: invokevirtual 60	java/lang/StringBuilder:toString	()Ljava/lang/String;
          //   297: invokespecial 61	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
          //   300: athrow
          //
          // Exception table:
          //   from	to	target	type
          //   140	158	207	java/lang/Exception
          //   163	183	207	java/lang/Exception
          //   189	200	207	java/lang/Exception
        }
      });
    }

    public final void d()
    {
      this.f = 0;
      this.e.post(new Runnable()
      {
        static
        {
          CoverageLogger.Log(58652672);
        }

        // ERROR //
        public final void run()
        {
          // Byte code:
          //   0: aload_0
          //   1: getfield 25	android/support/v4/media/MediaBrowserCompat$h$2:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   4: getfield 34	android/support/v4/media/MediaBrowserCompat$h:i	Landroid/os/Messenger;
          //   7: ifnull +25 -> 32
          //   10: aload_0
          //   11: getfield 25	android/support/v4/media/MediaBrowserCompat$h$2:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   14: getfield 38	android/support/v4/media/MediaBrowserCompat$h:h	Landroid/support/v4/media/MediaBrowserCompat$j;
          //   17: iconst_2
          //   18: aconst_null
          //   19: aload_0
          //   20: getfield 25	android/support/v4/media/MediaBrowserCompat$h$2:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   23: getfield 34	android/support/v4/media/MediaBrowserCompat$h:i	Landroid/os/Messenger;
          //   26: invokevirtual 43	android/support/v4/media/MediaBrowserCompat$j:a	(ILandroid/os/Bundle;Landroid/os/Messenger;)V
          //   29: goto +3 -> 32
          //   32: aload_0
          //   33: getfield 25	android/support/v4/media/MediaBrowserCompat$h$2:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   36: getfield 47	android/support/v4/media/MediaBrowserCompat$h:f	I
          //   39: istore_1
          //   40: aload_0
          //   41: getfield 25	android/support/v4/media/MediaBrowserCompat$h$2:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   44: invokevirtual 49	android/support/v4/media/MediaBrowserCompat$h:a	()V
          //   47: iload_1
          //   48: ifeq +11 -> 59
          //   51: aload_0
          //   52: getfield 25	android/support/v4/media/MediaBrowserCompat$h$2:a	Landroid/support/v4/media/MediaBrowserCompat$h;
          //   55: iload_1
          //   56: putfield 47	android/support/v4/media/MediaBrowserCompat$h:f	I
          //   59: return
          //
          // Exception table:
          //   from	to	target	type
          //   10	29	32	android/os/RemoteException
        }
      });
    }

    public final MediaSessionCompat.Token e()
    {
      int i1;
      if (this.f == 3)
        i1 = 1;
      else
        i1 = 0;
      if (i1 != 0)
        return this.l;
      StringBuilder localStringBuilder = new StringBuilder("getSessionToken() called while not connected(state=");
      localStringBuilder.append(this.f);
      localStringBuilder.append(")");
      throw new IllegalStateException(localStringBuilder.toString());
    }

    final class a
      implements ServiceConnection
    {
      static
      {
        CoverageLogger.Log(58654720);
      }

      a()
      {
      }

      private void a(Runnable paramRunnable)
      {
        if (Thread.currentThread() == MediaBrowserCompat.h.this.e.getLooper().getThread())
        {
          paramRunnable.run();
          return;
        }
        MediaBrowserCompat.h.this.e.post(paramRunnable);
      }

      final boolean a(String paramString)
      {
        return (MediaBrowserCompat.h.this.g == this) && (MediaBrowserCompat.h.this.f != 0) && (MediaBrowserCompat.h.this.f != 1);
      }

      public final void onServiceConnected(final ComponentName paramComponentName, final IBinder paramIBinder)
      {
        a(new Runnable()
        {
          static
          {
            CoverageLogger.Log(58966016);
          }

          public final void run()
          {
            if (!MediaBrowserCompat.h.a.this.a("onServiceConnected"))
              return;
            MediaBrowserCompat.h.this.h = new MediaBrowserCompat.j(paramIBinder, MediaBrowserCompat.h.this.d);
            MediaBrowserCompat.h.this.i = new Messenger(MediaBrowserCompat.h.this.e);
            MediaBrowserCompat.h.this.e.a(MediaBrowserCompat.h.this.i);
            MediaBrowserCompat.h.this.f = 2;
            try
            {
              MediaBrowserCompat.j localj = MediaBrowserCompat.h.this.h;
              Context localContext = MediaBrowserCompat.h.this.a;
              Messenger localMessenger = MediaBrowserCompat.h.this.i;
              Bundle localBundle = new Bundle();
              localBundle.putString("data_package_name", localContext.getPackageName());
              localBundle.putBundle("data_root_hints", localj.a);
              localj.a(1, localBundle, localMessenger);
            }
            catch (RemoteException localRemoteException)
            {
            }
          }
        });
      }

      public final void onServiceDisconnected(final ComponentName paramComponentName)
      {
        a(new Runnable()
        {
          static
          {
            CoverageLogger.Log(58646528);
          }

          public final void run()
          {
            if (!MediaBrowserCompat.h.a.this.a("onServiceDisconnected"))
              return;
            MediaBrowserCompat.h.this.h = null;
            MediaBrowserCompat.h.this.i = null;
            MediaBrowserCompat.h.this.e.a(null);
            MediaBrowserCompat.h.this.f = 4;
            MediaBrowserCompat.h.this.c.b();
          }
        });
      }
    }
  }

  static abstract interface i
  {
    static
    {
      CoverageLogger.Log(58656768);
    }

    public abstract void a(Messenger paramMessenger);

    public abstract void a(Messenger paramMessenger, String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle);

    public abstract void a(Messenger paramMessenger, String paramString, List paramList, Bundle paramBundle1, Bundle paramBundle2);
  }

  static final class j
  {
    Bundle a;
    private Messenger b;

    static
    {
      CoverageLogger.Log(58632192);
    }

    public j(IBinder paramIBinder, Bundle paramBundle)
    {
      this.b = new Messenger(paramIBinder);
      this.a = paramBundle;
    }

    void a(int paramInt, Bundle paramBundle, Messenger paramMessenger)
      throws RemoteException
    {
      Message localMessage = Message.obtain();
      localMessage.what = paramInt;
      localMessage.arg1 = 1;
      localMessage.setData(paramBundle);
      localMessage.replyTo = paramMessenger;
      this.b.send(localMessage);
    }
  }

  static final class k
  {
    public final List<MediaBrowserCompat.l> a = new ArrayList();
    public final List<Bundle> b = new ArrayList();

    static
    {
      CoverageLogger.Log(58677248);
    }

    public final MediaBrowserCompat.l a(Bundle paramBundle)
    {
      for (int i = 0; i < this.b.size(); i++)
        if (d.a((Bundle)this.b.get(i), paramBundle))
          return (MediaBrowserCompat.l)this.a.get(i);
      return null;
    }
  }

  public static abstract class l
  {
    final Object a;
    final IBinder b = new Binder();
    WeakReference<MediaBrowserCompat.k> c;

    static
    {
      CoverageLogger.Log(58681344);
    }

    public l()
    {
      if (Build.VERSION.SDK_INT >= 26)
      {
        this.a = new b.b(new b());
        return;
      }
      if (Build.VERSION.SDK_INT >= 21)
      {
        this.a = new a.d(new a());
        return;
      }
      this.a = null;
    }

    class a
      implements a.c
    {
      static
      {
        CoverageLogger.Log(58630144);
      }

      a()
      {
      }

      public final void a(String paramString, List<?> paramList)
      {
        MediaBrowserCompat.k localk;
        if (MediaBrowserCompat.l.this.c == null)
          localk = null;
        else
          localk = (MediaBrowserCompat.k)MediaBrowserCompat.l.this.c.get();
        if (localk == null)
        {
          MediaBrowserCompat.MediaItem.a(paramList);
          return;
        }
        List localList1 = MediaBrowserCompat.MediaItem.a(paramList);
        List localList2 = localk.a;
        List localList3 = localk.b;
        for (int i = 0; i < localList2.size(); i++)
        {
          Bundle localBundle = (Bundle)localList3.get(i);
          if ((localBundle != null) && (localList1 != null))
          {
            int j = localBundle.getInt("android.media.browse.extra.PAGE", -1);
            int k = localBundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
            if ((j != -1) || (k != -1))
            {
              int m = k * j;
              int n = m + k;
              if ((j >= 0) && (k > 0) && (m < localList1.size()))
              {
                if (n > localList1.size())
                  n = localList1.size();
                localList1.subList(m, n);
              }
              else
              {
                Collections.emptyList();
              }
            }
          }
        }
      }
    }

    final class b extends MediaBrowserCompat.l.a
      implements b.a
    {
      static
      {
        CoverageLogger.Log(58626048);
      }

      b()
      {
        super();
      }

      public final void a(String paramString, List<?> paramList, Bundle paramBundle)
      {
        MediaBrowserCompat.MediaItem.a(paramList);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.MediaBrowserCompat
 * JD-Core Version:    0.6.2
 */