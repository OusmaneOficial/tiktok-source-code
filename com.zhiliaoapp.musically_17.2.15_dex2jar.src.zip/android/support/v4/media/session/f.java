package android.support.v4.media.session;

import android.net.Uri;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class f
{
  static
  {
    CoverageLogger.Log(58501120);
  }

  // ERROR //
  public static String a(Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: checkcast 23	android/media/session/MediaSession
    //   4: astore_1
    //   5: aload_1
    //   6: invokevirtual 27	java/lang/Object:getClass	()Ljava/lang/Class;
    //   9: ldc 29
    //   11: iconst_0
    //   12: anewarray 31	java/lang/Class
    //   15: invokevirtual 35	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   18: aload_1
    //   19: iconst_0
    //   20: anewarray 4	java/lang/Object
    //   23: invokevirtual 41	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   26: checkcast 43	java/lang/String
    //   29: astore_2
    //   30: aload_2
    //   31: areturn
    //   32: aconst_null
    //   33: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   5	30	32	java/lang/NoSuchMethodException
    //   5	30	32	java/lang/reflect/InvocationTargetException
    //   5	30	32	java/lang/IllegalAccessException
  }

  public static abstract interface a extends e.a
  {
    static
    {
      CoverageLogger.Log(58492928);
    }
  }

  static final class b<T extends f.a> extends e.b<T>
  {
    static
    {
      CoverageLogger.Log(58499072);
    }

    public b(T paramT)
    {
      super();
    }

    public final void onPrepare()
    {
    }

    public final void onPrepareFromMediaId(String paramString, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
    }

    public final void onPrepareFromSearch(String paramString, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
    }

    public final void onPrepareFromUri(Uri paramUri, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.f
 * JD-Core Version:    0.6.2
 */