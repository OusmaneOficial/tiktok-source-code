package android.support.v4.media.session;

import android.content.Intent;
import android.media.Rating;
import android.media.session.MediaSession.Callback;
import android.media.session.MediaSession.Token;
import android.os.Bundle;
import android.os.ResultReceiver;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class d
{
  static
  {
    CoverageLogger.Log(58480640);
  }

  public static Object a(Object paramObject)
  {
    if ((paramObject instanceof MediaSession.Token))
      return paramObject;
    throw new IllegalArgumentException("token is not a valid MediaSession.Token object");
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(58484736);
    }

    public abstract void a(Object paramObject);

    public abstract void a(String paramString, Bundle paramBundle);

    public abstract void a(String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver);

    public abstract boolean a(Intent paramIntent);
  }

  static class b<T extends d.a> extends MediaSession.Callback
  {
    protected final T a;

    static
    {
      CoverageLogger.Log(58486784);
    }

    public b(T paramT)
    {
      this.a = paramT;
    }

    public void onCommand(String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver)
    {
      MediaSessionCompat.a(paramBundle);
      this.a.a(paramString, paramBundle, paramResultReceiver);
    }

    public void onCustomAction(String paramString, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
      this.a.a(paramString, paramBundle);
    }

    public void onFastForward()
    {
    }

    public boolean onMediaButtonEvent(Intent paramIntent)
    {
      return (this.a.a(paramIntent)) || (super.onMediaButtonEvent(paramIntent));
    }

    public void onPause()
    {
    }

    public void onPlay()
    {
    }

    public void onPlayFromMediaId(String paramString, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
    }

    public void onPlayFromSearch(String paramString, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
    }

    public void onRewind()
    {
    }

    public void onSeekTo(long paramLong)
    {
    }

    public void onSetRating(Rating paramRating)
    {
      this.a.a(paramRating);
    }

    public void onSkipToNext()
    {
    }

    public void onSkipToPrevious()
    {
    }

    public void onSkipToQueueItem(long paramLong)
    {
    }

    public void onStop()
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.d
 * JD-Core Version:    0.6.2
 */