package android.support.v4.media.session;

import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.session.MediaController.Callback;
import android.media.session.MediaController.PlaybackInfo;
import android.media.session.MediaSession.QueueItem;
import android.media.session.PlaybackState;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

final class c
{
  static
  {
    CoverageLogger.Log(58767360);
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(58759168);
    }

    public abstract void a();

    public abstract void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

    public abstract void a(Bundle paramBundle);

    public abstract void a(CharSequence paramCharSequence);

    public abstract void a(Object paramObject);

    public abstract void a(String paramString, Bundle paramBundle);

    public abstract void a(List<?> paramList);

    public abstract void b(Object paramObject);
  }

  static final class b<T extends c.a> extends MediaController.Callback
  {
    protected final T a;

    static
    {
      CoverageLogger.Log(58542080);
    }

    public b(T paramT)
    {
      this.a = paramT;
    }

    public final void onAudioInfoChanged(MediaController.PlaybackInfo paramPlaybackInfo)
    {
      c.a locala = this.a;
      int i = paramPlaybackInfo.getPlaybackType();
      AudioAttributes localAudioAttributes = ((MediaController.PlaybackInfo)paramPlaybackInfo).getAudioAttributes();
      int j;
      if ((0x1 & localAudioAttributes.getFlags()) == 1)
        j = 7;
      else if ((0x4 & localAudioAttributes.getFlags()) == 4)
        j = 6;
      else
        switch (localAudioAttributes.getUsage())
        {
        case 1:
        case 11:
        case 12:
        case 14:
        default:
          j = 3;
          break;
        case 13:
          j = 1;
          break;
        case 6:
          j = 2;
          break;
        case 5:
        case 7:
        case 8:
        case 9:
        case 10:
          j = 5;
          break;
        case 4:
          j = 4;
          break;
        case 3:
          j = 8;
          break;
        case 2:
          j = 0;
        }
      locala.a(i, j, paramPlaybackInfo.getVolumeControl(), paramPlaybackInfo.getMaxVolume(), paramPlaybackInfo.getCurrentVolume());
    }

    public final void onExtrasChanged(Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
      this.a.a(paramBundle);
    }

    public final void onMetadataChanged(MediaMetadata paramMediaMetadata)
    {
      this.a.b(paramMediaMetadata);
    }

    public final void onPlaybackStateChanged(PlaybackState paramPlaybackState)
    {
      this.a.a(paramPlaybackState);
    }

    public final void onQueueChanged(List<MediaSession.QueueItem> paramList)
    {
      this.a.a(paramList);
    }

    public final void onQueueTitleChanged(CharSequence paramCharSequence)
    {
      this.a.a(paramCharSequence);
    }

    public final void onSessionDestroyed()
    {
      this.a.a();
    }

    public final void onSessionEvent(String paramString, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
      this.a.a(paramString, paramBundle);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.c
 * JD-Core Version:    0.6.2
 */