package android.support.v4.media.session;

import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession.QueueItem;
import android.media.session.MediaSession.Token;
import android.media.session.PlaybackState;
import android.media.session.PlaybackState.CustomAction;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.view.KeyEvent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public final class MediaControllerCompat
{
  public final b a;
  public final MediaSessionCompat.Token b;
  private final HashSet<a> c = new HashSet();

  static
  {
    CoverageLogger.Log(58755072);
  }

  public MediaControllerCompat(Context paramContext, MediaSessionCompat.Token paramToken)
    throws RemoteException
  {
    if (paramToken != null)
    {
      this.b = paramToken;
      if (Build.VERSION.SDK_INT >= 24)
      {
        this.a = new d(paramContext, paramToken);
        return;
      }
      if (Build.VERSION.SDK_INT >= 23)
      {
        this.a = new c(paramContext, paramToken);
        return;
      }
      if (Build.VERSION.SDK_INT >= 21)
      {
        this.a = new MediaControllerImplApi21(paramContext, paramToken);
        return;
      }
      this.a = new e(paramToken);
      return;
    }
    throw new IllegalArgumentException("sessionToken must not be null");
  }

  // ERROR //
  public MediaControllerCompat(Context paramContext, MediaSessionCompat paramMediaSessionCompat)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 26	java/lang/Object:<init>	()V
    //   4: aload_0
    //   5: new 28	java/util/HashSet
    //   8: dup
    //   9: invokespecial 29	java/util/HashSet:<init>	()V
    //   12: putfield 31	android/support/v4/media/session/MediaControllerCompat:c	Ljava/util/HashSet;
    //   15: aload_0
    //   16: aload_2
    //   17: invokevirtual 69	android/support/v4/media/session/MediaSessionCompat:a	()Landroid/support/v4/media/session/MediaSessionCompat$Token;
    //   20: putfield 33	android/support/v4/media/session/MediaControllerCompat:b	Landroid/support/v4/media/session/MediaSessionCompat$Token;
    //   23: getstatic 39	android/os/Build$VERSION:SDK_INT	I
    //   26: bipush 24
    //   28: if_icmplt +19 -> 47
    //   31: new 41	android/support/v4/media/session/MediaControllerCompat$d
    //   34: dup
    //   35: aload_1
    //   36: aload_0
    //   37: getfield 33	android/support/v4/media/session/MediaControllerCompat:b	Landroid/support/v4/media/session/MediaSessionCompat$Token;
    //   40: invokespecial 43	android/support/v4/media/session/MediaControllerCompat$d:<init>	(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V
    //   43: astore_3
    //   44: goto +68 -> 112
    //   47: getstatic 39	android/os/Build$VERSION:SDK_INT	I
    //   50: bipush 23
    //   52: if_icmplt +19 -> 71
    //   55: new 47	android/support/v4/media/session/MediaControllerCompat$c
    //   58: dup
    //   59: aload_1
    //   60: aload_0
    //   61: getfield 33	android/support/v4/media/session/MediaControllerCompat:b	Landroid/support/v4/media/session/MediaSessionCompat$Token;
    //   64: invokespecial 48	android/support/v4/media/session/MediaControllerCompat$c:<init>	(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V
    //   67: astore_3
    //   68: goto +44 -> 112
    //   71: getstatic 39	android/os/Build$VERSION:SDK_INT	I
    //   74: bipush 21
    //   76: if_icmplt +19 -> 95
    //   79: new 50	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21
    //   82: dup
    //   83: aload_1
    //   84: aload_0
    //   85: getfield 33	android/support/v4/media/session/MediaControllerCompat:b	Landroid/support/v4/media/session/MediaSessionCompat$Token;
    //   88: invokespecial 51	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:<init>	(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V
    //   91: astore_3
    //   92: goto +20 -> 112
    //   95: new 53	android/support/v4/media/session/MediaControllerCompat$e
    //   98: dup
    //   99: aload_0
    //   100: getfield 33	android/support/v4/media/session/MediaControllerCompat:b	Landroid/support/v4/media/session/MediaSessionCompat$Token;
    //   103: invokespecial 56	android/support/v4/media/session/MediaControllerCompat$e:<init>	(Landroid/support/v4/media/session/MediaSessionCompat$Token;)V
    //   106: astore_3
    //   107: goto +5 -> 112
    //   110: aconst_null
    //   111: astore_3
    //   112: aload_0
    //   113: aload_3
    //   114: putfield 45	android/support/v4/media/session/MediaControllerCompat:a	Landroid/support/v4/media/session/MediaControllerCompat$b;
    //   117: return
    //
    // Exception table:
    //   from	to	target	type
    //   23	44	110	android/os/RemoteException
    //   47	68	110	android/os/RemoteException
    //   71	92	110	android/os/RemoteException
    //   95	107	110	android/os/RemoteException
  }

  static class MediaControllerImplApi21
    implements MediaControllerCompat.b
  {
    protected final Object a;
    final Object b = new Object();
    final List<MediaControllerCompat.a> c = new ArrayList();
    HashMap<MediaControllerCompat.a, a> d = new HashMap();
    final MediaSessionCompat.Token e;

    static
    {
      CoverageLogger.Log(58556416);
    }

    public MediaControllerImplApi21(Context paramContext, MediaSessionCompat.Token paramToken)
      throws RemoteException
    {
      this.e = paramToken;
      this.a = new MediaController(paramContext, (MediaSession.Token)this.e.a);
      if (this.a != null)
      {
        if (this.e.b == null)
        {
          ExtraBinderRequestResultReceiver localExtraBinderRequestResultReceiver = new ExtraBinderRequestResultReceiver(this);
          ((MediaController)this.a).sendCommand("android.support.v4.media.session.command.GET_EXTRA_BINDER", null, localExtraBinderRequestResultReceiver);
        }
        return;
      }
      throw new RemoteException();
    }

    public final boolean a(KeyEvent paramKeyEvent)
    {
      return ((MediaController)this.a).dispatchMediaButtonEvent(paramKeyEvent);
    }

    static class ExtraBinderRequestResultReceiver extends ResultReceiver
    {
      private WeakReference<MediaControllerCompat.MediaControllerImplApi21> a;

      static
      {
        CoverageLogger.Log(58736640);
      }

      ExtraBinderRequestResultReceiver(MediaControllerCompat.MediaControllerImplApi21 paramMediaControllerImplApi21)
      {
        super();
        this.a = new WeakReference(paramMediaControllerImplApi21);
      }

      // ERROR //
      protected void onReceiveResult(int paramInt, Bundle paramBundle)
      {
        // Byte code:
        //   0: aload_0
        //   1: getfield 28	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21$ExtraBinderRequestResultReceiver:a	Ljava/lang/ref/WeakReference;
        //   4: invokevirtual 36	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
        //   7: checkcast 38	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21
        //   10: astore_3
        //   11: aload_3
        //   12: ifnull +166 -> 178
        //   15: aload_2
        //   16: ifnonnull +4 -> 20
        //   19: return
        //   20: aload_3
        //   21: getfield 42	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:b	Ljava/lang/Object;
        //   24: astore 4
        //   26: aload 4
        //   28: monitorenter
        //   29: aload_3
        //   30: getfield 46	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:e	Landroid/support/v4/media/session/MediaSessionCompat$Token;
        //   33: aload_2
        //   34: ldc 48
        //   36: invokestatic 53	androidx/core/app/d:a	(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/IBinder;
        //   39: invokestatic 58	android/support/v4/media/session/b$a:a	(Landroid/os/IBinder;)Landroid/support/v4/media/session/b;
        //   42: putfield 63	android/support/v4/media/session/MediaSessionCompat$Token:b	Landroid/support/v4/media/session/b;
        //   45: aload_3
        //   46: getfield 46	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:e	Landroid/support/v4/media/session/MediaSessionCompat$Token;
        //   49: aload_2
        //   50: ldc 65
        //   52: invokevirtual 71	android/os/Bundle:getBundle	(Ljava/lang/String;)Landroid/os/Bundle;
        //   55: putfield 75	android/support/v4/media/session/MediaSessionCompat$Token:c	Landroid/os/Bundle;
        //   58: aload_3
        //   59: getfield 46	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:e	Landroid/support/v4/media/session/MediaSessionCompat$Token;
        //   62: getfield 63	android/support/v4/media/session/MediaSessionCompat$Token:b	Landroid/support/v4/media/session/b;
        //   65: ifnull +101 -> 166
        //   68: aload_3
        //   69: getfield 78	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:c	Ljava/util/List;
        //   72: invokeinterface 84 1 0
        //   77: astore 6
        //   79: aload 6
        //   81: invokeinterface 90 1 0
        //   86: ifeq +71 -> 157
        //   89: aload 6
        //   91: invokeinterface 93 1 0
        //   96: checkcast 95	android/support/v4/media/session/MediaControllerCompat$a
        //   99: astore 7
        //   101: new 97	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21$a
        //   104: dup
        //   105: aload 7
        //   107: invokespecial 100	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21$a:<init>	(Landroid/support/v4/media/session/MediaControllerCompat$a;)V
        //   110: astore 8
        //   112: aload_3
        //   113: getfield 104	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:d	Ljava/util/HashMap;
        //   116: aload 7
        //   118: aload 8
        //   120: invokevirtual 110	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   123: pop
        //   124: aload 7
        //   126: aload 8
        //   128: putfield 113	android/support/v4/media/session/MediaControllerCompat$a:c	Landroid/support/v4/media/session/a;
        //   131: aload_3
        //   132: getfield 46	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:e	Landroid/support/v4/media/session/MediaSessionCompat$Token;
        //   135: getfield 63	android/support/v4/media/session/MediaSessionCompat$Token:b	Landroid/support/v4/media/session/b;
        //   138: aload 8
        //   140: invokeinterface 118 2 0
        //   145: aload 7
        //   147: bipush 13
        //   149: aconst_null
        //   150: aconst_null
        //   151: invokevirtual 121	android/support/v4/media/session/MediaControllerCompat$a:a	(ILjava/lang/Object;Landroid/os/Bundle;)V
        //   154: goto -75 -> 79
        //   157: aload_3
        //   158: getfield 78	android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi21:c	Ljava/util/List;
        //   161: invokeinterface 124 1 0
        //   166: aload 4
        //   168: monitorexit
        //   169: return
        //   170: astore 5
        //   172: aload 4
        //   174: monitorexit
        //   175: aload 5
        //   177: athrow
        //   178: return
        //
        // Exception table:
        //   from	to	target	type
        //   131	145	157	android/os/RemoteException
        //   29	79	170	finally
        //   79	131	170	finally
        //   131	145	170	finally
        //   145	154	170	finally
        //   157	166	170	finally
        //   166	169	170	finally
        //   172	175	170	finally
      }
    }

    static final class a extends MediaControllerCompat.a.c
    {
      static
      {
        CoverageLogger.Log(58740736);
      }

      a(MediaControllerCompat.a parama)
      {
        super();
      }

      public final void a()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(MediaMetadataCompat paramMediaMetadataCompat)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(ParcelableVolumeInfo paramParcelableVolumeInfo)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(CharSequence paramCharSequence)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(List<MediaSessionCompat.QueueItem> paramList)
        throws RemoteException
      {
        throw new AssertionError();
      }
    }
  }

  public static abstract class a
    implements IBinder.DeathRecipient
  {
    final Object a;
    a b;
    public a c;

    static
    {
      CoverageLogger.Log(58564608);
    }

    public a()
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        this.a = new c.b(new b(this));
        return;
      }
      c localc = new c(this);
      this.c = localc;
      this.a = localc;
    }

    final void a(int paramInt, Object paramObject, Bundle paramBundle)
    {
      a locala = this.b;
      if (locala != null)
      {
        Message localMessage = locala.obtainMessage(paramInt, paramObject);
        localMessage.setData(paramBundle);
        localMessage.sendToTarget();
      }
    }

    final class a extends Handler
    {
      boolean a;

      static
      {
        CoverageLogger.Log(58570752);
      }

      public final void handleMessage(Message paramMessage)
      {
        if (!this.a)
          return;
        switch (paramMessage.what)
        {
        case 8:
        case 10:
        default:
          return;
        case 12:
          ((Integer)paramMessage.obj).intValue();
          return;
        case 11:
          ((Boolean)paramMessage.obj).booleanValue();
          return;
        case 9:
          ((Integer)paramMessage.obj).intValue();
          return;
        case 7:
          MediaSessionCompat.a((Bundle)paramMessage.obj);
          return;
        case 6:
          return;
        case 5:
          return;
        case 4:
          return;
        case 3:
          return;
        case 2:
          return;
        case 1:
        }
        MediaSessionCompat.a(paramMessage.getData());
      }
    }

    static final class b
      implements c.a
    {
      private final WeakReference<MediaControllerCompat.a> a;

      static
      {
        CoverageLogger.Log(58734592);
      }

      b(MediaControllerCompat.a parama)
      {
        this.a = new WeakReference(parama);
      }

      public final void a()
      {
        this.a.get();
      }

      public final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
      {
        if ((MediaControllerCompat.a)this.a.get() != null)
          new MediaControllerCompat.f(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      }

      public final void a(Bundle paramBundle)
      {
        this.a.get();
      }

      public final void a(CharSequence paramCharSequence)
      {
        this.a.get();
      }

      public final void a(Object paramObject)
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if ((locala != null) && (locala.c == null) && (paramObject != null) && (Build.VERSION.SDK_INT >= 21))
        {
          PlaybackState localPlaybackState = (PlaybackState)paramObject;
          List localList = localPlaybackState.getCustomActions();
          ArrayList localArrayList2;
          if (localList != null)
          {
            ArrayList localArrayList1 = new ArrayList(localList.size());
            Iterator localIterator = localList.iterator();
            while (localIterator.hasNext())
            {
              Object localObject = localIterator.next();
              PlaybackStateCompat.CustomAction localCustomAction;
              if ((localObject != null) && (Build.VERSION.SDK_INT >= 21))
              {
                PlaybackState.CustomAction localCustomAction1 = (PlaybackState.CustomAction)localObject;
                localCustomAction = new PlaybackStateCompat.CustomAction(localCustomAction1.getAction(), localCustomAction1.getName(), localCustomAction1.getIcon(), localCustomAction1.getExtras());
                localCustomAction.e = localObject;
              }
              else
              {
                localCustomAction = null;
              }
              localArrayList1.add(localCustomAction);
            }
            localArrayList2 = localArrayList1;
          }
          else
          {
            localArrayList2 = null;
          }
          int i = Build.VERSION.SDK_INT;
          Bundle localBundle1 = null;
          if (i >= 22)
            localBundle1 = localPlaybackState.getExtras();
          Bundle localBundle2 = localBundle1;
          PlaybackStateCompat localPlaybackStateCompat = new PlaybackStateCompat(localPlaybackState.getState(), localPlaybackState.getPosition(), localPlaybackState.getBufferedPosition(), localPlaybackState.getPlaybackSpeed(), localPlaybackState.getActions(), 0, localPlaybackState.getErrorMessage(), localPlaybackState.getLastPositionUpdateTime(), localArrayList2, localPlaybackState.getActiveQueueItemId(), localBundle2);
          localPlaybackStateCompat.l = paramObject;
        }
      }

      public final void a(String paramString, Bundle paramBundle)
      {
        this.a.get();
      }

      public final void a(List<?> paramList)
      {
        if (((MediaControllerCompat.a)this.a.get() != null) && (paramList != null))
        {
          if (Build.VERSION.SDK_INT < 21)
            return;
          ArrayList localArrayList = new ArrayList();
          Iterator localIterator = paramList.iterator();
          while (localIterator.hasNext())
          {
            Object localObject = localIterator.next();
            MediaSessionCompat.QueueItem localQueueItem;
            if ((localObject != null) && (Build.VERSION.SDK_INT >= 21))
            {
              MediaSession.QueueItem localQueueItem1 = (MediaSession.QueueItem)localObject;
              localQueueItem = new MediaSessionCompat.QueueItem(localObject, MediaDescriptionCompat.a(localQueueItem1.getDescription()), localQueueItem1.getQueueId());
            }
            else
            {
              localQueueItem = null;
            }
            localArrayList.add(localQueueItem);
          }
        }
      }

      public final void b(Object paramObject)
      {
        if (((MediaControllerCompat.a)this.a.get() != null) && (paramObject != null) && (Build.VERSION.SDK_INT >= 21))
        {
          Parcel localParcel = Parcel.obtain();
          ((MediaMetadata)paramObject).writeToParcel(localParcel, 0);
          localParcel.setDataPosition(0);
          MediaMetadataCompat localMediaMetadataCompat = (MediaMetadataCompat)MediaMetadataCompat.CREATOR.createFromParcel(localParcel);
          localParcel.recycle();
          localMediaMetadataCompat.c = paramObject;
        }
      }
    }

    static class c extends a.a
    {
      private final WeakReference<MediaControllerCompat.a> a;

      static
      {
        CoverageLogger.Log(58568704);
      }

      c(MediaControllerCompat.a parama)
      {
        this.a = new WeakReference(parama);
      }

      public void a()
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(8, null, null);
      }

      public final void a(int paramInt)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(9, Integer.valueOf(paramInt), null);
      }

      public void a(Bundle paramBundle)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(7, paramBundle, null);
      }

      public void a(MediaMetadataCompat paramMediaMetadataCompat)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(3, paramMediaMetadataCompat, null);
      }

      public void a(ParcelableVolumeInfo paramParcelableVolumeInfo)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
        {
          MediaControllerCompat.f localf;
          if (paramParcelableVolumeInfo != null)
          {
            int i = paramParcelableVolumeInfo.a;
            int j = paramParcelableVolumeInfo.b;
            int k = paramParcelableVolumeInfo.c;
            int m = paramParcelableVolumeInfo.d;
            int n = paramParcelableVolumeInfo.e;
            localf = new MediaControllerCompat.f(i, j, k, m, n);
          }
          else
          {
            localf = null;
          }
          locala.a(4, localf, null);
        }
      }

      public final void a(PlaybackStateCompat paramPlaybackStateCompat)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(2, paramPlaybackStateCompat, null);
      }

      public void a(CharSequence paramCharSequence)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(6, paramCharSequence, null);
      }

      public final void a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(1, paramString, paramBundle);
      }

      public void a(List<MediaSessionCompat.QueueItem> paramList)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(5, paramList, null);
      }

      public final void a(boolean paramBoolean)
        throws RemoteException
      {
      }

      public final void b()
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(13, null, null);
      }

      public final void b(int paramInt)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(12, Integer.valueOf(paramInt), null);
      }

      public final void b(boolean paramBoolean)
        throws RemoteException
      {
        MediaControllerCompat.a locala = (MediaControllerCompat.a)this.a.get();
        if (locala != null)
          locala.a(11, Boolean.valueOf(paramBoolean), null);
      }
    }
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(58562560);
    }

    public abstract boolean a(KeyEvent paramKeyEvent);
  }

  static class c extends MediaControllerCompat.MediaControllerImplApi21
  {
    static
    {
      CoverageLogger.Log(58744832);
    }

    public c(Context paramContext, MediaSessionCompat.Token paramToken)
      throws RemoteException
    {
      super(paramToken);
    }
  }

  static final class d extends MediaControllerCompat.c
  {
    static
    {
      CoverageLogger.Log(58552320);
    }

    public d(Context paramContext, MediaSessionCompat.Token paramToken)
      throws RemoteException
    {
      super(paramToken);
    }
  }

  static final class e
    implements MediaControllerCompat.b
  {
    private b a;

    static
    {
      CoverageLogger.Log(58750976);
    }

    public e(MediaSessionCompat.Token paramToken)
    {
      this.a = b.a.a((IBinder)paramToken.a);
    }

    public final boolean a(KeyEvent paramKeyEvent)
    {
      if (paramKeyEvent != null)
      {
        try
        {
          this.a.a(paramKeyEvent);
        }
        catch (RemoteException localRemoteException)
        {
        }
        return false;
      }
      throw new IllegalArgumentException("event may not be null.");
    }
  }

  public static final class f
  {
    public final int a;
    public final int b;
    public final int c;
    public final int d;
    public final int e;

    static
    {
      CoverageLogger.Log(58753024);
    }

    f(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
    {
      this.a = paramInt1;
      this.b = paramInt2;
      this.c = paramInt3;
      this.d = paramInt4;
      this.e = paramInt5;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.MediaControllerCompat
 * JD-Core Version:    0.6.2
 */