package android.support.v4.media.session;

import android.net.Uri;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class e
{
  static
  {
    CoverageLogger.Log(58490880);
  }

  public static abstract interface a extends d.a
  {
    static
    {
      CoverageLogger.Log(58482688);
    }
  }

  static class b<T extends e.a> extends d.b<T>
  {
    static
    {
      CoverageLogger.Log(58476544);
    }

    public b(T paramT)
    {
      super();
    }

    public void onPlayFromUri(Uri paramUri, Bundle paramBundle)
    {
      MediaSessionCompat.a(paramBundle);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.e
 * JD-Core Version:    0.6.2
 */