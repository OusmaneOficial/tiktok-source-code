package android.support.v4.media.session;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.support.v4.media.MediaMetadataCompat;
import android.text.TextUtils;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public abstract interface a extends IInterface
{
  static
  {
    CoverageLogger.Log(58728448);
  }

  public abstract void a()
    throws RemoteException;

  public abstract void a(int paramInt)
    throws RemoteException;

  public abstract void a(Bundle paramBundle)
    throws RemoteException;

  public abstract void a(MediaMetadataCompat paramMediaMetadataCompat)
    throws RemoteException;

  public abstract void a(ParcelableVolumeInfo paramParcelableVolumeInfo)
    throws RemoteException;

  public abstract void a(PlaybackStateCompat paramPlaybackStateCompat)
    throws RemoteException;

  public abstract void a(CharSequence paramCharSequence)
    throws RemoteException;

  public abstract void a(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract void a(List<MediaSessionCompat.QueueItem> paramList)
    throws RemoteException;

  public abstract void a(boolean paramBoolean)
    throws RemoteException;

  public abstract void b()
    throws RemoteException;

  public abstract void b(int paramInt)
    throws RemoteException;

  public abstract void b(boolean paramBoolean)
    throws RemoteException;

  public static abstract class a extends Binder
    implements a
  {
    static
    {
      CoverageLogger.Log(58726400);
    }

    public a()
    {
      attachInterface(this, "android.support.v4.media.session.IMediaControllerCallback");
    }

    public static a a(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.support.v4.media.session.IMediaControllerCallback");
      if ((localIInterface != null) && ((localIInterface instanceof a)))
        return (a)localIInterface;
      return new a(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      if (paramInt1 != 1598968902)
      {
        switch (paramInt1)
        {
        default:
          return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
        case 13:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          b();
          return true;
        case 12:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          b(paramParcel1.readInt());
          return true;
        case 11:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          int i3 = paramParcel1.readInt();
          boolean bool2 = false;
          if (i3 != 0)
            bool2 = true;
          b(bool2);
          return true;
        case 10:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          int i2 = paramParcel1.readInt();
          boolean bool1 = false;
          if (i2 != 0)
            bool1 = true;
          a(bool1);
          return true;
        case 9:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          a(paramParcel1.readInt());
          return true;
        case 8:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          int i1 = paramParcel1.readInt();
          ParcelableVolumeInfo localParcelableVolumeInfo = null;
          if (i1 != 0)
            localParcelableVolumeInfo = (ParcelableVolumeInfo)ParcelableVolumeInfo.CREATOR.createFromParcel(paramParcel1);
          a(localParcelableVolumeInfo);
          return true;
        case 7:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          int n = paramParcel1.readInt();
          Bundle localBundle2 = null;
          if (n != 0)
            localBundle2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          a(localBundle2);
          return true;
        case 6:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          int m = paramParcel1.readInt();
          CharSequence localCharSequence = null;
          if (m != 0)
            localCharSequence = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel1);
          a(localCharSequence);
          return true;
        case 5:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          a(paramParcel1.createTypedArrayList(MediaSessionCompat.QueueItem.CREATOR));
          return true;
        case 4:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          int k = paramParcel1.readInt();
          MediaMetadataCompat localMediaMetadataCompat = null;
          if (k != 0)
            localMediaMetadataCompat = (MediaMetadataCompat)MediaMetadataCompat.CREATOR.createFromParcel(paramParcel1);
          a(localMediaMetadataCompat);
          return true;
        case 3:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          int j = paramParcel1.readInt();
          PlaybackStateCompat localPlaybackStateCompat = null;
          if (j != 0)
            localPlaybackStateCompat = (PlaybackStateCompat)PlaybackStateCompat.CREATOR.createFromParcel(paramParcel1);
          a(localPlaybackStateCompat);
          return true;
        case 2:
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
          a();
          return true;
        case 1:
        }
        paramParcel1.enforceInterface("android.support.v4.media.session.IMediaControllerCallback");
        String str = paramParcel1.readString();
        int i = paramParcel1.readInt();
        Bundle localBundle1 = null;
        if (i != 0)
          localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
        a(str, localBundle1);
        return true;
      }
      paramParcel2.writeString("android.support.v4.media.session.IMediaControllerCallback");
      return true;
    }

    static final class a
      implements a
    {
      private IBinder a;

      static
      {
        CoverageLogger.Log(58720256);
      }

      a(IBinder paramIBinder)
      {
        this.a = paramIBinder;
      }

      public final void a()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          this.a.transact(2, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(int paramInt)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          localParcel.writeInt(paramInt);
          this.a.transact(9, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          if (paramBundle != null)
          {
            localParcel.writeInt(1);
            paramBundle.writeToParcel(localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(7, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(MediaMetadataCompat paramMediaMetadataCompat)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          if (paramMediaMetadataCompat != null)
          {
            localParcel.writeInt(1);
            paramMediaMetadataCompat.writeToParcel(localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(4, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(ParcelableVolumeInfo paramParcelableVolumeInfo)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          if (paramParcelableVolumeInfo != null)
          {
            localParcel.writeInt(1);
            paramParcelableVolumeInfo.writeToParcel(localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(8, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(PlaybackStateCompat paramPlaybackStateCompat)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          if (paramPlaybackStateCompat != null)
          {
            localParcel.writeInt(1);
            paramPlaybackStateCompat.writeToParcel(localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(3, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(CharSequence paramCharSequence)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          if (paramCharSequence != null)
          {
            localParcel.writeInt(1);
            TextUtils.writeToParcel(paramCharSequence, localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(6, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          localParcel.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel.writeInt(1);
            paramBundle.writeToParcel(localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(List<MediaSessionCompat.QueueItem> paramList)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          localParcel.writeTypedList(paramList);
          this.a.transact(5, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
            if (paramBoolean)
            {
              i = 1;
              localParcel.writeInt(i);
              this.a.transact(10, localParcel, null, 1);
              return;
            }
          }
          finally
          {
            localParcel.recycle();
          }
          int i = 0;
        }
      }

      public final IBinder asBinder()
      {
        return this.a;
      }

      public final void b()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          this.a.transact(13, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void b(int paramInt)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
          localParcel.writeInt(paramInt);
          this.a.transact(12, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void b(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel.writeInterfaceToken("android.support.v4.media.session.IMediaControllerCallback");
            if (paramBoolean)
            {
              i = 1;
              localParcel.writeInt(i);
              this.a.transact(11, localParcel, null, 1);
              return;
            }
          }
          finally
          {
            localParcel.recycle();
          }
          int i = 0;
        }
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.a
 * JD-Core Version:    0.6.2
 */