package android.support.v4.media.session;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.media.AudioManager;
import android.media.Rating;
import android.media.RemoteControlClient;
import android.media.RemoteControlClient.OnMetadataUpdateListener;
import android.media.RemoteControlClient.OnPlaybackPositionUpdateListener;
import android.media.session.MediaSession;
import android.media.session.MediaSession.Callback;
import android.net.Uri;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import androidx.media.i;
import androidx.media.i.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class MediaSessionCompat
{
  static int b;
  public final MediaControllerCompat a;
  private final b c;
  private final ArrayList<Object> d = new ArrayList();

  static
  {
    CoverageLogger.Log(58806272);
  }

  public MediaSessionCompat(Context paramContext, String paramString)
  {
    this(paramContext, paramString, null, null);
  }

  private MediaSessionCompat(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent)
  {
    this(paramContext, paramString, null, null, null);
  }

  private MediaSessionCompat(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent, Bundle paramBundle)
  {
    if (paramContext != null)
    {
      if (!TextUtils.isEmpty(paramString))
      {
        if (paramComponentName == null)
        {
          Intent localIntent1 = new Intent("android.intent.action.MEDIA_BUTTON");
          localIntent1.setPackage(paramContext.getPackageName());
          List localList = paramContext.getPackageManager().queryBroadcastReceivers(localIntent1, 0);
          if (localList.size() == 1)
          {
            ResolveInfo localResolveInfo = (ResolveInfo)localList.get(0);
            paramComponentName = new ComponentName(localResolveInfo.activityInfo.packageName, localResolveInfo.activityInfo.name);
          }
          else
          {
            localList.size();
            paramComponentName = null;
          }
        }
        if ((paramComponentName != null) && (paramPendingIntent == null))
        {
          Intent localIntent2 = new Intent("android.intent.action.MEDIA_BUTTON");
          localIntent2.setComponent(paramComponentName);
          paramPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent2, 0);
        }
        if (Build.VERSION.SDK_INT >= 28)
        {
          this.c = new f(paramContext, paramString, null);
          a(new a()
          {
            static
            {
              CoverageLogger.Log(58535936);
            }
          });
          this.c.a(paramPendingIntent);
        }
        else if (Build.VERSION.SDK_INT >= 21)
        {
          this.c = new e(paramContext, paramString, null);
          a(new a()
          {
            static
            {
              CoverageLogger.Log(58769408);
            }
          });
          this.c.a(paramPendingIntent);
        }
        else if (Build.VERSION.SDK_INT >= 19)
        {
          this.c = new d(paramContext, paramString, paramComponentName, paramPendingIntent);
        }
        else if (Build.VERSION.SDK_INT >= 18)
        {
          this.c = new c(paramContext, paramString, paramComponentName, paramPendingIntent);
        }
        else
        {
          this.c = new g(paramContext, paramString, paramComponentName, paramPendingIntent);
        }
        this.a = new MediaControllerCompat(paramContext, this);
        if (b == 0)
          b = (int)(0.5F + TypedValue.applyDimension(1, 320.0F, paramContext.getResources().getDisplayMetrics()));
        return;
      }
      throw new IllegalArgumentException("tag must not be null or empty");
    }
    throw new IllegalArgumentException("context must not be null");
  }

  static PlaybackStateCompat a(PlaybackStateCompat paramPlaybackStateCompat, MediaMetadataCompat paramMediaMetadataCompat)
  {
    PlaybackStateCompat localPlaybackStateCompat = paramPlaybackStateCompat;
    if (localPlaybackStateCompat != null)
    {
      long l1 = localPlaybackStateCompat.b;
      long l2 = -1L;
      if (l1 == l2)
        return localPlaybackStateCompat;
      if ((localPlaybackStateCompat.a == 3) || (localPlaybackStateCompat.a == 4) || (localPlaybackStateCompat.a == 5))
      {
        long l3 = localPlaybackStateCompat.h;
        if (l3 > 0L)
        {
          long l4 = SystemClock.elapsedRealtime();
          long l5 = ()(localPlaybackStateCompat.d * (float)(l4 - l3)) + localPlaybackStateCompat.b;
          if ((paramMediaMetadataCompat != null) && (paramMediaMetadataCompat.b.containsKey("android.media.metadata.DURATION")))
            l2 = paramMediaMetadataCompat.b.getLong("android.media.metadata.DURATION", 0L);
          if ((l2 >= 0L) && (l5 > l2))
            l5 = l2;
          else if (l5 < 0L)
            l5 = 0L;
          PlaybackStateCompat.a locala = new PlaybackStateCompat.a(localPlaybackStateCompat);
          int i = localPlaybackStateCompat.a;
          float f = localPlaybackStateCompat.d;
          locala.b = i;
          locala.c = l5;
          locala.i = l4;
          locala.e = f;
          localPlaybackStateCompat = new PlaybackStateCompat(locala.b, locala.c, locala.d, locala.e, locala.f, locala.g, locala.h, locala.i, locala.a, locala.j, locala.k);
        }
      }
    }
    return localPlaybackStateCompat;
  }

  public static void a(Bundle paramBundle)
  {
    if (paramBundle != null)
      paramBundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
  }

  private void a(a parama)
  {
    a(parama, null);
  }

  private void a(a parama, Handler paramHandler)
  {
    if (parama == null)
    {
      this.c.a(null, null);
      return;
    }
    this.c.a(parama, new Handler());
  }

  public final Token a()
  {
    return this.c.a();
  }

  public static final class QueueItem
    implements Parcelable
  {
    public static final Parcelable.Creator<QueueItem> CREATOR = new Parcelable.Creator()
    {
      static
      {
        CoverageLogger.Log(58791936);
      }
    };
    public final MediaDescriptionCompat a;
    public final long b;
    private Object c;

    static
    {
      CoverageLogger.Log(58497024);
    }

    QueueItem(Parcel paramParcel)
    {
      this.a = ((MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel));
      this.b = paramParcel.readLong();
    }

    QueueItem(Object paramObject, MediaDescriptionCompat paramMediaDescriptionCompat, long paramLong)
    {
      if (paramMediaDescriptionCompat != null)
      {
        if (paramLong != -1L)
        {
          this.a = paramMediaDescriptionCompat;
          this.b = paramLong;
          this.c = paramObject;
          return;
        }
        throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
      }
      throw new IllegalArgumentException("Description cannot be null.");
    }

    public final int describeContents()
    {
      return 0;
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("MediaSession.QueueItem {Description=");
      localStringBuilder.append(this.a);
      localStringBuilder.append(", Id=");
      localStringBuilder.append(this.b);
      localStringBuilder.append(" }");
      return localStringBuilder.toString();
    }

    public final void writeToParcel(Parcel paramParcel, int paramInt)
    {
      this.a.writeToParcel(paramParcel, paramInt);
      paramParcel.writeLong(this.b);
    }
  }

  public static final class ResultReceiverWrapper
    implements Parcelable
  {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new Parcelable.Creator()
    {
      static
      {
        CoverageLogger.Log(58494976);
      }
    };
    ResultReceiver a;

    static
    {
      CoverageLogger.Log(58804224);
    }

    ResultReceiverWrapper(Parcel paramParcel)
    {
      this.a = ((ResultReceiver)ResultReceiver.CREATOR.createFromParcel(paramParcel));
    }

    public final int describeContents()
    {
      return 0;
    }

    public final void writeToParcel(Parcel paramParcel, int paramInt)
    {
      this.a.writeToParcel(paramParcel, paramInt);
    }
  }

  public static final class Token
    implements Parcelable
  {
    public static final Parcelable.Creator<Token> CREATOR = new Parcelable.Creator()
    {
      static
      {
        CoverageLogger.Log(58810368);
      }
    };
    public final Object a;
    public b b;
    public Bundle c;

    static
    {
      CoverageLogger.Log(58488832);
    }

    Token(Object paramObject)
    {
      this(paramObject, null, null);
    }

    private Token(Object paramObject, b paramb)
    {
      this(paramObject, paramb, null);
    }

    Token(Object paramObject, b paramb, Bundle paramBundle)
    {
      this.a = paramObject;
      this.b = paramb;
      this.c = paramBundle;
    }

    public static Token a(Object paramObject, b paramb)
    {
      if ((paramObject != null) && (Build.VERSION.SDK_INT >= 21))
        return new Token(d.a(paramObject), paramb);
      return null;
    }

    public final int describeContents()
    {
      return 0;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (!(paramObject instanceof Token))
        return false;
      Token localToken = (Token)paramObject;
      Object localObject1 = this.a;
      if (localObject1 == null)
        return localToken.a == null;
      Object localObject2 = localToken.a;
      if (localObject2 == null)
        return false;
      return localObject1.equals(localObject2);
    }

    public final int hashCode()
    {
      Object localObject = this.a;
      if (localObject == null)
        return 0;
      return localObject.hashCode();
    }

    public final void writeToParcel(Parcel paramParcel, int paramInt)
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        paramParcel.writeParcelable((Parcelable)this.a, paramInt);
        return;
      }
      paramParcel.writeStrongBinder((IBinder)this.a);
    }
  }

  public static abstract class a
  {
    private a a;
    final Object b;
    WeakReference<MediaSessionCompat.b> c;
    private boolean d;

    static
    {
      CoverageLogger.Log(58771456);
    }

    public a()
    {
      if (Build.VERSION.SDK_INT >= 24)
      {
        this.b = new f.b(new d());
        return;
      }
      if (Build.VERSION.SDK_INT >= 23)
      {
        this.b = new e.b(new c());
        return;
      }
      if (Build.VERSION.SDK_INT >= 21)
      {
        this.b = new d.b(new b());
        return;
      }
      this.b = null;
    }

    final void a(MediaSessionCompat.b paramb, Handler paramHandler)
    {
      this.c = new WeakReference(paramb);
      a locala = this.a;
      if (locala != null)
        locala.removeCallbacksAndMessages(null);
      this.a = new a(paramHandler.getLooper());
    }

    final void a(androidx.media.e.a parama)
    {
      if (!this.d)
        return;
      this.d = false;
      this.a.removeMessages(1);
      MediaSessionCompat.b localb = (MediaSessionCompat.b)this.c.get();
      if (localb == null)
        return;
      localb.b();
      localb.a(parama);
      localb.a(null);
    }

    public final boolean a(Intent paramIntent)
    {
      if (Build.VERSION.SDK_INT >= 27)
        return false;
      MediaSessionCompat.b localb = (MediaSessionCompat.b)this.c.get();
      if (localb != null)
      {
        if (this.a == null)
          return false;
        KeyEvent localKeyEvent = (KeyEvent)paramIntent.getParcelableExtra("android.intent.extra.KEY_EVENT");
        if (localKeyEvent != null)
        {
          if (localKeyEvent.getAction() != 0)
            return false;
          androidx.media.e.a locala = localb.c();
          int i = localKeyEvent.getKeyCode();
          if ((i != 79) && (i != 85))
          {
            a(locala);
            return false;
          }
          if (localKeyEvent.getRepeatCount() > 0)
          {
            a(locala);
            return true;
          }
          if (this.d)
          {
            this.a.removeMessages(1);
            this.d = false;
            localb.b();
            return true;
          }
          this.d = true;
          a locala1 = this.a;
          locala1.sendMessageDelayed(locala1.obtainMessage(1, locala), ViewConfiguration.getDoubleTapTimeout());
          return true;
        }
      }
      return false;
    }

    final class a extends Handler
    {
      static
      {
        CoverageLogger.Log(58533888);
      }

      a(Looper arg2)
      {
        super();
      }

      public final void handleMessage(Message paramMessage)
      {
        if (paramMessage.what == 1)
          MediaSessionCompat.a.this.a((androidx.media.e.a)paramMessage.obj);
      }
    }

    class b
      implements d.a
    {
      static
      {
        CoverageLogger.Log(58537984);
      }

      b()
      {
      }

      public final void a(Object paramObject)
      {
        RatingCompat.a(paramObject);
      }

      public final void a(String paramString, Bundle paramBundle)
      {
        MediaSessionCompat.a(paramBundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS"));
        if (paramString.equals("android.support.v4.media.session.action.PLAY_FROM_URI"))
        {
          paramBundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
          return;
        }
        if (!paramString.equals("android.support.v4.media.session.action.PREPARE"))
        {
          if (paramString.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID"))
          {
            paramBundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID");
            return;
          }
          if (paramString.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH"))
          {
            paramBundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY");
            return;
          }
          if (paramString.equals("android.support.v4.media.session.action.PREPARE_FROM_URI"))
          {
            paramBundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
            return;
          }
          if (paramString.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED"))
          {
            paramBundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED");
            return;
          }
          if (paramString.equals("android.support.v4.media.session.action.SET_REPEAT_MODE"))
          {
            paramBundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE");
            return;
          }
          if (paramString.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE"))
          {
            paramBundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE");
            return;
          }
          if (paramString.equals("android.support.v4.media.session.action.SET_RATING"))
            paramBundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_RATING");
        }
      }

      public final void a(String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver)
      {
        try
        {
          if (paramString.equals("android.support.v4.media.session.command.GET_EXTRA_BINDER"))
          {
            MediaSessionCompat.e locale2 = (MediaSessionCompat.e)MediaSessionCompat.a.this.c.get();
            if (locale2 != null)
            {
              Bundle localBundle = new Bundle();
              MediaSessionCompat.Token localToken = locale2.a();
              b localb = localToken.b;
              IBinder localIBinder;
              if (localb == null)
                localIBinder = null;
              else
                localIBinder = localb.asBinder();
              androidx.core.app.d.a(localBundle, "android.support.v4.media.session.EXTRA_BINDER", localIBinder);
              localBundle.putBundle("android.support.v4.media.session.SESSION_TOKEN2_BUNDLE", localToken.c);
              paramResultReceiver.send(0, localBundle);
            }
          }
          else
          {
            boolean bool1 = paramString.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM");
            if (bool1)
            {
              paramBundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION");
              return;
            }
            boolean bool2 = paramString.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT");
            if (bool2)
            {
              paramBundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION");
              paramBundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX");
              return;
            }
            if (paramString.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM"))
            {
              paramBundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION");
              return;
            }
            if (paramString.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT"))
            {
              MediaSessionCompat.e locale1 = (MediaSessionCompat.e)MediaSessionCompat.a.this.c.get();
              if ((locale1 != null) && (locale1.f != null))
              {
                int i = paramBundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX", -1);
                if ((i >= 0) && (i < locale1.f.size()))
                  locale1.f.get(i);
              }
            }
          }
        }
        catch (BadParcelableException localBadParcelableException)
        {
        }
      }

      public final boolean a(Intent paramIntent)
      {
        return MediaSessionCompat.a.this.a(paramIntent);
      }
    }

    class c extends MediaSessionCompat.a.b
      implements e.a
    {
      static
      {
        CoverageLogger.Log(58773504);
      }

      c()
      {
        super();
      }
    }

    final class d extends MediaSessionCompat.a.c
      implements f.a
    {
      static
      {
        CoverageLogger.Log(58523648);
      }

      d()
      {
        super();
      }
    }
  }

  static abstract interface b
  {
    static
    {
      CoverageLogger.Log(58775552);
    }

    public abstract MediaSessionCompat.Token a();

    public abstract void a(PendingIntent paramPendingIntent);

    public abstract void a(MediaSessionCompat.a parama, Handler paramHandler);

    public abstract void a(androidx.media.e.a parama);

    public abstract PlaybackStateCompat b();

    public abstract androidx.media.e.a c();
  }

  static class c extends MediaSessionCompat.g
  {
    private static boolean x = true;

    static
    {
      CoverageLogger.Log(58777600);
    }

    c(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent)
    {
      super(paramString, paramComponentName, paramPendingIntent);
    }

    public void a(MediaSessionCompat.a parama, Handler paramHandler)
    {
      super.a(parama, paramHandler);
      if (parama == null)
      {
        this.d.setPlaybackPositionUpdateListener(null);
        return;
      }
      RemoteControlClient.OnPlaybackPositionUpdateListener local1 = new RemoteControlClient.OnPlaybackPositionUpdateListener()
      {
        static
        {
          CoverageLogger.Log(58521600);
        }

        public final void onPlaybackPositionUpdate(long paramAnonymousLong)
        {
          MediaSessionCompat.c.this.a(18, -1, -1, Long.valueOf(paramAnonymousLong), null);
        }
      };
      this.d.setPlaybackPositionUpdateListener(local1);
    }
  }

  static final class d extends MediaSessionCompat.c
  {
    static
    {
      CoverageLogger.Log(58515456);
    }

    d(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent)
    {
      super(paramString, paramComponentName, paramPendingIntent);
    }

    public final void a(MediaSessionCompat.a parama, Handler paramHandler)
    {
      super.a(parama, paramHandler);
      if (parama == null)
      {
        this.d.setMetadataUpdateListener(null);
        return;
      }
      RemoteControlClient.OnMetadataUpdateListener local1 = new RemoteControlClient.OnMetadataUpdateListener()
      {
        static
        {
          CoverageLogger.Log(58517504);
        }

        public final void onMetadataUpdate(int paramAnonymousInt, Object paramAnonymousObject)
        {
          if ((paramAnonymousInt == 268435457) && ((paramAnonymousObject instanceof Rating)))
            MediaSessionCompat.d.this.a(19, -1, -1, RatingCompat.a(paramAnonymousObject), null);
        }
      };
      this.d.setMetadataUpdateListener(local1);
    }
  }

  static class e
    implements MediaSessionCompat.b
  {
    final Object a;
    final MediaSessionCompat.Token b;
    boolean c;
    final RemoteCallbackList<a> d = new RemoteCallbackList();
    PlaybackStateCompat e;
    List<MediaSessionCompat.QueueItem> f;
    MediaMetadataCompat g;
    int h;
    boolean i;
    int j;
    int k;

    static
    {
      CoverageLogger.Log(58513408);
    }

    e(Context paramContext, String paramString, Bundle paramBundle)
    {
      this.a = new MediaSession(paramContext, paramString);
      this.b = new MediaSessionCompat.Token(((MediaSession)this.a).getSessionToken(), new a(), paramBundle);
    }

    public final MediaSessionCompat.Token a()
    {
      return this.b;
    }

    public final void a(PendingIntent paramPendingIntent)
    {
      ((MediaSession)this.a).setMediaButtonReceiver(paramPendingIntent);
    }

    public final void a(MediaSessionCompat.a parama, Handler paramHandler)
    {
      Object localObject1 = this.a;
      Object localObject2;
      if (parama == null)
        localObject2 = null;
      else
        localObject2 = parama.b;
      ((MediaSession)localObject1).setCallback((MediaSession.Callback)localObject2, paramHandler);
      if (parama != null)
        parama.a(this, paramHandler);
    }

    public void a(androidx.media.e.a parama)
    {
    }

    public final PlaybackStateCompat b()
    {
      return this.e;
    }

    public androidx.media.e.a c()
    {
      return null;
    }

    final class a extends b.a
    {
      static
      {
        CoverageLogger.Log(58779648);
      }

      a()
      {
      }

      public final void a(int paramInt)
      {
        throw new AssertionError();
      }

      public final void a(int paramInt1, int paramInt2, String paramString)
      {
        throw new AssertionError();
      }

      public final void a(long paramLong)
      {
        throw new AssertionError();
      }

      public final void a(Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(MediaDescriptionCompat paramMediaDescriptionCompat)
      {
        throw new AssertionError();
      }

      public final void a(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt)
      {
        throw new AssertionError();
      }

      public final void a(RatingCompat paramRatingCompat)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(RatingCompat paramRatingCompat, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(a parama)
      {
        if (!MediaSessionCompat.e.this.c)
        {
          MediaSessionCompat.e locale = MediaSessionCompat.e.this;
          String str;
          if (Build.VERSION.SDK_INT < 24)
            str = null;
          else
            str = f.a(locale.a);
          if (str == null)
            str = "android.media.session.MediaController";
          androidx.media.e.a locala = new androidx.media.e.a(str, getCallingPid(), getCallingUid());
          MediaSessionCompat.e.this.d.register(parama, locala);
        }
      }

      public final void a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void a(String paramString, Bundle paramBundle, MediaSessionCompat.ResultReceiverWrapper paramResultReceiverWrapper)
      {
        throw new AssertionError();
      }

      public final void a(boolean paramBoolean)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final boolean a()
      {
        throw new AssertionError();
      }

      public final boolean a(KeyEvent paramKeyEvent)
      {
        throw new AssertionError();
      }

      public final String b()
      {
        throw new AssertionError();
      }

      public final void b(int paramInt)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void b(int paramInt1, int paramInt2, String paramString)
      {
        throw new AssertionError();
      }

      public final void b(long paramLong)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void b(Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void b(MediaDescriptionCompat paramMediaDescriptionCompat)
      {
        throw new AssertionError();
      }

      public final void b(a parama)
      {
        MediaSessionCompat.e.this.d.unregister(parama);
      }

      public final void b(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void b(boolean paramBoolean)
        throws RemoteException
      {
      }

      public final String c()
      {
        throw new AssertionError();
      }

      public final void c(int paramInt)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void c(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final PendingIntent d()
      {
        throw new AssertionError();
      }

      public final void d(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final long e()
      {
        throw new AssertionError();
      }

      public final void e(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final ParcelableVolumeInfo f()
      {
        throw new AssertionError();
      }

      public final MediaMetadataCompat g()
      {
        throw new AssertionError();
      }

      public final PlaybackStateCompat h()
      {
        return MediaSessionCompat.a(MediaSessionCompat.e.this.e, MediaSessionCompat.e.this.g);
      }

      public final List<MediaSessionCompat.QueueItem> i()
      {
        return null;
      }

      public final CharSequence j()
      {
        throw new AssertionError();
      }

      public final Bundle k()
      {
        throw new AssertionError();
      }

      public final int l()
      {
        return MediaSessionCompat.e.this.h;
      }

      public final boolean m()
      {
        return MediaSessionCompat.e.this.i;
      }

      public final int n()
      {
        return MediaSessionCompat.e.this.j;
      }

      public final boolean o()
      {
        return false;
      }

      public final int p()
      {
        return MediaSessionCompat.e.this.k;
      }

      public final void q()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void r()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void s()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void t()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void u()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void v()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void w()
        throws RemoteException
      {
        throw new AssertionError();
      }

      public final void x()
        throws RemoteException
      {
        throw new AssertionError();
      }
    }
  }

  static final class f extends MediaSessionCompat.e
  {
    static
    {
      CoverageLogger.Log(58509312);
    }

    f(Context paramContext, String paramString, Bundle paramBundle)
    {
      super(paramString, paramBundle);
    }

    public final void a(androidx.media.e.a parama)
    {
    }

    public final androidx.media.e.a c()
    {
      return new androidx.media.e.a(((MediaSession)this.a).getCurrentControllerInfo());
    }
  }

  static class g
    implements MediaSessionCompat.b
  {
    private final b A;
    private final MediaSessionCompat.Token B;
    private c C;
    private boolean D = false;
    private boolean E = false;
    private androidx.media.e.a F;
    private i.a G = new i.a()
    {
      static
      {
        CoverageLogger.Log(58505216);
      }
    };
    final String a;
    final String b;
    final AudioManager c;
    final RemoteControlClient d;
    final Object e = new Object();
    final RemoteCallbackList<a> f = new RemoteCallbackList();
    boolean g = false;
    boolean h = false;
    volatile MediaSessionCompat.a i;
    int j;
    MediaMetadataCompat k;
    PlaybackStateCompat l;
    PendingIntent m;
    List<MediaSessionCompat.QueueItem> n;
    CharSequence o;
    int p;
    boolean q;
    int r;
    int s;
    Bundle t;
    int u;
    int v;
    i w;
    private final Context x;
    private final ComponentName y;
    private final PendingIntent z;

    static
    {
      CoverageLogger.Log(58787840);
    }

    public g(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent)
    {
      if (paramComponentName != null)
      {
        this.x = paramContext;
        this.a = paramContext.getPackageName();
        this.c = ((AudioManager)paramContext.getSystemService("audio"));
        this.b = paramString;
        this.y = paramComponentName;
        this.z = paramPendingIntent;
        this.A = new b();
        this.B = new MediaSessionCompat.Token(this.A);
        this.p = 0;
        this.u = 1;
        this.v = 3;
        this.d = new RemoteControlClient(paramPendingIntent);
        return;
      }
      throw new IllegalArgumentException("MediaButtonReceiver component may not be null.");
    }

    public final MediaSessionCompat.Token a()
    {
      return this.B;
    }

    final void a(int paramInt1, int paramInt2)
    {
      if (this.u == 2)
      {
        if (this.w == null);
      }
      else
        this.c.adjustStreamVolume(this.v, paramInt1, paramInt2);
    }

    final void a(int paramInt1, int paramInt2, int paramInt3, Object paramObject, Bundle paramBundle)
    {
      synchronized (this.e)
      {
        if (this.C != null)
        {
          Message localMessage = this.C.obtainMessage(paramInt1, paramInt2, paramInt3, paramObject);
          Bundle localBundle = new Bundle();
          localBundle.putString("data_calling_pkg", "android.media.session.MediaController");
          localBundle.putInt("data_calling_pid", Binder.getCallingPid());
          localBundle.putInt("data_calling_uid", Binder.getCallingUid());
          if (paramBundle != null)
            localBundle.putBundle("data_extras", paramBundle);
          localMessage.setData(localBundle);
          localMessage.sendToTarget();
        }
        return;
      }
    }

    public final void a(PendingIntent paramPendingIntent)
    {
    }

    public void a(MediaSessionCompat.a parama, Handler paramHandler)
    {
      this.i = parama;
      if (parama != null)
      {
        if (paramHandler == null)
          paramHandler = new Handler();
        synchronized (this.e)
        {
          if (this.C != null)
            this.C.removeCallbacksAndMessages(null);
          this.C = new c(paramHandler.getLooper());
          this.i.a(this, paramHandler);
          return;
        }
      }
    }

    public final void a(androidx.media.e.a parama)
    {
      synchronized (this.e)
      {
        this.F = parama;
        return;
      }
    }

    public final PlaybackStateCompat b()
    {
      synchronized (this.e)
      {
        PlaybackStateCompat localPlaybackStateCompat = this.l;
        return localPlaybackStateCompat;
      }
    }

    final void b(int paramInt1, int paramInt2)
    {
      if (this.u == 2)
      {
        if (this.w == null);
      }
      else
        this.c.setStreamVolume(this.v, paramInt1, paramInt2);
    }

    public final androidx.media.e.a c()
    {
      synchronized (this.e)
      {
        androidx.media.e.a locala = this.F;
        return locala;
      }
    }

    static final class a
    {
      public final String a;
      public final Bundle b;
      public final ResultReceiver c;

      static
      {
        CoverageLogger.Log(58785792);
      }

      public a(String paramString, Bundle paramBundle, ResultReceiver paramResultReceiver)
      {
        this.a = paramString;
        this.b = paramBundle;
        this.c = paramResultReceiver;
      }
    }

    final class b extends b.a
    {
      static
      {
        CoverageLogger.Log(58783744);
      }

      b()
      {
      }

      private void a(int paramInt1, int paramInt2)
      {
        MediaSessionCompat.g.this.a(paramInt1, paramInt2, 0, null, null);
      }

      private void a(int paramInt, Object paramObject)
      {
        MediaSessionCompat.g.this.a(paramInt, 0, 0, paramObject, null);
      }

      private void a(int paramInt, Object paramObject, Bundle paramBundle)
      {
        MediaSessionCompat.g.this.a(paramInt, 0, 0, paramObject, paramBundle);
      }

      private void d(int paramInt)
      {
        MediaSessionCompat.g.this.a(paramInt, 0, 0, null, null);
      }

      public final void a(int paramInt)
      {
        a(28, paramInt);
      }

      public final void a(int paramInt1, int paramInt2, String paramString)
      {
        MediaSessionCompat.g.this.a(paramInt1, paramInt2);
      }

      public final void a(long paramLong)
      {
        a(11, Long.valueOf(paramLong));
      }

      public final void a(Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        a(6, paramUri, paramBundle);
      }

      public final void a(MediaDescriptionCompat paramMediaDescriptionCompat)
      {
        a(25, paramMediaDescriptionCompat);
      }

      public final void a(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt)
      {
        MediaSessionCompat.g.this.a(26, paramInt, 0, paramMediaDescriptionCompat, null);
      }

      public final void a(RatingCompat paramRatingCompat)
        throws RemoteException
      {
        a(19, paramRatingCompat);
      }

      public final void a(RatingCompat paramRatingCompat, Bundle paramBundle)
        throws RemoteException
      {
        a(31, paramRatingCompat, paramBundle);
      }

      public final void a(a parama)
      {
        if (MediaSessionCompat.g.this.g)
        {
          try
          {
            parama.a();
          }
          catch (Exception localException)
          {
          }
          return;
        }
        androidx.media.e.a locala = new androidx.media.e.a("android.media.session.MediaController", getCallingPid(), getCallingUid());
        MediaSessionCompat.g.this.f.register(parama, locala);
      }

      public final void a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        a(4, paramString, paramBundle);
      }

      public final void a(String paramString, Bundle paramBundle, MediaSessionCompat.ResultReceiverWrapper paramResultReceiverWrapper)
      {
        a(1, new MediaSessionCompat.g.a(paramString, paramBundle, paramResultReceiverWrapper.a));
      }

      public final void a(boolean paramBoolean)
        throws RemoteException
      {
        a(29, Boolean.valueOf(paramBoolean));
      }

      public final boolean a()
      {
        return (0x2 & MediaSessionCompat.g.this.j) != 0;
      }

      public final boolean a(KeyEvent paramKeyEvent)
      {
        int i = MediaSessionCompat.g.this.j;
        int j = 1;
        if ((i & j) == 0)
          j = 0;
        if (j != 0)
          a(21, paramKeyEvent);
        return j;
      }

      public final String b()
      {
        return MediaSessionCompat.g.this.a;
      }

      public final void b(int paramInt)
        throws RemoteException
      {
        a(23, paramInt);
      }

      public final void b(int paramInt1, int paramInt2, String paramString)
      {
        MediaSessionCompat.g.this.b(paramInt1, paramInt2);
      }

      public final void b(long paramLong)
        throws RemoteException
      {
        a(18, Long.valueOf(paramLong));
      }

      public final void b(Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        a(10, paramUri, paramBundle);
      }

      public final void b(MediaDescriptionCompat paramMediaDescriptionCompat)
      {
        a(27, paramMediaDescriptionCompat);
      }

      public final void b(a parama)
      {
        MediaSessionCompat.g.this.f.unregister(parama);
      }

      public final void b(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        a(5, paramString, paramBundle);
      }

      public final void b(boolean paramBoolean)
        throws RemoteException
      {
      }

      public final String c()
      {
        return MediaSessionCompat.g.this.b;
      }

      public final void c(int paramInt)
        throws RemoteException
      {
        a(30, paramInt);
      }

      public final void c(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        a(8, paramString, paramBundle);
      }

      public final PendingIntent d()
      {
        synchronized (MediaSessionCompat.g.this.e)
        {
          PendingIntent localPendingIntent = MediaSessionCompat.g.this.m;
          return localPendingIntent;
        }
      }

      public final void d(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        a(9, paramString, paramBundle);
      }

      public final long e()
      {
        synchronized (MediaSessionCompat.g.this.e)
        {
          long l = MediaSessionCompat.g.this.j;
          return l;
        }
      }

      public final void e(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        a(20, paramString, paramBundle);
      }

      public final ParcelableVolumeInfo f()
      {
        synchronized (MediaSessionCompat.g.this.e)
        {
          int i = MediaSessionCompat.g.this.u;
          int j = MediaSessionCompat.g.this.v;
          i locali = MediaSessionCompat.g.this.w;
          int n;
          int i1;
          int i2;
          if (i == 2)
          {
            int k = locali.a;
            int m = locali.b;
            n = locali.c;
            i1 = m;
            i2 = k;
          }
          else
          {
            int i3 = MediaSessionCompat.g.this.c.getStreamMaxVolume(j);
            int i4 = MediaSessionCompat.g.this.c.getStreamVolume(j);
            i1 = i3;
            n = i4;
            i2 = 2;
          }
          ParcelableVolumeInfo localParcelableVolumeInfo = new ParcelableVolumeInfo(i, j, i2, i1, n);
          return localParcelableVolumeInfo;
        }
      }

      public final MediaMetadataCompat g()
      {
        return MediaSessionCompat.g.this.k;
      }

      public final PlaybackStateCompat h()
      {
        synchronized (MediaSessionCompat.g.this.e)
        {
          PlaybackStateCompat localPlaybackStateCompat = MediaSessionCompat.g.this.l;
          MediaMetadataCompat localMediaMetadataCompat = MediaSessionCompat.g.this.k;
          return MediaSessionCompat.a(localPlaybackStateCompat, localMediaMetadataCompat);
        }
      }

      public final List<MediaSessionCompat.QueueItem> i()
      {
        synchronized (MediaSessionCompat.g.this.e)
        {
          List localList = MediaSessionCompat.g.this.n;
          return localList;
        }
      }

      public final CharSequence j()
      {
        return MediaSessionCompat.g.this.o;
      }

      public final Bundle k()
      {
        synchronized (MediaSessionCompat.g.this.e)
        {
          Bundle localBundle = MediaSessionCompat.g.this.t;
          return localBundle;
        }
      }

      public final int l()
      {
        return MediaSessionCompat.g.this.p;
      }

      public final boolean m()
      {
        return MediaSessionCompat.g.this.q;
      }

      public final int n()
      {
        return MediaSessionCompat.g.this.r;
      }

      public final boolean o()
      {
        return false;
      }

      public final int p()
      {
        return MediaSessionCompat.g.this.s;
      }

      public final void q()
        throws RemoteException
      {
        d(3);
      }

      public final void r()
        throws RemoteException
      {
        d(7);
      }

      public final void s()
        throws RemoteException
      {
        d(12);
      }

      public final void t()
        throws RemoteException
      {
        d(13);
      }

      public final void u()
        throws RemoteException
      {
        d(14);
      }

      public final void v()
        throws RemoteException
      {
        d(15);
      }

      public final void w()
        throws RemoteException
      {
        d(16);
      }

      public final void x()
        throws RemoteException
      {
        d(17);
      }
    }

    final class c extends Handler
    {
      static
      {
        CoverageLogger.Log(58503168);
      }

      public c(Looper arg2)
      {
        super();
      }

      public final void handleMessage(Message paramMessage)
      {
        MediaSessionCompat.a locala = MediaSessionCompat.g.this.i;
        if (locala == null)
          return;
        Bundle localBundle = paramMessage.getData();
        MediaSessionCompat.a(localBundle);
        MediaSessionCompat.g.this.a(new androidx.media.e.a(localBundle.getString("data_calling_pkg"), localBundle.getInt("data_calling_pid"), localBundle.getInt("data_calling_uid")));
        MediaSessionCompat.a(localBundle.getBundle("data_extras"));
        while (true)
          try
          {
            switch (paramMessage.what)
            {
            case 31:
              break;
            case 30:
              break;
            case 29:
              ((Boolean)paramMessage.obj).booleanValue();
              break;
            case 28:
              if ((MediaSessionCompat.g.this.n != null) && (paramMessage.arg1 >= 0) && (paramMessage.arg1 < MediaSessionCompat.g.this.n.size()))
                MediaSessionCompat.g.this.n.get(paramMessage.arg1);
              break;
            case 27:
              break;
            case 26:
              break;
            case 25:
              break;
            case 23:
              break;
            case 22:
              MediaSessionCompat.g.this.b(paramMessage.arg1, 0);
              break;
            case 21:
              KeyEvent localKeyEvent = (KeyEvent)paramMessage.obj;
              Intent localIntent = new Intent("android.intent.action.MEDIA_BUTTON");
              localIntent.putExtra("android.intent.extra.KEY_EVENT", localKeyEvent);
              if ((!locala.a(localIntent)) && (localKeyEvent != null) && (localKeyEvent.getAction() == 0))
                localKeyEvent.getKeyCode();
              break;
            case 20:
              break;
            case 19:
              break;
            case 18:
              ((Long)paramMessage.obj).longValue();
              break;
            case 11:
              ((Long)paramMessage.obj).longValue();
              break;
            case 10:
              break;
            case 9:
              break;
            case 8:
              break;
            case 6:
              break;
            case 5:
              break;
            case 4:
              break;
            case 2:
              MediaSessionCompat.g.this.a(paramMessage.arg1, 0);
              break;
            case 1:
            case 3:
            case 7:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
              return;
            case 24:
            }
          }
          finally
          {
            MediaSessionCompat.g.this.a(null);
          }
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.MediaSessionCompat
 * JD-Core Version:    0.6.2
 */