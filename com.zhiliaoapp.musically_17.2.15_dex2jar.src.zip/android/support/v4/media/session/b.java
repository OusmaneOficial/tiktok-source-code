package android.support.v4.media.session;

import android.app.PendingIntent;
import android.net.Uri;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.text.TextUtils;
import android.view.KeyEvent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.List;

public abstract interface b extends IInterface
{
  static
  {
    CoverageLogger.Log(58730496);
  }

  public abstract void a(int paramInt)
    throws RemoteException;

  public abstract void a(int paramInt1, int paramInt2, String paramString)
    throws RemoteException;

  public abstract void a(long paramLong)
    throws RemoteException;

  public abstract void a(Uri paramUri, Bundle paramBundle)
    throws RemoteException;

  public abstract void a(MediaDescriptionCompat paramMediaDescriptionCompat)
    throws RemoteException;

  public abstract void a(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt)
    throws RemoteException;

  public abstract void a(RatingCompat paramRatingCompat)
    throws RemoteException;

  public abstract void a(RatingCompat paramRatingCompat, Bundle paramBundle)
    throws RemoteException;

  public abstract void a(a parama)
    throws RemoteException;

  public abstract void a(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract void a(String paramString, Bundle paramBundle, MediaSessionCompat.ResultReceiverWrapper paramResultReceiverWrapper)
    throws RemoteException;

  public abstract void a(boolean paramBoolean)
    throws RemoteException;

  public abstract boolean a()
    throws RemoteException;

  public abstract boolean a(KeyEvent paramKeyEvent)
    throws RemoteException;

  public abstract String b()
    throws RemoteException;

  public abstract void b(int paramInt)
    throws RemoteException;

  public abstract void b(int paramInt1, int paramInt2, String paramString)
    throws RemoteException;

  public abstract void b(long paramLong)
    throws RemoteException;

  public abstract void b(Uri paramUri, Bundle paramBundle)
    throws RemoteException;

  public abstract void b(MediaDescriptionCompat paramMediaDescriptionCompat)
    throws RemoteException;

  public abstract void b(a parama)
    throws RemoteException;

  public abstract void b(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract void b(boolean paramBoolean)
    throws RemoteException;

  public abstract String c()
    throws RemoteException;

  public abstract void c(int paramInt)
    throws RemoteException;

  public abstract void c(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract PendingIntent d()
    throws RemoteException;

  public abstract void d(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract long e()
    throws RemoteException;

  public abstract void e(String paramString, Bundle paramBundle)
    throws RemoteException;

  public abstract ParcelableVolumeInfo f()
    throws RemoteException;

  public abstract MediaMetadataCompat g()
    throws RemoteException;

  public abstract PlaybackStateCompat h()
    throws RemoteException;

  public abstract List<MediaSessionCompat.QueueItem> i()
    throws RemoteException;

  public abstract CharSequence j()
    throws RemoteException;

  public abstract Bundle k()
    throws RemoteException;

  public abstract int l()
    throws RemoteException;

  public abstract boolean m()
    throws RemoteException;

  public abstract int n()
    throws RemoteException;

  public abstract boolean o()
    throws RemoteException;

  public abstract int p()
    throws RemoteException;

  public abstract void q()
    throws RemoteException;

  public abstract void r()
    throws RemoteException;

  public abstract void s()
    throws RemoteException;

  public abstract void t()
    throws RemoteException;

  public abstract void u()
    throws RemoteException;

  public abstract void v()
    throws RemoteException;

  public abstract void w()
    throws RemoteException;

  public abstract void x()
    throws RemoteException;

  public static abstract class a extends Binder
    implements b
  {
    static
    {
      CoverageLogger.Log(58724352);
    }

    public a()
    {
      attachInterface(this, "android.support.v4.media.session.IMediaSession");
    }

    public static b a(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.support.v4.media.session.IMediaSession");
      if ((localIInterface != null) && ((localIInterface instanceof b)))
        return (b)localIInterface;
      return new a(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      if (paramInt1 != 51)
      {
        if (paramInt1 != 1598968902)
        {
          switch (paramInt1)
          {
          default:
            return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
          case 48:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            c(paramParcel1.readInt());
            paramParcel2.writeNoException();
            return true;
          case 47:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i18 = p();
            paramParcel2.writeNoException();
            paramParcel2.writeInt(i18);
            return true;
          case 46:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i17 = paramParcel1.readInt();
            boolean bool2 = false;
            if (i17 != 0)
              bool2 = true;
            a(bool2);
            paramParcel2.writeNoException();
            return true;
          case 45:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i16 = m();
            paramParcel2.writeNoException();
            paramParcel2.writeInt(i16);
            return true;
          case 44:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            a(paramParcel1.readInt());
            paramParcel2.writeNoException();
            return true;
          case 43:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i15 = paramParcel1.readInt();
            MediaDescriptionCompat localMediaDescriptionCompat3 = null;
            if (i15 != 0)
              localMediaDescriptionCompat3 = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel1);
            b(localMediaDescriptionCompat3);
            paramParcel2.writeNoException();
            return true;
          case 42:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i14 = paramParcel1.readInt();
            MediaDescriptionCompat localMediaDescriptionCompat2 = null;
            if (i14 != 0)
              localMediaDescriptionCompat2 = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel1);
            a(localMediaDescriptionCompat2, paramParcel1.readInt());
            paramParcel2.writeNoException();
            return true;
          case 41:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i13 = paramParcel1.readInt();
            MediaDescriptionCompat localMediaDescriptionCompat1 = null;
            if (i13 != 0)
              localMediaDescriptionCompat1 = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel1);
            a(localMediaDescriptionCompat1);
            paramParcel2.writeNoException();
            return true;
          case 40:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i12 = paramParcel1.readInt();
            boolean bool1 = false;
            if (i12 != 0)
              bool1 = true;
            b(bool1);
            paramParcel2.writeNoException();
            return true;
          case 39:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            b(paramParcel1.readInt());
            paramParcel2.writeNoException();
            return true;
          case 38:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i11 = o();
            paramParcel2.writeNoException();
            paramParcel2.writeInt(i11);
            return true;
          case 37:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i10 = n();
            paramParcel2.writeNoException();
            paramParcel2.writeInt(i10);
            return true;
          case 36:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            Uri localUri2;
            if (paramParcel1.readInt() != 0)
              localUri2 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
            else
              localUri2 = null;
            int i9 = paramParcel1.readInt();
            Bundle localBundle10 = null;
            if (i9 != 0)
              localBundle10 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            a(localUri2, localBundle10);
            paramParcel2.writeNoException();
            return true;
          case 35:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            String str8 = paramParcel1.readString();
            int i8 = paramParcel1.readInt();
            Bundle localBundle9 = null;
            if (i8 != 0)
              localBundle9 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            b(str8, localBundle9);
            paramParcel2.writeNoException();
            return true;
          case 34:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            String str7 = paramParcel1.readString();
            int i7 = paramParcel1.readInt();
            Bundle localBundle8 = null;
            if (i7 != 0)
              localBundle8 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            a(str7, localBundle8);
            paramParcel2.writeNoException();
            return true;
          case 33:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            q();
            paramParcel2.writeNoException();
            return true;
          case 32:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i6 = l();
            paramParcel2.writeNoException();
            paramParcel2.writeInt(i6);
            return true;
          case 31:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            Bundle localBundle7 = k();
            paramParcel2.writeNoException();
            if (localBundle7 != null)
            {
              paramParcel2.writeInt(1);
              localBundle7.writeToParcel(paramParcel2, 1);
              return true;
            }
            paramParcel2.writeInt(0);
            return true;
          case 30:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            CharSequence localCharSequence = j();
            paramParcel2.writeNoException();
            if (localCharSequence != null)
            {
              paramParcel2.writeInt(1);
              TextUtils.writeToParcel(localCharSequence, paramParcel2, 1);
              return true;
            }
            paramParcel2.writeInt(0);
            return true;
          case 29:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            List localList = i();
            paramParcel2.writeNoException();
            paramParcel2.writeTypedList(localList);
            return true;
          case 28:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            PlaybackStateCompat localPlaybackStateCompat = h();
            paramParcel2.writeNoException();
            if (localPlaybackStateCompat != null)
            {
              paramParcel2.writeInt(1);
              localPlaybackStateCompat.writeToParcel(paramParcel2, 1);
              return true;
            }
            paramParcel2.writeInt(0);
            return true;
          case 27:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            MediaMetadataCompat localMediaMetadataCompat = g();
            paramParcel2.writeNoException();
            if (localMediaMetadataCompat != null)
            {
              paramParcel2.writeInt(1);
              localMediaMetadataCompat.writeToParcel(paramParcel2, 1);
              return true;
            }
            paramParcel2.writeInt(0);
            return true;
          case 26:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            String str6 = paramParcel1.readString();
            int i5 = paramParcel1.readInt();
            Bundle localBundle6 = null;
            if (i5 != 0)
              localBundle6 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            e(str6, localBundle6);
            paramParcel2.writeNoException();
            return true;
          case 25:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int i4 = paramParcel1.readInt();
            RatingCompat localRatingCompat2 = null;
            if (i4 != 0)
              localRatingCompat2 = (RatingCompat)RatingCompat.CREATOR.createFromParcel(paramParcel1);
            a(localRatingCompat2);
            paramParcel2.writeNoException();
            return true;
          case 24:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            b(paramParcel1.readLong());
            paramParcel2.writeNoException();
            return true;
          case 23:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            x();
            paramParcel2.writeNoException();
            return true;
          case 22:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            w();
            paramParcel2.writeNoException();
            return true;
          case 21:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            v();
            paramParcel2.writeNoException();
            return true;
          case 20:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            u();
            paramParcel2.writeNoException();
            return true;
          case 19:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            t();
            paramParcel2.writeNoException();
            return true;
          case 18:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            s();
            paramParcel2.writeNoException();
            return true;
          case 17:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            a(paramParcel1.readLong());
            paramParcel2.writeNoException();
            return true;
          case 16:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            Uri localUri1;
            if (paramParcel1.readInt() != 0)
              localUri1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
            else
              localUri1 = null;
            int i3 = paramParcel1.readInt();
            Bundle localBundle5 = null;
            if (i3 != 0)
              localBundle5 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            b(localUri1, localBundle5);
            paramParcel2.writeNoException();
            return true;
          case 15:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            String str5 = paramParcel1.readString();
            int i2 = paramParcel1.readInt();
            Bundle localBundle4 = null;
            if (i2 != 0)
              localBundle4 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            d(str5, localBundle4);
            paramParcel2.writeNoException();
            return true;
          case 14:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            String str4 = paramParcel1.readString();
            int i1 = paramParcel1.readInt();
            Bundle localBundle3 = null;
            if (i1 != 0)
              localBundle3 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
            c(str4, localBundle3);
            paramParcel2.writeNoException();
            return true;
          case 13:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            r();
            paramParcel2.writeNoException();
            return true;
          case 12:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            b(paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readString());
            paramParcel2.writeNoException();
            return true;
          case 11:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            a(paramParcel1.readInt(), paramParcel1.readInt(), paramParcel1.readString());
            paramParcel2.writeNoException();
            return true;
          case 10:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            ParcelableVolumeInfo localParcelableVolumeInfo = f();
            paramParcel2.writeNoException();
            if (localParcelableVolumeInfo != null)
            {
              paramParcel2.writeInt(1);
              localParcelableVolumeInfo.writeToParcel(paramParcel2, 1);
              return true;
            }
            paramParcel2.writeInt(0);
            return true;
          case 9:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            long l = e();
            paramParcel2.writeNoException();
            paramParcel2.writeLong(l);
            return true;
          case 8:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            PendingIntent localPendingIntent = d();
            paramParcel2.writeNoException();
            if (localPendingIntent != null)
            {
              paramParcel2.writeInt(1);
              localPendingIntent.writeToParcel(paramParcel2, 1);
              return true;
            }
            paramParcel2.writeInt(0);
            return true;
          case 7:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            String str3 = c();
            paramParcel2.writeNoException();
            paramParcel2.writeString(str3);
            return true;
          case 6:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            String str2 = b();
            paramParcel2.writeNoException();
            paramParcel2.writeString(str2);
            return true;
          case 5:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int n = a();
            paramParcel2.writeNoException();
            paramParcel2.writeInt(n);
            return true;
          case 4:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            b(a.a.a(paramParcel1.readStrongBinder()));
            paramParcel2.writeNoException();
            return true;
          case 3:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            a(a.a.a(paramParcel1.readStrongBinder()));
            paramParcel2.writeNoException();
            return true;
          case 2:
            paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
            int k = paramParcel1.readInt();
            KeyEvent localKeyEvent = null;
            if (k != 0)
              localKeyEvent = (KeyEvent)KeyEvent.CREATOR.createFromParcel(paramParcel1);
            int m = a(localKeyEvent);
            paramParcel2.writeNoException();
            paramParcel2.writeInt(m);
            return true;
          case 1:
          }
          paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
          String str1 = paramParcel1.readString();
          Bundle localBundle2;
          if (paramParcel1.readInt() != 0)
            localBundle2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
          else
            localBundle2 = null;
          int j = paramParcel1.readInt();
          MediaSessionCompat.ResultReceiverWrapper localResultReceiverWrapper = null;
          if (j != 0)
            localResultReceiverWrapper = (MediaSessionCompat.ResultReceiverWrapper)MediaSessionCompat.ResultReceiverWrapper.CREATOR.createFromParcel(paramParcel1);
          a(str1, localBundle2, localResultReceiverWrapper);
          paramParcel2.writeNoException();
          return true;
        }
        paramParcel2.writeString("android.support.v4.media.session.IMediaSession");
        return true;
      }
      paramParcel1.enforceInterface("android.support.v4.media.session.IMediaSession");
      RatingCompat localRatingCompat1;
      if (paramParcel1.readInt() != 0)
        localRatingCompat1 = (RatingCompat)RatingCompat.CREATOR.createFromParcel(paramParcel1);
      else
        localRatingCompat1 = null;
      int i = paramParcel1.readInt();
      Bundle localBundle1 = null;
      if (i != 0)
        localBundle1 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
      a(localRatingCompat1, localBundle1);
      paramParcel2.writeNoException();
      return true;
    }

    static final class a
      implements b
    {
      private IBinder a;

      static
      {
        CoverageLogger.Log(58710016);
      }

      a(IBinder paramIBinder)
      {
        this.a = paramIBinder;
      }

      public final void a(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeInt(paramInt);
          this.a.transact(44, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(int paramInt1, int paramInt2, String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeString(paramString);
          this.a.transact(11, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeLong(paramLong);
          this.a.transact(17, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (paramUri != null)
          {
            localParcel1.writeInt(1);
            paramUri.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(36, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(MediaDescriptionCompat paramMediaDescriptionCompat)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (paramMediaDescriptionCompat != null)
          {
            localParcel1.writeInt(1);
            paramMediaDescriptionCompat.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(41, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (paramMediaDescriptionCompat != null)
          {
            localParcel1.writeInt(1);
            paramMediaDescriptionCompat.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          localParcel1.writeInt(paramInt);
          this.a.transact(42, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(RatingCompat paramRatingCompat)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (paramRatingCompat != null)
          {
            localParcel1.writeInt(1);
            paramRatingCompat.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(25, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(RatingCompat paramRatingCompat, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (paramRatingCompat != null)
          {
            localParcel1.writeInt(1);
            paramRatingCompat.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(51, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(a parama)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              this.a.transact(3, localParcel1, localParcel2, 0);
              localParcel2.readException();
              return;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final void a(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(34, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(String paramString, Bundle paramBundle, MediaSessionCompat.ResultReceiverWrapper paramResultReceiverWrapper)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          if (paramResultReceiverWrapper != null)
          {
            localParcel1.writeInt(1);
            paramResultReceiverWrapper.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void a(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            if (paramBoolean)
            {
              i = 1;
              localParcel1.writeInt(i);
              this.a.transact(46, localParcel1, localParcel2, 0);
              localParcel2.readException();
              return;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          int i = 0;
        }
      }

      public final boolean a()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final boolean a(KeyEvent paramKeyEvent)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          int i = 1;
          if (paramKeyEvent != null)
          {
            localParcel1.writeInt(i);
            paramKeyEvent.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int j = localParcel2.readInt();
          if (j == 0)
            i = 0;
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final IBinder asBinder()
      {
        return this.a;
      }

      public final String b()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(6, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void b(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeInt(paramInt);
          this.a.transact(39, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void b(int paramInt1, int paramInt2, String paramString)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeInt(paramInt1);
          localParcel1.writeInt(paramInt2);
          localParcel1.writeString(paramString);
          this.a.transact(12, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void b(long paramLong)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeLong(paramLong);
          this.a.transact(24, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void b(Uri paramUri, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (paramUri != null)
          {
            localParcel1.writeInt(1);
            paramUri.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(16, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void b(MediaDescriptionCompat paramMediaDescriptionCompat)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          if (paramMediaDescriptionCompat != null)
          {
            localParcel1.writeInt(1);
            paramMediaDescriptionCompat.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(43, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void b(a parama)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            if (parama != null)
            {
              localIBinder = parama.asBinder();
              localParcel1.writeStrongBinder(localIBinder);
              this.a.transact(4, localParcel1, localParcel2, 0);
              localParcel2.readException();
              return;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          IBinder localIBinder = null;
        }
      }

      public final void b(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(35, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void b(boolean paramBoolean)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        while (true)
        {
          try
          {
            localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
            if (paramBoolean)
            {
              i = 1;
              localParcel1.writeInt(i);
              this.a.transact(40, localParcel1, localParcel2, 0);
              localParcel2.readException();
              return;
            }
          }
          finally
          {
            localParcel2.recycle();
            localParcel1.recycle();
          }
          int i = 0;
        }
      }

      public final String c()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(7, localParcel1, localParcel2, 0);
          localParcel2.readException();
          String str = localParcel2.readString();
          return str;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void c(int paramInt)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeInt(paramInt);
          this.a.transact(48, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void c(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(14, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final PendingIntent d()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(8, localParcel1, localParcel2, 0);
          localParcel2.readException();
          PendingIntent localPendingIntent;
          if (localParcel2.readInt() != 0)
            localPendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel(localParcel2);
          else
            localPendingIntent = null;
          return localPendingIntent;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void d(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(15, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final long e()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(9, localParcel1, localParcel2, 0);
          localParcel2.readException();
          long l = localParcel2.readLong();
          return l;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void e(String paramString, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          localParcel1.writeString(paramString);
          if (paramBundle != null)
          {
            localParcel1.writeInt(1);
            paramBundle.writeToParcel(localParcel1, 0);
          }
          else
          {
            localParcel1.writeInt(0);
          }
          this.a.transact(26, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final ParcelableVolumeInfo f()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(10, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ParcelableVolumeInfo localParcelableVolumeInfo;
          if (localParcel2.readInt() != 0)
            localParcelableVolumeInfo = (ParcelableVolumeInfo)ParcelableVolumeInfo.CREATOR.createFromParcel(localParcel2);
          else
            localParcelableVolumeInfo = null;
          return localParcelableVolumeInfo;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final MediaMetadataCompat g()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(27, localParcel1, localParcel2, 0);
          localParcel2.readException();
          MediaMetadataCompat localMediaMetadataCompat;
          if (localParcel2.readInt() != 0)
            localMediaMetadataCompat = (MediaMetadataCompat)MediaMetadataCompat.CREATOR.createFromParcel(localParcel2);
          else
            localMediaMetadataCompat = null;
          return localMediaMetadataCompat;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final PlaybackStateCompat h()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(28, localParcel1, localParcel2, 0);
          localParcel2.readException();
          PlaybackStateCompat localPlaybackStateCompat;
          if (localParcel2.readInt() != 0)
            localPlaybackStateCompat = (PlaybackStateCompat)PlaybackStateCompat.CREATOR.createFromParcel(localParcel2);
          else
            localPlaybackStateCompat = null;
          return localPlaybackStateCompat;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final List<MediaSessionCompat.QueueItem> i()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(29, localParcel1, localParcel2, 0);
          localParcel2.readException();
          ArrayList localArrayList = localParcel2.createTypedArrayList(MediaSessionCompat.QueueItem.CREATOR);
          return localArrayList;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final CharSequence j()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(30, localParcel1, localParcel2, 0);
          localParcel2.readException();
          CharSequence localCharSequence;
          if (localParcel2.readInt() != 0)
            localCharSequence = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(localParcel2);
          else
            localCharSequence = null;
          return localCharSequence;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final Bundle k()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(31, localParcel1, localParcel2, 0);
          localParcel2.readException();
          Bundle localBundle;
          if (localParcel2.readInt() != 0)
            localBundle = (Bundle)Bundle.CREATOR.createFromParcel(localParcel2);
          else
            localBundle = null;
          return localBundle;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final int l()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(32, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final boolean m()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(45, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final int n()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(37, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final boolean o()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(38, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          boolean bool = false;
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final int p()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(47, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          return i;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void q()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(33, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void r()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(13, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void s()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(18, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void t()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(19, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void u()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(20, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void v()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(21, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void w()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(22, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public final void x()
        throws RemoteException
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("android.support.v4.media.session.IMediaSession");
          this.a.transact(23, localParcel1, localParcel2, 0);
          localParcel2.readException();
          return;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.media.session.b
 * JD-Core Version:    0.6.2
 */