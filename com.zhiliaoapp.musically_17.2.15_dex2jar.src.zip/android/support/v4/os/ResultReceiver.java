package android.support.v4.os;

import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class ResultReceiver
  implements Parcelable
{
  public static final Parcelable.Creator<ResultReceiver> CREATOR = new Parcelable.Creator()
  {
    static
    {
      CoverageLogger.Log(46911488);
    }
  };
  final boolean a;
  final Handler b;
  a c;

  static
  {
    CoverageLogger.Log(46622720);
  }

  ResultReceiver(Parcel paramParcel)
  {
    IBinder localIBinder = paramParcel.readStrongBinder();
    Object localObject;
    if (localIBinder == null)
    {
      localObject = null;
    }
    else
    {
      IInterface localIInterface = localIBinder.queryLocalInterface("android.support.v4.os.IResultReceiver");
      if ((localIInterface != null) && ((localIInterface instanceof a)))
        localObject = (a)localIInterface;
      else
        localObject = new a.a.a(localIBinder);
    }
    this.c = ((a)localObject);
  }

  protected void a(int paramInt, Bundle paramBundle)
  {
  }

  public final void b(int paramInt, Bundle paramBundle)
  {
    if (this.a)
    {
      Handler localHandler = this.b;
      if (localHandler != null)
      {
        localHandler.post(new b(paramInt, paramBundle));
        return;
      }
      a(paramInt, paramBundle);
      return;
    }
    a locala = this.c;
    if (locala != null);
    try
    {
      locala.a(paramInt, paramBundle);
    }
    catch (RemoteException localRemoteException)
    {
    }
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    try
    {
      if (this.c == null)
        this.c = new a();
      paramParcel.writeStrongBinder(this.c.asBinder());
      return;
    }
    finally
    {
    }
  }

  final class a extends a.a
  {
    static
    {
      CoverageLogger.Log(46913536);
    }

    a()
    {
    }

    public final void a(int paramInt, Bundle paramBundle)
    {
      if (ResultReceiver.this.b != null)
      {
        ResultReceiver.this.b.post(new ResultReceiver.b(ResultReceiver.this, paramInt, paramBundle));
        return;
      }
      ResultReceiver.this.a(paramInt, paramBundle);
    }
  }

  final class b
    implements Runnable
  {
    final int a;
    final Bundle b;

    static
    {
      CoverageLogger.Log(46915584);
    }

    b(int paramBundle, Bundle arg3)
    {
      this.a = paramBundle;
      Object localObject;
      this.b = localObject;
    }

    public final void run()
    {
      ResultReceiver.this.a(this.a, this.b);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.os.ResultReceiver
 * JD-Core Version:    0.6.2
 */