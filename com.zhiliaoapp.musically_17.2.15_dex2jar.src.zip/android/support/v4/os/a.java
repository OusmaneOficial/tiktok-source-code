package android.support.v4.os;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a extends IInterface
{
  static
  {
    CoverageLogger.Log(46628864);
  }

  public abstract void a(int paramInt, Bundle paramBundle)
    throws RemoteException;

  public static abstract class a extends Binder
    implements a
  {
    static
    {
      CoverageLogger.Log(46630912);
    }

    public a()
    {
      attachInterface(this, "android.support.v4.os.IResultReceiver");
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      if (paramInt1 != 1)
      {
        if (paramInt1 != 1598968902)
          return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
        paramParcel2.writeString("android.support.v4.os.IResultReceiver");
        return true;
      }
      paramParcel1.enforceInterface("android.support.v4.os.IResultReceiver");
      int i = paramParcel1.readInt();
      Bundle localBundle;
      if (paramParcel1.readInt() != 0)
        localBundle = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);
      else
        localBundle = null;
      a(i, localBundle);
      return true;
    }

    static final class a
      implements a
    {
      private IBinder a;

      static
      {
        CoverageLogger.Log(46909440);
      }

      a(IBinder paramIBinder)
      {
        this.a = paramIBinder;
      }

      public final void a(int paramInt, Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.os.IResultReceiver");
          localParcel.writeInt(paramInt);
          if (paramBundle != null)
          {
            localParcel.writeInt(1);
            paramBundle.writeToParcel(localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final IBinder asBinder()
      {
        return this.a;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.os.a
 * JD-Core Version:    0.6.2
 */