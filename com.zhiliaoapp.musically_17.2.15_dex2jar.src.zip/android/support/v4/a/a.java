package android.support.v4.a;

import android.app.Notification;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a extends IInterface
{
  static
  {
    CoverageLogger.Log(46903296);
  }

  public abstract void a(String paramString)
    throws RemoteException;

  public abstract void a(String paramString1, int paramInt, String paramString2)
    throws RemoteException;

  public abstract void a(String paramString1, int paramInt, String paramString2, Notification paramNotification)
    throws RemoteException;

  public static abstract class a extends Binder
    implements a
  {
    static
    {
      CoverageLogger.Log(46641152);
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      if (paramInt1 != 1)
      {
        if (paramInt1 != 2)
        {
          if (paramInt1 != 3)
          {
            if (paramInt1 != 1598968902)
              return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
            paramParcel2.writeString("android.support.v4.app.INotificationSideChannel");
            return true;
          }
          paramParcel1.enforceInterface("android.support.v4.app.INotificationSideChannel");
          a(paramParcel1.readString());
          return true;
        }
        paramParcel1.enforceInterface("android.support.v4.app.INotificationSideChannel");
        a(paramParcel1.readString(), paramParcel1.readInt(), paramParcel1.readString());
        return true;
      }
      paramParcel1.enforceInterface("android.support.v4.app.INotificationSideChannel");
      String str1 = paramParcel1.readString();
      int i = paramParcel1.readInt();
      String str2 = paramParcel1.readString();
      Notification localNotification;
      if (paramParcel1.readInt() != 0)
        localNotification = (Notification)Notification.CREATOR.createFromParcel(paramParcel1);
      else
        localNotification = null;
      a(str1, i, str2, localNotification);
      return true;
    }

    public static final class a
      implements a
    {
      private IBinder a;

      static
      {
        CoverageLogger.Log(46899200);
      }

      public a(IBinder paramIBinder)
      {
        this.a = paramIBinder;
      }

      public final void a(String paramString)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.app.INotificationSideChannel");
          localParcel.writeString(paramString);
          this.a.transact(3, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(String paramString1, int paramInt, String paramString2)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.app.INotificationSideChannel");
          localParcel.writeString(paramString1);
          localParcel.writeInt(paramInt);
          localParcel.writeString(paramString2);
          this.a.transact(2, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final void a(String paramString1, int paramInt, String paramString2, Notification paramNotification)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("android.support.v4.app.INotificationSideChannel");
          localParcel.writeString(paramString1);
          localParcel.writeInt(paramInt);
          localParcel.writeString(paramString2);
          if (paramNotification != null)
          {
            localParcel.writeInt(1);
            paramNotification.writeToParcel(localParcel, 0);
          }
          else
          {
            localParcel.writeInt(0);
          }
          this.a.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public final IBinder asBinder()
      {
        return this.a;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.support.v4.a.a
 * JD-Core Version:    0.6.2
 */