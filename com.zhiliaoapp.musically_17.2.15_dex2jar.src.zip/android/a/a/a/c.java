package android.a.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface c
{
  static
  {
    CoverageLogger.Log(65120256);
  }

  public abstract int a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.a.a.a.c
 * JD-Core Version:    0.6.2
 */