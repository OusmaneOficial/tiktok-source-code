package android.a.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public enum f
{
  private int a;

  static
  {
    CoverageLogger.Log(65128448);
    BEGIN = new f("BEGIN", 0, 1);
    END = new f("END", 1, 2);
    f[] arrayOff = new f[2];
    arrayOff[0] = BEGIN;
    arrayOff[1] = END;
  }

  private f(int paramInt)
  {
    this.a = paramInt;
  }

  public final int getStatus()
  {
    return this.a;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.a.a.a.f
 * JD-Core Version:    0.6.2
 */