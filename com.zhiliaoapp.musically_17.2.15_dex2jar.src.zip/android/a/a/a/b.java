package android.a.a.a;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory.Options;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface b
{
  static
  {
    CoverageLogger.Log(65116160);
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(65114112);
    }

    public abstract Bitmap a(int paramInt1, long paramLong, int paramInt2, int paramInt3, BitmapFactory.Options paramOptions);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.a.a.a.b
 * JD-Core Version:    0.6.2
 */