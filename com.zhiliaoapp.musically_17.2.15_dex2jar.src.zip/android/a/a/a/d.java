package android.a.a.a;

import android.a.a.a.a.a;
import android.a.a.a.a.b;
import android.os.Bundle;
import android.util.SparseIntArray;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class d
{
  private static volatile d a;
  private SparseIntArray b = new SparseIntArray();
  private android.a.a.a.a.c c = new b();

  static
  {
    CoverageLogger.Log(65122304);
  }

  private boolean a(c paramc, f paramf, Bundle paramBundle)
  {
    try
    {
      android.a.a.a.a.c localc = this.c;
      if (localc == null)
        return false;
      try
      {
        if (this.b.get(paramc.a()) != paramf.getStatus())
        {
          this.b.put(paramc.a(), paramf.getStatus());
          return false;
        }
      }
      finally
      {
        return false;
      }
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public static d b()
  {
    if (a == null)
      try
      {
        if (a == null)
          a = new d();
      }
      finally
      {
      }
    return a;
  }

  public final b.a a()
  {
    try
    {
      boolean bool = this.c instanceof a;
      if (!bool);
    }
    finally
    {
    }
    return null;
  }

  public final void a(long paramLong)
  {
    try
    {
      android.a.a.a.a.c localc = this.c;
      if (localc == null)
        return;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public final boolean a(c paramc, f paramf)
  {
    return a(paramc, paramf, null);
  }

  public final void b(long paramLong)
  {
    try
    {
      android.a.a.a.a.c localc = this.c;
      if (localc == null)
        return;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.a.a.a.d
 * JD-Core Version:    0.6.2
 */