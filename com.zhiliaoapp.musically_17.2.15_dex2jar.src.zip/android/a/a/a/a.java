package android.a.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a
{
  public static final e a = new e(1, "app start");
  public static final e b = new e(2, "open camera");
  public static final e c = new e(3, "window switch");
  public static final e d = new e(4, "data transfer");
  public static final e e = new e(5, "page loading");
  public static final e f = new e(6, "video loading");
  public static final e g = new e(7, "video parse");
  public static final e h = new e(9, "instance message");
  public static final e i = new e(10, "tab switch");
  public static final e j = new e(11, "living");
  public static final e k = new e(12, "thread priority promote");
  public static final e l = new e(14, "first frame");
  public static final e m = new e(13, "video frame fetch");
  public static final e n = new e(15, "model loading");
  public static final e o = new e(16, "fake sound");
  public static final e p = new e(17, "sound denoise");
  public static final e q = new e(18, "reverse play");
  public static final e r = new e(7, "video parse and upload");

  static
  {
    CoverageLogger.Log(65112064);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.a.a.a.a
 * JD-Core Version:    0.6.2
 */