package android.view;

import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintLayout.LayoutParams;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a extends View
{
  static
  {
    CoverageLogger.Log(65138688);
  }

  public static ViewGroup.MarginLayoutParams a(ViewGroup paramViewGroup, int paramInt1, int paramInt2)
  {
    if ((paramViewGroup instanceof RelativeLayout))
      return new RelativeLayout.LayoutParams(paramInt1, paramInt2);
    if ((paramViewGroup instanceof LinearLayout))
      return new LinearLayout.LayoutParams(paramInt1, paramInt2);
    if ((paramViewGroup instanceof FrameLayout))
      return new FrameLayout.LayoutParams(paramInt1, paramInt2);
    if ((paramViewGroup instanceof ConstraintLayout))
      return new ConstraintLayout.LayoutParams(paramInt1, paramInt2);
    return new ViewGroup.MarginLayoutParams(paramInt1, paramInt2);
  }

  public static void a(View paramView)
  {
    paramView.onFinishInflate();
  }

  public static void a(View paramView, int paramInt)
  {
    ((TextView)paramView).setMinWidth(paramInt);
  }

  public static void b(View paramView, int paramInt)
  {
    ((TextView)paramView).setMinHeight(paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     android.view.a
 * JD-Core Version:    0.6.2
 */