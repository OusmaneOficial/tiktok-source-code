package androidx.g.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public final class a
{
  private static final Object f = new Object();
  private static a g;
  final Context a;
  final HashMap<BroadcastReceiver, ArrayList<b>> b = new HashMap();
  final ArrayList<a> c = new ArrayList();
  private final HashMap<String, ArrayList<b>> d = new HashMap();
  private final Handler e;

  static
  {
    CoverageLogger.Log(115167232);
  }

  private a(Context paramContext)
  {
    this.a = paramContext;
    this.e = new Handler(paramContext.getMainLooper())
    {
      static
      {
        CoverageLogger.Log(115163136);
      }

      public final void handleMessage(Message paramAnonymousMessage)
      {
        if (paramAnonymousMessage.what != 1)
        {
          super.handleMessage(paramAnonymousMessage);
          return;
        }
        a locala = a.this;
        synchronized (locala.b)
        {
          a.a[] arrayOfa;
          int j;
          do
          {
            int i = locala.c.size();
            if (i <= 0)
              return;
            arrayOfa = new a.a[i];
            locala.c.toArray(arrayOfa);
            locala.c.clear();
            j = 0;
          }
          while (j >= arrayOfa.length);
          a.a locala1 = arrayOfa[j];
          int k = locala1.b.size();
          for (int m = 0; m < k; m++)
          {
            a.b localb = (a.b)locala1.b.get(m);
            if (!localb.d)
              localb.b.onReceive(locala.a, locala1.a);
          }
          j++;
        }
        while (true)
          throw localObject;
      }
    };
  }

  public static a a(Context paramContext)
  {
    synchronized (f)
    {
      if (g == null)
        g = new a(paramContext.getApplicationContext());
      a locala = g;
      return locala;
    }
  }

  public final void a(BroadcastReceiver paramBroadcastReceiver)
  {
    int i;
    int j;
    int k;
    label200: label206: synchronized (this.b)
    {
      ArrayList localArrayList1 = (ArrayList)this.b.remove(paramBroadcastReceiver);
      if (localArrayList1 == null)
        return;
      i = localArrayList1.size() - 1;
      if (i >= 0)
      {
        b localb1 = (b)localArrayList1.get(i);
        localb1.d = true;
        j = 0;
        if (j >= localb1.a.countActions())
          break label206;
        String str = localb1.a.getAction(j);
        ArrayList localArrayList2 = (ArrayList)this.d.get(str);
        if (localArrayList2 == null)
          break label200;
        k = localArrayList2.size() - 1;
        if (k >= 0)
        {
          b localb2 = (b)localArrayList2.get(k);
          if (localb2.b == paramBroadcastReceiver)
          {
            localb2.d = true;
            localArrayList2.remove(k);
          }
        }
        else
        {
          if (localArrayList2.size() > 0)
            break label200;
          this.d.remove(str);
          break label200;
        }
      }
      else
      {
        return;
      }
    }
  }

  public final void a(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter)
  {
    synchronized (this.b)
    {
      b localb = new b(paramIntentFilter, paramBroadcastReceiver);
      ArrayList localArrayList1 = (ArrayList)this.b.get(paramBroadcastReceiver);
      if (localArrayList1 == null)
      {
        localArrayList1 = new ArrayList(1);
        this.b.put(paramBroadcastReceiver, localArrayList1);
      }
      localArrayList1.add(localb);
      for (int i = 0; i < paramIntentFilter.countActions(); i++)
      {
        String str = paramIntentFilter.getAction(i);
        ArrayList localArrayList2 = (ArrayList)this.d.get(str);
        if (localArrayList2 == null)
        {
          localArrayList2 = new ArrayList(1);
          this.d.put(str, localArrayList2);
        }
        localArrayList2.add(localb);
      }
      return;
    }
    while (true)
      throw localObject;
  }

  public final boolean a(Intent paramIntent)
  {
    Object localObject2;
    Object localObject3;
    Object localObject4;
    Object localObject5;
    int i;
    int k;
    Object localObject7;
    Object localObject8;
    Object localObject9;
    Object localObject10;
    int j;
    Object localObject6;
    label316: label323: label327: label348: synchronized (this.b)
    {
      localObject2 = paramIntent.getAction();
      localObject3 = paramIntent.resolveTypeIfNeeded(this.a.getContentResolver());
      Uri localUri = paramIntent.getData();
      String str = paramIntent.getScheme();
      Set localSet = paramIntent.getCategories();
      if ((0x8 & paramIntent.getFlags()) != 0)
      {
        localObject4 = (ArrayList)this.d.get(paramIntent.getAction());
        if (localObject4 != null)
        {
          localObject5 = null;
          i = 0;
          if (i >= ((ArrayList)localObject4).size())
            break label348;
          b localb = (b)((ArrayList)localObject4).get(i);
          if (localb.c)
          {
            k = i;
            localObject7 = localObject4;
            localObject8 = localObject2;
            localObject9 = localObject3;
            localObject10 = localObject5;
            break label323;
          }
          IntentFilter localIntentFilter = localb.a;
          Object localObject11 = localObject2;
          Object localObject12 = localObject3;
          localObject8 = localObject2;
          localObject10 = localObject5;
          k = i;
          localObject7 = localObject4;
          localObject9 = localObject3;
          if (localIntentFilter.match(localObject11, localObject12, str, localUri, localSet, "LocalBroadcastManager") < 0)
            break label323;
          if (localObject10 != null)
            break label316;
          localObject5 = new ArrayList();
          ((ArrayList)localObject5).add(localb);
          localb.c = true;
          break label327;
          while (j < ((ArrayList)localObject6).size())
          {
            ((b)((ArrayList)localObject6).get(j)).c = false;
            j++;
          }
          this.c.add(new a(paramIntent, (ArrayList)localObject6));
          if (!this.e.hasMessages(1))
            this.e.sendEmptyMessage(1);
          return true;
        }
        return false;
      }
    }
  }

  static final class a
  {
    final Intent a;
    final ArrayList<a.b> b;

    static
    {
      CoverageLogger.Log(114870272);
    }

    a(Intent paramIntent, ArrayList<a.b> paramArrayList)
    {
      this.a = paramIntent;
      this.b = paramArrayList;
    }
  }

  static final class b
  {
    final IntentFilter a;
    final BroadcastReceiver b;
    boolean c;
    boolean d;

    static
    {
      CoverageLogger.Log(114864128);
    }

    b(IntentFilter paramIntentFilter, BroadcastReceiver paramBroadcastReceiver)
    {
      this.a = paramIntentFilter;
      this.b = paramBroadcastReceiver;
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder(128);
      localStringBuilder.append("Receiver{");
      localStringBuilder.append(this.b);
      localStringBuilder.append(" filter=");
      localStringBuilder.append(this.a);
      if (this.d)
        localStringBuilder.append(" DEAD");
      localStringBuilder.append("}");
      return localStringBuilder.toString();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.g.a.a
 * JD-Core Version:    0.6.2
 */