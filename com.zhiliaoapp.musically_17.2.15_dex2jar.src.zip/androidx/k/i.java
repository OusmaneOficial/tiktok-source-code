package androidx.k;

import android.animation.TypeEvaluator;
import android.graphics.Rect;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class i
  implements TypeEvaluator<Rect>
{
  private Rect a;

  static
  {
    CoverageLogger.Log(33955840);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.i
 * JD-Core Version:    0.6.2
 */