package androidx.k;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Picture;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class r
{
  private static final boolean a;
  private static final boolean b;
  private static final boolean c = bool1;

  static
  {
    CoverageLogger.Log(34013184);
    int i = Build.VERSION.SDK_INT;
    boolean bool1 = true;
    boolean bool2;
    if (i >= 19)
      bool2 = true;
    else
      bool2 = false;
    a = bool2;
    boolean bool3;
    if (Build.VERSION.SDK_INT >= 18)
      bool3 = true;
    else
      bool3 = false;
    b = bool3;
    if (Build.VERSION.SDK_INT < 28)
      bool1 = false;
  }

  static View a(ViewGroup paramViewGroup, View paramView1, View paramView2)
  {
    Matrix localMatrix = new Matrix();
    localMatrix.setTranslate(-paramView2.getScrollX(), -paramView2.getScrollY());
    ae.a.a(paramView1, localMatrix);
    ae.a.b(paramViewGroup, localMatrix);
    RectF localRectF = new RectF(0.0F, 0.0F, paramView1.getWidth(), paramView1.getHeight());
    localMatrix.mapRect(localRectF);
    int i = Math.round(localRectF.left);
    int j = Math.round(localRectF.top);
    int k = Math.round(localRectF.right);
    int m = Math.round(localRectF.bottom);
    ImageView localImageView = new ImageView(paramView1.getContext());
    localImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
    boolean bool1;
    if (a)
    {
      bool1 = true ^ paramView1.isAttachedToWindow();
      if (paramViewGroup != null)
      {
        bool2 = paramViewGroup.isAttachedToWindow();
        break label165;
      }
    }
    else
    {
      bool1 = false;
    }
    boolean bool2 = false;
    label165: ViewGroup localViewGroup;
    int n;
    if ((b) && (bool1))
    {
      if (!bool2)
      {
        localBitmap = null;
        break label435;
      }
      localViewGroup = (ViewGroup)paramView1.getParent();
      n = localViewGroup.indexOfChild(paramView1);
      paramViewGroup.getOverlay().add(paramView1);
    }
    else
    {
      localViewGroup = null;
      n = 0;
    }
    int i1 = Math.round(localRectF.width());
    int i2 = Math.round(localRectF.height());
    Bitmap localBitmap = null;
    if (i1 > 0)
    {
      localBitmap = null;
      if (i2 > 0)
      {
        float f = Math.min(1.0F, 1048576.0F / (i1 * i2));
        int i3 = Math.round(f * i1);
        int i4 = Math.round(f * i2);
        localMatrix.postTranslate(-localRectF.left, -localRectF.top);
        localMatrix.postScale(f, f);
        if (c)
        {
          Picture localPicture = new Picture();
          Canvas localCanvas1 = localPicture.beginRecording(i3, i4);
          localCanvas1.concat(localMatrix);
          paramView1.draw(localCanvas1);
          localPicture.endRecording();
          localBitmap = Bitmap.createBitmap(localPicture);
        }
        else
        {
          localBitmap = Bitmap.createBitmap(i3, i4, Bitmap.Config.ARGB_8888);
          Canvas localCanvas2 = new Canvas(localBitmap);
          localCanvas2.concat(localMatrix);
          paramView1.draw(localCanvas2);
        }
      }
    }
    if ((b) && (bool1))
    {
      paramViewGroup.getOverlay().remove(paramView1);
      localViewGroup.addView(paramView1, n);
    }
    label435: if (localBitmap != null)
      localImageView.setImageBitmap(localBitmap);
    localImageView.measure(View.MeasureSpec.makeMeasureSpec(k - i, 1073741824), View.MeasureSpec.makeMeasureSpec(m - j, 1073741824));
    localImageView.layout(i, j, k, m);
    return localImageView;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.r
 * JD-Core Version:    0.6.2
 */