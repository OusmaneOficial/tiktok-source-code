package androidx.k;

import android.os.Build.VERSION;
import android.view.ViewGroup;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class y
{
  static
  {
    CoverageLogger.Log(34027520);
  }

  static void a(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 18)
    {
      aa.a(paramViewGroup, paramBoolean);
      return;
    }
    z.a(paramViewGroup, paramBoolean);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.y
 * JD-Core Version:    0.6.2
 */