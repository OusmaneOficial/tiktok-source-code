package androidx.k;

import android.graphics.Path;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class g
{
  static
  {
    CoverageLogger.Log(33794048);
  }

  public abstract Path a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.g
 * JD-Core Version:    0.6.2
 */