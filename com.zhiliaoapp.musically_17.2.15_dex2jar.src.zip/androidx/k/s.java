package androidx.k;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class s
{
  public final Map<String, Object> a = new HashMap();
  public View b;
  final ArrayList<m> c = new ArrayList();

  static
  {
    CoverageLogger.Log(33732608);
  }

  public final boolean equals(Object paramObject)
  {
    if ((paramObject instanceof s))
    {
      View localView = this.b;
      s locals = (s)paramObject;
      if ((localView == locals.b) && (this.a.equals(locals.a)))
        return true;
    }
    return false;
  }

  public final int hashCode()
  {
    return 31 * this.b.hashCode() + this.a.hashCode();
  }

  public final String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder("TransitionValues@");
    localStringBuilder1.append(Integer.toHexString(hashCode()));
    localStringBuilder1.append(":\n");
    String str1 = localStringBuilder1.toString();
    StringBuilder localStringBuilder2 = new StringBuilder();
    localStringBuilder2.append(str1);
    localStringBuilder2.append("    view = ");
    localStringBuilder2.append(this.b);
    localStringBuilder2.append("\n");
    String str2 = localStringBuilder2.toString();
    StringBuilder localStringBuilder3 = new StringBuilder();
    localStringBuilder3.append(str2);
    localStringBuilder3.append("    values:");
    String str3 = localStringBuilder3.toString();
    Iterator localIterator = this.a.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str4 = (String)localIterator.next();
      StringBuilder localStringBuilder4 = new StringBuilder();
      localStringBuilder4.append(str3);
      localStringBuilder4.append("    ");
      localStringBuilder4.append(str4);
      localStringBuilder4.append(": ");
      localStringBuilder4.append(this.a.get(str4));
      localStringBuilder4.append("\n");
      str3 = localStringBuilder4.toString();
    }
    return str3;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.s
 * JD-Core Version:    0.6.2
 */