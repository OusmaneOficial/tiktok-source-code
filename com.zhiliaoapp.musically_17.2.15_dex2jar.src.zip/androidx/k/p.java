package androidx.k;

import android.view.ViewGroup;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class p
{
  static
  {
    CoverageLogger.Log(34009088);
  }

  public abstract long a(ViewGroup paramViewGroup, m paramm, s params1, s params2);

  public abstract void a(s params);

  public abstract String[] a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.p
 * JD-Core Version:    0.6.2
 */