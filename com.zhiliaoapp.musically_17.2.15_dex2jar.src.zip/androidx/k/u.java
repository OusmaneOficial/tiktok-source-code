package androidx.k;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class u
{
  static
  {
    CoverageLogger.Log(33728512);
  }

  static Animator a(View paramView, s params, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, TimeInterpolator paramTimeInterpolator)
  {
    float f1 = paramView.getTranslationX();
    float f2 = paramView.getTranslationY();
    int[] arrayOfInt = (int[])params.b.getTag(2131302261);
    float f3;
    float f4;
    if (arrayOfInt != null)
    {
      f3 = f1 + (arrayOfInt[0] - paramInt1);
      f4 = f2 + (arrayOfInt[1] - paramInt2);
    }
    else
    {
      f3 = paramFloat1;
      f4 = paramFloat2;
    }
    int i = paramInt1 + Math.round(f3 - f1);
    int j = paramInt2 + Math.round(f4 - f2);
    paramView.setTranslationX(f3);
    paramView.setTranslationY(f4);
    if ((f3 == paramFloat3) && (f4 == paramFloat4))
      return null;
    PropertyValuesHolder[] arrayOfPropertyValuesHolder = new PropertyValuesHolder[2];
    arrayOfPropertyValuesHolder[0] = PropertyValuesHolder.ofFloat(View.TRANSLATION_X, new float[] { f3, paramFloat3 });
    arrayOfPropertyValuesHolder[1] = PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, new float[] { f4, paramFloat4 });
    ObjectAnimator localObjectAnimator = ObjectAnimator.ofPropertyValuesHolder(paramView, arrayOfPropertyValuesHolder);
    a locala = new a(paramView, params.b, i, j, f1, f2);
    localObjectAnimator.addListener(locala);
    a.a(localObjectAnimator, locala);
    localObjectAnimator.setInterpolator(paramTimeInterpolator);
    return localObjectAnimator;
  }

  static final class a extends AnimatorListenerAdapter
  {
    private final View a;
    private final View b;
    private final int c;
    private final int d;
    private int[] e;
    private float f;
    private float g;
    private final float h;
    private final float i;

    static
    {
      CoverageLogger.Log(34017280);
    }

    a(View paramView1, View paramView2, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2)
    {
      this.b = paramView1;
      this.a = paramView2;
      this.c = (paramInt1 - Math.round(this.b.getTranslationX()));
      this.d = (paramInt2 - Math.round(this.b.getTranslationY()));
      this.h = paramFloat1;
      this.i = paramFloat2;
      this.e = ((int[])this.a.getTag(2131302261));
      if (this.e != null)
        this.a.setTag(2131302261, null);
    }

    public final void onAnimationCancel(Animator paramAnimator)
    {
      if (this.e == null)
        this.e = new int[2];
      this.e[0] = Math.round(this.c + this.b.getTranslationX());
      this.e[1] = Math.round(this.d + this.b.getTranslationY());
      this.a.setTag(2131302261, this.e);
    }

    public final void onAnimationEnd(Animator paramAnimator)
    {
      this.b.setTranslationX(this.h);
      this.b.setTranslationY(this.i);
    }

    public final void onAnimationPause(Animator paramAnimator)
    {
      this.f = this.b.getTranslationX();
      this.g = this.b.getTranslationY();
      this.b.setTranslationX(this.h);
      this.b.setTranslationY(this.i);
    }

    public final void onAnimationResume(Animator paramAnimator)
    {
      this.b.setTranslationX(this.f);
      this.b.setTranslationY(this.g);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.u
 * JD-Core Version:    0.6.2
 */