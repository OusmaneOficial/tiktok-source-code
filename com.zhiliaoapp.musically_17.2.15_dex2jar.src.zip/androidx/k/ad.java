package androidx.k;

import android.graphics.drawable.Drawable;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

abstract interface ad
{
  static
  {
    CoverageLogger.Log(33705984);
  }

  public abstract void a(Drawable paramDrawable);

  public abstract void b(Drawable paramDrawable);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.ad
 * JD-Core Version:    0.6.2
 */