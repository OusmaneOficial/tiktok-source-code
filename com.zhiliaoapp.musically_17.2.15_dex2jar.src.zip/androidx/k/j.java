package androidx.k;

import android.view.View;
import android.view.ViewGroup;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class j
{
  public ViewGroup a;
  public Runnable b;

  static
  {
    CoverageLogger.Log(33957888);
  }

  static j a(View paramView)
  {
    return (j)paramView.getTag(2131302259);
  }

  static void a(View paramView, j paramj)
  {
    paramView.setTag(2131302259, null);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.j
 * JD-Core Version:    0.6.2
 */