package androidx.k;

import android.animation.LayoutTransition;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

final class z
{
  private static LayoutTransition a;
  private static Field b;
  private static boolean c;
  private static Method d;
  private static boolean e;

  static
  {
    CoverageLogger.Log(33716224);
  }

  private static void a(LayoutTransition paramLayoutTransition)
  {
    if (!e)
    {
      try
      {
        Method localMethod2 = LayoutTransition.class.getDeclaredMethod("cancel", new Class[0]);
        d = localMethod2;
        localMethod2.setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
      }
      e = true;
    }
    Method localMethod1 = d;
    if (localMethod1 != null);
    try
    {
      localMethod1.invoke(paramLayoutTransition, new Object[0]);
    }
    catch (IllegalAccessException|InvocationTargetException localIllegalAccessException)
    {
    }
  }

  // ERROR //
  static void a(android.view.ViewGroup paramViewGroup, boolean paramBoolean)
  {
    // Byte code:
    //   0: getstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   3: ifnonnull +53 -> 56
    //   6: new 60	androidx/k/z$1
    //   9: dup
    //   10: invokespecial 63	androidx/k/z$1:<init>	()V
    //   13: astore_2
    //   14: aload_2
    //   15: putstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   18: aload_2
    //   19: iconst_2
    //   20: aconst_null
    //   21: invokevirtual 67	android/animation/LayoutTransition:setAnimator	(ILandroid/animation/Animator;)V
    //   24: getstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   27: iconst_0
    //   28: aconst_null
    //   29: invokevirtual 67	android/animation/LayoutTransition:setAnimator	(ILandroid/animation/Animator;)V
    //   32: getstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   35: iconst_1
    //   36: aconst_null
    //   37: invokevirtual 67	android/animation/LayoutTransition:setAnimator	(ILandroid/animation/Animator;)V
    //   40: getstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   43: iconst_3
    //   44: aconst_null
    //   45: invokevirtual 67	android/animation/LayoutTransition:setAnimator	(ILandroid/animation/Animator;)V
    //   48: getstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   51: iconst_4
    //   52: aconst_null
    //   53: invokevirtual 67	android/animation/LayoutTransition:setAnimator	(ILandroid/animation/Animator;)V
    //   56: iload_1
    //   57: ifeq +51 -> 108
    //   60: aload_0
    //   61: invokevirtual 73	android/view/ViewGroup:getLayoutTransition	()Landroid/animation/LayoutTransition;
    //   64: astore 10
    //   66: aload 10
    //   68: ifnull +32 -> 100
    //   71: aload 10
    //   73: invokevirtual 77	android/animation/LayoutTransition:isRunning	()Z
    //   76: ifeq +8 -> 84
    //   79: aload 10
    //   81: invokestatic 79	androidx/k/z:a	(Landroid/animation/LayoutTransition;)V
    //   84: aload 10
    //   86: getstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   89: if_acmpeq +11 -> 100
    //   92: aload_0
    //   93: ldc 80
    //   95: aload 10
    //   97: invokevirtual 84	android/view/ViewGroup:setTag	(ILjava/lang/Object;)V
    //   100: aload_0
    //   101: getstatic 58	androidx/k/z:a	Landroid/animation/LayoutTransition;
    //   104: invokevirtual 87	android/view/ViewGroup:setLayoutTransition	(Landroid/animation/LayoutTransition;)V
    //   107: return
    //   108: aload_0
    //   109: aconst_null
    //   110: invokevirtual 87	android/view/ViewGroup:setLayoutTransition	(Landroid/animation/LayoutTransition;)V
    //   113: getstatic 89	androidx/k/z:c	Z
    //   116: ifne +31 -> 147
    //   119: ldc 69
    //   121: ldc 91
    //   123: invokevirtual 95	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   126: astore 9
    //   128: aload 9
    //   130: putstatic 97	androidx/k/z:b	Ljava/lang/reflect/Field;
    //   133: aload 9
    //   135: iconst_1
    //   136: invokevirtual 100	java/lang/reflect/Field:setAccessible	(Z)V
    //   139: goto +4 -> 143
    //   142: pop
    //   143: iconst_1
    //   144: putstatic 89	androidx/k/z:c	Z
    //   147: getstatic 97	androidx/k/z:b	Ljava/lang/reflect/Field;
    //   150: astore_3
    //   151: iconst_0
    //   152: istore 4
    //   154: aload_3
    //   155: ifnull +34 -> 189
    //   158: aload_3
    //   159: aload_0
    //   160: invokevirtual 104	java/lang/reflect/Field:getBoolean	(Ljava/lang/Object;)Z
    //   163: istore 6
    //   165: iload 6
    //   167: ifeq +14 -> 181
    //   170: getstatic 97	androidx/k/z:b	Ljava/lang/reflect/Field;
    //   173: aload_0
    //   174: iconst_0
    //   175: invokevirtual 108	java/lang/reflect/Field:setBoolean	(Ljava/lang/Object;Z)V
    //   178: goto +4 -> 182
    //   181: pop
    //   182: iload 6
    //   184: istore 4
    //   186: goto +3 -> 189
    //   189: iload 4
    //   191: ifeq +7 -> 198
    //   194: aload_0
    //   195: invokevirtual 111	android/view/ViewGroup:requestLayout	()V
    //   198: aload_0
    //   199: ldc 80
    //   201: invokevirtual 115	android/view/ViewGroup:getTag	(I)Ljava/lang/Object;
    //   204: checkcast 33	android/animation/LayoutTransition
    //   207: astore 5
    //   209: aload 5
    //   211: ifnull +16 -> 227
    //   214: aload_0
    //   215: ldc 80
    //   217: aconst_null
    //   218: invokevirtual 84	android/view/ViewGroup:setTag	(ILjava/lang/Object;)V
    //   221: aload_0
    //   222: aload 5
    //   224: invokevirtual 87	android/view/ViewGroup:setLayoutTransition	(Landroid/animation/LayoutTransition;)V
    //   227: return
    //
    // Exception table:
    //   from	to	target	type
    //   119	139	142	java/lang/NoSuchFieldException
    //   170	178	181	java/lang/IllegalAccessException
    //   158	165	189	java/lang/IllegalAccessException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.z
 * JD-Core Version:    0.6.2
 */