package androidx.k;

import android.view.ViewGroup;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

final class aa
{
  private static Method a;
  private static boolean b;

  static
  {
    CoverageLogger.Log(34039808);
  }

  private static void a()
  {
    if (!b)
    {
      try
      {
        Class[] arrayOfClass = new Class[1];
        arrayOfClass[0] = Boolean.TYPE;
        Method localMethod = ViewGroup.class.getDeclaredMethod("suppressLayout", arrayOfClass);
        a = localMethod;
        localMethod.setAccessible(true);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
      }
      b = true;
    }
  }

  static void a(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    a();
    Method localMethod = a;
    if (localMethod != null);
    try
    {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Boolean.valueOf(paramBoolean);
      localMethod.invoke(paramViewGroup, arrayOfObject);
    }
    catch (IllegalAccessException|InvocationTargetException localIllegalAccessException)
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.aa
 * JD-Core Version:    0.6.2
 */