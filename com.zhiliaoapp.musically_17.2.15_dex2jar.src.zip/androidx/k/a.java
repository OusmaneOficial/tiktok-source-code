package androidx.k;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class a
{
  static
  {
    CoverageLogger.Log(33904640);
  }

  static void a(Animator paramAnimator, AnimatorListenerAdapter paramAnimatorListenerAdapter)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramAnimator.addPauseListener(paramAnimatorListenerAdapter);
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(33847296);
    }

    public abstract void onAnimationPause(Animator paramAnimator);

    public abstract void onAnimationResume(Animator paramAnimator);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.a
 * JD-Core Version:    0.6.2
 */