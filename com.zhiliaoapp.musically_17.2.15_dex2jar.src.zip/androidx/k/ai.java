package androidx.k;

import android.graphics.Matrix;
import android.view.View;
import android.view.ViewParent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

class ai
{
  static
  {
    CoverageLogger.Log(33695744);
  }

  public float a(View paramView)
  {
    Float localFloat = (Float)paramView.getTag(2131301202);
    if (localFloat != null)
      return paramView.getAlpha() / localFloat.floatValue();
    return paramView.getAlpha();
  }

  public void a(View paramView, float paramFloat)
  {
    Float localFloat = (Float)paramView.getTag(2131301202);
    if (localFloat != null)
    {
      paramView.setAlpha(paramFloat * localFloat.floatValue());
      return;
    }
    paramView.setAlpha(paramFloat);
  }

  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.setLeft(paramInt1);
    paramView.setTop(paramInt2);
    paramView.setRight(paramInt3);
    paramView.setBottom(paramInt4);
  }

  public void a(View paramView, Matrix paramMatrix)
  {
    ViewParent localViewParent = paramView.getParent();
    if ((localViewParent instanceof View))
    {
      View localView = (View)localViewParent;
      a(localView, paramMatrix);
      paramMatrix.preTranslate(-localView.getScrollX(), -localView.getScrollY());
    }
    paramMatrix.preTranslate(paramView.getLeft(), paramView.getTop());
    Matrix localMatrix = paramView.getMatrix();
    if (!localMatrix.isIdentity())
      paramMatrix.preConcat(localMatrix);
  }

  public void b(View paramView)
  {
    if (paramView.getTag(2131301202) == null)
      paramView.setTag(2131301202, Float.valueOf(paramView.getAlpha()));
  }

  public void b(View paramView, Matrix paramMatrix)
  {
    ViewParent localViewParent = paramView.getParent();
    if ((localViewParent instanceof View))
    {
      View localView = (View)localViewParent;
      b(localView, paramMatrix);
      paramMatrix.postTranslate(localView.getScrollX(), localView.getScrollY());
    }
    paramMatrix.postTranslate(paramView.getLeft(), paramView.getTop());
    Matrix localMatrix1 = paramView.getMatrix();
    if (!localMatrix1.isIdentity())
    {
      Matrix localMatrix2 = new Matrix();
      if (localMatrix1.invert(localMatrix2))
        paramMatrix.postConcat(localMatrix2);
    }
  }

  public void c(View paramView)
  {
    if (paramView.getVisibility() == 0)
      paramView.setTag(2131301202, null);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.k.ai
 * JD-Core Version:    0.6.2
 */