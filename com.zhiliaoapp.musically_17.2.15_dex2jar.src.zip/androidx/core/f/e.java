package androidx.core.f;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Locale;

public final class e
{
  public static final d a = new e(null, false);
  public static final d b = new e(null, true);
  public static final d c = new e(b.a, false);
  public static final d d = new e(b.a, true);
  public static final d e = new e(a.a, false);
  public static final d f = f.a;

  static
  {
    CoverageLogger.Log(46319616);
  }

  static final class a
    implements e.c
  {
    static final a a = new a(true);
    static final a b = new a(false);
    private final boolean c;

    static
    {
      CoverageLogger.Log(46573568);
    }

    private a(boolean paramBoolean)
    {
      this.c = paramBoolean;
    }

    public final int a(CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      int i = paramInt2 + paramInt1;
      int j = 0;
      int k;
      while (true)
      {
        k = 2;
        if (paramInt1 >= i)
          break;
        int m = Character.getDirectionality(paramCharSequence.charAt(paramInt1));
        if (m != 0)
        {
          if ((m == 1) || (m == k))
            k = 0;
        }
        else
          k = 1;
        if (k != 0)
        {
          if (k != 1)
            break label94;
          if (!this.c)
            return 1;
        }
        else if (this.c)
        {
          return 0;
        }
        j = 1;
        label94: paramInt1++;
      }
      if (j != 0)
      {
        if (this.c)
          return 1;
        return 0;
      }
      return k;
    }
  }

  static final class b
    implements e.c
  {
    static final b a = new b();

    static
    {
      CoverageLogger.Log(46329856);
    }

    public final int a(CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      int i = paramInt2 + paramInt1;
      int j = 2;
      while ((paramInt1 < i) && (j == 2))
      {
        int k = Character.getDirectionality(paramCharSequence.charAt(paramInt1));
        if (k != 0)
        {
          if ((k != 1) && (k != 2));
          switch (k)
          {
          default:
            j = 2;
            break;
          case 16:
          case 17:
            j = 0;
            break;
          case 14:
          case 15:
          }
        }
        else
        {
          j = 1;
        }
        paramInt1++;
      }
      return j;
    }
  }

  static abstract interface c
  {
    static
    {
      CoverageLogger.Log(46575616);
    }

    public abstract int a(CharSequence paramCharSequence, int paramInt1, int paramInt2);
  }

  static abstract class d
    implements d
  {
    private final e.c a;

    static
    {
      CoverageLogger.Log(46325760);
    }

    d(e.c paramc)
    {
      this.a = paramc;
    }

    protected abstract boolean a();

    public final boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2)
    {
      if ((paramCharSequence != null) && (paramInt2 >= 0) && (paramCharSequence.length() - paramInt2 >= 0))
      {
        e.c localc = this.a;
        if (localc == null)
          return a();
        int i = localc.a(paramCharSequence, 0, paramInt2);
        if (i != 0)
        {
          if (i != 1)
            return a();
          return false;
        }
        return true;
      }
      throw new IllegalArgumentException();
    }
  }

  static final class e extends e.d
  {
    private final boolean a;

    static
    {
      CoverageLogger.Log(46577664);
    }

    e(e.c paramc, boolean paramBoolean)
    {
      super();
      this.a = paramBoolean;
    }

    protected final boolean a()
    {
      return this.a;
    }
  }

  static final class f extends e.d
  {
    static final f a = new f();

    static
    {
      CoverageLogger.Log(46581760);
    }

    f()
    {
      super();
    }

    protected final boolean a()
    {
      return f.a(Locale.getDefault()) == 1;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.f.e
 * JD-Core Version:    0.6.2
 */