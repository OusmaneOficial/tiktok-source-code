package androidx.core.f;

import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.LocaleList;
import android.text.PrecomputedText;
import android.text.PrecomputedText.Params;
import android.text.PrecomputedText.Params.Builder;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import androidx.core.g.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Locale;
import java.util.concurrent.Executor;

public final class c
  implements Spannable
{
  private static final Object b = new Object();
  private static Executor c = null;
  public final a a;
  private final Spannable d;
  private final PrecomputedText e;

  static
  {
    CoverageLogger.Log(46569472);
  }

  public final PrecomputedText a()
  {
    Spannable localSpannable = this.d;
    if ((localSpannable instanceof PrecomputedText))
      return (PrecomputedText)localSpannable;
    return null;
  }

  public final char charAt(int paramInt)
  {
    return this.d.charAt(paramInt);
  }

  public final int getSpanEnd(Object paramObject)
  {
    return this.d.getSpanEnd(paramObject);
  }

  public final int getSpanFlags(Object paramObject)
  {
    return this.d.getSpanFlags(paramObject);
  }

  public final int getSpanStart(Object paramObject)
  {
    return this.d.getSpanStart(paramObject);
  }

  public final <T> T[] getSpans(int paramInt1, int paramInt2, Class<T> paramClass)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return this.e.getSpans(paramInt1, paramInt2, paramClass);
    return this.d.getSpans(paramInt1, paramInt2, paramClass);
  }

  public final int length()
  {
    return this.d.length();
  }

  public final int nextSpanTransition(int paramInt1, int paramInt2, Class paramClass)
  {
    return this.d.nextSpanTransition(paramInt1, paramInt2, paramClass);
  }

  public final void removeSpan(Object paramObject)
  {
    if (!(paramObject instanceof MetricAffectingSpan))
    {
      if (Build.VERSION.SDK_INT >= 28)
      {
        this.e.removeSpan(paramObject);
        return;
      }
      this.d.removeSpan(paramObject);
      return;
    }
    throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
  }

  public final void setSpan(Object paramObject, int paramInt1, int paramInt2, int paramInt3)
  {
    if (!(paramObject instanceof MetricAffectingSpan))
    {
      if (Build.VERSION.SDK_INT >= 28)
      {
        this.e.setSpan(paramObject, paramInt1, paramInt2, paramInt3);
        return;
      }
      this.d.setSpan(paramObject, paramInt1, paramInt2, paramInt3);
      return;
    }
    throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
  }

  public final CharSequence subSequence(int paramInt1, int paramInt2)
  {
    return this.d.subSequence(paramInt1, paramInt2);
  }

  public final String toString()
  {
    return this.d.toString();
  }

  public static final class a
  {
    public final TextPaint a;
    public final TextDirectionHeuristic b;
    public final int c;
    public final int d;
    final PrecomputedText.Params e;

    static
    {
      CoverageLogger.Log(46561280);
    }

    public a(PrecomputedText.Params paramParams)
    {
      this.a = paramParams.getTextPaint();
      this.b = paramParams.getTextDirection();
      this.c = paramParams.getBreakStrategy();
      this.d = paramParams.getHyphenationFrequency();
      this.e = paramParams;
    }

    a(TextPaint paramTextPaint, TextDirectionHeuristic paramTextDirectionHeuristic, int paramInt1, int paramInt2)
    {
      if (Build.VERSION.SDK_INT >= 28)
        this.e = new PrecomputedText.Params.Builder(paramTextPaint).setBreakStrategy(paramInt1).setHyphenationFrequency(paramInt2).setTextDirection(paramTextDirectionHeuristic).build();
      else
        this.e = null;
      this.a = paramTextPaint;
      this.b = paramTextDirectionHeuristic;
      this.c = paramInt1;
      this.d = paramInt2;
    }

    public final boolean equals(Object paramObject)
    {
      if (paramObject == this)
        return true;
      if (paramObject != null)
      {
        if (!(paramObject instanceof a))
          return false;
        a locala = (a)paramObject;
        PrecomputedText.Params localParams = this.e;
        if (localParams != null)
          return localParams.equals(locala.e);
        if (Build.VERSION.SDK_INT >= 23)
        {
          if (this.c != locala.c)
            return false;
          if (this.d != locala.d)
            return false;
        }
        if ((Build.VERSION.SDK_INT >= 18) && (this.b != locala.b))
          return false;
        if (this.a.getTextSize() != locala.a.getTextSize())
          return false;
        if (this.a.getTextScaleX() != locala.a.getTextScaleX())
          return false;
        if (this.a.getTextSkewX() != locala.a.getTextSkewX())
          return false;
        if (Build.VERSION.SDK_INT >= 21)
        {
          if (this.a.getLetterSpacing() != locala.a.getLetterSpacing())
            return false;
          if (!TextUtils.equals(this.a.getFontFeatureSettings(), locala.a.getFontFeatureSettings()))
            return false;
        }
        if (this.a.getFlags() != locala.a.getFlags())
          return false;
        if (Build.VERSION.SDK_INT >= 24)
        {
          if (!this.a.getTextLocales().equals(locala.a.getTextLocales()))
            return false;
        }
        else if ((Build.VERSION.SDK_INT >= 17) && (!this.a.getTextLocale().equals(locala.a.getTextLocale())))
          return false;
        if (this.a.getTypeface() == null)
        {
          if (locala.a.getTypeface() != null)
            return false;
        }
        else if (!this.a.getTypeface().equals(locala.a.getTypeface()))
          return false;
        return true;
      }
      return false;
    }

    public final int hashCode()
    {
      if (Build.VERSION.SDK_INT >= 24)
      {
        Object[] arrayOfObject5 = new Object[11];
        arrayOfObject5[0] = Float.valueOf(this.a.getTextSize());
        arrayOfObject5[1] = Float.valueOf(this.a.getTextScaleX());
        arrayOfObject5[2] = Float.valueOf(this.a.getTextSkewX());
        arrayOfObject5[3] = Float.valueOf(this.a.getLetterSpacing());
        arrayOfObject5[4] = Integer.valueOf(this.a.getFlags());
        arrayOfObject5[5] = this.a.getTextLocales();
        arrayOfObject5[6] = this.a.getTypeface();
        arrayOfObject5[7] = Boolean.valueOf(this.a.isElegantTextHeight());
        arrayOfObject5[8] = this.b;
        arrayOfObject5[9] = Integer.valueOf(this.c);
        arrayOfObject5[10] = Integer.valueOf(this.d);
        return d.a(arrayOfObject5);
      }
      if (Build.VERSION.SDK_INT >= 21)
      {
        Object[] arrayOfObject4 = new Object[11];
        arrayOfObject4[0] = Float.valueOf(this.a.getTextSize());
        arrayOfObject4[1] = Float.valueOf(this.a.getTextScaleX());
        arrayOfObject4[2] = Float.valueOf(this.a.getTextSkewX());
        arrayOfObject4[3] = Float.valueOf(this.a.getLetterSpacing());
        arrayOfObject4[4] = Integer.valueOf(this.a.getFlags());
        arrayOfObject4[5] = this.a.getTextLocale();
        arrayOfObject4[6] = this.a.getTypeface();
        arrayOfObject4[7] = Boolean.valueOf(this.a.isElegantTextHeight());
        arrayOfObject4[8] = this.b;
        arrayOfObject4[9] = Integer.valueOf(this.c);
        arrayOfObject4[10] = Integer.valueOf(this.d);
        return d.a(arrayOfObject4);
      }
      if (Build.VERSION.SDK_INT >= 18)
      {
        Object[] arrayOfObject3 = new Object[9];
        arrayOfObject3[0] = Float.valueOf(this.a.getTextSize());
        arrayOfObject3[1] = Float.valueOf(this.a.getTextScaleX());
        arrayOfObject3[2] = Float.valueOf(this.a.getTextSkewX());
        arrayOfObject3[3] = Integer.valueOf(this.a.getFlags());
        arrayOfObject3[4] = this.a.getTextLocale();
        arrayOfObject3[5] = this.a.getTypeface();
        arrayOfObject3[6] = this.b;
        arrayOfObject3[7] = Integer.valueOf(this.c);
        arrayOfObject3[8] = Integer.valueOf(this.d);
        return d.a(arrayOfObject3);
      }
      if (Build.VERSION.SDK_INT >= 17)
      {
        Object[] arrayOfObject2 = new Object[9];
        arrayOfObject2[0] = Float.valueOf(this.a.getTextSize());
        arrayOfObject2[1] = Float.valueOf(this.a.getTextScaleX());
        arrayOfObject2[2] = Float.valueOf(this.a.getTextSkewX());
        arrayOfObject2[3] = Integer.valueOf(this.a.getFlags());
        arrayOfObject2[4] = this.a.getTextLocale();
        arrayOfObject2[5] = this.a.getTypeface();
        arrayOfObject2[6] = this.b;
        arrayOfObject2[7] = Integer.valueOf(this.c);
        arrayOfObject2[8] = Integer.valueOf(this.d);
        return d.a(arrayOfObject2);
      }
      Object[] arrayOfObject1 = new Object[8];
      arrayOfObject1[0] = Float.valueOf(this.a.getTextSize());
      arrayOfObject1[1] = Float.valueOf(this.a.getTextScaleX());
      arrayOfObject1[2] = Float.valueOf(this.a.getTextSkewX());
      arrayOfObject1[3] = Integer.valueOf(this.a.getFlags());
      arrayOfObject1[4] = this.a.getTypeface();
      arrayOfObject1[5] = this.b;
      arrayOfObject1[6] = Integer.valueOf(this.c);
      arrayOfObject1[7] = Integer.valueOf(this.d);
      return d.a(arrayOfObject1);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder1 = new StringBuilder("{");
      StringBuilder localStringBuilder2 = new StringBuilder("textSize=");
      localStringBuilder2.append(this.a.getTextSize());
      localStringBuilder1.append(localStringBuilder2.toString());
      StringBuilder localStringBuilder3 = new StringBuilder(", textScaleX=");
      localStringBuilder3.append(this.a.getTextScaleX());
      localStringBuilder1.append(localStringBuilder3.toString());
      StringBuilder localStringBuilder4 = new StringBuilder(", textSkewX=");
      localStringBuilder4.append(this.a.getTextSkewX());
      localStringBuilder1.append(localStringBuilder4.toString());
      if (Build.VERSION.SDK_INT >= 21)
      {
        StringBuilder localStringBuilder5 = new StringBuilder(", letterSpacing=");
        localStringBuilder5.append(this.a.getLetterSpacing());
        localStringBuilder1.append(localStringBuilder5.toString());
        StringBuilder localStringBuilder6 = new StringBuilder(", elegantTextHeight=");
        localStringBuilder6.append(this.a.isElegantTextHeight());
        localStringBuilder1.append(localStringBuilder6.toString());
      }
      if (Build.VERSION.SDK_INT >= 24)
      {
        StringBuilder localStringBuilder7 = new StringBuilder(", textLocale=");
        localStringBuilder7.append(this.a.getTextLocales());
        localStringBuilder1.append(localStringBuilder7.toString());
      }
      else if (Build.VERSION.SDK_INT >= 17)
      {
        StringBuilder localStringBuilder13 = new StringBuilder(", textLocale=");
        localStringBuilder13.append(this.a.getTextLocale());
        localStringBuilder1.append(localStringBuilder13.toString());
      }
      StringBuilder localStringBuilder8 = new StringBuilder(", typeface=");
      localStringBuilder8.append(this.a.getTypeface());
      localStringBuilder1.append(localStringBuilder8.toString());
      if (Build.VERSION.SDK_INT >= 26)
      {
        StringBuilder localStringBuilder9 = new StringBuilder(", variationSettings=");
        localStringBuilder9.append(this.a.getFontVariationSettings());
        localStringBuilder1.append(localStringBuilder9.toString());
      }
      StringBuilder localStringBuilder10 = new StringBuilder(", textDir=");
      localStringBuilder10.append(this.b);
      localStringBuilder1.append(localStringBuilder10.toString());
      StringBuilder localStringBuilder11 = new StringBuilder(", breakStrategy=");
      localStringBuilder11.append(this.c);
      localStringBuilder1.append(localStringBuilder11.toString());
      StringBuilder localStringBuilder12 = new StringBuilder(", hyphenationFrequency=");
      localStringBuilder12.append(this.d);
      localStringBuilder1.append(localStringBuilder12.toString());
      localStringBuilder1.append("}");
      return localStringBuilder1.toString();
    }

    public static final class a
    {
      private final TextPaint a;
      private TextDirectionHeuristic b;
      private int c;
      private int d;

      static
      {
        CoverageLogger.Log(46336000);
      }

      public a(TextPaint paramTextPaint)
      {
        this.a = paramTextPaint;
        if (Build.VERSION.SDK_INT >= 23)
        {
          this.c = 1;
          this.d = 1;
        }
        else
        {
          this.d = 0;
          this.c = 0;
        }
        if (Build.VERSION.SDK_INT >= 18)
        {
          this.b = TextDirectionHeuristics.FIRSTSTRONG_LTR;
          return;
        }
        this.b = null;
      }

      public final a a(int paramInt)
      {
        this.c = paramInt;
        return this;
      }

      public final a a(TextDirectionHeuristic paramTextDirectionHeuristic)
      {
        this.b = paramTextDirectionHeuristic;
        return this;
      }

      public final c.a a()
      {
        return new c.a(this.a, this.b, this.c, this.d);
      }

      public final a b(int paramInt)
      {
        this.d = paramInt;
        return this;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.f.c
 * JD-Core Version:    0.6.2
 */