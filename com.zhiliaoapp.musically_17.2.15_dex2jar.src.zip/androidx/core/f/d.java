package androidx.core.f;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface d
{
  static
  {
    CoverageLogger.Log(46571520);
  }

  public abstract boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.f.d
 * JD-Core Version:    0.6.2
 */