package androidx.core.f;

import java.lang.reflect.Method;

public final class b
{
  private static Method a;
  private static Method b;

  // ERROR //
  static
  {
    // Byte code:
    //   0: ldc 12
    //   2: invokestatic 18	com/ss/android/ugc/bytex/coverage_lib/CoverageLogger:Log	(I)V
    //   5: getstatic 24	android/os/Build$VERSION:SDK_INT	I
    //   8: bipush 21
    //   10: if_icmplt +36 -> 46
    //   13: ldc 26
    //   15: invokestatic 32	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   18: ldc 34
    //   20: iconst_1
    //   21: anewarray 28	java/lang/Class
    //   24: dup
    //   25: iconst_0
    //   26: ldc 36
    //   28: aastore
    //   29: invokevirtual 40	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   32: putstatic 42	androidx/core/f/b:b	Ljava/lang/reflect/Method;
    //   35: return
    //   36: astore_1
    //   37: new 44	java/lang/IllegalStateException
    //   40: dup
    //   41: aload_1
    //   42: invokespecial 48	java/lang/IllegalStateException:<init>	(Ljava/lang/Throwable;)V
    //   45: athrow
    //   46: ldc 26
    //   48: invokestatic 32	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   51: astore_0
    //   52: aload_0
    //   53: ifnull +39 -> 92
    //   56: aload_0
    //   57: ldc 50
    //   59: iconst_1
    //   60: anewarray 28	java/lang/Class
    //   63: dup
    //   64: iconst_0
    //   65: ldc 52
    //   67: aastore
    //   68: invokevirtual 40	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   71: putstatic 54	androidx/core/f/b:a	Ljava/lang/reflect/Method;
    //   74: aload_0
    //   75: ldc 34
    //   77: iconst_1
    //   78: anewarray 28	java/lang/Class
    //   81: dup
    //   82: iconst_0
    //   83: ldc 52
    //   85: aastore
    //   86: invokevirtual 40	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   89: putstatic 42	androidx/core/f/b:b	Ljava/lang/reflect/Method;
    //   92: return
    //   93: aconst_null
    //   94: putstatic 54	androidx/core/f/b:a	Ljava/lang/reflect/Method;
    //   97: aconst_null
    //   98: putstatic 42	androidx/core/f/b:b	Ljava/lang/reflect/Method;
    //   101: return
    //
    // Exception table:
    //   from	to	target	type
    //   13	35	36	java/lang/Exception
    //   46	52	93	java/lang/Exception
    //   56	92	93	java/lang/Exception
  }

  // ERROR //
  private static java.lang.String a(java.lang.String paramString)
  {
    // Byte code:
    //   0: getstatic 54	androidx/core/f/b:a	Ljava/lang/reflect/Method;
    //   3: ifnull +26 -> 29
    //   6: iconst_1
    //   7: anewarray 4	java/lang/Object
    //   10: dup
    //   11: iconst_0
    //   12: aload_0
    //   13: aastore
    //   14: astore_1
    //   15: getstatic 54	androidx/core/f/b:a	Ljava/lang/reflect/Method;
    //   18: aconst_null
    //   19: aload_1
    //   20: invokevirtual 65	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   23: checkcast 52	java/lang/String
    //   26: astore_2
    //   27: aload_2
    //   28: areturn
    //   29: aconst_null
    //   30: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	27	29	java/lang/IllegalAccessException
    //   0	27	29	java/lang/reflect/InvocationTargetException
  }

  // ERROR //
  public static java.lang.String a(java.util.Locale paramLocale)
  {
    // Byte code:
    //   0: getstatic 24	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 21
    //   5: if_icmplt +34 -> 39
    //   8: iconst_1
    //   9: anewarray 4	java/lang/Object
    //   12: dup
    //   13: iconst_0
    //   14: aload_0
    //   15: aastore
    //   16: astore_2
    //   17: getstatic 42	androidx/core/f/b:b	Ljava/lang/reflect/Method;
    //   20: aconst_null
    //   21: aload_2
    //   22: invokevirtual 65	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   25: checkcast 36	java/util/Locale
    //   28: invokevirtual 69	java/util/Locale:getScript	()Ljava/lang/String;
    //   31: astore_3
    //   32: aload_3
    //   33: areturn
    //   34: aload_0
    //   35: invokevirtual 69	java/util/Locale:getScript	()Ljava/lang/String;
    //   38: areturn
    //   39: aload_0
    //   40: invokestatic 71	androidx/core/f/b:b	(Ljava/util/Locale;)Ljava/lang/String;
    //   43: astore_1
    //   44: aload_1
    //   45: ifnull +8 -> 53
    //   48: aload_1
    //   49: invokestatic 73	androidx/core/f/b:a	(Ljava/lang/String;)Ljava/lang/String;
    //   52: areturn
    //   53: aconst_null
    //   54: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   8	32	34	java/lang/reflect/InvocationTargetException
    //   8	32	34	java/lang/IllegalAccessException
  }

  // ERROR //
  private static java.lang.String b(java.util.Locale paramLocale)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 76	java/util/Locale:toString	()Ljava/lang/String;
    //   4: astore_1
    //   5: getstatic 42	androidx/core/f/b:b	Ljava/lang/reflect/Method;
    //   8: ifnull +26 -> 34
    //   11: iconst_1
    //   12: anewarray 4	java/lang/Object
    //   15: dup
    //   16: iconst_0
    //   17: aload_1
    //   18: aastore
    //   19: astore_2
    //   20: getstatic 42	androidx/core/f/b:b	Ljava/lang/reflect/Method;
    //   23: aconst_null
    //   24: aload_2
    //   25: invokevirtual 65	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   28: checkcast 52	java/lang/String
    //   31: astore_3
    //   32: aload_3
    //   33: areturn
    //   34: aload_1
    //   35: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   5	32	34	java/lang/IllegalAccessException
    //   5	32	34	java/lang/reflect/InvocationTargetException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.f.b
 * JD-Core Version:    0.6.2
 */