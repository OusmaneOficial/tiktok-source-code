package androidx.core.f;

import android.os.Build.VERSION;
import android.text.TextUtils;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Locale;

public final class f
{
  private static final Locale a = new Locale("", "");

  static
  {
    CoverageLogger.Log(46587904);
  }

  public static int a(Locale paramLocale)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return TextUtils.getLayoutDirectionFromLocale(paramLocale);
    if ((paramLocale != null) && (!paramLocale.equals(a)))
    {
      String str = b.a(paramLocale);
      if (str == null)
        return b(paramLocale);
      if ((str.equalsIgnoreCase("Arab")) || (str.equalsIgnoreCase("Hebr")))
        return 1;
    }
    return 0;
  }

  private static int b(Locale paramLocale)
  {
    int i = Character.getDirectionality(paramLocale.getDisplayName(paramLocale).charAt(0));
    if ((i != 1) && (i != 2))
      return 0;
    return 1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.f.f
 * JD-Core Version:    0.6.2
 */