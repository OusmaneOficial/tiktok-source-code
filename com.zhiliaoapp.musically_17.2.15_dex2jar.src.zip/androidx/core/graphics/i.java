package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.os.Process;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

public final class i
{
  static
  {
    CoverageLogger.Log(46444544);
  }

  public static File a(Context paramContext)
  {
    StringBuilder localStringBuilder1 = new StringBuilder(".font");
    localStringBuilder1.append(Process.myPid());
    localStringBuilder1.append("-");
    localStringBuilder1.append(Process.myTid());
    localStringBuilder1.append("-");
    String str = localStringBuilder1.toString();
    int i = 0;
    while (i < 100)
    {
      File localFile1 = paramContext.getCacheDir();
      StringBuilder localStringBuilder2 = new StringBuilder();
      localStringBuilder2.append(str);
      localStringBuilder2.append(i);
      File localFile2 = new File(localFile1, localStringBuilder2.toString());
      try
      {
        boolean bool = localFile2.createNewFile();
        if (bool)
          return localFile2;
      }
      catch (IOException localIOException)
      {
        i++;
        tmpTernaryOp = localIOException;
      }
    }
    return null;
  }

  public static ByteBuffer a(Context paramContext, Resources paramResources, int paramInt)
  {
    File localFile = a(paramContext);
    if (localFile == null)
      return null;
    try
    {
      boolean bool = a(localFile, paramResources, paramInt);
      if (!bool)
        return null;
      ByteBuffer localByteBuffer = a(localFile);
      return localByteBuffer;
    }
    finally
    {
      localFile.delete();
    }
  }

  // ERROR //
  public static ByteBuffer a(Context paramContext, android.os.CancellationSignal paramCancellationSignal, android.net.Uri paramUri)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 81	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   4: astore_3
    //   5: aload_3
    //   6: aload_2
    //   7: ldc 83
    //   9: aload_1
    //   10: invokevirtual 89	android/content/ContentResolver:openFileDescriptor	(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   13: astore 4
    //   15: aload 4
    //   17: ifnonnull +15 -> 32
    //   20: aload 4
    //   22: ifnull +8 -> 30
    //   25: aload 4
    //   27: invokevirtual 94	android/os/ParcelFileDescriptor:close	()V
    //   30: aconst_null
    //   31: areturn
    //   32: new 96	java/io/FileInputStream
    //   35: dup
    //   36: aload 4
    //   38: invokevirtual 100	android/os/ParcelFileDescriptor:getFileDescriptor	()Ljava/io/FileDescriptor;
    //   41: invokespecial 103	java/io/FileInputStream:<init>	(Ljava/io/FileDescriptor;)V
    //   44: astore 5
    //   46: aload 5
    //   48: invokevirtual 107	java/io/FileInputStream:getChannel	()Ljava/nio/channels/FileChannel;
    //   51: astore 12
    //   53: aload 12
    //   55: invokevirtual 113	java/nio/channels/FileChannel:size	()J
    //   58: lstore 13
    //   60: aload 12
    //   62: getstatic 119	java/nio/channels/FileChannel$MapMode:READ_ONLY	Ljava/nio/channels/FileChannel$MapMode;
    //   65: lconst_0
    //   66: lload 13
    //   68: invokevirtual 123	java/nio/channels/FileChannel:map	(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   71: astore 15
    //   73: aload 5
    //   75: invokevirtual 124	java/io/FileInputStream:close	()V
    //   78: aload 4
    //   80: ifnull +8 -> 88
    //   83: aload 4
    //   85: invokevirtual 94	android/os/ParcelFileDescriptor:close	()V
    //   88: aload 15
    //   90: areturn
    //   91: astore 6
    //   93: aload 6
    //   95: athrow
    //   96: astore 7
    //   98: aload 5
    //   100: invokevirtual 124	java/io/FileInputStream:close	()V
    //   103: goto +12 -> 115
    //   106: astore 8
    //   108: aload 6
    //   110: aload 8
    //   112: invokestatic 129	com/google/c/a/a/a/a/a:a	(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   115: aload 7
    //   117: athrow
    //   118: astore 9
    //   120: aload 9
    //   122: athrow
    //   123: astore 10
    //   125: aload 4
    //   127: ifnull +20 -> 147
    //   130: aload 4
    //   132: invokevirtual 94	android/os/ParcelFileDescriptor:close	()V
    //   135: goto +12 -> 147
    //   138: astore 11
    //   140: aload 9
    //   142: aload 11
    //   144: invokestatic 129	com/google/c/a/a/a/a/a:a	(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   147: aload 10
    //   149: athrow
    //   150: aconst_null
    //   151: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   46	73	91	finally
    //   93	96	96	finally
    //   98	103	106	finally
    //   32	46	118	finally
    //   73	78	118	finally
    //   108	115	118	finally
    //   115	118	118	finally
    //   120	123	123	finally
    //   130	135	138	finally
    //   5	15	150	java/io/IOException
    //   25	30	150	java/io/IOException
    //   83	88	150	java/io/IOException
    //   140	147	150	java/io/IOException
    //   147	150	150	java/io/IOException
  }

  // ERROR //
  private static ByteBuffer a(File paramFile)
  {
    // Byte code:
    //   0: new 96	java/io/FileInputStream
    //   3: dup
    //   4: aload_0
    //   5: invokespecial 132	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   8: astore_1
    //   9: aload_1
    //   10: invokevirtual 107	java/io/FileInputStream:getChannel	()Ljava/nio/channels/FileChannel;
    //   13: astore 5
    //   15: aload 5
    //   17: invokevirtual 113	java/nio/channels/FileChannel:size	()J
    //   20: lstore 6
    //   22: aload 5
    //   24: getstatic 119	java/nio/channels/FileChannel$MapMode:READ_ONLY	Ljava/nio/channels/FileChannel$MapMode;
    //   27: lconst_0
    //   28: lload 6
    //   30: invokevirtual 123	java/nio/channels/FileChannel:map	(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;
    //   33: astore 8
    //   35: aload_1
    //   36: invokevirtual 124	java/io/FileInputStream:close	()V
    //   39: aload 8
    //   41: areturn
    //   42: astore_2
    //   43: aload_2
    //   44: athrow
    //   45: astore_3
    //   46: aload_1
    //   47: invokevirtual 124	java/io/FileInputStream:close	()V
    //   50: goto +11 -> 61
    //   53: astore 4
    //   55: aload_2
    //   56: aload 4
    //   58: invokestatic 129	com/google/c/a/a/a/a/a:a	(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    //   61: aload_3
    //   62: athrow
    //   63: aconst_null
    //   64: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   9	35	42	finally
    //   43	45	45	finally
    //   46	50	53	finally
    //   0	9	63	java/io/IOException
    //   35	39	63	java/io/IOException
    //   55	61	63	java/io/IOException
    //   61	63	63	java/io/IOException
  }

  public static void a(Closeable paramCloseable)
  {
    if (paramCloseable != null);
    try
    {
      paramCloseable.close();
    }
    catch (IOException localIOException)
    {
    }
  }

  // ERROR //
  public static boolean a(File paramFile, Resources paramResources, int paramInt)
  {
    // Byte code:
    //   0: aload_1
    //   1: iload_2
    //   2: invokevirtual 142	android/content/res/Resources:openRawResource	(I)Ljava/io/InputStream;
    //   5: astore 4
    //   7: aload_0
    //   8: aload 4
    //   10: invokestatic 145	androidx/core/graphics/i:a	(Ljava/io/File;Ljava/io/InputStream;)Z
    //   13: istore 5
    //   15: aload 4
    //   17: invokestatic 147	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   20: iload 5
    //   22: ireturn
    //   23: astore_3
    //   24: goto +7 -> 31
    //   27: astore_3
    //   28: aconst_null
    //   29: astore 4
    //   31: aload 4
    //   33: invokestatic 147	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   36: aload_3
    //   37: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   7	15	23	finally
    //   0	7	27	finally
  }

  // ERROR //
  public static boolean a(File paramFile, java.io.InputStream paramInputStream)
  {
    // Byte code:
    //   0: invokestatic 153	android/os/StrictMode:allowThreadDiskWrites	()Landroid/os/StrictMode$ThreadPolicy;
    //   3: astore_2
    //   4: aconst_null
    //   5: astore_3
    //   6: new 155	java/io/FileOutputStream
    //   9: dup
    //   10: aload_0
    //   11: iconst_0
    //   12: invokespecial 158	java/io/FileOutputStream:<init>	(Ljava/io/File;Z)V
    //   15: astore 4
    //   17: sipush 1024
    //   20: newarray byte
    //   22: astore 6
    //   24: aload_1
    //   25: aload 6
    //   27: invokevirtual 164	java/io/InputStream:read	([B)I
    //   30: istore 7
    //   32: iload 7
    //   34: iconst_m1
    //   35: if_icmpeq +16 -> 51
    //   38: aload 4
    //   40: aload 6
    //   42: iconst_0
    //   43: iload 7
    //   45: invokevirtual 168	java/io/FileOutputStream:write	([BII)V
    //   48: goto -24 -> 24
    //   51: aload 4
    //   53: invokestatic 147	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   56: aload_2
    //   57: invokestatic 172	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   60: iconst_1
    //   61: ireturn
    //   62: astore 5
    //   64: goto +14 -> 78
    //   67: aload 4
    //   69: astore_3
    //   70: goto +20 -> 90
    //   73: astore 5
    //   75: aconst_null
    //   76: astore 4
    //   78: aload 4
    //   80: invokestatic 147	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   83: aload_2
    //   84: invokestatic 172	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   87: aload 5
    //   89: athrow
    //   90: aload_3
    //   91: invokestatic 147	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   94: aload_2
    //   95: invokestatic 172	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   98: iconst_0
    //   99: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   17	24	62	finally
    //   24	32	62	finally
    //   38	48	62	finally
    //   17	24	67	java/io/IOException
    //   24	32	67	java/io/IOException
    //   38	48	67	java/io/IOException
    //   6	17	73	finally
    //   6	17	90	java/io/IOException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.i
 * JD-Core Version:    0.6.2
 */