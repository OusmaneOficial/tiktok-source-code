package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import androidx.core.content.a.c.b;
import androidx.core.content.a.c.c;
import androidx.core.e.b.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class h
{
  static
  {
    CoverageLogger.Log(46450688);
  }

  // ERROR //
  protected static Typeface a(Context paramContext, java.io.InputStream paramInputStream)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic 25	androidx/core/graphics/i:a	(Landroid/content/Context;)Ljava/io/File;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnonnull +5 -> 11
    //   9: aconst_null
    //   10: areturn
    //   11: aload_2
    //   12: aload_1
    //   13: invokestatic 28	androidx/core/graphics/i:a	(Ljava/io/File;Ljava/io/InputStream;)Z
    //   16: istore 6
    //   18: iload 6
    //   20: ifne +10 -> 30
    //   23: aload_2
    //   24: invokevirtual 34	java/io/File:delete	()Z
    //   27: pop
    //   28: aconst_null
    //   29: areturn
    //   30: aload_2
    //   31: invokevirtual 38	java/io/File:getPath	()Ljava/lang/String;
    //   34: invokestatic 44	android/graphics/Typeface:createFromFile	(Ljava/lang/String;)Landroid/graphics/Typeface;
    //   37: astore 7
    //   39: aload_2
    //   40: invokevirtual 34	java/io/File:delete	()Z
    //   43: pop
    //   44: aload 7
    //   46: areturn
    //   47: astore 4
    //   49: aload_2
    //   50: invokevirtual 34	java/io/File:delete	()Z
    //   53: pop
    //   54: aload 4
    //   56: athrow
    //   57: aload_2
    //   58: invokevirtual 34	java/io/File:delete	()Z
    //   61: pop
    //   62: aconst_null
    //   63: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   11	18	47	finally
    //   30	39	47	finally
    //   11	18	57	java/lang/RuntimeException
    //   30	39	57	java/lang/RuntimeException
  }

  private static <T> T a(T[] paramArrayOfT, int paramInt, a<T> parama)
  {
    int i;
    if ((paramInt & 0x1) == 0)
      i = 400;
    else
      i = 700;
    int j;
    if ((paramInt & 0x2) != 0)
      j = 1;
    else
      j = 0;
    int k = paramArrayOfT.length;
    Object localObject = null;
    int m = 0;
    int n = 2147483647;
    while (m < k)
    {
      T ? = paramArrayOfT[m];
      int i1 = 2 * Math.abs(parama.b(?) - i);
      int i2;
      if (parama.a(?) == j)
        i2 = 0;
      else
        i2 = 1;
      int i3 = i1 + i2;
      if ((localObject == null) || (n > i3))
      {
        localObject = ?;
        n = i3;
      }
      m++;
    }
    return localObject;
  }

  // ERROR //
  public Typeface a(Context paramContext, Resources paramResources, int paramInt1, java.lang.String paramString, int paramInt2)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic 25	androidx/core/graphics/i:a	(Landroid/content/Context;)Ljava/io/File;
    //   4: astore 6
    //   6: aload 6
    //   8: ifnonnull +5 -> 13
    //   11: aconst_null
    //   12: areturn
    //   13: aload 6
    //   15: aload_2
    //   16: iload_3
    //   17: invokestatic 65	androidx/core/graphics/i:a	(Ljava/io/File;Landroid/content/res/Resources;I)Z
    //   20: istore 10
    //   22: iload 10
    //   24: ifne +11 -> 35
    //   27: aload 6
    //   29: invokevirtual 34	java/io/File:delete	()Z
    //   32: pop
    //   33: aconst_null
    //   34: areturn
    //   35: aload 6
    //   37: invokevirtual 38	java/io/File:getPath	()Ljava/lang/String;
    //   40: invokestatic 44	android/graphics/Typeface:createFromFile	(Ljava/lang/String;)Landroid/graphics/Typeface;
    //   43: astore 11
    //   45: aload 6
    //   47: invokevirtual 34	java/io/File:delete	()Z
    //   50: pop
    //   51: aload 11
    //   53: areturn
    //   54: astore 8
    //   56: aload 6
    //   58: invokevirtual 34	java/io/File:delete	()Z
    //   61: pop
    //   62: aload 8
    //   64: athrow
    //   65: aload 6
    //   67: invokevirtual 34	java/io/File:delete	()Z
    //   70: pop
    //   71: aconst_null
    //   72: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   13	22	54	finally
    //   35	45	54	finally
    //   13	22	65	java/lang/RuntimeException
    //   35	45	65	java/lang/RuntimeException
  }

  // ERROR //
  public Typeface a(Context paramContext, android.os.CancellationSignal paramCancellationSignal, b.b[] paramArrayOfb, int paramInt)
  {
    // Byte code:
    //   0: aload_3
    //   1: arraylength
    //   2: istore 5
    //   4: aconst_null
    //   5: astore 6
    //   7: iload 5
    //   9: ifgt +5 -> 14
    //   12: aconst_null
    //   13: areturn
    //   14: aload_0
    //   15: aload_3
    //   16: iload 4
    //   18: invokevirtual 71	androidx/core/graphics/h:a	([Landroidx/core/e/b$b;I)Landroidx/core/e/b$b;
    //   21: astore 7
    //   23: aload_1
    //   24: invokevirtual 77	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   27: aload 7
    //   29: getfield 82	androidx/core/e/b$b:a	Landroid/net/Uri;
    //   32: invokevirtual 88	android/content/ContentResolver:openInputStream	(Landroid/net/Uri;)Ljava/io/InputStream;
    //   35: astore 8
    //   37: aload_1
    //   38: aload 8
    //   40: invokestatic 90	androidx/core/graphics/h:a	(Landroid/content/Context;Ljava/io/InputStream;)Landroid/graphics/Typeface;
    //   43: astore 11
    //   45: aload 8
    //   47: invokestatic 93	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   50: aload 11
    //   52: areturn
    //   53: astore 9
    //   55: aload 8
    //   57: astore 6
    //   59: goto +5 -> 64
    //   62: astore 9
    //   64: aload 6
    //   66: invokestatic 93	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   69: aload 9
    //   71: athrow
    //   72: aconst_null
    //   73: astore 8
    //   75: goto +4 -> 79
    //   78: pop
    //   79: aload 8
    //   81: invokestatic 93	androidx/core/graphics/i:a	(Ljava/io/Closeable;)V
    //   84: aconst_null
    //   85: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   37	45	53	finally
    //   23	37	62	finally
    //   23	37	72	java/io/IOException
    //   37	45	78	java/io/IOException
  }

  public Typeface a(Context paramContext, c.b paramb, Resources paramResources, int paramInt)
  {
    c.c localc = (c.c)a(paramb.a, paramInt, new a()
    {
      static
      {
        CoverageLogger.Log(46452736);
      }
    });
    if (localc == null)
      return null;
    return c.a(paramContext, paramResources, localc.f, localc.a, paramInt);
  }

  protected final b.b a(b.b[] paramArrayOfb, int paramInt)
  {
    return (b.b)a(paramArrayOfb, paramInt, new a()
    {
      static
      {
        CoverageLogger.Log(46448640);
      }
    });
  }

  static abstract interface a<T>
  {
    static
    {
      CoverageLogger.Log(46454784);
    }

    public abstract boolean a(T paramT);

    public abstract int b(T paramT);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.h
 * JD-Core Version:    0.6.2
 */