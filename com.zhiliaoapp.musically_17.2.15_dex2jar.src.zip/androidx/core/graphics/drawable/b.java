package androidx.core.graphics.drawable;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class b extends Drawable
{
  public final Bitmap a;
  public int b = 119;
  public final Paint c = new Paint(3);
  public float d;
  final Rect e = new Rect();
  public boolean f;
  private int g = 160;
  private final BitmapShader h;
  private final Matrix i = new Matrix();
  private final RectF j = new RectF();
  private boolean k = true;
  private int l;
  private int m;

  static
  {
    CoverageLogger.Log(46469120);
  }

  b(Resources paramResources, Bitmap paramBitmap)
  {
    if (paramResources != null)
      this.g = paramResources.getDisplayMetrics().densityDpi;
    this.a = paramBitmap;
    Bitmap localBitmap1 = this.a;
    if (localBitmap1 != null)
    {
      this.l = localBitmap1.getScaledWidth(this.g);
      this.m = this.a.getScaledHeight(this.g);
      Bitmap localBitmap2 = this.a;
      Shader.TileMode localTileMode = Shader.TileMode.CLAMP;
      this.h = new BitmapShader(localBitmap2, localTileMode, localTileMode);
      return;
    }
    this.m = -1;
    this.l = -1;
    this.h = null;
  }

  private static boolean b(float paramFloat)
  {
    return paramFloat > 0.05F;
  }

  final void a()
  {
    if (this.k)
    {
      if (this.f)
      {
        int n = Math.min(this.l, this.m);
        a(this.b, n, n, getBounds(), this.e);
        int i1 = Math.min(this.e.width(), this.e.height());
        int i2 = Math.max(0, (this.e.width() - i1) / 2);
        int i3 = Math.max(0, (this.e.height() - i1) / 2);
        this.e.inset(i2, i3);
        this.d = (0.5F * i1);
      }
      else
      {
        a(this.b, this.l, this.m, getBounds(), this.e);
      }
      this.j.set(this.e);
      if (this.h != null)
      {
        this.i.setTranslate(this.j.left, this.j.top);
        this.i.preScale(this.j.width() / this.a.getWidth(), this.j.height() / this.a.getHeight());
        this.h.setLocalMatrix(this.i);
        this.c.setShader(this.h);
      }
      this.k = false;
    }
  }

  public final void a(float paramFloat)
  {
    if (this.d == paramFloat)
      return;
    this.f = false;
    if (b(paramFloat))
      this.c.setShader(this.h);
    else
      this.c.setShader(null);
    this.d = paramFloat;
    invalidateSelf();
  }

  void a(int paramInt1, int paramInt2, int paramInt3, Rect paramRect1, Rect paramRect2)
  {
    throw new UnsupportedOperationException();
  }

  public void draw(Canvas paramCanvas)
  {
    Bitmap localBitmap = this.a;
    if (localBitmap == null)
      return;
    a();
    if (this.c.getShader() == null)
    {
      paramCanvas.drawBitmap(localBitmap, null, this.e, this.c);
      return;
    }
    RectF localRectF = this.j;
    float f1 = this.d;
    paramCanvas.drawRoundRect(localRectF, f1, f1, this.c);
  }

  public int getAlpha()
  {
    return this.c.getAlpha();
  }

  public ColorFilter getColorFilter()
  {
    return this.c.getColorFilter();
  }

  public int getIntrinsicHeight()
  {
    return this.m;
  }

  public int getIntrinsicWidth()
  {
    return this.l;
  }

  public int getOpacity()
  {
    if (this.b == 119)
    {
      if (this.f)
        return -3;
      Bitmap localBitmap = this.a;
      if ((localBitmap != null) && (!localBitmap.hasAlpha()) && (this.c.getAlpha() >= 255))
      {
        if (b(this.d))
          return -3;
        return -1;
      }
    }
    return -3;
  }

  protected void onBoundsChange(Rect paramRect)
  {
    super.onBoundsChange(paramRect);
    if (this.f)
      this.d = (Math.min(this.m, this.l) / 2);
    this.k = true;
  }

  public void setAlpha(int paramInt)
  {
    if (paramInt != this.c.getAlpha())
    {
      this.c.setAlpha(paramInt);
      invalidateSelf();
    }
  }

  public void setColorFilter(ColorFilter paramColorFilter)
  {
    this.c.setColorFilter(paramColorFilter);
    invalidateSelf();
  }

  public void setDither(boolean paramBoolean)
  {
    this.c.setDither(paramBoolean);
    invalidateSelf();
  }

  public void setFilterBitmap(boolean paramBoolean)
  {
    this.c.setFilterBitmap(paramBoolean);
    invalidateSelf();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.b
 * JD-Core Version:    0.6.2
 */