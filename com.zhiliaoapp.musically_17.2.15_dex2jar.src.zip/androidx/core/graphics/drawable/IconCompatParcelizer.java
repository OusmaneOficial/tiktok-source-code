package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.os.Parcelable;
import androidx.versionedparcelable.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.nio.charset.Charset;

public class IconCompatParcelizer
{
  static
  {
    CoverageLogger.Log(46467072);
  }

  public static IconCompat read(a parama)
  {
    IconCompat localIconCompat = new IconCompat();
    localIconCompat.a = parama.b(localIconCompat.a, 1);
    localIconCompat.c = parama.b(localIconCompat.c, 2);
    localIconCompat.d = parama.b(localIconCompat.d, 3);
    localIconCompat.e = parama.b(localIconCompat.e, 4);
    localIconCompat.f = parama.b(localIconCompat.f, 5);
    localIconCompat.g = ((ColorStateList)parama.b(localIconCompat.g, 6));
    localIconCompat.j = parama.b(localIconCompat.j, 7);
    localIconCompat.i = PorterDuff.Mode.valueOf(localIconCompat.j);
    int i = localIconCompat.a;
    if (i != -1)
    {
      if (i != 1)
      {
        if (i != 2)
          if (i != 3)
          {
            if (i != 4)
            {
              if (i == 5)
                break label184;
              return localIconCompat;
            }
          }
          else
          {
            localIconCompat.b = localIconCompat.c;
            return localIconCompat;
          }
        localIconCompat.b = new String(localIconCompat.c, Charset.forName("UTF-16"));
        return localIconCompat;
      }
      label184: if (localIconCompat.d != null)
      {
        localIconCompat.b = localIconCompat.d;
        return localIconCompat;
      }
      localIconCompat.b = localIconCompat.c;
      localIconCompat.a = 3;
      localIconCompat.e = 0;
      localIconCompat.f = localIconCompat.c.length;
      return localIconCompat;
    }
    if (localIconCompat.d != null)
    {
      localIconCompat.b = localIconCompat.d;
      return localIconCompat;
    }
    throw new IllegalArgumentException("Invalid icon");
  }

  public static void write(IconCompat paramIconCompat, a parama)
  {
    paramIconCompat.j = paramIconCompat.i.name();
    int i = paramIconCompat.a;
    if (i != -1)
    {
      if (i != 1)
        if (i != 2)
        {
          if (i != 3)
          {
            if (i != 4)
            {
              if (i != 5)
                break label135;
            }
            else
            {
              paramIconCompat.c = paramIconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
              break label135;
            }
          }
          else
          {
            paramIconCompat.c = ((byte[])paramIconCompat.b);
            break label135;
          }
        }
        else
        {
          paramIconCompat.c = ((String)paramIconCompat.b).getBytes(Charset.forName("UTF-16"));
          break label135;
        }
      paramIconCompat.d = ((Parcelable)paramIconCompat.b);
    }
    else
    {
      paramIconCompat.d = ((Parcelable)paramIconCompat.b);
    }
    label135: parama.a(paramIconCompat.a, 1);
    parama.a(paramIconCompat.c, 2);
    parama.a(paramIconCompat.d, 3);
    parama.a(paramIconCompat.e, 4);
    parama.a(paramIconCompat.f, 5);
    parama.a(paramIconCompat.g, 6);
    parama.a(paramIconCompat.j, 7);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.IconCompatParcelizer
 * JD-Core Version:    0.6.2
 */