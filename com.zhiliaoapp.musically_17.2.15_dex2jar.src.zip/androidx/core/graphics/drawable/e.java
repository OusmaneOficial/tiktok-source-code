package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface e
{
  static
  {
    CoverageLogger.Log(46424064);
  }

  public abstract void setTint(int paramInt);

  public abstract void setTintList(ColorStateList paramColorStateList);

  public abstract void setTintMode(PorterDuff.Mode paramMode);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.e
 * JD-Core Version:    0.6.2
 */