package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.DrawableContainer.DrawableContainerState;
import android.graphics.drawable.InsetDrawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.IOException;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class a
{
  private static Method a;
  private static boolean b;
  private static Method c;
  private static boolean d;

  static
  {
    CoverageLogger.Log(46442496);
  }

  public static void a(Drawable paramDrawable)
  {
    paramDrawable.jumpToCurrentState();
  }

  public static void a(Drawable paramDrawable, float paramFloat1, float paramFloat2)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramDrawable.setHotspot(paramFloat1, paramFloat2);
  }

  public static void a(Drawable paramDrawable, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramDrawable.setTint(paramInt);
      return;
    }
    if ((paramDrawable instanceof e))
      ((e)paramDrawable).setTint(paramInt);
  }

  public static void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramDrawable.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static void a(Drawable paramDrawable, ColorStateList paramColorStateList)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramDrawable.setTintList(paramColorStateList);
      return;
    }
    if ((paramDrawable instanceof e))
      ((e)paramDrawable).setTintList(paramColorStateList);
  }

  public static void a(Drawable paramDrawable, Resources.Theme paramTheme)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramDrawable.applyTheme(paramTheme);
  }

  public static void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    throws XmlPullParserException, IOException
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramDrawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return;
    }
    paramDrawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet);
  }

  public static void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramDrawable.setTintMode(paramMode);
      return;
    }
    if ((paramDrawable instanceof e))
      ((e)paramDrawable).setTintMode(paramMode);
  }

  public static void a(Drawable paramDrawable, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramDrawable.setAutoMirrored(paramBoolean);
  }

  public static boolean b(Drawable paramDrawable)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return paramDrawable.isAutoMirrored();
    return false;
  }

  // ERROR //
  public static boolean b(Drawable paramDrawable, int paramInt)
  {
    // Byte code:
    //   0: getstatic 32	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 23
    //   5: if_icmplt +9 -> 14
    //   8: aload_0
    //   9: iload_1
    //   10: invokevirtual 96	android/graphics/drawable/Drawable:setLayoutDirection	(I)Z
    //   13: ireturn
    //   14: getstatic 32	android/os/Build$VERSION:SDK_INT	I
    //   17: bipush 17
    //   19: if_icmplt +85 -> 104
    //   22: getstatic 98	androidx/core/graphics/drawable/a:b	Z
    //   25: ifne +46 -> 71
    //   28: iconst_1
    //   29: anewarray 100	java/lang/Class
    //   32: astore 6
    //   34: aload 6
    //   36: iconst_0
    //   37: getstatic 106	java/lang/Integer:TYPE	Ljava/lang/Class;
    //   40: aastore
    //   41: ldc 22
    //   43: ldc 107
    //   45: aload 6
    //   47: invokevirtual 111	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   50: astore 7
    //   52: aload 7
    //   54: putstatic 113	androidx/core/graphics/drawable/a:a	Ljava/lang/reflect/Method;
    //   57: aload 7
    //   59: iconst_1
    //   60: invokevirtual 118	java/lang/reflect/Method:setAccessible	(Z)V
    //   63: goto +4 -> 67
    //   66: pop
    //   67: iconst_1
    //   68: putstatic 98	androidx/core/graphics/drawable/a:b	Z
    //   71: getstatic 113	androidx/core/graphics/drawable/a:a	Ljava/lang/reflect/Method;
    //   74: astore_2
    //   75: aload_2
    //   76: ifnull +28 -> 104
    //   79: iconst_1
    //   80: anewarray 4	java/lang/Object
    //   83: astore_3
    //   84: aload_3
    //   85: iconst_0
    //   86: iload_1
    //   87: invokestatic 122	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   90: aastore
    //   91: aload_2
    //   92: aload_0
    //   93: aload_3
    //   94: invokevirtual 126	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   97: pop
    //   98: iconst_1
    //   99: ireturn
    //   100: aconst_null
    //   101: putstatic 113	androidx/core/graphics/drawable/a:a	Ljava/lang/reflect/Method;
    //   104: iconst_0
    //   105: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   28	63	66	java/lang/NoSuchMethodException
    //   79	98	100	java/lang/Exception
  }

  public static int c(Drawable paramDrawable)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return paramDrawable.getAlpha();
    return 0;
  }

  public static boolean d(Drawable paramDrawable)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramDrawable.canApplyTheme();
    return false;
  }

  public static void e(Drawable paramDrawable)
  {
    if ((Build.VERSION.SDK_INT < 23) && (Build.VERSION.SDK_INT >= 21))
    {
      paramDrawable.clearColorFilter();
      if ((paramDrawable instanceof InsetDrawable))
      {
        e(((InsetDrawable)paramDrawable).getDrawable());
        return;
      }
      if ((paramDrawable instanceof f))
      {
        e(((f)paramDrawable).a());
        return;
      }
      if ((paramDrawable instanceof DrawableContainer))
      {
        DrawableContainer.DrawableContainerState localDrawableContainerState = (DrawableContainer.DrawableContainerState)((DrawableContainer)paramDrawable).getConstantState();
        if (localDrawableContainerState != null)
        {
          int i = 0;
          int j = localDrawableContainerState.getChildCount();
          while (i < j)
          {
            Drawable localDrawable = localDrawableContainerState.getChild(i);
            if (localDrawable != null)
              e(localDrawable);
            i++;
          }
        }
      }
    }
    else
    {
      paramDrawable.clearColorFilter();
    }
  }

  public static Drawable f(Drawable paramDrawable)
  {
    if (Build.VERSION.SDK_INT >= 23)
      return paramDrawable;
    if (Build.VERSION.SDK_INT >= 21)
    {
      if (!(paramDrawable instanceof e))
        return new h(paramDrawable);
      return paramDrawable;
    }
    if (!(paramDrawable instanceof e))
      return new g(paramDrawable);
    return paramDrawable;
  }

  // ERROR //
  public static int g(Drawable paramDrawable)
  {
    // Byte code:
    //   0: getstatic 32	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 23
    //   5: if_icmplt +8 -> 13
    //   8: aload_0
    //   9: invokevirtual 179	android/graphics/drawable/Drawable:getLayoutDirection	()I
    //   12: ireturn
    //   13: getstatic 32	android/os/Build$VERSION:SDK_INT	I
    //   16: bipush 17
    //   18: if_icmplt +71 -> 89
    //   21: getstatic 181	androidx/core/graphics/drawable/a:d	Z
    //   24: ifne +35 -> 59
    //   27: ldc 22
    //   29: ldc 182
    //   31: iconst_0
    //   32: anewarray 100	java/lang/Class
    //   35: invokevirtual 111	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   38: astore 4
    //   40: aload 4
    //   42: putstatic 184	androidx/core/graphics/drawable/a:c	Ljava/lang/reflect/Method;
    //   45: aload 4
    //   47: iconst_1
    //   48: invokevirtual 118	java/lang/reflect/Method:setAccessible	(Z)V
    //   51: goto +4 -> 55
    //   54: pop
    //   55: iconst_1
    //   56: putstatic 181	androidx/core/graphics/drawable/a:d	Z
    //   59: getstatic 184	androidx/core/graphics/drawable/a:c	Ljava/lang/reflect/Method;
    //   62: astore_1
    //   63: aload_1
    //   64: ifnull +25 -> 89
    //   67: aload_1
    //   68: aload_0
    //   69: iconst_0
    //   70: anewarray 4	java/lang/Object
    //   73: invokevirtual 126	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   76: checkcast 102	java/lang/Integer
    //   79: invokevirtual 187	java/lang/Integer:intValue	()I
    //   82: istore_2
    //   83: iload_2
    //   84: ireturn
    //   85: aconst_null
    //   86: putstatic 184	androidx/core/graphics/drawable/a:c	Ljava/lang/reflect/Method;
    //   89: iconst_0
    //   90: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   27	51	54	java/lang/NoSuchMethodException
    //   67	83	85	java/lang/Exception
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.a
 * JD-Core Version:    0.6.2
 */