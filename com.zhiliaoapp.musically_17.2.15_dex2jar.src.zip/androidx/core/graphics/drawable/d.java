package androidx.core.graphics.drawable;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
{
  static
  {
    CoverageLogger.Log(46481408);
  }

  public static b a(Resources paramResources, Bitmap paramBitmap)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return new c(paramResources, paramBitmap);
    return new a(paramResources, paramBitmap);
  }

  static final class a extends b
  {
    static
    {
      CoverageLogger.Log(46479360);
    }

    a(Resources paramResources, Bitmap paramBitmap)
    {
      super(paramBitmap);
    }

    final void a(int paramInt1, int paramInt2, int paramInt3, Rect paramRect1, Rect paramRect2)
    {
      androidx.core.h.d.a(paramInt1, paramInt2, paramInt3, paramRect1, paramRect2, 0);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.d
 * JD-Core Version:    0.6.2
 */