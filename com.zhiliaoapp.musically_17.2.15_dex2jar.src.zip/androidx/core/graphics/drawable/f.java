package androidx.core.graphics.drawable;

import android.graphics.drawable.Drawable;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface f
{
  static
  {
    CoverageLogger.Log(46487552);
  }

  public abstract Drawable a();

  public abstract void a(Drawable paramDrawable);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.drawable.f
 * JD-Core Version:    0.6.2
 */