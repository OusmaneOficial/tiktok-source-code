package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c
{
  public static final h a;
  public static final androidx.c.e<String, Typeface> b;

  static
  {
    CoverageLogger.Log(46764032);
    if (Build.VERSION.SDK_INT >= 28)
    {
      a = new g();
    }
    else if (Build.VERSION.SDK_INT >= 26)
    {
      a = new f();
    }
    else
    {
      if (Build.VERSION.SDK_INT >= 24)
      {
        int i;
        if (e.a != null)
          i = 1;
        else
          i = 0;
        if (i != 0)
        {
          a = new e();
          break label116;
        }
      }
      if (Build.VERSION.SDK_INT >= 21)
        a = new d();
      else
        a = new h();
    }
    label116: b = new androidx.c.e(16);
  }

  public static Typeface a(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2)
  {
    Typeface localTypeface = a.a(paramContext, paramResources, paramInt1, paramString, paramInt2);
    if (localTypeface != null)
    {
      String str = a(paramResources, paramInt1, paramInt2);
      b.a(str, localTypeface);
    }
    return localTypeface;
  }

  public static String a(Resources paramResources, int paramInt1, int paramInt2)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(paramResources.getResourcePackageName(paramInt1));
    localStringBuilder.append("-");
    localStringBuilder.append(paramInt1);
    localStringBuilder.append("-");
    localStringBuilder.append(paramInt2);
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.c
 * JD-Core Version:    0.6.2
 */