package androidx.core.graphics;

import android.graphics.Path;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class b
{
  static
  {
    CoverageLogger.Log(46462976);
  }

  private static int a(String paramString, int paramInt)
  {
    while (paramInt < paramString.length())
    {
      int i = paramString.charAt(paramInt);
      if ((((i - 65) * (i - 90) <= 0) || ((i - 97) * (i - 122) <= 0)) && (i != 101) && (i != 69))
        return paramInt;
      paramInt++;
    }
    return paramInt;
  }

  public static Path a(String paramString)
  {
    Path localPath = new Path();
    b[] arrayOfb = b(paramString);
    if (arrayOfb != null)
      try
      {
        b.a(arrayOfb, localPath);
        return localPath;
      }
      catch (RuntimeException localRuntimeException)
      {
        StringBuilder localStringBuilder = new StringBuilder("Error in parsing ");
        localStringBuilder.append(paramString);
        throw new RuntimeException(localStringBuilder.toString(), localRuntimeException);
      }
    return null;
  }

  private static void a(ArrayList<b> paramArrayList, char paramChar, float[] paramArrayOfFloat)
  {
    paramArrayList.add(new b(paramChar, paramArrayOfFloat));
  }

  public static boolean a(b[] paramArrayOfb1, b[] paramArrayOfb2)
  {
    if (paramArrayOfb1 != null)
    {
      if (paramArrayOfb2 == null)
        return false;
      if (paramArrayOfb1.length != paramArrayOfb2.length)
        return false;
      int i = 0;
      while (i < paramArrayOfb1.length)
        if (paramArrayOfb1[i].a == paramArrayOfb2[i].a)
        {
          if (paramArrayOfb1[i].b.length != paramArrayOfb2[i].b.length)
            return false;
          i++;
        }
        else
        {
          return false;
        }
      return true;
    }
    return false;
  }

  static float[] a(float[] paramArrayOfFloat, int paramInt1, int paramInt2)
  {
    if (paramInt2 >= 0)
    {
      int i = paramArrayOfFloat.length;
      if (i >= 0)
      {
        int j = paramInt2 - 0;
        int k = Math.min(j, i - 0);
        float[] arrayOfFloat = new float[j];
        System.arraycopy(paramArrayOfFloat, 0, arrayOfFloat, 0, k);
        return arrayOfFloat;
      }
      throw new ArrayIndexOutOfBoundsException();
    }
    throw new IllegalArgumentException();
  }

  public static b[] a(b[] paramArrayOfb)
  {
    if (paramArrayOfb == null)
      return null;
    b[] arrayOfb = new b[paramArrayOfb.length];
    for (int i = 0; i < paramArrayOfb.length; i++)
      arrayOfb[i] = new b(paramArrayOfb[i]);
    return arrayOfb;
  }

  public static b[] b(String paramString)
  {
    if (paramString == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    int i = 1;
    int j = 0;
    while (i < paramString.length())
    {
      int k = a(paramString, i);
      String str = paramString.substring(j, k).trim();
      if (str.length() > 0)
      {
        float[] arrayOfFloat = c(str);
        a(localArrayList, str.charAt(0), arrayOfFloat);
      }
      int m = k + 1;
      j = k;
      i = m;
    }
    if ((i - j == 1) && (j < paramString.length()))
      a(localArrayList, paramString.charAt(j), new float[0]);
    return (b[])localArrayList.toArray(new b[localArrayList.size()]);
  }

  private static float[] c(String paramString)
  {
    if ((paramString.charAt(0) != 'z') && (paramString.charAt(0) != 'Z'));
    while (true)
    {
      int j;
      int m;
      int n;
      int i1;
      int i2;
      int i3;
      try
      {
        float[] arrayOfFloat1 = new float[paramString.length()];
        a locala = new a();
        int i = paramString.length();
        j = 1;
        int k = 0;
        int i5;
        if (j < i)
        {
          locala.b = false;
          m = j;
          n = 0;
          i1 = 0;
          i2 = 0;
          if (m < paramString.length())
          {
            i5 = paramString.charAt(m);
            if (i5 == 32)
              break label319;
            if ((i5 == 69) || (i5 == 101))
              break label313;
          }
        }
        switch (i5)
        {
        case 45:
          locala.b = true;
          break label319;
          if ((m == j) || (n != 0))
            break label307;
          locala.b = true;
          break label319;
          locala.a = m;
          i3 = locala.a;
          if (j < i3)
          {
            int i4 = k + 1;
            arrayOfFloat1[k] = Float.parseFloat(paramString.substring(j, i3));
            k = i4;
          }
          if (!locala.b)
            break label336;
          j = i3;
          continue;
          float[] arrayOfFloat2 = a(arrayOfFloat1, 0, k);
          return arrayOfFloat2;
        default:
        case 46:
        case 44:
        }
      }
      catch (NumberFormatException localNumberFormatException)
      {
        StringBuilder localStringBuilder = new StringBuilder("error in parsing \"");
        localStringBuilder.append(paramString);
        localStringBuilder.append("\"");
        throw new RuntimeException(localStringBuilder.toString(), localNumberFormatException);
      }
      return new float[0];
      if (i1 == 0)
      {
        i1 = 1;
        n = 0;
        break label325;
        label307: n = 0;
        break label325;
        label313: n = 1;
        break label325;
        label319: n = 0;
        i2 = 1;
        label325: if (i2 == 0)
        {
          m++;
          continue;
          label336: j = i3 + 1;
        }
      }
    }
  }

  static final class a
  {
    int a;
    boolean b;

    static
    {
      CoverageLogger.Log(46465024);
    }
  }

  public static final class b
  {
    public char a;
    public float[] b;

    static
    {
      CoverageLogger.Log(46473216);
    }

    b(char paramChar, float[] paramArrayOfFloat)
    {
      this.a = paramChar;
      this.b = paramArrayOfFloat;
    }

    b(b paramb)
    {
      this.a = paramb.a;
      float[] arrayOfFloat = paramb.b;
      this.b = b.a(arrayOfFloat, 0, arrayOfFloat.length);
    }

    private static void a(Path paramPath, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9)
    {
      double d1 = paramDouble3;
      int i = (int)Math.ceil(Math.abs(paramDouble9 * 4.0D / 3.141592653589793D));
      double d2 = Math.cos(paramDouble7);
      double d3 = Math.sin(paramDouble7);
      double d4 = Math.cos(paramDouble8);
      double d5 = Math.sin(paramDouble8);
      double d6 = -d1;
      double d7 = d6 * d2;
      double d8 = d7 * d5;
      double d9 = paramDouble4 * d3;
      double d10 = d8 - d9 * d4;
      double d11 = d6 * d3;
      double d12 = d5 * d11;
      double d13 = paramDouble4 * d2;
      double d14 = d12 + d4 * d13;
      double d15 = i;
      Double.isNaN(d15);
      double d16 = paramDouble9 / d15;
      double d17 = paramDouble5;
      double d18 = paramDouble6;
      double d19 = d14;
      double d20 = d10;
      int j = 0;
      double d21 = paramDouble8;
      while (j < i)
      {
        double d22 = d21 + d16;
        double d23 = Math.sin(d22);
        double d24 = Math.cos(d22);
        double d25 = paramDouble1 + d24 * (d1 * d2) - d9 * d23;
        double d26 = paramDouble2 + d24 * (d1 * d3) + d13 * d23;
        double d27 = d7 * d23 - d9 * d24;
        double d28 = d23 * d11 + d24 * d13;
        double d29 = d22 - d21;
        double d30 = Math.tan(d29 / 2.0D);
        double d31 = Math.sin(d29) * (Math.sqrt(4.0D + d30 * (d30 * 3.0D)) - 1.0D) / 3.0D;
        double d32 = d20 * d31;
        int k = i;
        double d33 = d2;
        double d34 = d17 + d32;
        double d35 = d19 * d31;
        double d36 = d3;
        double d37 = d18 + d35;
        double d38 = d31 * d27;
        double d39 = d16;
        double d40 = d25 - d38;
        double d41 = d31 * d28;
        double d42 = d11;
        double d43 = d26 - d41;
        paramPath.rLineTo(0.0F, 0.0F);
        paramPath.cubicTo((float)d34, (float)d37, (float)d40, (float)d43, (float)d25, (float)d26);
        j++;
        d16 = d39;
        i = k;
        d3 = d36;
        d18 = d26;
        d11 = d42;
        d21 = d22;
        d19 = d28;
        d20 = d27;
        d2 = d33;
        d1 = paramDouble3;
        d17 = d25;
      }
    }

    private static void a(Path paramPath, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, boolean paramBoolean1, boolean paramBoolean2)
    {
      float f1 = paramFloat1;
      float f2 = paramFloat3;
      float f3 = paramFloat5;
      float f4 = paramFloat6;
      double d1;
      double d2;
      double d3;
      double d4;
      double d6;
      double d8;
      double d9;
      double d13;
      double d14;
      double d19;
      double d23;
      double d24;
      double d25;
      double d26;
      double d27;
      double d29;
      for (float f5 = paramFloat7; ; f5 = paramFloat7)
      {
        d1 = Math.toRadians(f5);
        d2 = Math.cos(d1);
        d3 = Math.sin(d1);
        d4 = f1;
        Double.isNaN(d4);
        double d5 = d4 * d2;
        d6 = paramFloat2;
        Double.isNaN(d6);
        double d7 = d5 + d6 * d3;
        d8 = f3;
        Double.isNaN(d8);
        d9 = d7 / d8;
        double d10 = -f1;
        Double.isNaN(d10);
        double d11 = d10 * d3;
        Double.isNaN(d6);
        double d12 = d11 + d6 * d2;
        d13 = f4;
        Double.isNaN(d13);
        d14 = d12 / d13;
        float f6 = f3;
        float f7 = f4;
        double d15 = f2;
        Double.isNaN(d15);
        double d16 = d15 * d2;
        double d17 = paramFloat4;
        Double.isNaN(d17);
        double d18 = d16 + d17 * d3;
        Double.isNaN(d8);
        d19 = d18 / d8;
        double d20 = -f2;
        Double.isNaN(d20);
        double d21 = d20 * d3;
        Double.isNaN(d17);
        double d22 = d21 + d17 * d2;
        Double.isNaN(d13);
        d23 = d22 / d13;
        d24 = d9 - d19;
        d25 = d14 - d23;
        d26 = (d9 + d19) / 2.0D;
        d27 = (d14 + d23) / 2.0D;
        double d28 = d24 * d24 + d25 * d25;
        if (d28 == 0.0D)
          return;
        d29 = 1.0D / d28 - 0.25D;
        if (d29 >= 0.0D)
          break;
        float f8 = (float)(Math.sqrt(d28) / 1.99999D);
        f3 = f6 * f8;
        f4 = f7 * f8;
        f1 = paramFloat1;
        f2 = paramFloat3;
      }
      double d30 = Math.sqrt(d29);
      double d31 = d24 * d30;
      double d32 = d30 * d25;
      double d33;
      double d34;
      if (paramBoolean1 == paramBoolean2)
      {
        d33 = d26 - d32;
        d34 = d27 + d31;
      }
      else
      {
        d33 = d26 + d32;
        d34 = d27 - d31;
      }
      double d35 = Math.atan2(d14 - d34, d9 - d33);
      double d36 = Math.atan2(d23 - d34, d19 - d33) - d35;
      boolean bool;
      if (d36 >= 0.0D)
        bool = true;
      else
        bool = false;
      if (paramBoolean2 != bool)
        if (d36 > 0.0D)
          d36 -= 6.283185307179586D;
        else
          d36 += 6.283185307179586D;
      Double.isNaN(d8);
      double d37 = d33 * d8;
      Double.isNaN(d13);
      double d38 = d34 * d13;
      a(paramPath, d37 * d2 - d38 * d3, d37 * d3 + d38 * d2, d8, d13, d4, d6, d1, d35, d36);
    }

    public static void a(b[] paramArrayOfb, Path paramPath)
    {
      b[] arrayOfb = paramArrayOfb;
      float[] arrayOfFloat = new float[6];
      int i = 109;
      int j = 0;
      while (j < arrayOfb.length)
      {
        int k = arrayOfb[j].a;
        Object localObject1 = arrayOfb[j].b;
        float f1 = arrayOfFloat[0];
        float f2 = arrayOfFloat[1];
        float f3 = arrayOfFloat[2];
        float f4 = arrayOfFloat[3];
        float f5 = arrayOfFloat[4];
        float f6 = arrayOfFloat[5];
        int m;
        switch (k)
        {
        case 76:
        case 77:
        case 84:
        case 108:
        case 109:
        case 116:
        default:
        case 90:
        case 122:
          while (true)
          {
            m = 2;
            break;
            paramPath.close();
            paramPath.moveTo(f5, f6);
            f1 = f5;
            f3 = f1;
            f2 = f6;
            f4 = f2;
          }
        case 81:
        case 83:
        case 113:
        case 115:
          m = 4;
          break;
        case 72:
        case 86:
        case 104:
        case 118:
          m = 1;
          break;
        case 67:
        case 99:
          m = 6;
          break;
        case 65:
        case 97:
          m = 7;
        }
        float f7 = f5;
        float f8 = f6;
        int n = 0;
        float f9 = f1;
        float f10 = f2;
        while (n < localObject1.length)
        {
          int i3;
          Object localObject2;
          int i4;
          int i5;
          if (k != 65)
          {
            if (k != 67)
            {
              if (k != 72)
              {
                if (k != 81)
                {
                  if (k != 86)
                  {
                    if (k != 97)
                    {
                      float f39;
                      float f46;
                      float f47;
                      float f48;
                      float f49;
                      if (k != 99)
                      {
                        float f61;
                        float f62;
                        if (k != 104)
                          if (k != 113)
                            if (k != 118)
                              if (k != 76)
                              {
                                if (k != 77)
                                {
                                  if (k != 83)
                                  {
                                    if (k != 84)
                                    {
                                      if (k != 108)
                                      {
                                        if (k != 109)
                                        {
                                          if (k != 115)
                                          {
                                            if (k != 116);
                                            while (true)
                                            {
                                              i3 = n;
                                              localObject2 = localObject1;
                                              i4 = k;
                                              i5 = j;
                                              break;
                                              float f91;
                                              float f90;
                                              if ((i != 113) && (i != 116) && (i != 81) && (i != 84))
                                              {
                                                f91 = 0.0F;
                                                f90 = 0.0F;
                                              }
                                              else
                                              {
                                                f90 = f9 - f3;
                                                f91 = f10 - f4;
                                              }
                                              int i48 = n + 0;
                                              float f92 = localObject1[i48];
                                              int i49 = n + 1;
                                              paramPath.rQuadTo(f90, f91, f92, localObject1[i49]);
                                              float f93 = f90 + f9;
                                              float f94 = f91 + f10;
                                              f9 += localObject1[i48];
                                              f10 += localObject1[i49];
                                              f4 = f94;
                                              f3 = f93;
                                            }
                                          }
                                          float f84;
                                          float f83;
                                          if ((i != 99) && (i != 115) && (i != 67) && (i != 83))
                                          {
                                            f84 = 0.0F;
                                            f83 = 0.0F;
                                          }
                                          else
                                          {
                                            float f82 = f9 - f3;
                                            f83 = f10 - f4;
                                            f84 = f82;
                                          }
                                          int i44 = n + 0;
                                          float f85 = localObject1[i44];
                                          int i45 = n + 1;
                                          float f86 = localObject1[i45];
                                          int i46 = n + 2;
                                          float f87 = localObject1[i46];
                                          int i47 = n + 3;
                                          float f88 = localObject1[i47];
                                          f39 = f10;
                                          i5 = j;
                                          float f89 = f9;
                                          paramPath.rCubicTo(f84, f83, f85, f86, f87, f88);
                                          f46 = f89 + localObject1[i44];
                                          f47 = f39 + localObject1[i45];
                                          f48 = f89 + localObject1[i46];
                                          f49 = localObject1[i47];
                                          break label1738;
                                        }
                                        float f80 = f10;
                                        i5 = j;
                                        float f81 = f9;
                                        int i42 = n + 0;
                                        f9 = f81 + localObject1[i42];
                                        int i43 = n + 1;
                                        f10 = f80 + localObject1[i43];
                                        if (n > 0)
                                        {
                                          paramPath.rLineTo(localObject1[i42], localObject1[i43]);
                                          break label1372;
                                        }
                                        paramPath.rMoveTo(localObject1[i42], localObject1[i43]);
                                      }
                                      else
                                      {
                                        f61 = f10;
                                        i5 = j;
                                        float f78 = f9;
                                        int i40 = n + 0;
                                        float f79 = localObject1[i40];
                                        int i41 = n + 1;
                                        paramPath.rLineTo(f79, localObject1[i41]);
                                        f9 = f78 + localObject1[i40];
                                        f62 = localObject1[i41];
                                        f10 = f61 + f62;
                                        break label1372;
                                      }
                                    }
                                    else
                                    {
                                      float f74 = f10;
                                      i5 = j;
                                      float f75 = f9;
                                      if ((i == 113) || (i == 116) || (i == 81) || (i == 84))
                                      {
                                        float f76 = f75 * 2.0F - f3;
                                        f74 = f74 * 2.0F - f4;
                                        f75 = f76;
                                      }
                                      int i38 = n + 0;
                                      float f77 = localObject1[i38];
                                      int i39 = n + 1;
                                      paramPath.quadTo(f75, f74, f77, localObject1[i39]);
                                      f9 = localObject1[i38];
                                      f10 = localObject1[i39];
                                      f4 = f74;
                                      i3 = n;
                                      localObject2 = localObject1;
                                      i4 = k;
                                      f3 = f75;
                                      break label2457;
                                    }
                                  }
                                  else
                                  {
                                    float f64 = f10;
                                    i5 = j;
                                    float f65 = f9;
                                    float f67;
                                    float f68;
                                    if ((i != 99) && (i != 115) && (i != 67) && (i != 83))
                                    {
                                      f67 = f64;
                                      f68 = f65;
                                    }
                                    else
                                    {
                                      float f66 = f65 * 2.0F - f3;
                                      f67 = f64 * 2.0F - f4;
                                      f68 = f66;
                                    }
                                    int i34 = n + 0;
                                    float f69 = localObject1[i34];
                                    int i35 = n + 1;
                                    float f70 = localObject1[i35];
                                    int i36 = n + 2;
                                    float f71 = localObject1[i36];
                                    int i37 = n + 3;
                                    paramPath.cubicTo(f68, f67, f69, f70, f71, localObject1[i37]);
                                    float f72 = localObject1[i34];
                                    float f73 = localObject1[i35];
                                    f9 = localObject1[i36];
                                    f10 = localObject1[i37];
                                    f3 = f72;
                                    f4 = f73;
                                    break label1372;
                                  }
                                }
                                else
                                {
                                  i5 = j;
                                  int i32 = n + 0;
                                  f9 = localObject1[i32];
                                  int i33 = n + 1;
                                  f10 = localObject1[i33];
                                  if (n > 0)
                                  {
                                    paramPath.lineTo(localObject1[i32], localObject1[i33]);
                                    break label1372;
                                  }
                                  paramPath.moveTo(localObject1[i32], localObject1[i33]);
                                }
                                f8 = f10;
                                f7 = f9;
                              }
                              else
                              {
                                i5 = j;
                                int i30 = n + 0;
                                float f63 = localObject1[i30];
                                int i31 = n + 1;
                                paramPath.lineTo(f63, localObject1[i31]);
                                f9 = localObject1[i30];
                                f10 = localObject1[i31];
                              }
                        while (true)
                        {
                          label1372: i3 = n;
                          localObject2 = localObject1;
                          i4 = k;
                          break label2457;
                          f61 = f10;
                          i5 = j;
                          int i29 = n + 0;
                          paramPath.rLineTo(0.0F, localObject1[i29]);
                          f62 = localObject1[i29];
                          break;
                          float f52 = f10;
                          i5 = j;
                          float f53 = f9;
                          int i25 = n + 0;
                          float f54 = localObject1[i25];
                          int i26 = n + 1;
                          float f55 = localObject1[i26];
                          int i27 = n + 2;
                          float f56 = localObject1[i27];
                          int i28 = n + 3;
                          paramPath.rQuadTo(f54, f55, f56, localObject1[i28]);
                          float f57 = f53 + localObject1[i25];
                          float f58 = f52 + localObject1[i26];
                          float f59 = f53 + localObject1[i27];
                          float f60 = f52 + localObject1[i28];
                          f3 = f57;
                          f9 = f59;
                          f4 = f58;
                          i3 = n;
                          localObject2 = localObject1;
                          i4 = k;
                          f10 = f60;
                          break label2457;
                          i5 = j;
                          float f51 = f9;
                          int i24 = n + 0;
                          paramPath.rLineTo(localObject1[i24], 0.0F);
                          f9 = f51 + localObject1[i24];
                        }
                      }
                      else
                      {
                        f39 = f10;
                        i5 = j;
                        float f40 = f9;
                        float f41 = localObject1[(n + 0)];
                        float f42 = localObject1[(n + 1)];
                        int i20 = n + 2;
                        float f43 = localObject1[i20];
                        int i21 = n + 3;
                        float f44 = localObject1[i21];
                        int i22 = n + 4;
                        float f45 = localObject1[i22];
                        int i23 = n + 5;
                        paramPath.rCubicTo(f41, f42, f43, f44, f45, localObject1[i23]);
                        f46 = f40 + localObject1[i20];
                        f47 = f39 + localObject1[i21];
                        f48 = f40 + localObject1[i22];
                        f49 = localObject1[i23];
                      }
                      label1738: float f50 = f39 + f49;
                      f4 = f47;
                      f3 = f46;
                      i3 = n;
                      localObject2 = localObject1;
                      i4 = k;
                      f10 = f50;
                      f9 = f48;
                      break label2457;
                    }
                    float f32 = f10;
                    i5 = j;
                    float f33 = f9;
                    int i18 = n + 5;
                    float f34 = f33 + localObject1[i18];
                    int i19 = n + 6;
                    float f35 = f32 + localObject1[i19];
                    float f36 = localObject1[(n + 0)];
                    float f37 = localObject1[(n + 1)];
                    float f38 = localObject1[(n + 2)];
                    boolean bool3;
                    if (localObject1[(n + 3)] != 0.0F)
                      bool3 = true;
                    else
                      bool3 = false;
                    boolean bool4;
                    if (localObject1[(n + 4)] != 0.0F)
                      bool4 = true;
                    else
                      bool4 = false;
                    i3 = n;
                    localObject2 = localObject1;
                    boolean bool5 = bool3;
                    i4 = k;
                    a(paramPath, f33, f32, f34, f35, f36, f37, f38, bool5, bool4);
                    f9 = f33 + localObject2[i18];
                    f10 = f32 + localObject2[i19];
                  }
                  else
                  {
                    i3 = n;
                    localObject2 = localObject1;
                    i4 = k;
                    i5 = j;
                    float f31 = f9;
                    int i17 = i3 + 0;
                    paramPath.lineTo(f31, localObject2[i17]);
                    f10 = localObject2[i17];
                    break label2457;
                  }
                }
                else
                {
                  i3 = n;
                  localObject2 = localObject1;
                  i4 = k;
                  i5 = j;
                  int i13 = i3 + 0;
                  float f26 = localObject2[i13];
                  int i14 = i3 + 1;
                  float f27 = localObject2[i14];
                  int i15 = i3 + 2;
                  float f28 = localObject2[i15];
                  int i16 = i3 + 3;
                  paramPath.quadTo(f26, f27, f28, localObject2[i16]);
                  float f29 = localObject2[i13];
                  float f30 = localObject2[i14];
                  f9 = localObject2[i15];
                  f10 = localObject2[i16];
                  f3 = f29;
                  f4 = f30;
                  break label2457;
                }
              }
              else
              {
                float f25 = f10;
                i3 = n;
                localObject2 = localObject1;
                i4 = k;
                i5 = j;
                int i12 = i3 + 0;
                paramPath.lineTo(localObject2[i12], f25);
                f9 = localObject2[i12];
                break label2457;
              }
            }
            else
            {
              i3 = n;
              localObject2 = localObject1;
              i4 = k;
              i5 = j;
              float f19 = localObject2[(i3 + 0)];
              float f20 = localObject2[(i3 + 1)];
              int i8 = i3 + 2;
              float f21 = localObject2[i8];
              int i9 = i3 + 3;
              float f22 = localObject2[i9];
              int i10 = i3 + 4;
              float f23 = localObject2[i10];
              int i11 = i3 + 5;
              paramPath.cubicTo(f19, f20, f21, f22, f23, localObject2[i11]);
              f9 = localObject2[i10];
              f10 = localObject2[i11];
              float f24 = localObject2[i8];
              f4 = localObject2[i9];
              f3 = f24;
              break label2457;
            }
          }
          else
          {
            float f12 = f10;
            i3 = n;
            localObject2 = localObject1;
            i4 = k;
            i5 = j;
            float f13 = f9;
            int i6 = i3 + 5;
            float f14 = localObject2[i6];
            int i7 = i3 + 6;
            float f15 = localObject2[i7];
            float f16 = localObject2[(i3 + 0)];
            float f17 = localObject2[(i3 + 1)];
            float f18 = localObject2[(i3 + 2)];
            boolean bool1;
            if (localObject2[(i3 + 3)] != 0.0F)
              bool1 = true;
            else
              bool1 = false;
            boolean bool2;
            if (localObject2[(i3 + 4)] != 0.0F)
              bool2 = true;
            else
              bool2 = false;
            a(paramPath, f13, f12, f14, f15, f16, f17, f18, bool1, bool2);
            f9 = localObject2[i6];
            f10 = localObject2[i7];
          }
          f4 = f10;
          f3 = f9;
          label2457: n = i3 + m;
          localObject1 = localObject2;
          j = i5;
          i = i4;
          k = i;
        }
        float f11 = f10;
        int i1 = j;
        arrayOfFloat[0] = f9;
        arrayOfFloat[1] = f11;
        arrayOfFloat[2] = f3;
        arrayOfFloat[3] = f4;
        arrayOfFloat[4] = f7;
        arrayOfFloat[5] = f8;
        int i2 = paramArrayOfb[i1].a;
        j = i1 + 1;
        i = i2;
        arrayOfb = paramArrayOfb;
      }
    }

    public final void a(b paramb1, b paramb2, float paramFloat)
    {
      for (int i = 0; ; i++)
      {
        float[] arrayOfFloat = paramb1.b;
        if (i >= arrayOfFloat.length)
          break;
        this.b[i] = (arrayOfFloat[i] * (1.0F - paramFloat) + paramFloat * paramb2.b[i]);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.graphics.b
 * JD-Core Version:    0.6.2
 */