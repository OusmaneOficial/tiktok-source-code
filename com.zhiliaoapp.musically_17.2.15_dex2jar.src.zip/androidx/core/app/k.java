package androidx.core.app;

import android.app.Person;
import android.app.Person.Builder;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class k
{
  public CharSequence a;
  public IconCompat b;
  public String c;
  public String d;
  public boolean e;
  public boolean f;

  static
  {
    CoverageLogger.Log(46675968);
  }

  k(a parama)
  {
    this.a = parama.a;
    this.b = parama.b;
    this.c = parama.c;
    this.d = parama.d;
    this.e = parama.e;
    this.f = parama.f;
  }

  public final Bundle a()
  {
    Bundle localBundle1 = new Bundle();
    localBundle1.putCharSequence("name", this.a);
    IconCompat localIconCompat = this.b;
    Bundle localBundle2;
    if (localIconCompat != null)
      localBundle2 = localIconCompat.b();
    else
      localBundle2 = null;
    localBundle1.putBundle("icon", localBundle2);
    localBundle1.putString("uri", this.c);
    localBundle1.putString("key", this.d);
    localBundle1.putBoolean("isBot", this.e);
    localBundle1.putBoolean("isImportant", this.f);
    return localBundle1;
  }

  public final Person b()
  {
    Person.Builder localBuilder = new Person.Builder().setName(this.a);
    IconCompat localIconCompat = this.b;
    Icon localIcon;
    if (localIconCompat != null)
      localIcon = localIconCompat.a();
    else
      localIcon = null;
    return localBuilder.setIcon(localIcon).setUri(this.c).setKey(this.d).setBot(this.e).setImportant(this.f).build();
  }

  public static final class a
  {
    CharSequence a;
    IconCompat b;
    String c;
    String d;
    boolean e;
    boolean f;

    static
    {
      CoverageLogger.Log(46518272);
    }

    public final a a(CharSequence paramCharSequence)
    {
      this.a = paramCharSequence;
      return this;
    }

    public final k a()
    {
      return new k(this);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.k
 * JD-Core Version:    0.6.2
 */