package androidx.core.app;

import android.graphics.Matrix;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class m
{
  Matrix a;

  static
  {
    CoverageLogger.Log(46688256);
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46684160);
    }

    public abstract void a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.m
 * JD-Core Version:    0.6.2
 */