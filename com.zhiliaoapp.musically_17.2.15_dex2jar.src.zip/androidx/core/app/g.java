package androidx.core.app;

import android.app.Notification;
import android.app.Notification.BigPictureStyle;
import android.app.Notification.BigTextStyle;
import android.app.Notification.Builder;
import android.app.Notification.InboxStyle;
import android.app.Notification.MessagingStyle;
import android.app.Notification.MessagingStyle.Message;
import android.app.PendingIntent;
import android.app.Person;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.media.AudioAttributes.Builder;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.widget.RemoteViews;
import androidx.core.f.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class g
{
  static
  {
    CoverageLogger.Log(46659584);
  }

  public static Bundle a(Notification paramNotification)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return paramNotification.extras;
    if (Build.VERSION.SDK_INT >= 16)
      return i.a(paramNotification);
    return null;
  }

  public static final class a
  {
    public final Bundle a;
    public final l[] b;
    public final l[] c;
    public boolean d;
    public boolean e = true;
    public final int f;
    public int g;
    public CharSequence h;
    public PendingIntent i;

    static
    {
      CoverageLogger.Log(46643200);
    }

    public a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent)
    {
      this(paramInt, paramCharSequence, paramPendingIntent, new Bundle(), null, null, true, 0, true);
    }

    private a(int paramInt1, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle, l[] paramArrayOfl1, l[] paramArrayOfl2, boolean paramBoolean1, int paramInt2, boolean paramBoolean2)
    {
      this.g = paramInt1;
      this.h = g.d.d(paramCharSequence);
      this.i = paramPendingIntent;
      this.a = paramBundle;
      this.b = null;
      this.c = null;
      this.d = true;
      this.f = 0;
      this.e = true;
    }
  }

  public static final class b extends g.g
  {
    private Bitmap a;
    private Bitmap b;
    private boolean c;

    static
    {
      CoverageLogger.Log(46563328);
    }

    public final b a(Bitmap paramBitmap)
    {
      this.a = paramBitmap;
      return this;
    }

    public final b a(CharSequence paramCharSequence)
    {
      this.e = g.d.d(paramCharSequence);
      return this;
    }

    public final void a(f paramf)
    {
      if (Build.VERSION.SDK_INT >= 16)
      {
        Notification.BigPictureStyle localBigPictureStyle = new Notification.BigPictureStyle(paramf.a()).setBigContentTitle(this.e).bigPicture(this.a);
        if (this.c)
          localBigPictureStyle.bigLargeIcon(this.b);
        if (this.g)
          localBigPictureStyle.setSummaryText(this.f);
      }
    }

    public final b b(Bitmap paramBitmap)
    {
      this.b = paramBitmap;
      this.c = true;
      return this;
    }

    public final b b(CharSequence paramCharSequence)
    {
      this.f = g.d.d(paramCharSequence);
      this.g = true;
      return this;
    }
  }

  public static final class c extends g.g
  {
    private CharSequence a;

    static
    {
      CoverageLogger.Log(46649344);
    }

    public final c a(CharSequence paramCharSequence)
    {
      this.e = g.d.d(paramCharSequence);
      return this;
    }

    public final void a(f paramf)
    {
      if (Build.VERSION.SDK_INT >= 16)
      {
        Notification.BigTextStyle localBigTextStyle = new Notification.BigTextStyle(paramf.a()).setBigContentTitle(this.e).bigText(this.a);
        if (this.g)
          localBigTextStyle.setSummaryText(this.f);
      }
    }

    public final c b(CharSequence paramCharSequence)
    {
      this.f = g.d.d(paramCharSequence);
      this.g = true;
      return this;
    }

    public final c c(CharSequence paramCharSequence)
    {
      this.a = g.d.d(paramCharSequence);
      return this;
    }
  }

  public static final class d
  {
    public String A;
    Bundle B;
    public int C = 0;
    int D = 0;
    Notification E;
    public RemoteViews F;
    public RemoteViews G;
    public RemoteViews H;
    public String I;
    int J = 0;
    String K;
    long L;
    int M = 0;
    public Notification N = new Notification();
    public ArrayList<String> O;
    public Context a;
    public ArrayList<g.a> b = new ArrayList();
    ArrayList<g.a> c = new ArrayList();
    CharSequence d;
    CharSequence e;
    PendingIntent f;
    public PendingIntent g;
    RemoteViews h;
    Bitmap i;
    CharSequence j;
    int k;
    public int l;
    boolean m = true;
    boolean n;
    g.g o;
    CharSequence p;
    CharSequence[] q;
    int r;
    int s;
    boolean t;
    public String u;
    public boolean v;
    String w;
    public boolean x = false;
    boolean y;
    boolean z;

    static
    {
      CoverageLogger.Log(46645248);
    }

    public d(Context paramContext)
    {
      this(paramContext, null);
    }

    public d(Context paramContext, String paramString)
    {
      this.a = paramContext;
      this.I = paramString;
      this.N.when = System.currentTimeMillis();
      this.N.audioStreamType = -1;
      this.l = 0;
      this.O = new ArrayList();
    }

    protected static CharSequence d(CharSequence paramCharSequence)
    {
      if (paramCharSequence == null)
        return paramCharSequence;
      if (paramCharSequence.length() > 5120)
        paramCharSequence = paramCharSequence.subSequence(0, 5120);
      return paramCharSequence;
    }

    public final Bundle a()
    {
      if (this.B == null)
        this.B = new Bundle();
      return this.B;
    }

    public final d a(int paramInt)
    {
      this.N.icon = paramInt;
      return this;
    }

    public final d a(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      this.r = 100;
      this.s = paramInt2;
      this.t = false;
      return this;
    }

    public final d a(long paramLong)
    {
      this.N.when = paramLong;
      return this;
    }

    public final d a(PendingIntent paramPendingIntent)
    {
      this.f = paramPendingIntent;
      return this;
    }

    public final d a(Bitmap paramBitmap)
    {
      if ((paramBitmap != null) && (Build.VERSION.SDK_INT < 27))
      {
        Resources localResources = this.a.getResources();
        int i1 = localResources.getDimensionPixelSize(2131165445);
        int i2 = localResources.getDimensionPixelSize(2131165444);
        if ((paramBitmap.getWidth() > i1) || (paramBitmap.getHeight() > i2))
        {
          double d1 = i1;
          double d2 = Math.max(1, paramBitmap.getWidth());
          Double.isNaN(d1);
          Double.isNaN(d2);
          double d3 = d1 / d2;
          double d4 = i2;
          double d5 = Math.max(1, paramBitmap.getHeight());
          Double.isNaN(d4);
          Double.isNaN(d5);
          double d6 = Math.min(d3, d4 / d5);
          double d7 = paramBitmap.getWidth();
          Double.isNaN(d7);
          int i3 = (int)Math.ceil(d7 * d6);
          double d8 = paramBitmap.getHeight();
          Double.isNaN(d8);
          paramBitmap = Bitmap.createScaledBitmap(paramBitmap, i3, (int)Math.ceil(d8 * d6), true);
        }
      }
      this.i = paramBitmap;
      return this;
    }

    public final d a(Uri paramUri)
    {
      Notification localNotification = this.N;
      localNotification.sound = paramUri;
      localNotification.audioStreamType = -1;
      if (Build.VERSION.SDK_INT >= 21)
        this.N.audioAttributes = new AudioAttributes.Builder().setContentType(4).setUsage(5).build();
      return this;
    }

    public final d a(g.g paramg)
    {
      if (this.o != paramg)
      {
        this.o = paramg;
        g.g localg = this.o;
        if (localg != null)
          localg.a(this);
      }
      return this;
    }

    public final d a(CharSequence paramCharSequence)
    {
      this.d = d(paramCharSequence);
      return this;
    }

    public final d a(boolean paramBoolean)
    {
      a(2, true);
      return this;
    }

    public void a(int paramInt, boolean paramBoolean)
    {
      if (paramBoolean)
      {
        Notification localNotification2 = this.N;
        localNotification2.flags = (paramInt | localNotification2.flags);
        return;
      }
      Notification localNotification1 = this.N;
      localNotification1.flags &= (paramInt ^ 0xFFFFFFFF);
    }

    public final Notification b()
    {
      return new h(this).b();
    }

    public final d b(int paramInt)
    {
      Notification localNotification = this.N;
      localNotification.defaults = paramInt;
      if ((paramInt & 0x4) != 0)
        localNotification.flags = (0x1 | localNotification.flags);
      return this;
    }

    public final d b(PendingIntent paramPendingIntent)
    {
      this.N.deleteIntent = paramPendingIntent;
      return this;
    }

    public final d b(CharSequence paramCharSequence)
    {
      this.e = d(paramCharSequence);
      return this;
    }

    public final d b(boolean paramBoolean)
    {
      a(16, true);
      return this;
    }

    public final long c()
    {
      if (this.m)
        return this.N.when;
      return 0L;
    }

    public final d c(int paramInt)
    {
      this.l = paramInt;
      return this;
    }

    public final d c(CharSequence paramCharSequence)
    {
      this.N.tickerText = d(paramCharSequence);
      return this;
    }

    public final d d(int paramInt)
    {
      this.C = paramInt;
      return this;
    }

    public final d e(int paramInt)
    {
      this.D = paramInt;
      return this;
    }
  }

  public static final class e extends g.g
  {
    private ArrayList<CharSequence> a = new ArrayList();

    static
    {
      CoverageLogger.Log(46555136);
    }

    public final e a(CharSequence paramCharSequence)
    {
      this.e = g.d.d(paramCharSequence);
      return this;
    }

    public final void a(f paramf)
    {
      if (Build.VERSION.SDK_INT >= 16)
      {
        Notification.InboxStyle localInboxStyle = new Notification.InboxStyle(paramf.a()).setBigContentTitle(this.e);
        if (this.g)
          localInboxStyle.setSummaryText(this.f);
        Iterator localIterator = this.a.iterator();
        while (localIterator.hasNext())
          localInboxStyle.addLine((CharSequence)localIterator.next());
      }
    }

    public final e b(CharSequence paramCharSequence)
    {
      this.f = g.d.d(paramCharSequence);
      this.g = true;
      return this;
    }

    public final e c(CharSequence paramCharSequence)
    {
      this.a.add(g.d.d(paramCharSequence));
      return this;
    }
  }

  public static final class f extends g.g
  {
    public final List<a> a = new ArrayList();
    public k b;
    public CharSequence c;
    private Boolean h;

    static
    {
      CoverageLogger.Log(46553088);
    }

    private f()
    {
    }

    public f(CharSequence paramCharSequence)
    {
      this.b = new k.a().a(paramCharSequence).a();
    }

    private static TextAppearanceSpan a(int paramInt)
    {
      TextAppearanceSpan localTextAppearanceSpan = new TextAppearanceSpan(null, 0, 0, ColorStateList.valueOf(paramInt), null);
      return localTextAppearanceSpan;
    }

    private a a()
    {
      for (int i = -1 + this.a.size(); i >= 0; i--)
      {
        a locala = (a)this.a.get(i);
        if ((locala.c != null) && (!TextUtils.isEmpty(locala.c.a)))
          return locala;
      }
      if (!this.a.isEmpty())
      {
        List localList = this.a;
        return (a)localList.get(-1 + localList.size());
      }
      return null;
    }

    private CharSequence a(a parama)
    {
      a locala = a.a();
      SpannableStringBuilder localSpannableStringBuilder = new SpannableStringBuilder();
      int i;
      if (Build.VERSION.SDK_INT >= 21)
        i = 1;
      else
        i = 0;
      int j;
      if (i != 0)
        j = -16777216;
      else
        j = -1;
      k localk = parama.c;
      Object localObject1 = "";
      Object localObject2;
      if (localk == null)
        localObject2 = localObject1;
      else
        localObject2 = parama.c.a;
      if (TextUtils.isEmpty((CharSequence)localObject2))
      {
        localObject2 = this.b.a;
        if ((i != 0) && (this.d.C != 0))
          j = this.d.C;
      }
      CharSequence localCharSequence = locala.a((CharSequence)localObject2);
      localSpannableStringBuilder.append(localCharSequence);
      localSpannableStringBuilder.setSpan(a(j), localSpannableStringBuilder.length() - localCharSequence.length(), localSpannableStringBuilder.length(), 33);
      if (parama.a != null)
        localObject1 = parama.a;
      localSpannableStringBuilder.append("  ").append(locala.a((CharSequence)localObject1));
      return localSpannableStringBuilder;
    }

    private boolean b()
    {
      for (int i = this.a.size() - 1; i >= 0; i--)
      {
        a locala = (a)this.a.get(i);
        if ((locala.c != null) && (locala.c.a == null))
          return true;
      }
      return false;
    }

    public final void a(Bundle paramBundle)
    {
      super.a(paramBundle);
      paramBundle.putCharSequence("android.selfDisplayName", this.b.a);
      paramBundle.putBundle("android.messagingStyleUser", this.b.a());
      paramBundle.putCharSequence("android.hiddenConversationTitle", this.c);
      if ((this.c != null) && (this.h.booleanValue()))
        paramBundle.putCharSequence("android.conversationTitle", this.c);
      if (!this.a.isEmpty())
      {
        List localList = this.a;
        Bundle[] arrayOfBundle = new Bundle[localList.size()];
        int i = localList.size();
        for (int j = 0; j < i; j++)
        {
          a locala = (a)localList.get(j);
          Bundle localBundle = new Bundle();
          if (locala.a != null)
            localBundle.putCharSequence("text", locala.a);
          localBundle.putLong("time", locala.b);
          if (locala.c != null)
          {
            localBundle.putCharSequence("sender", locala.c.a);
            if (Build.VERSION.SDK_INT >= 28)
              localBundle.putParcelable("sender_person", locala.c.b());
            else
              localBundle.putBundle("person", locala.c.a());
          }
          if (locala.e != null)
            localBundle.putString("type", locala.e);
          if (locala.f != null)
            localBundle.putParcelable("uri", locala.f);
          if (locala.d != null)
            localBundle.putBundle("extras", locala.d);
          arrayOfBundle[j] = localBundle;
        }
        paramBundle.putParcelableArray("android.messages", arrayOfBundle);
      }
      Boolean localBoolean = this.h;
      if (localBoolean != null)
        paramBundle.putBoolean("android.isGroupConversation", localBoolean.booleanValue());
    }

    public final void a(f paramf)
    {
      if ((this.d != null) && (this.d.a.getApplicationInfo().targetSdkVersion < 28) && (this.h == null))
      {
        if (this.c != null)
        {
          bool = true;
          break label63;
        }
      }
      else
      {
        Boolean localBoolean = this.h;
        if (localBoolean != null)
        {
          bool = localBoolean.booleanValue();
          break label63;
        }
      }
      boolean bool = false;
      label63: this.h = Boolean.valueOf(bool);
      if (Build.VERSION.SDK_INT >= 24)
      {
        Notification.MessagingStyle localMessagingStyle;
        if (Build.VERSION.SDK_INT >= 28)
          localMessagingStyle = new Notification.MessagingStyle(this.b.b());
        else
          localMessagingStyle = new Notification.MessagingStyle(this.b.a);
        if ((this.h.booleanValue()) || (Build.VERSION.SDK_INT >= 28))
          localMessagingStyle.setConversationTitle(this.c);
        if (Build.VERSION.SDK_INT >= 28)
          localMessagingStyle.setGroupConversation(this.h.booleanValue());
        Iterator localIterator = this.a.iterator();
        while (localIterator.hasNext())
        {
          a locala3 = (a)localIterator.next();
          Notification.MessagingStyle.Message localMessage;
          if (Build.VERSION.SDK_INT >= 28)
          {
            k localk = locala3.c;
            CharSequence localCharSequence4 = locala3.a;
            long l = locala3.b;
            Person localPerson;
            if (localk == null)
              localPerson = null;
            else
              localPerson = localk.b();
            localMessage = new Notification.MessagingStyle.Message(localCharSequence4, l, localPerson);
          }
          else
          {
            CharSequence localCharSequence3;
            if (locala3.c != null)
              localCharSequence3 = locala3.c.a;
            else
              localCharSequence3 = null;
            localMessage = new Notification.MessagingStyle.Message(locala3.a, locala3.b, localCharSequence3);
          }
          if (locala3.e != null)
            localMessage.setData(locala3.e, locala3.f);
          localMessagingStyle.addMessage(localMessage);
        }
        localMessagingStyle.setBuilder(paramf.a());
        return;
      }
      a locala1 = a();
      if ((this.c != null) && (this.h.booleanValue()))
      {
        paramf.a().setContentTitle(this.c);
      }
      else if (locala1 != null)
      {
        paramf.a().setContentTitle("");
        if (locala1.c != null)
          paramf.a().setContentTitle(locala1.c.a);
      }
      if (locala1 != null)
      {
        Notification.Builder localBuilder = paramf.a();
        CharSequence localCharSequence2;
        if (this.c != null)
          localCharSequence2 = a(locala1);
        else
          localCharSequence2 = locala1.a;
        localBuilder.setContentText(localCharSequence2);
      }
      if (Build.VERSION.SDK_INT >= 16)
      {
        SpannableStringBuilder localSpannableStringBuilder = new SpannableStringBuilder();
        int i;
        if ((this.c == null) && (!b()))
          i = 0;
        else
          i = 1;
        for (int j = this.a.size() - 1; j >= 0; j--)
        {
          a locala2 = (a)this.a.get(j);
          CharSequence localCharSequence1;
          if (i != 0)
            localCharSequence1 = a(locala2);
          else
            localCharSequence1 = locala2.a;
          if (j != this.a.size() - 1)
            localSpannableStringBuilder.insert(0, "\n");
          localSpannableStringBuilder.insert(0, localCharSequence1);
        }
        new Notification.BigTextStyle(paramf.a()).setBigContentTitle(null).bigText(localSpannableStringBuilder);
      }
    }

    public static final class a
    {
      public final CharSequence a;
      public final long b;
      public final k c;
      public Bundle d = new Bundle();
      public String e;
      public Uri f;

      static
      {
        CoverageLogger.Log(46548992);
      }

      public a(CharSequence paramCharSequence, long paramLong, k paramk)
      {
        this.a = paramCharSequence;
        this.b = paramLong;
        this.c = paramk;
      }
    }
  }

  public static abstract class g
  {
    protected g.d d;
    CharSequence e;
    CharSequence f;
    boolean g;

    static
    {
      CoverageLogger.Log(46546944);
    }

    public final RemoteViews a(boolean paramBoolean1, int paramInt, boolean paramBoolean2)
    {
      Resources localResources = this.d.a.getResources();
      RemoteViews localRemoteViews = new RemoteViews(this.d.a.getPackageName(), paramInt);
      int i = this.d.l;
      boolean bool1 = true;
      int j;
      if (i < -1)
        j = 1;
      else
        j = 0;
      if ((Build.VERSION.SDK_INT >= 16) && (Build.VERSION.SDK_INT < 21))
        if (j != 0)
        {
          localRemoteViews.setInt(2131300327, "setBackgroundResource", 2131233848);
          localRemoteViews.setInt(2131298662, "setBackgroundResource", 2131233855);
        }
        else
        {
          localRemoteViews.setInt(2131300327, "setBackgroundResource", 2131233847);
          localRemoteViews.setInt(2131298662, "setBackgroundResource", 2131233854);
        }
      if (this.d.i != null)
        if (Build.VERSION.SDK_INT >= 16)
        {
          localRemoteViews.setViewVisibility(2131298662, 0);
          localRemoteViews.setImageViewBitmap(2131298662, this.d.i);
        }
        else
        {
          localRemoteViews.setViewVisibility(2131298662, 8);
        }
      if (this.d.d != null)
        localRemoteViews.setTextViewText(2131302118, this.d.d);
      int k;
      if (this.d.e != null)
      {
        localRemoteViews.setTextViewText(2131302010, this.d.e);
        k = 1;
      }
      else
      {
        k = 0;
      }
      boolean bool2;
      if ((Build.VERSION.SDK_INT < 21) && (this.d.i != null))
        bool2 = true;
      else
        bool2 = false;
      if (this.d.j != null)
      {
        localRemoteViews.setTextViewText(2131298806, this.d.j);
        localRemoteViews.setViewVisibility(2131298806, 0);
      }
      while (true)
      {
        k = 1;
        bool3 = true;
        break label397;
        if (this.d.k <= 0)
          break;
        int i2 = localResources.getInteger(2131361834);
        if (this.d.k > i2)
          localRemoteViews.setTextViewText(2131298806, localResources.getString(2131829801));
        else
          localRemoteViews.setTextViewText(2131298806, NumberFormat.getIntegerInstance().format(this.d.k));
        localRemoteViews.setViewVisibility(2131298806, 0);
      }
      localRemoteViews.setViewVisibility(2131298806, 8);
      boolean bool3 = bool2;
      label397: int m;
      if ((this.d.p != null) && (Build.VERSION.SDK_INT >= 16))
      {
        localRemoteViews.setTextViewText(2131302010, this.d.p);
        if (this.d.e != null)
        {
          localRemoteViews.setTextViewText(2131302012, this.d.e);
          localRemoteViews.setViewVisibility(2131302012, 0);
          m = 1;
        }
        else
        {
          localRemoteViews.setViewVisibility(2131302012, 8);
        }
      }
      else
      {
        m = 0;
      }
      if ((m != 0) && (Build.VERSION.SDK_INT >= 16))
      {
        if (paramBoolean2)
          localRemoteViews.setTextViewTextSize(2131302010, 0, localResources.getDimensionPixelSize(2131165730));
        localRemoteViews.setViewPadding(2131299597, 0, 0, 0, 0);
      }
      if (this.d.c() != 0L)
      {
        if ((this.d.n) && (Build.VERSION.SDK_INT >= 16))
        {
          localRemoteViews.setViewVisibility(2131297176, 0);
          localRemoteViews.setLong(2131297176, "setBase", this.d.c() + (SystemClock.elapsedRealtime() - System.currentTimeMillis()));
          localRemoteViews.setBoolean(2131297176, "setStarted", bool1);
        }
        else
        {
          localRemoteViews.setViewVisibility(2131302093, 0);
          localRemoteViews.setLong(2131302093, "setTime", this.d.c());
        }
      }
      else
        bool1 = bool3;
      int n;
      if (bool1)
        n = 0;
      else
        n = 8;
      localRemoteViews.setViewVisibility(2131301027, n);
      int i1;
      if (k != 0)
        i1 = 0;
      else
        i1 = 8;
      localRemoteViews.setViewVisibility(2131299598, i1);
      return localRemoteViews;
    }

    public void a(Bundle paramBundle)
    {
    }

    public void a(f paramf)
    {
    }

    public final void a(g.d paramd)
    {
      if (this.d != paramd)
      {
        this.d = paramd;
        g.d locald = this.d;
        if (locald != null)
          locald.a(this);
      }
    }

    public RemoteViews b(f paramf)
    {
      return null;
    }

    public RemoteViews c(f paramf)
    {
      return null;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.g
 * JD-Core Version:    0.6.2
 */