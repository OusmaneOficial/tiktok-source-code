package androidx.core.app;

import android.app.Service;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class NotificationCompatSideChannelService extends Service
{
  static
  {
    CoverageLogger.Log(46665728);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.NotificationCompatSideChannelService
 * JD-Core Version:    0.6.2
 */