package androidx.core.app;

import android.app.RemoteInput;
import android.app.RemoteInput.Builder;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Set;

public final class l
{
  public final String a;
  public final CharSequence b;
  public final CharSequence[] c;
  public final boolean d;
  public final Bundle e;
  public final Set<String> f;

  static
  {
    CoverageLogger.Log(46682112);
  }

  static RemoteInput[] a(l[] paramArrayOfl)
  {
    if (paramArrayOfl == null)
      return null;
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfl.length];
    for (int i = 0; i < paramArrayOfl.length; i++)
    {
      l locall = paramArrayOfl[i];
      arrayOfRemoteInput[i] = new RemoteInput.Builder(locall.a).setLabel(locall.b).setChoices(locall.c).setAllowFreeFormInput(locall.d).addExtras(locall.e).build();
    }
    return arrayOfRemoteInput;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.l
 * JD-Core Version:    0.6.2
 */