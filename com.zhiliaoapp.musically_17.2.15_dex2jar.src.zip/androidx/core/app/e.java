package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
{
  static
  {
    CoverageLogger.Log(46639104);
  }

  // ERROR //
  public static Intent a(Activity paramActivity)
  {
    // Byte code:
    //   0: getstatic 23	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 16
    //   5: if_icmplt +17 -> 22
    //   8: aload_0
    //   9: invokevirtual 29	android/app/Activity:getParentActivityIntent	()Landroid/content/Intent;
    //   12: astore 4
    //   14: aload 4
    //   16: ifnull +6 -> 22
    //   19: aload 4
    //   21: areturn
    //   22: aload_0
    //   23: invokestatic 33	androidx/core/app/e:b	(Landroid/app/Activity;)Ljava/lang/String;
    //   26: astore_1
    //   27: aload_1
    //   28: ifnonnull +5 -> 33
    //   31: aconst_null
    //   32: areturn
    //   33: new 35	android/content/ComponentName
    //   36: dup
    //   37: aload_0
    //   38: aload_1
    //   39: invokespecial 39	android/content/ComponentName:<init>	(Landroid/content/Context;Ljava/lang/String;)V
    //   42: astore_2
    //   43: aload_0
    //   44: aload_2
    //   45: invokestatic 42	androidx/core/app/e:b	(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;
    //   48: ifnonnull +8 -> 56
    //   51: aload_2
    //   52: invokestatic 48	android/content/Intent:makeMainActivity	(Landroid/content/ComponentName;)Landroid/content/Intent;
    //   55: areturn
    //   56: new 44	android/content/Intent
    //   59: dup
    //   60: invokespecial 50	android/content/Intent:<init>	()V
    //   63: aload_2
    //   64: invokevirtual 53	android/content/Intent:setComponent	(Landroid/content/ComponentName;)Landroid/content/Intent;
    //   67: astore_3
    //   68: aload_3
    //   69: areturn
    //   70: aconst_null
    //   71: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   43	56	70	android/content/pm/PackageManager$NameNotFoundException
    //   56	68	70	android/content/pm/PackageManager$NameNotFoundException
  }

  public static Intent a(Context paramContext, ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    String str = b(paramContext, paramComponentName);
    if (str == null)
      return null;
    ComponentName localComponentName = new ComponentName(paramComponentName.getPackageName(), str);
    if (b(paramContext, localComponentName) == null)
      return Intent.makeMainActivity(localComponentName);
    return new Intent().setComponent(localComponentName);
  }

  public static String b(Activity paramActivity)
  {
    try
    {
      String str = b(paramActivity, paramActivity.getComponentName());
      return str;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      throw new IllegalArgumentException(localNameNotFoundException);
    }
  }

  private static String b(Context paramContext, ComponentName paramComponentName)
    throws PackageManager.NameNotFoundException
  {
    ActivityInfo localActivityInfo = paramContext.getPackageManager().getActivityInfo(paramComponentName, 128);
    if (Build.VERSION.SDK_INT >= 16)
    {
      String str2 = localActivityInfo.parentActivityName;
      if (str2 != null)
        return str2;
    }
    if (localActivityInfo.metaData == null)
      return null;
    String str1 = localActivityInfo.metaData.getString("android.support.PARENT_ACTIVITY");
    if (str1 == null)
      return null;
    if (str1.charAt(0) == '.')
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(paramContext.getPackageName());
      localStringBuilder.append(str1);
      str1 = localStringBuilder.toString();
    }
    return str1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.e
 * JD-Core Version:    0.6.2
 */