package androidx.core.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.Iterator;

public final class n
  implements Iterable<Intent>
{
  public final ArrayList<Intent> a = new ArrayList();
  public final Context b;

  static
  {
    CoverageLogger.Log(46690304);
  }

  public n(Context paramContext)
  {
    this.b = paramContext;
  }

  public final n a(ComponentName paramComponentName)
  {
    int i = this.a.size();
    IllegalArgumentException localIllegalArgumentException;
    try
    {
      for (Intent localIntent = e.a(this.b, paramComponentName); localIntent != null; localIntent = e.a(this.b, localIntent.getComponent()))
        this.a.add(i, localIntent);
      return this;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      localIllegalArgumentException = new IllegalArgumentException(localNameNotFoundException);
    }
    while (true)
      throw localIllegalArgumentException;
  }

  public final Iterator<Intent> iterator()
  {
    return this.a.iterator();
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46510080);
    }

    public abstract Intent getSupportParentActivityIntent();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.n
 * JD-Core Version:    0.6.2
 */