package androidx.core.app;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Method;

public final class d
{
  static
  {
    CoverageLogger.Log(46925824);
  }

  public static IBinder a(Bundle paramBundle, String paramString)
  {
    if (Build.VERSION.SDK_INT >= 18)
      return paramBundle.getBinder(paramString);
    return a.a(paramBundle, paramString);
  }

  public static void a(Bundle paramBundle, String paramString, IBinder paramIBinder)
  {
    if (Build.VERSION.SDK_INT >= 18)
    {
      paramBundle.putBinder(paramString, paramIBinder);
      return;
    }
    a.a(paramBundle, paramString, paramIBinder);
  }

  static final class a
  {
    private static Method a;
    private static boolean b;
    private static Method c;
    private static boolean d;

    static
    {
      CoverageLogger.Log(46600192);
    }

    // ERROR //
    public static IBinder a(Bundle paramBundle, String paramString)
    {
      // Byte code:
      //   0: getstatic 30	androidx/core/app/d$a:b	Z
      //   3: ifne +40 -> 43
      //   6: ldc 32
      //   8: ldc 34
      //   10: iconst_1
      //   11: anewarray 36	java/lang/Class
      //   14: dup
      //   15: iconst_0
      //   16: ldc 38
      //   18: aastore
      //   19: invokevirtual 42	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   22: astore 5
      //   24: aload 5
      //   26: putstatic 44	androidx/core/app/d$a:a	Ljava/lang/reflect/Method;
      //   29: aload 5
      //   31: iconst_1
      //   32: invokevirtual 50	java/lang/reflect/Method:setAccessible	(Z)V
      //   35: goto +4 -> 39
      //   38: pop
      //   39: iconst_1
      //   40: putstatic 30	androidx/core/app/d$a:b	Z
      //   43: getstatic 44	androidx/core/app/d$a:a	Ljava/lang/reflect/Method;
      //   46: astore_2
      //   47: aload_2
      //   48: ifnull +26 -> 74
      //   51: aload_2
      //   52: aload_0
      //   53: iconst_1
      //   54: anewarray 4	java/lang/Object
      //   57: dup
      //   58: iconst_0
      //   59: aload_1
      //   60: aastore
      //   61: invokevirtual 54	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   64: checkcast 56	android/os/IBinder
      //   67: astore_3
      //   68: aload_3
      //   69: areturn
      //   70: aconst_null
      //   71: putstatic 44	androidx/core/app/d$a:a	Ljava/lang/reflect/Method;
      //   74: aconst_null
      //   75: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   6	35	38	java/lang/NoSuchMethodException
      //   51	68	70	java/lang/reflect/InvocationTargetException
      //   51	68	70	java/lang/IllegalAccessException
      //   51	68	70	java/lang/IllegalArgumentException
    }

    // ERROR //
    public static void a(Bundle paramBundle, String paramString, IBinder paramIBinder)
    {
      // Byte code:
      //   0: getstatic 59	androidx/core/app/d$a:d	Z
      //   3: ifne +45 -> 48
      //   6: ldc 32
      //   8: ldc 61
      //   10: iconst_2
      //   11: anewarray 36	java/lang/Class
      //   14: dup
      //   15: iconst_0
      //   16: ldc 38
      //   18: aastore
      //   19: dup
      //   20: iconst_1
      //   21: ldc 56
      //   23: aastore
      //   24: invokevirtual 42	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   27: astore 6
      //   29: aload 6
      //   31: putstatic 63	androidx/core/app/d$a:c	Ljava/lang/reflect/Method;
      //   34: aload 6
      //   36: iconst_1
      //   37: invokevirtual 50	java/lang/reflect/Method:setAccessible	(Z)V
      //   40: goto +4 -> 44
      //   43: pop
      //   44: iconst_1
      //   45: putstatic 59	androidx/core/app/d$a:d	Z
      //   48: getstatic 63	androidx/core/app/d$a:c	Ljava/lang/reflect/Method;
      //   51: astore_3
      //   52: aload_3
      //   53: ifnull +26 -> 79
      //   56: aload_3
      //   57: aload_0
      //   58: iconst_2
      //   59: anewarray 4	java/lang/Object
      //   62: dup
      //   63: iconst_0
      //   64: aload_1
      //   65: aastore
      //   66: dup
      //   67: iconst_1
      //   68: aload_2
      //   69: aastore
      //   70: invokevirtual 54	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   73: pop
      //   74: return
      //   75: aconst_null
      //   76: putstatic 63	androidx/core/app/d$a:c	Ljava/lang/reflect/Method;
      //   79: return
      //
      // Exception table:
      //   from	to	target	type
      //   6	40	43	java/lang/NoSuchMethodException
      //   56	74	75	java/lang/reflect/InvocationTargetException
      //   56	74	75	java/lang/IllegalAccessException
      //   56	74	75	java/lang/IllegalArgumentException
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.d
 * JD-Core Version:    0.6.2
 */