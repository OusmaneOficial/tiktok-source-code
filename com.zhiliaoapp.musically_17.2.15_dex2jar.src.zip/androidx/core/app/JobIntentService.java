package androidx.core.app;

import android.app.Service;
import android.app.job.JobInfo;
import android.app.job.JobInfo.Builder;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobServiceEngine;
import android.app.job.JobWorkItem;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import com.ss.android.ugc.aweme.push.downgrade.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class JobIntentService extends Service
{
  static final HashMap<ComponentName, h> sClassWorkEnqueuer = new HashMap();
  static final Object sLock;
  final ArrayList<d> mCompatQueue;
  h mCompatWorkEnqueuer;
  a mCurProcessor;
  boolean mDestroyed;
  public boolean mInterruptIfStopped;
  b mJobImpl;
  public boolean mStopped;

  static
  {
    CoverageLogger.Log(46632960);
    sLock = new Object();
  }

  public JobIntentService()
  {
    if (Build.VERSION.SDK_INT >= 26)
    {
      this.mCompatQueue = null;
      return;
    }
    this.mCompatQueue = new ArrayList();
  }

  public static void enqueueWork(Context paramContext, ComponentName paramComponentName, int paramInt, Intent paramIntent)
  {
    if (paramIntent != null)
      synchronized (sLock)
      {
        h localh = getWorkEnqueuer(paramContext, paramComponentName, true, paramInt);
        localh.a(paramInt);
        localh.a(paramIntent);
        return;
      }
    throw new IllegalArgumentException("work must not be null");
  }

  public static void enqueueWork(Context paramContext, Class paramClass, int paramInt, Intent paramIntent)
  {
    enqueueWork(paramContext, new ComponentName(paramContext, paramClass), paramInt, paramIntent);
  }

  static h getWorkEnqueuer(Context paramContext, ComponentName paramComponentName, boolean paramBoolean, int paramInt)
  {
    Object localObject1 = (h)sClassWorkEnqueuer.get(paramComponentName);
    if (localObject1 == null)
    {
      Object localObject2;
      if (Build.VERSION.SDK_INT >= 26)
      {
        if (paramBoolean)
          localObject2 = new g(paramContext, paramComponentName, paramInt);
        else
          throw new IllegalArgumentException("Can't be here without a job id");
      }
      else
        localObject2 = new c(paramContext, paramComponentName);
      localObject1 = localObject2;
      sClassWorkEnqueuer.put(paramComponentName, localObject1);
    }
    return localObject1;
  }

  e dequeueWork()
  {
    b localb = this.mJobImpl;
    if (localb != null)
      return localb.b();
    synchronized (this.mCompatQueue)
    {
      if (this.mCompatQueue.size() > 0)
      {
        e locale = (e)this.mCompatQueue.remove(0);
        return locale;
      }
      return null;
    }
  }

  boolean doStopCurrentWork()
  {
    a locala = this.mCurProcessor;
    if (locala != null)
      locala.cancel(this.mInterruptIfStopped);
    this.mStopped = true;
    return onStopCurrentWork();
  }

  void ensureProcessorRunningLocked(boolean paramBoolean)
  {
    if (this.mCurProcessor == null)
    {
      this.mCurProcessor = new a();
      h localh = this.mCompatWorkEnqueuer;
      if ((localh != null) && (paramBoolean))
        localh.b();
      this.mCurProcessor.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    b localb = this.mJobImpl;
    if (localb != null)
      return localb.a();
    return null;
  }

  public void onCreate()
  {
    super.onCreate();
    if (Build.VERSION.SDK_INT >= 26)
    {
      this.mJobImpl = new f(this);
      this.mCompatWorkEnqueuer = null;
      return;
    }
    this.mJobImpl = null;
    this.mCompatWorkEnqueuer = getWorkEnqueuer(this, new ComponentName(this, getClass()), false, 0);
  }

  public void onDestroy()
  {
    super.onDestroy();
    ArrayList localArrayList = this.mCompatQueue;
    if (localArrayList != null)
      try
      {
        this.mDestroyed = true;
        this.mCompatWorkEnqueuer.c();
        return;
      }
      finally
      {
      }
  }

  protected abstract void onHandleWork(Intent paramIntent);

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    if (this.mCompatQueue != null)
    {
      this.mCompatWorkEnqueuer.a();
      synchronized (this.mCompatQueue)
      {
        ArrayList localArrayList2 = this.mCompatQueue;
        if (paramIntent == null)
          paramIntent = new Intent();
        localArrayList2.add(new d(paramIntent, paramInt2));
        ensureProcessorRunningLocked(true);
        return 3;
      }
    }
    return 2;
  }

  public boolean onStopCurrentWork()
  {
    return true;
  }

  void processorFinished()
  {
    ArrayList localArrayList = this.mCompatQueue;
    if (localArrayList != null)
      try
      {
        this.mCurProcessor = null;
        if ((this.mCompatQueue != null) && (this.mCompatQueue.size() > 0))
          ensureProcessorRunningLocked(false);
        else if (!this.mDestroyed)
          this.mCompatWorkEnqueuer.c();
        return;
      }
      finally
      {
      }
  }

  final class a extends AsyncTask<Void, Void, Void>
  {
    static
    {
      CoverageLogger.Log(46610432);
    }

    a()
    {
    }
  }

  static abstract interface b
  {
    static
    {
      CoverageLogger.Log(46583808);
    }

    public abstract IBinder a();

    public abstract JobIntentService.e b();
  }

  static final class c extends JobIntentService.h
  {
    boolean a;
    boolean b;
    private final Context f;
    private final PowerManager.WakeLock g;
    private final PowerManager.WakeLock h;

    static
    {
      CoverageLogger.Log(46585856);
    }

    c(Context paramContext, ComponentName paramComponentName)
    {
      super(paramComponentName);
      this.f = paramContext.getApplicationContext();
      PowerManager localPowerManager = (PowerManager)paramContext.getSystemService("power");
      StringBuilder localStringBuilder1 = new StringBuilder();
      localStringBuilder1.append(paramComponentName.getClassName());
      localStringBuilder1.append(":launch");
      this.g = localPowerManager.newWakeLock(1, localStringBuilder1.toString());
      this.g.setReferenceCounted(false);
      StringBuilder localStringBuilder2 = new StringBuilder();
      localStringBuilder2.append(paramComponentName.getClassName());
      localStringBuilder2.append(":run");
      this.h = localPowerManager.newWakeLock(1, localStringBuilder2.toString());
      this.h.setReferenceCounted(false);
    }

    public final void a()
    {
      try
      {
        this.a = false;
        return;
      }
      finally
      {
      }
    }

    final void a(Intent paramIntent)
    {
      Intent localIntent = new Intent(paramIntent);
      localIntent.setComponent(this.c);
      Context localContext = this.f;
      ComponentName localComponentName;
      if ((localContext != null) && ((localContext instanceof Context)) && (d.a((Context)localContext, localIntent)))
        localComponentName = null;
      else
        localComponentName = localContext.startService(localIntent);
      if (localComponentName != null)
        try
        {
          if (!this.a)
          {
            this.a = true;
            if (!this.b)
              this.g.acquire(60000L);
          }
          return;
        }
        finally
        {
        }
    }

    public final void b()
    {
      try
      {
        if (!this.b)
        {
          this.b = true;
          this.h.acquire(600000L);
          this.g.release();
        }
        return;
      }
      finally
      {
      }
    }

    public final void c()
    {
      try
      {
        if (this.b)
        {
          if (this.a)
            this.g.acquire(60000L);
          this.b = false;
          this.h.release();
        }
        return;
      }
      finally
      {
      }
    }
  }

  final class d
    implements JobIntentService.e
  {
    final Intent a;
    final int b;

    static
    {
      CoverageLogger.Log(46579712);
    }

    d(Intent paramInt, int arg3)
    {
      this.a = paramInt;
      int i;
      this.b = i;
    }

    public final Intent a()
    {
      return this.a;
    }

    public final void b()
    {
      JobIntentService.this.stopSelf(this.b);
    }
  }

  static abstract interface e
  {
    static
    {
      CoverageLogger.Log(46624768);
    }

    public abstract Intent a();

    public abstract void b();
  }

  static final class f extends JobServiceEngine
    implements JobIntentService.b
  {
    final JobIntentService a;
    final Object b = new Object();
    JobParameters c;

    static
    {
      CoverageLogger.Log(46626816);
    }

    f(JobIntentService paramJobIntentService)
    {
      super();
      this.a = paramJobIntentService;
    }

    public final IBinder a()
    {
      return getBinder();
    }

    public final JobIntentService.e b()
    {
      synchronized (this.b)
      {
        if (this.c == null)
          return null;
        JobWorkItem localJobWorkItem = this.c.dequeueWork();
        if (localJobWorkItem != null)
        {
          localJobWorkItem.getIntent().setExtrasClassLoader(this.a.getClassLoader());
          return new a(localJobWorkItem);
        }
        return null;
      }
    }

    public final boolean onStartJob(JobParameters paramJobParameters)
    {
      this.c = paramJobParameters;
      this.a.ensureProcessorRunningLocked(false);
      return true;
    }

    public final boolean onStopJob(JobParameters paramJobParameters)
    {
      boolean bool = this.a.doStopCurrentWork();
      synchronized (this.b)
      {
        this.c = null;
        return bool;
      }
    }

    final class a
      implements JobIntentService.e
    {
      final JobWorkItem a;

      static
      {
        CoverageLogger.Log(46620672);
      }

      a(JobWorkItem arg2)
      {
        Object localObject;
        this.a = localObject;
      }

      public final Intent a()
      {
        return this.a.getIntent();
      }

      public final void b()
      {
        synchronized (JobIntentService.f.this.b)
        {
          if (JobIntentService.f.this.c != null)
            JobIntentService.f.this.c.completeWork(this.a);
          return;
        }
      }
    }
  }

  static final class g extends JobIntentService.h
  {
    private final JobInfo a;
    private final JobScheduler b;

    static
    {
      CoverageLogger.Log(46635008);
    }

    g(Context paramContext, ComponentName paramComponentName, int paramInt)
    {
      super(paramComponentName);
      a(paramInt);
      this.a = new JobInfo.Builder(paramInt, this.c).setOverrideDeadline(0L).build();
      this.b = ((JobScheduler)paramContext.getApplicationContext().getSystemService("jobscheduler"));
    }

    final void a(Intent paramIntent)
    {
      this.b.enqueue(this.a, new JobWorkItem(paramIntent));
    }
  }

  static abstract class h
  {
    final ComponentName c;
    boolean d;
    int e;

    static
    {
      CoverageLogger.Log(46637056);
    }

    h(Context paramContext, ComponentName paramComponentName)
    {
      this.c = paramComponentName;
    }

    public void a()
    {
    }

    final void a(int paramInt)
    {
      if (!this.d)
      {
        this.d = true;
        this.e = paramInt;
        return;
      }
      if (this.e == paramInt)
        return;
      StringBuilder localStringBuilder = new StringBuilder("Given job ID ");
      localStringBuilder.append(paramInt);
      localStringBuilder.append(" is different than previous ");
      localStringBuilder.append(this.e);
      throw new IllegalArgumentException(localStringBuilder.toString());
    }

    abstract void a(Intent paramIntent);

    public void b()
    {
    }

    public void c()
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.JobIntentService
 * JD-Core Version:    0.6.2
 */