package androidx.core.app;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import androidx.core.g.e;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class c
{
  static
  {
    CoverageLogger.Log(46923776);
  }

  public static c a(Activity paramActivity, View paramView, String paramString)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return new a(ActivityOptions.makeSceneTransitionAnimation(paramActivity, paramView, paramString));
    return new c();
  }

  public static c a(Activity paramActivity, e<View, String>[] paramArrayOfe)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      Pair[] arrayOfPair = new Pair[paramArrayOfe.length];
      for (int i = 0; i < paramArrayOfe.length; i++)
        arrayOfPair[i] = Pair.create(paramArrayOfe[i].a, paramArrayOfe[i].b);
      return new a(ActivityOptions.makeSceneTransitionAnimation(paramActivity, arrayOfPair));
    }
    return new c();
  }

  public static c a(Context paramContext, int paramInt1, int paramInt2)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new a(ActivityOptions.makeCustomAnimation(paramContext, paramInt1, paramInt2));
    return new c();
  }

  public static c a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new a(ActivityOptions.makeScaleUpAnimation(paramView, paramInt1, paramInt2, 0, 0));
    return new c();
  }

  public static c b(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 23)
      return new a(ActivityOptions.makeClipRevealAnimation(paramView, 0, 0, paramInt3, paramInt4));
    return new c();
  }

  public Bundle a()
  {
    return null;
  }

  static final class a extends c
  {
    private final ActivityOptions a;

    static
    {
      CoverageLogger.Log(46604288);
    }

    a(ActivityOptions paramActivityOptions)
    {
      this.a = paramActivityOptions;
    }

    public final Bundle a()
    {
      return this.a.toBundle();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.c
 * JD-Core Version:    0.6.2
 */