package androidx.core.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings.Secure;
import android.support.v4.a.a;
import android.support.v4.a.a.a.a;
import com.ss.android.ugc.aweme.push.downgrade.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class j
{
  private static final Object a = new Object();
  private static String b;
  private static Set<String> c = new HashSet();
  private static final Object f = new Object();
  private static d g;
  private final Context d;
  private final NotificationManager e;

  static
  {
    CoverageLogger.Log(46673920);
  }

  private j(Context paramContext)
  {
    this.d = paramContext;
    this.e = ((NotificationManager)this.d.getSystemService("notification"));
  }

  public static j a(Context paramContext)
  {
    return new j(paramContext);
  }

  private void a(e parame)
  {
    synchronized (f)
    {
      if (g == null)
        g = new d(this.d.getApplicationContext());
      g.a(parame);
      return;
    }
  }

  public static Set<String> b(Context paramContext)
  {
    String str = Settings.Secure.getString(paramContext.getContentResolver(), "enabled_notification_listeners");
    Object localObject1 = a;
    if (str != null);
    try
    {
      if (!str.equals(b))
      {
        String[] arrayOfString = str.split(":", -1);
        HashSet localHashSet = new HashSet(arrayOfString.length);
        int i = arrayOfString.length;
        j = 0;
        if (j < i)
        {
          ComponentName localComponentName = ComponentName.unflattenFromString(arrayOfString[j]);
          if (localComponentName != null)
            localHashSet.add(localComponentName.getPackageName());
        }
        else
        {
          c = localHashSet;
          b = str;
        }
      }
      else
      {
        Set localSet = c;
        return localSet;
      }
    }
    finally
    {
      while (true)
      {
        int j;
        while (true)
          throw localObject2;
        j++;
      }
    }
  }

  public final void a(int paramInt)
  {
    a(null, 1);
  }

  public final void a(int paramInt, Notification paramNotification)
  {
    Bundle localBundle = g.a(paramNotification);
    int i;
    if ((localBundle != null) && (localBundle.getBoolean("android.support.useSideChannel")))
      i = 1;
    else
      i = 0;
    if (i != 0)
    {
      a(new b(this.d.getPackageName(), 1, null, paramNotification));
      this.e.cancel(null, 1);
      return;
    }
    this.e.notify(null, 1, paramNotification);
  }

  public final void a(String paramString, int paramInt)
  {
    this.e.cancel(paramString, paramInt);
    if (Build.VERSION.SDK_INT <= 19)
      a(new a(this.d.getPackageName(), paramInt, paramString));
  }

  // ERROR //
  public final boolean a()
  {
    // Byte code:
    //   0: getstatic 150	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 24
    //   5: if_icmplt +11 -> 16
    //   8: aload_0
    //   9: getfield 54	androidx/core/app/j:e	Landroid/app/NotificationManager;
    //   12: invokevirtual 171	android/app/NotificationManager:areNotificationsEnabled	()Z
    //   15: ireturn
    //   16: getstatic 150	android/os/Build$VERSION:SDK_INT	I
    //   19: bipush 19
    //   21: if_icmplt +162 -> 183
    //   24: aload_0
    //   25: getfield 42	androidx/core/app/j:d	Landroid/content/Context;
    //   28: ldc 173
    //   30: invokevirtual 50	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   33: checkcast 175	android/app/AppOpsManager
    //   36: astore_1
    //   37: aload_0
    //   38: getfield 42	androidx/core/app/j:d	Landroid/content/Context;
    //   41: invokevirtual 179	android/content/Context:getApplicationInfo	()Landroid/content/pm/ApplicationInfo;
    //   44: astore_2
    //   45: aload_0
    //   46: getfield 42	androidx/core/app/j:d	Landroid/content/Context;
    //   49: invokevirtual 66	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   52: invokevirtual 133	android/content/Context:getPackageName	()Ljava/lang/String;
    //   55: astore_3
    //   56: aload_2
    //   57: getfield 184	android/content/pm/ApplicationInfo:uid	I
    //   60: istore 4
    //   62: ldc 175
    //   64: invokevirtual 189	java/lang/Class:getName	()Ljava/lang/String;
    //   67: invokestatic 193	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   70: astore 5
    //   72: iconst_3
    //   73: anewarray 186	java/lang/Class
    //   76: astore 6
    //   78: aload 6
    //   80: iconst_0
    //   81: getstatic 199	java/lang/Integer:TYPE	Ljava/lang/Class;
    //   84: aastore
    //   85: aload 6
    //   87: iconst_1
    //   88: getstatic 199	java/lang/Integer:TYPE	Ljava/lang/Class;
    //   91: aastore
    //   92: aload 6
    //   94: iconst_2
    //   95: ldc 86
    //   97: aastore
    //   98: aload 5
    //   100: ldc 201
    //   102: aload 6
    //   104: invokevirtual 205	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   107: astore 7
    //   109: aload 5
    //   111: ldc 207
    //   113: invokevirtual 211	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   116: ldc 195
    //   118: invokevirtual 217	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   121: checkcast 195	java/lang/Integer
    //   124: invokevirtual 221	java/lang/Integer:intValue	()I
    //   127: istore 8
    //   129: iconst_3
    //   130: anewarray 4	java/lang/Object
    //   133: astore 9
    //   135: aload 9
    //   137: iconst_0
    //   138: iload 8
    //   140: invokestatic 225	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   143: aastore
    //   144: aload 9
    //   146: iconst_1
    //   147: iload 4
    //   149: invokestatic 225	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   152: aastore
    //   153: aload 9
    //   155: iconst_2
    //   156: aload_3
    //   157: aastore
    //   158: aload 7
    //   160: aload_1
    //   161: aload 9
    //   163: invokevirtual 231	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   166: checkcast 195	java/lang/Integer
    //   169: invokevirtual 221	java/lang/Integer:intValue	()I
    //   172: istore 10
    //   174: iload 10
    //   176: ifne +5 -> 181
    //   179: iconst_1
    //   180: ireturn
    //   181: iconst_0
    //   182: ireturn
    //   183: iconst_1
    //   184: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   62	174	183	java/lang/ClassNotFoundException
    //   62	174	183	java/lang/NoSuchMethodException
    //   62	174	183	java/lang/NoSuchFieldException
    //   62	174	183	java/lang/reflect/InvocationTargetException
    //   62	174	183	java/lang/IllegalAccessException
    //   62	174	183	java/lang/RuntimeException
  }

  static final class a
    implements j.e
  {
    final String a;
    final int b;
    final String c;
    final boolean d;

    static
    {
      CoverageLogger.Log(46536704);
    }

    a(String paramString1, int paramInt, String paramString2)
    {
      this.a = paramString1;
      this.b = paramInt;
      this.c = paramString2;
    }

    public final void a(a parama)
      throws RemoteException
    {
      if (this.d)
      {
        parama.a(this.a);
        return;
      }
      parama.a(this.a, this.b, this.c);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("CancelTask[");
      localStringBuilder.append("packageName:");
      localStringBuilder.append(this.a);
      localStringBuilder.append(", id:");
      localStringBuilder.append(this.b);
      localStringBuilder.append(", tag:");
      localStringBuilder.append(this.c);
      localStringBuilder.append(", all:");
      localStringBuilder.append(this.d);
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  static final class b
    implements j.e
  {
    final String a;
    final int b;
    final String c;
    final Notification d;

    static
    {
      CoverageLogger.Log(46667776);
    }

    b(String paramString1, int paramInt, String paramString2, Notification paramNotification)
    {
      this.a = paramString1;
      this.b = paramInt;
      this.c = paramString2;
      this.d = paramNotification;
    }

    public final void a(a parama)
      throws RemoteException
    {
      parama.a(this.a, this.b, this.c, this.d);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("NotifyTask[");
      localStringBuilder.append("packageName:");
      localStringBuilder.append(this.a);
      localStringBuilder.append(", id:");
      localStringBuilder.append(this.b);
      localStringBuilder.append(", tag:");
      localStringBuilder.append(this.c);
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  static final class c
  {
    final ComponentName a;
    final IBinder b;

    static
    {
      CoverageLogger.Log(46671872);
    }

    c(ComponentName paramComponentName, IBinder paramIBinder)
    {
      this.a = paramComponentName;
      this.b = paramIBinder;
    }
  }

  static final class d
    implements ServiceConnection, Handler.Callback
  {
    private final Context a;
    private final HandlerThread b;
    private final Handler c;
    private final Map<ComponentName, a> d = new HashMap();
    private Set<String> e = new HashSet();

    static
    {
      CoverageLogger.Log(46532608);
    }

    d(Context paramContext)
    {
      this.a = paramContext;
      this.b = new HandlerThread("NotificationManagerCompat");
      this.b.start();
      this.c = new Handler(this.b.getLooper(), this);
    }

    private boolean a(a parama)
    {
      boolean bool1 = parama.b;
      boolean bool2 = true;
      if (bool1)
        return bool2;
      Intent localIntent = new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(parama.a);
      Context localContext = this.a;
      if ((localContext == null) || (!(localContext instanceof Context)) || (!d.a((Context)localContext, localIntent)))
        bool2 = localContext.bindService(localIntent, this, 33);
      parama.b = bool2;
      if (parama.b)
        parama.e = 0;
      else
        this.a.unbindService(this);
      return parama.b;
    }

    private void b(a parama)
    {
      if (parama.b)
      {
        this.a.unbindService(this);
        parama.b = false;
      }
      parama.c = null;
    }

    private void c(a parama)
    {
      if (this.c.hasMessages(3, parama.a))
        return;
      parama.e = (1 + parama.e);
      if (parama.e > 6)
      {
        parama.d.clear();
        return;
      }
      int i = 1000 * (1 << parama.e - 1);
      Message localMessage = this.c.obtainMessage(3, parama.a);
      this.c.sendMessageDelayed(localMessage, i);
    }

    // ERROR //
    private void d(a parama)
    {
      // Byte code:
      //   0: aload_1
      //   1: getfield 115	androidx/core/app/j$d$a:d	Ljava/util/ArrayDeque;
      //   4: invokevirtual 136	java/util/ArrayDeque:isEmpty	()Z
      //   7: ifeq +4 -> 11
      //   10: return
      //   11: aload_0
      //   12: aload_1
      //   13: invokespecial 138	androidx/core/app/j$d:a	(Landroidx/core/app/j$d$a;)Z
      //   16: ifeq +65 -> 81
      //   19: aload_1
      //   20: getfield 108	androidx/core/app/j$d$a:c	Landroid/support/v4/a/a;
      //   23: ifnonnull +6 -> 29
      //   26: goto +55 -> 81
      //   29: aload_1
      //   30: getfield 115	androidx/core/app/j$d$a:d	Ljava/util/ArrayDeque;
      //   33: invokevirtual 142	java/util/ArrayDeque:peek	()Ljava/lang/Object;
      //   36: checkcast 144	androidx/core/app/j$e
      //   39: astore_2
      //   40: aload_2
      //   41: ifnull +24 -> 65
      //   44: aload_2
      //   45: aload_1
      //   46: getfield 108	androidx/core/app/j$d$a:c	Landroid/support/v4/a/a;
      //   49: invokeinterface 147 2 0
      //   54: aload_1
      //   55: getfield 115	androidx/core/app/j$d$a:d	Ljava/util/ArrayDeque;
      //   58: invokevirtual 150	java/util/ArrayDeque:remove	()Ljava/lang/Object;
      //   61: pop
      //   62: goto -33 -> 29
      //   65: aload_1
      //   66: getfield 115	androidx/core/app/j$d$a:d	Ljava/util/ArrayDeque;
      //   69: invokevirtual 136	java/util/ArrayDeque:isEmpty	()Z
      //   72: ifne +8 -> 80
      //   75: aload_0
      //   76: aload_1
      //   77: invokespecial 152	androidx/core/app/j$d:c	(Landroidx/core/app/j$d$a;)V
      //   80: return
      //   81: aload_0
      //   82: aload_1
      //   83: invokespecial 152	androidx/core/app/j$d:c	(Landroidx/core/app/j$d$a;)V
      //   86: return
      //
      // Exception table:
      //   from	to	target	type
      //   44	62	65	android/os/DeadObjectException
      //   44	62	65	android/os/RemoteException
    }

    public final void a(j.e parame)
    {
      this.c.obtainMessage(0, parame).sendToTarget();
    }

    public final boolean handleMessage(Message paramMessage)
    {
      int i = paramMessage.what;
      if (i != 0)
      {
        if (i != 1)
        {
          if (i != 2)
          {
            if (i != 3)
              return false;
            ComponentName localComponentName5 = (ComponentName)paramMessage.obj;
            a locala4 = (a)this.d.get(localComponentName5);
            if (locala4 != null)
              d(locala4);
            return true;
          }
          ComponentName localComponentName4 = (ComponentName)paramMessage.obj;
          a locala3 = (a)this.d.get(localComponentName4);
          if (locala3 != null)
            b(locala3);
          return true;
        }
        j.c localc = (j.c)paramMessage.obj;
        ComponentName localComponentName3 = localc.a;
        IBinder localIBinder = localc.b;
        a locala2 = (a)this.d.get(localComponentName3);
        if (locala2 != null)
        {
          Object localObject;
          if (localIBinder == null)
          {
            localObject = null;
          }
          else
          {
            IInterface localIInterface = localIBinder.queryLocalInterface("android.support.v4.app.INotificationSideChannel");
            if ((localIInterface != null) && ((localIInterface instanceof a)))
              localObject = (a)localIInterface;
            else
              localObject = new a.a.a(localIBinder);
          }
          locala2.c = ((a)localObject);
          locala2.e = 0;
          d(locala2);
        }
        return true;
      }
      j.e locale = (j.e)paramMessage.obj;
      Set localSet = j.b(this.a);
      if (!localSet.equals(this.e))
      {
        this.e = localSet;
        List localList = this.a.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
        HashSet localHashSet = new HashSet();
        Iterator localIterator2 = localList.iterator();
        while (localIterator2.hasNext())
        {
          ResolveInfo localResolveInfo = (ResolveInfo)localIterator2.next();
          if (localSet.contains(localResolveInfo.serviceInfo.packageName))
          {
            ComponentName localComponentName2 = new ComponentName(localResolveInfo.serviceInfo.packageName, localResolveInfo.serviceInfo.name);
            if (localResolveInfo.serviceInfo.permission == null)
              localHashSet.add(localComponentName2);
          }
        }
        Iterator localIterator3 = localHashSet.iterator();
        while (localIterator3.hasNext())
        {
          ComponentName localComponentName1 = (ComponentName)localIterator3.next();
          if (!this.d.containsKey(localComponentName1))
            this.d.put(localComponentName1, new a(localComponentName1));
        }
        Iterator localIterator4 = this.d.entrySet().iterator();
        while (localIterator4.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator4.next();
          if (!localHashSet.contains(localEntry.getKey()))
          {
            b((a)localEntry.getValue());
            localIterator4.remove();
          }
        }
      }
      Iterator localIterator1 = this.d.values().iterator();
      while (localIterator1.hasNext())
      {
        a locala1 = (a)localIterator1.next();
        locala1.d.add(locale);
        d(locala1);
      }
      return true;
    }

    public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      this.c.obtainMessage(1, new j.c(paramComponentName, paramIBinder)).sendToTarget();
    }

    public final void onServiceDisconnected(ComponentName paramComponentName)
    {
      this.c.obtainMessage(2, paramComponentName).sendToTarget();
    }

    static final class a
    {
      final ComponentName a;
      boolean b;
      a c;
      ArrayDeque<j.e> d = new ArrayDeque();
      int e = 0;

      static
      {
        CoverageLogger.Log(46526464);
      }

      a(ComponentName paramComponentName)
      {
        this.a = paramComponentName;
      }
    }
  }

  static abstract interface e
  {
    static
    {
      CoverageLogger.Log(46522368);
    }

    public abstract void a(a parama)
      throws RemoteException;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.j
 * JD-Core Version:    0.6.2
 */