package androidx.core.app;

import android.os.Bundle;
import android.util.SparseArray;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

final class i
{
  private static final Object a = new Object();
  private static Field b;
  private static boolean c;
  private static final Object d = new Object();

  static
  {
    CoverageLogger.Log(46661632);
  }

  // ERROR //
  public static Bundle a(android.app.Notification paramNotification)
  {
    // Byte code:
    //   0: getstatic 25	androidx/core/app/i:a	Ljava/lang/Object;
    //   3: astore_1
    //   4: aload_1
    //   5: monitorenter
    //   6: getstatic 34	androidx/core/app/i:c	Z
    //   9: ifeq +7 -> 16
    //   12: aload_1
    //   13: monitorexit
    //   14: aconst_null
    //   15: areturn
    //   16: getstatic 36	androidx/core/app/i:b	Ljava/lang/reflect/Field;
    //   19: ifnonnull +44 -> 63
    //   22: ldc 38
    //   24: ldc 40
    //   26: invokevirtual 46	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   29: astore 4
    //   31: ldc 48
    //   33: aload 4
    //   35: invokevirtual 54	java/lang/reflect/Field:getType	()Ljava/lang/Class;
    //   38: invokevirtual 58	java/lang/Class:isAssignableFrom	(Ljava/lang/Class;)Z
    //   41: ifne +11 -> 52
    //   44: iconst_1
    //   45: putstatic 34	androidx/core/app/i:c	Z
    //   48: aload_1
    //   49: monitorexit
    //   50: aconst_null
    //   51: areturn
    //   52: aload 4
    //   54: iconst_1
    //   55: invokevirtual 62	java/lang/reflect/Field:setAccessible	(Z)V
    //   58: aload 4
    //   60: putstatic 36	androidx/core/app/i:b	Ljava/lang/reflect/Field;
    //   63: getstatic 36	androidx/core/app/i:b	Ljava/lang/reflect/Field;
    //   66: aload_0
    //   67: invokevirtual 66	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   70: checkcast 48	android/os/Bundle
    //   73: astore_3
    //   74: aload_3
    //   75: ifnonnull +19 -> 94
    //   78: new 48	android/os/Bundle
    //   81: dup
    //   82: invokespecial 67	android/os/Bundle:<init>	()V
    //   85: astore_3
    //   86: getstatic 36	androidx/core/app/i:b	Ljava/lang/reflect/Field;
    //   89: aload_0
    //   90: aload_3
    //   91: invokevirtual 71	java/lang/reflect/Field:set	(Ljava/lang/Object;Ljava/lang/Object;)V
    //   94: aload_1
    //   95: monitorexit
    //   96: aload_3
    //   97: areturn
    //   98: iconst_1
    //   99: putstatic 34	androidx/core/app/i:c	Z
    //   102: aload_1
    //   103: monitorexit
    //   104: aconst_null
    //   105: areturn
    //   106: astore_2
    //   107: aload_1
    //   108: monitorexit
    //   109: aload_2
    //   110: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   16	48	98	java/lang/IllegalAccessException
    //   16	48	98	java/lang/NoSuchFieldException
    //   52	63	98	java/lang/IllegalAccessException
    //   52	63	98	java/lang/NoSuchFieldException
    //   63	74	98	java/lang/IllegalAccessException
    //   63	74	98	java/lang/NoSuchFieldException
    //   78	94	98	java/lang/IllegalAccessException
    //   78	94	98	java/lang/NoSuchFieldException
    //   6	14	106	finally
    //   16	48	106	finally
    //   48	50	106	finally
    //   52	63	106	finally
    //   63	74	106	finally
    //   78	94	106	finally
    //   94	96	106	finally
    //   98	104	106	finally
    //   107	109	106	finally
  }

  public static SparseArray<Bundle> a(List<Bundle> paramList)
  {
    int i = paramList.size();
    SparseArray localSparseArray = null;
    for (int j = 0; j < i; j++)
    {
      Bundle localBundle = (Bundle)paramList.get(j);
      if (localBundle != null)
      {
        if (localSparseArray == null)
          localSparseArray = new SparseArray();
        localSparseArray.put(j, localBundle);
      }
    }
    return localSparseArray;
  }

  static Bundle[] a(l[] paramArrayOfl)
  {
    if (paramArrayOfl == null)
      return null;
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfl.length];
    for (int i = 0; i < paramArrayOfl.length; i++)
    {
      l locall = paramArrayOfl[i];
      Bundle localBundle = new Bundle();
      localBundle.putString("resultKey", locall.a);
      localBundle.putCharSequence("label", locall.b);
      localBundle.putCharSequenceArray("choices", locall.c);
      localBundle.putBoolean("allowFreeFormInput", locall.d);
      localBundle.putBundle("extras", locall.e);
      Set localSet = locall.f;
      if ((localSet != null) && (!localSet.isEmpty()))
      {
        ArrayList localArrayList = new ArrayList(localSet.size());
        Iterator localIterator = localSet.iterator();
        while (localIterator.hasNext())
          localArrayList.add((String)localIterator.next());
        localBundle.putStringArrayList("allowedDataTypes", localArrayList);
      }
      arrayOfBundle[i] = localBundle;
    }
    return arrayOfBundle;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.i
 * JD-Core Version:    0.6.2
 */