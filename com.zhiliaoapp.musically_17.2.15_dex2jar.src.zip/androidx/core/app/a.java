package androidx.core.app;

import android.view.View;
import androidx.core.h.a.c;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  static
  {
    CoverageLogger.Log(80472064);
  }

  public static void a(View paramView, a parama)
  {
    if (paramView == null)
      return;
    t.a(paramView, new androidx.core.h.a()
    {
      static
      {
        CoverageLogger.Log(80470016);
      }

      public final void a(View paramAnonymousView, c paramAnonymousc)
      {
        super.a(paramAnonymousView, paramAnonymousc);
        a.a locala = this.a;
        if (locala != null)
          locala.a(paramAnonymousView, paramAnonymousc);
      }
    });
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(80478208);
    }

    public abstract void a(View paramView, c paramc);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.a
 * JD-Core Version:    0.6.2
 */