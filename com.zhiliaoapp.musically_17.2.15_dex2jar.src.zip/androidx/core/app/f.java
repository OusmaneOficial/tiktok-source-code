package androidx.core.app;

import android.app.Notification.Builder;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface f
{
  static
  {
    CoverageLogger.Log(46567424);
  }

  public abstract Notification.Builder a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.app.f
 * JD-Core Version:    0.6.2
 */