package androidx.core.h;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface l
{
  static
  {
    CoverageLogger.Log(46249984);
  }

  public abstract int getNestedScrollAxes();

  public abstract boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean);

  public abstract boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2);

  public abstract void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt);

  public abstract void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt);

  public abstract boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt);

  public abstract void onStopNestedScroll(View paramView);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.l
 * JD-Core Version:    0.6.2
 */