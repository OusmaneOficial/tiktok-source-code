package androidx.core.h;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface r
{
  static
  {
    CoverageLogger.Log(46235648);
  }

  public abstract ColorStateList getSupportBackgroundTintList();

  public abstract PorterDuff.Mode getSupportBackgroundTintMode();

  public abstract void setSupportBackgroundTintList(ColorStateList paramColorStateList);

  public abstract void setSupportBackgroundTintMode(PorterDuff.Mode paramMode);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.r
 * JD-Core Version:    0.6.2
 */