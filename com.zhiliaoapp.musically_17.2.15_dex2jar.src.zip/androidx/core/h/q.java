package androidx.core.h;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface q
{
  static
  {
    CoverageLogger.Log(46358528);
  }

  public abstract int computeVerticalScrollOffset();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.q
 * JD-Core Version:    0.6.2
 */