package androidx.core.h;

import android.content.Context;
import android.os.Build.VERSION;
import android.view.PointerIcon;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class p
{
  public Object a;

  static
  {
    CoverageLogger.Log(46354432);
  }

  private p(Object paramObject)
  {
    this.a = paramObject;
  }

  public static p a(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 24)
      return new p(PointerIcon.getSystemIcon(paramContext, 1002));
    return new p(null);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.p
 * JD-Core Version:    0.6.2
 */