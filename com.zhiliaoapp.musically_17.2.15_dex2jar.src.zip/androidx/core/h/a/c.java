package androidx.core.h.a;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction;
import android.view.accessibility.AccessibilityNodeInfo.CollectionItemInfo;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c
{
  public final AccessibilityNodeInfo a;
  public int b = -1;

  static
  {
    CoverageLogger.Log(46411776);
  }

  private c(AccessibilityNodeInfo paramAccessibilityNodeInfo)
  {
    this.a = paramAccessibilityNodeInfo;
  }

  public static c a(AccessibilityNodeInfo paramAccessibilityNodeInfo)
  {
    return new c(paramAccessibilityNodeInfo);
  }

  public static c a(c paramc)
  {
    return a(AccessibilityNodeInfo.obtain(paramc.a));
  }

  public final int a()
  {
    return this.a.getActions();
  }

  public final void a(int paramInt)
  {
    this.a.addAction(paramInt);
  }

  public final void a(Rect paramRect)
  {
    this.a.getBoundsInParent(paramRect);
  }

  public final void a(View paramView)
  {
    this.a.setSource(paramView);
  }

  public final void a(CharSequence paramCharSequence)
  {
    this.a.setPackageName(paramCharSequence);
  }

  public final void a(Object paramObject)
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      AccessibilityNodeInfo localAccessibilityNodeInfo = this.a;
      AccessibilityNodeInfo.CollectionItemInfo localCollectionItemInfo;
      if (paramObject == null)
        localCollectionItemInfo = null;
      else
        localCollectionItemInfo = (AccessibilityNodeInfo.CollectionItemInfo)((c)paramObject).a;
      localAccessibilityNodeInfo.setCollectionItemInfo(localCollectionItemInfo);
    }
  }

  public final void a(boolean paramBoolean)
  {
    this.a.setCheckable(paramBoolean);
  }

  public final boolean a(a parama)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return this.a.removeAction((AccessibilityNodeInfo.AccessibilityAction)parama.H);
    return false;
  }

  public final void b(Rect paramRect)
  {
    this.a.setBoundsInParent(paramRect);
  }

  public final void b(View paramView)
  {
    this.a.addChild(paramView);
  }

  public final void b(CharSequence paramCharSequence)
  {
    this.a.setClassName(paramCharSequence);
  }

  public final void b(boolean paramBoolean)
  {
    this.a.setFocusable(paramBoolean);
  }

  public final boolean b()
  {
    return this.a.isFocusable();
  }

  public final void c(Rect paramRect)
  {
    this.a.getBoundsInScreen(paramRect);
  }

  public final void c(View paramView)
  {
    this.a.setParent(paramView);
  }

  public final void c(CharSequence paramCharSequence)
  {
    this.a.setText(paramCharSequence);
  }

  public final void c(boolean paramBoolean)
  {
    this.a.setFocused(paramBoolean);
  }

  public final boolean c()
  {
    return this.a.isFocused();
  }

  public final void d(Rect paramRect)
  {
    this.a.setBoundsInScreen(paramRect);
  }

  public final void d(CharSequence paramCharSequence)
  {
    this.a.setContentDescription(paramCharSequence);
  }

  public final void d(boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 16)
      this.a.setVisibleToUser(paramBoolean);
  }

  public final boolean d()
  {
    if (Build.VERSION.SDK_INT >= 16)
      return this.a.isVisibleToUser();
    return false;
  }

  public final void e(boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 16)
      this.a.setAccessibilityFocused(paramBoolean);
  }

  public final boolean e()
  {
    if (Build.VERSION.SDK_INT >= 16)
      return this.a.isAccessibilityFocused();
    return false;
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject == null)
      return false;
    if (getClass() != paramObject.getClass())
      return false;
    c localc = (c)paramObject;
    AccessibilityNodeInfo localAccessibilityNodeInfo = this.a;
    if (localAccessibilityNodeInfo == null)
    {
      if (localc.a != null)
        return false;
    }
    else if (!localAccessibilityNodeInfo.equals(localc.a))
      return false;
    return true;
  }

  public final void f(boolean paramBoolean)
  {
    this.a.setSelected(paramBoolean);
  }

  public final boolean f()
  {
    return this.a.isSelected();
  }

  public final void g(boolean paramBoolean)
  {
    this.a.setClickable(paramBoolean);
  }

  public final boolean g()
  {
    return this.a.isClickable();
  }

  public final void h(boolean paramBoolean)
  {
    this.a.setLongClickable(paramBoolean);
  }

  public final boolean h()
  {
    return this.a.isLongClickable();
  }

  public final int hashCode()
  {
    AccessibilityNodeInfo localAccessibilityNodeInfo = this.a;
    if (localAccessibilityNodeInfo == null)
      return 0;
    return localAccessibilityNodeInfo.hashCode();
  }

  public final void i(boolean paramBoolean)
  {
    this.a.setEnabled(paramBoolean);
  }

  public final boolean i()
  {
    return this.a.isEnabled();
  }

  public final CharSequence j()
  {
    return this.a.getPackageName();
  }

  public final void j(boolean paramBoolean)
  {
    this.a.setScrollable(paramBoolean);
  }

  public final CharSequence k()
  {
    return this.a.getClassName();
  }

  public final void k(boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 19)
      this.a.setDismissable(paramBoolean);
  }

  public final CharSequence l()
  {
    return this.a.getContentDescription();
  }

  public final void m()
  {
    this.a.recycle();
  }

  public final String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    localStringBuilder1.append(super.toString());
    Rect localRect = new Rect();
    a(localRect);
    StringBuilder localStringBuilder2 = new StringBuilder("; boundsInParent: ");
    localStringBuilder2.append(localRect);
    localStringBuilder1.append(localStringBuilder2.toString());
    c(localRect);
    StringBuilder localStringBuilder3 = new StringBuilder("; boundsInScreen: ");
    localStringBuilder3.append(localRect);
    localStringBuilder1.append(localStringBuilder3.toString());
    localStringBuilder1.append("; packageName: ");
    localStringBuilder1.append(j());
    localStringBuilder1.append("; className: ");
    localStringBuilder1.append(k());
    localStringBuilder1.append("; text: ");
    localStringBuilder1.append(this.a.getText());
    localStringBuilder1.append("; contentDescription: ");
    localStringBuilder1.append(l());
    localStringBuilder1.append("; viewId: ");
    String str1;
    if (Build.VERSION.SDK_INT >= 18)
      str1 = this.a.getViewIdResourceName();
    else
      str1 = null;
    localStringBuilder1.append(str1);
    localStringBuilder1.append("; checkable: ");
    localStringBuilder1.append(this.a.isCheckable());
    localStringBuilder1.append("; checked: ");
    localStringBuilder1.append(this.a.isChecked());
    localStringBuilder1.append("; focusable: ");
    localStringBuilder1.append(b());
    localStringBuilder1.append("; focused: ");
    localStringBuilder1.append(c());
    localStringBuilder1.append("; selected: ");
    localStringBuilder1.append(f());
    localStringBuilder1.append("; clickable: ");
    localStringBuilder1.append(g());
    localStringBuilder1.append("; longClickable: ");
    localStringBuilder1.append(h());
    localStringBuilder1.append("; enabled: ");
    localStringBuilder1.append(i());
    localStringBuilder1.append("; password: ");
    localStringBuilder1.append(this.a.isPassword());
    StringBuilder localStringBuilder4 = new StringBuilder("; scrollable: ");
    localStringBuilder4.append(this.a.isScrollable());
    localStringBuilder1.append(localStringBuilder4.toString());
    localStringBuilder1.append("; [");
    int i = a();
    while (i != 0)
    {
      int j = 1 << Integer.numberOfTrailingZeros(i);
      i &= (j ^ 0xFFFFFFFF);
      String str2;
      if (j != 1)
      {
        if (j != 2)
          switch (j)
          {
          default:
            str2 = "ACTION_UNKNOWN";
            break;
          case 131072:
            str2 = "ACTION_SET_SELECTION";
            break;
          case 65536:
            str2 = "ACTION_CUT";
            break;
          case 32768:
            str2 = "ACTION_PASTE";
            break;
          case 16384:
            str2 = "ACTION_COPY";
            break;
          case 8192:
            str2 = "ACTION_SCROLL_BACKWARD";
            break;
          case 4096:
            str2 = "ACTION_SCROLL_FORWARD";
            break;
          case 2048:
            str2 = "ACTION_PREVIOUS_HTML_ELEMENT";
            break;
          case 1024:
            str2 = "ACTION_NEXT_HTML_ELEMENT";
            break;
          case 512:
            str2 = "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            break;
          case 256:
            str2 = "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            break;
          case 128:
            str2 = "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            break;
          case 64:
            str2 = "ACTION_ACCESSIBILITY_FOCUS";
            break;
          case 32:
            str2 = "ACTION_LONG_CLICK";
            break;
          case 16:
            str2 = "ACTION_CLICK";
            break;
          case 8:
            str2 = "ACTION_CLEAR_SELECTION";
            break;
          case 4:
            str2 = "ACTION_SELECT";
            break;
          }
        else
          str2 = "ACTION_CLEAR_FOCUS";
      }
      else
        str2 = "ACTION_FOCUS";
      localStringBuilder1.append(str2);
      if (i != 0)
        localStringBuilder1.append(", ");
    }
    localStringBuilder1.append("]");
    return localStringBuilder1.toString();
  }

  public static final class a
  {
    public static final a A;
    public static final a B;
    public static final a C;
    public static final a D;
    public static final a E;
    public static final a F;
    public static final a G = new a(localAccessibilityAction11);
    public static final a a;
    public static final a b;
    public static final a c;
    public static final a d;
    public static final a e;
    public static final a f;
    public static final a g;
    public static final a h;
    public static final a i;
    public static final a j;
    public static final a k;
    public static final a l;
    public static final a m;
    public static final a n;
    public static final a o;
    public static final a p;
    public static final a q;
    public static final a r;
    public static final a s;
    public static final a t;
    public static final a u;
    public static final a v;
    public static final a w;
    public static final a x;
    public static final a y;
    public static final a z;
    final Object H;

    static
    {
      CoverageLogger.Log(46194688);
      a = new a(1, null);
      b = new a(2, null);
      c = new a(4, null);
      d = new a(8, null);
      e = new a(16, null);
      f = new a(32, null);
      g = new a(64, null);
      h = new a(128, null);
      i = new a(256, null);
      j = new a(512, null);
      k = new a(1024, null);
      l = new a(2048, null);
      m = new a(4096, null);
      n = new a(8192, null);
      o = new a(16384, null);
      p = new a(32768, null);
      q = new a(65536, null);
      r = new a(131072, null);
      s = new a(262144, null);
      t = new a(524288, null);
      u = new a(1048576, null);
      v = new a(2097152, null);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction1;
      if (Build.VERSION.SDK_INT >= 23)
        localAccessibilityAction1 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN;
      else
        localAccessibilityAction1 = null;
      w = new a(localAccessibilityAction1);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction2;
      if (Build.VERSION.SDK_INT >= 23)
        localAccessibilityAction2 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION;
      else
        localAccessibilityAction2 = null;
      x = new a(localAccessibilityAction2);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction3;
      if (Build.VERSION.SDK_INT >= 23)
        localAccessibilityAction3 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP;
      else
        localAccessibilityAction3 = null;
      y = new a(localAccessibilityAction3);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction4;
      if (Build.VERSION.SDK_INT >= 23)
        localAccessibilityAction4 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT;
      else
        localAccessibilityAction4 = null;
      z = new a(localAccessibilityAction4);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction5;
      if (Build.VERSION.SDK_INT >= 23)
        localAccessibilityAction5 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN;
      else
        localAccessibilityAction5 = null;
      A = new a(localAccessibilityAction5);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction6;
      if (Build.VERSION.SDK_INT >= 23)
        localAccessibilityAction6 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT;
      else
        localAccessibilityAction6 = null;
      B = new a(localAccessibilityAction6);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction7;
      if (Build.VERSION.SDK_INT >= 23)
        localAccessibilityAction7 = AccessibilityNodeInfo.AccessibilityAction.ACTION_CONTEXT_CLICK;
      else
        localAccessibilityAction7 = null;
      C = new a(localAccessibilityAction7);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction8;
      if (Build.VERSION.SDK_INT >= 24)
        localAccessibilityAction8 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS;
      else
        localAccessibilityAction8 = null;
      D = new a(localAccessibilityAction8);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction9;
      if (Build.VERSION.SDK_INT >= 26)
        localAccessibilityAction9 = AccessibilityNodeInfo.AccessibilityAction.ACTION_MOVE_WINDOW;
      else
        localAccessibilityAction9 = null;
      E = new a(localAccessibilityAction9);
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction10;
      if (Build.VERSION.SDK_INT >= 28)
        localAccessibilityAction10 = AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TOOLTIP;
      else
        localAccessibilityAction10 = null;
      F = new a(localAccessibilityAction10);
      int i1 = Build.VERSION.SDK_INT;
      AccessibilityNodeInfo.AccessibilityAction localAccessibilityAction11 = null;
      if (i1 >= 28)
        localAccessibilityAction11 = AccessibilityNodeInfo.AccessibilityAction.ACTION_HIDE_TOOLTIP;
    }

    private a(int paramInt, CharSequence paramCharSequence)
    {
      this(localAccessibilityAction);
    }

    private a(Object paramObject)
    {
      this.H = paramObject;
    }
  }

  public static final class b
  {
    public final Object a;

    static
    {
      CoverageLogger.Log(46192640);
    }

    public b(Object paramObject)
    {
      this.a = paramObject;
    }
  }

  public static final class c
  {
    final Object a;

    static
    {
      CoverageLogger.Log(46190592);
    }

    private c(Object paramObject)
    {
      this.a = paramObject;
    }

    public static c a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2)
    {
      if (Build.VERSION.SDK_INT >= 21)
        return new c(AccessibilityNodeInfo.CollectionItemInfo.obtain(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean1, false));
      if (Build.VERSION.SDK_INT >= 19)
        return new c(AccessibilityNodeInfo.CollectionItemInfo.obtain(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean1));
      return new c(null);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.a.c
 * JD-Core Version:    0.6.2
 */