package androidx.core.h.a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityManager.TouchExplorationStateChangeListener;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b
{
  static
  {
    CoverageLogger.Log(46196736);
  }

  public static boolean a(AccessibilityManager paramAccessibilityManager, a parama)
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      if (parama == null)
        return false;
      return paramAccessibilityManager.removeTouchExplorationStateChangeListener(new b(parama));
    }
    return false;
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46200832);
    }

    public abstract void a(boolean paramBoolean);
  }

  public static final class b
    implements AccessibilityManager.TouchExplorationStateChangeListener
  {
    final b.a a;

    static
    {
      CoverageLogger.Log(46198784);
    }

    public b(b.a parama)
    {
      this.a = parama;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if ((paramObject != null) && (getClass() == paramObject.getClass()))
      {
        b localb = (b)paramObject;
        return this.a.equals(localb.a);
      }
      return false;
    }

    public final int hashCode()
    {
      return this.a.hashCode();
    }

    public final void onTouchExplorationStateChanged(boolean paramBoolean)
    {
      this.a.a(paramBoolean);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.a.b
 * JD-Core Version:    0.6.2
 */