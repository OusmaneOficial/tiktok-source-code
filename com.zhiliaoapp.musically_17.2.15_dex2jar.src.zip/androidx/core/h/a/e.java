package androidx.core.h.a;

import android.view.accessibility.AccessibilityRecord;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
{
  public final AccessibilityRecord a;

  static
  {
    CoverageLogger.Log(46182400);
  }

  private e(Object paramObject)
  {
    this.a = ((AccessibilityRecord)paramObject);
  }

  public static e a()
  {
    return new e(AccessibilityRecord.obtain());
  }

  public final void a(int paramInt)
  {
    this.a.setItemCount(paramInt);
  }

  public final void a(boolean paramBoolean)
  {
    this.a.setScrollable(paramBoolean);
  }

  public final void b(int paramInt)
  {
    this.a.setFromIndex(paramInt);
  }

  public final void c(int paramInt)
  {
    this.a.setToIndex(paramInt);
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject == null)
      return false;
    if (getClass() != paramObject.getClass())
      return false;
    e locale = (e)paramObject;
    AccessibilityRecord localAccessibilityRecord = this.a;
    if (localAccessibilityRecord == null)
    {
      if (locale.a != null)
        return false;
    }
    else if (!localAccessibilityRecord.equals(locale.a))
      return false;
    return true;
  }

  public final int hashCode()
  {
    AccessibilityRecord localAccessibilityRecord = this.a;
    if (localAccessibilityRecord == null)
      return 0;
    return localAccessibilityRecord.hashCode();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.a.e
 * JD-Core Version:    0.6.2
 */