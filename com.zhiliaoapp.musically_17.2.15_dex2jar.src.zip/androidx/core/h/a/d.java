package androidx.core.h.a;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public final class d
{
  public final Object a;

  static
  {
    CoverageLogger.Log(46184448);
  }

  public d()
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      this.a = new b(this);
      return;
    }
    if (Build.VERSION.SDK_INT >= 16)
    {
      this.a = new a(this);
      return;
    }
    this.a = null;
  }

  public d(Object paramObject)
  {
    this.a = paramObject;
  }

  static class a extends AccessibilityNodeProvider
  {
    final d a;

    static
    {
      CoverageLogger.Log(46419968);
    }

    a(d paramd)
    {
      this.a = paramd;
    }

    public AccessibilityNodeInfo createAccessibilityNodeInfo(int paramInt)
    {
      return null;
    }

    public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String paramString, int paramInt)
    {
      return null;
    }

    public boolean performAction(int paramInt1, int paramInt2, Bundle paramBundle)
    {
      return false;
    }
  }

  static final class b extends d.a
  {
    static
    {
      CoverageLogger.Log(46186496);
    }

    b(d paramd)
    {
      super();
    }

    public final AccessibilityNodeInfo findFocus(int paramInt)
    {
      return null;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.a.d
 * JD-Core Version:    0.6.2
 */