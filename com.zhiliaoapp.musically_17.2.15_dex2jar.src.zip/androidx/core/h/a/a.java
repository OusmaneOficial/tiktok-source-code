package androidx.core.h.a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityEvent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  static
  {
    CoverageLogger.Log(46409728);
  }

  public static void a(AccessibilityEvent paramAccessibilityEvent, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramAccessibilityEvent.setContentChangeTypes(paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.a.a
 * JD-Core Version:    0.6.2
 */