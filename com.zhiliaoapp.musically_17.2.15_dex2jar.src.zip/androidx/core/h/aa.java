package androidx.core.h;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface aa
{
  static
  {
    CoverageLogger.Log(46403584);
  }

  public abstract void a(View paramView);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.aa
 * JD-Core Version:    0.6.2
 */