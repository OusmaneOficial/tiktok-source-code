package androidx.core.h;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface o
{
  static
  {
    CoverageLogger.Log(46241792);
  }

  public abstract ab a(View paramView, ab paramab);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.o
 * JD-Core Version:    0.6.2
 */