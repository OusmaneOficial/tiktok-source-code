package androidx.core.h;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface i
{
  static
  {
    CoverageLogger.Log(46346240);
  }

  public abstract boolean isNestedScrollingEnabled();

  public abstract void stopNestedScroll();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.i
 * JD-Core Version:    0.6.2
 */