package androidx.core.h;

import android.os.Build.VERSION;
import android.view.ViewConfiguration;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Method;

public final class u
{
  private static Method a;

  static
  {
    CoverageLogger.Log(46383104);
    if (Build.VERSION.SDK_INT == 25);
    try
    {
      a = ViewConfiguration.class.getDeclaredMethod("getScaledScrollFactor", new Class[0]);
    }
    catch (Exception localException)
    {
    }
  }

  // ERROR //
  public static float a(ViewConfiguration paramViewConfiguration, android.content.Context paramContext)
  {
    // Byte code:
    //   0: getstatic 23	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 25
    //   5: if_icmplt +32 -> 37
    //   8: getstatic 35	androidx/core/h/u:a	Ljava/lang/reflect/Method;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnull +24 -> 37
    //   16: aload_3
    //   17: aload_0
    //   18: iconst_0
    //   19: anewarray 4	java/lang/Object
    //   22: invokevirtual 42	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   25: checkcast 44	java/lang/Integer
    //   28: invokevirtual 48	java/lang/Integer:intValue	()I
    //   31: istore 4
    //   33: iload 4
    //   35: i2f
    //   36: freturn
    //   37: new 50	android/util/TypedValue
    //   40: dup
    //   41: invokespecial 53	android/util/TypedValue:<init>	()V
    //   44: astore_2
    //   45: aload_1
    //   46: invokevirtual 59	android/content/Context:getTheme	()Landroid/content/res/Resources$Theme;
    //   49: ldc 60
    //   51: aload_2
    //   52: iconst_1
    //   53: invokevirtual 66	android/content/res/Resources$Theme:resolveAttribute	(ILandroid/util/TypedValue;Z)Z
    //   56: ifeq +15 -> 71
    //   59: aload_2
    //   60: aload_1
    //   61: invokevirtual 70	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   64: invokevirtual 76	android/content/res/Resources:getDisplayMetrics	()Landroid/util/DisplayMetrics;
    //   67: invokevirtual 80	android/util/TypedValue:getDimension	(Landroid/util/DisplayMetrics;)F
    //   70: freturn
    //   71: fconst_0
    //   72: freturn
    //
    // Exception table:
    //   from	to	target	type
    //   16	33	37	java/lang/Exception
  }

  public static int a(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.getScaledPagingTouchSlop();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.u
 * JD-Core Version:    0.6.2
 */