package androidx.core.h;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.Interpolator;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;

public final class x
{
  public WeakReference<View> a;
  Runnable b;
  public Runnable c;
  int d = -1;

  static
  {
    CoverageLogger.Log(46215168);
  }

  x(View paramView)
  {
    this.a = new WeakReference(paramView);
  }

  public final long a()
  {
    View localView = (View)this.a.get();
    if (localView != null)
      return localView.animate().getDuration();
    return 0L;
  }

  public final x a(float paramFloat)
  {
    View localView = (View)this.a.get();
    if (localView != null)
      localView.animate().alpha(paramFloat);
    return this;
  }

  public final x a(long paramLong)
  {
    View localView = (View)this.a.get();
    if (localView != null)
      localView.animate().setDuration(paramLong);
    return this;
  }

  public final x a(Interpolator paramInterpolator)
  {
    View localView = (View)this.a.get();
    if (localView != null)
      localView.animate().setInterpolator(paramInterpolator);
    return this;
  }

  public final x a(final aa paramaa)
  {
    final View localView = (View)this.a.get();
    if ((localView != null) && (Build.VERSION.SDK_INT >= 19))
    {
      ValueAnimator.AnimatorUpdateListener local2 = null;
      if (paramaa != null)
        local2 = new ValueAnimator.AnimatorUpdateListener()
        {
          static
          {
            CoverageLogger.Log(46393344);
          }

          public final void onAnimationUpdate(ValueAnimator paramAnonymousValueAnimator)
          {
            paramaa.a(localView);
          }
        };
      localView.animate().setUpdateListener(local2);
    }
    return this;
  }

  public final x a(y paramy)
  {
    View localView = (View)this.a.get();
    if (localView != null)
    {
      if (Build.VERSION.SDK_INT >= 16)
      {
        a(localView, paramy);
        return this;
      }
      localView.setTag(2113929216, paramy);
      a(localView, new a(this));
    }
    return this;
  }

  public void a(final View paramView, final y paramy)
  {
    if (paramy != null)
    {
      paramView.animate().setListener(new AnimatorListenerAdapter()
      {
        static
        {
          CoverageLogger.Log(46217216);
        }

        public final void onAnimationCancel(Animator paramAnonymousAnimator)
        {
          paramy.c(paramView);
        }

        public final void onAnimationEnd(Animator paramAnonymousAnimator)
        {
          paramy.b(paramView);
        }

        public final void onAnimationStart(Animator paramAnonymousAnimator)
        {
          paramy.a(paramView);
        }
      });
      return;
    }
    paramView.animate().setListener(null);
  }

  public final x b(float paramFloat)
  {
    View localView = (View)this.a.get();
    if (localView != null)
      localView.animate().translationY(paramFloat);
    return this;
  }

  public final x b(long paramLong)
  {
    View localView = (View)this.a.get();
    if (localView != null)
      localView.animate().setStartDelay(paramLong);
    return this;
  }

  public final void b()
  {
    View localView = (View)this.a.get();
    if (localView != null)
      localView.animate().cancel();
  }

  public final void c()
  {
    View localView = (View)this.a.get();
    if (localView != null)
      localView.animate().start();
  }

  public static final class a
    implements y
  {
    x a;
    boolean b;

    static
    {
      CoverageLogger.Log(46391296);
    }

    public a(x paramx)
    {
      this.a = paramx;
    }

    public final void a(View paramView)
    {
      this.b = false;
      if (this.a.d >= 0)
        paramView.setLayerType(2, null);
      if (this.a.b != null)
      {
        Runnable localRunnable = this.a.b;
        this.a.b = null;
        localRunnable.run();
      }
      Object localObject = paramView.getTag(2113929216);
      boolean bool = localObject instanceof y;
      y localy = null;
      if (bool)
        localy = (y)localObject;
      if (localy != null)
        localy.a(paramView);
    }

    public final void b(View paramView)
    {
      if (this.a.d >= 0)
      {
        paramView.setLayerType(this.a.d, null);
        this.a.d = -1;
      }
      if ((Build.VERSION.SDK_INT >= 16) || (!this.b))
      {
        if (this.a.c != null)
        {
          Runnable localRunnable = this.a.c;
          this.a.c = null;
          localRunnable.run();
        }
        Object localObject = paramView.getTag(2113929216);
        boolean bool = localObject instanceof y;
        y localy = null;
        if (bool)
          localy = (y)localObject;
        if (localy != null)
          localy.b(paramView);
        this.b = true;
      }
    }

    public final void c(View paramView)
    {
      Object localObject = paramView.getTag(2113929216);
      y localy;
      if ((localObject instanceof y))
        localy = (y)localObject;
      else
        localy = null;
      if (localy != null)
        localy.c(paramView);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.x
 * JD-Core Version:    0.6.2
 */