package androidx.core.h;

import android.os.Build.VERSION;
import android.view.ViewGroup;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class v
{
  static
  {
    CoverageLogger.Log(46387200);
  }

  public static int a(ViewGroup paramViewGroup)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramViewGroup.getNestedScrollAxes();
    return ((l)paramViewGroup).getNestedScrollAxes();
  }

  public static void a(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramViewGroup.setTransitionGroup(false);
      return;
    }
    paramViewGroup.setTag(2131301974, Boolean.valueOf(false));
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.v
 * JD-Core Version:    0.6.2
 */