package androidx.core.h;

import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewParent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class k
{
  public boolean a;
  private ViewParent b;
  private ViewParent c;
  private final View d;
  private int[] e;

  static
  {
    CoverageLogger.Log(46348288);
  }

  public k(View paramView)
  {
    this.d = paramView;
  }

  private void a(int paramInt, ViewParent paramViewParent)
  {
    if (paramInt != 0)
    {
      if (paramInt != 1)
        return;
      this.c = paramViewParent;
      return;
    }
    this.b = paramViewParent;
  }

  private ViewParent d(int paramInt)
  {
    if (paramInt != 0)
    {
      if (paramInt != 1)
        return null;
      return this.c;
    }
    return this.b;
  }

  public final void a(boolean paramBoolean)
  {
    if (this.a)
    {
      View localView = this.d;
      if (Build.VERSION.SDK_INT >= 21)
        localView.stopNestedScroll();
      else if ((localView instanceof i))
        ((i)localView).stopNestedScroll();
    }
    this.a = paramBoolean;
  }

  public final boolean a()
  {
    return a(0);
  }

  public final boolean a(float paramFloat1, float paramFloat2)
  {
    if (this.a)
    {
      ViewParent localViewParent = d(0);
      if (localViewParent != null)
        return w.a(localViewParent, this.d, paramFloat1, paramFloat2);
    }
    return false;
  }

  public final boolean a(float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    if (this.a)
    {
      ViewParent localViewParent = d(0);
      if (localViewParent != null)
        return w.a(localViewParent, this.d, paramFloat1, paramFloat2, paramBoolean);
    }
    return false;
  }

  public final boolean a(int paramInt)
  {
    return d(paramInt) != null;
  }

  public final boolean a(int paramInt1, int paramInt2)
  {
    if (a(paramInt2))
      return true;
    if (this.a)
    {
      ViewParent localViewParent = this.d.getParent();
      View localView = this.d;
      while (localViewParent != null)
      {
        if (w.a(localViewParent, localView, this.d, paramInt1, paramInt2))
        {
          a(paramInt2, localViewParent);
          w.b(localViewParent, localView, this.d, paramInt1, paramInt2);
          return true;
        }
        if ((localViewParent instanceof View))
          localView = (View)localViewParent;
        localViewParent = localViewParent.getParent();
      }
    }
    return false;
  }

  public final boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    return a(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt, 0);
  }

  public final boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt, int paramInt5)
  {
    if (this.a)
    {
      ViewParent localViewParent = d(paramInt5);
      if (localViewParent == null)
        return false;
      if ((paramInt1 == 0) && (paramInt2 == 0) && (paramInt3 == 0) && (paramInt4 == 0))
      {
        if (paramArrayOfInt != null)
        {
          paramArrayOfInt[0] = 0;
          paramArrayOfInt[1] = 0;
          return false;
        }
      }
      else
      {
        int i;
        int j;
        if (paramArrayOfInt != null)
        {
          this.d.getLocationInWindow(paramArrayOfInt);
          int k = paramArrayOfInt[0];
          int m = paramArrayOfInt[1];
          i = k;
          j = m;
        }
        else
        {
          i = 0;
          j = 0;
        }
        w.a(localViewParent, this.d, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
        if (paramArrayOfInt != null)
        {
          this.d.getLocationInWindow(paramArrayOfInt);
          paramArrayOfInt[0] -= i;
          paramArrayOfInt[1] -= j;
        }
        return true;
      }
    }
    return false;
  }

  public final boolean a(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    return a(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, 0);
  }

  public final boolean a(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt3)
  {
    if (this.a)
    {
      ViewParent localViewParent = d(paramInt3);
      if (localViewParent == null)
        return false;
      if ((paramInt1 == 0) && (paramInt2 == 0))
      {
        if (paramArrayOfInt2 != null)
        {
          paramArrayOfInt2[0] = 0;
          paramArrayOfInt2[1] = 0;
          return false;
        }
      }
      else
      {
        int i;
        int j;
        if (paramArrayOfInt2 != null)
        {
          this.d.getLocationInWindow(paramArrayOfInt2);
          int k = paramArrayOfInt2[0];
          int m = paramArrayOfInt2[1];
          i = k;
          j = m;
        }
        else
        {
          i = 0;
          j = 0;
        }
        if (paramArrayOfInt1 == null)
        {
          if (this.e == null)
            this.e = new int[2];
          paramArrayOfInt1 = this.e;
        }
        paramArrayOfInt1[0] = 0;
        paramArrayOfInt1[1] = 0;
        w.a(localViewParent, this.d, paramInt1, paramInt2, paramArrayOfInt1, paramInt3);
        if (paramArrayOfInt2 != null)
        {
          this.d.getLocationInWindow(paramArrayOfInt2);
          paramArrayOfInt2[0] -= i;
          paramArrayOfInt2[1] -= j;
        }
        if (paramArrayOfInt1[0] == 0)
          return paramArrayOfInt1[1] != 0;
        return true;
      }
    }
    return false;
  }

  public final void b()
  {
    c(0);
  }

  public final boolean b(int paramInt)
  {
    return a(paramInt, 0);
  }

  public final void c(int paramInt)
  {
    ViewParent localViewParent = d(paramInt);
    if (localViewParent != null)
    {
      w.a(localViewParent, this.d, paramInt);
      a(paramInt, null);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.k
 * JD-Core Version:    0.6.2
 */