package androidx.core.h;

import android.view.MotionEvent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class h
{
  static
  {
    CoverageLogger.Log(46342144);
  }

  public static int a(MotionEvent paramMotionEvent)
  {
    return paramMotionEvent.getActionMasked();
  }

  public static int a(MotionEvent paramMotionEvent, int paramInt)
  {
    return paramMotionEvent.findPointerIndex(paramInt);
  }

  public static int b(MotionEvent paramMotionEvent)
  {
    return paramMotionEvent.getActionIndex();
  }

  public static int b(MotionEvent paramMotionEvent, int paramInt)
  {
    return paramMotionEvent.getPointerId(paramInt);
  }

  public static float c(MotionEvent paramMotionEvent, int paramInt)
  {
    return paramMotionEvent.getX(paramInt);
  }

  public static float d(MotionEvent paramMotionEvent, int paramInt)
  {
    return paramMotionEvent.getY(paramInt);
  }

  public static boolean e(MotionEvent paramMotionEvent, int paramInt)
  {
    return (0x2002 & paramMotionEvent.getSource()) == 8194;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.h
 * JD-Core Version:    0.6.2
 */