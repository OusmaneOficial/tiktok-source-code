package androidx.core.h;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface.OnKeyListener;
import android.os.Build.VERSION;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.View;
import android.view.Window;
import android.view.Window.Callback;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class e
{
  private static boolean a;
  private static Method b;
  private static boolean c;
  private static Field d;

  static
  {
    CoverageLogger.Log(46270464);
  }

  // ERROR //
  private static DialogInterface.OnKeyListener a(Dialog paramDialog)
  {
    // Byte code:
    //   0: getstatic 27	androidx/core/h/e:c	Z
    //   3: ifne +31 -> 34
    //   6: ldc 29
    //   8: ldc 31
    //   10: invokevirtual 37	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   13: astore 4
    //   15: aload 4
    //   17: putstatic 39	androidx/core/h/e:d	Ljava/lang/reflect/Field;
    //   20: aload 4
    //   22: iconst_1
    //   23: invokevirtual 45	java/lang/reflect/Field:setAccessible	(Z)V
    //   26: goto +4 -> 30
    //   29: pop
    //   30: iconst_1
    //   31: putstatic 27	androidx/core/h/e:c	Z
    //   34: getstatic 39	androidx/core/h/e:d	Ljava/lang/reflect/Field;
    //   37: astore_1
    //   38: aload_1
    //   39: ifnull +14 -> 53
    //   42: aload_1
    //   43: aload_0
    //   44: invokevirtual 49	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   47: checkcast 51	android/content/DialogInterface$OnKeyListener
    //   50: astore_2
    //   51: aload_2
    //   52: areturn
    //   53: aconst_null
    //   54: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   6	26	29	java/lang/NoSuchFieldException
    //   42	51	53	java/lang/IllegalAccessException
  }

  // ERROR //
  private static boolean a(ActionBar paramActionBar, KeyEvent paramKeyEvent)
  {
    // Byte code:
    //   0: getstatic 58	androidx/core/h/e:a	Z
    //   3: ifne +32 -> 35
    //   6: aload_0
    //   7: invokevirtual 62	java/lang/Object:getClass	()Ljava/lang/Class;
    //   10: ldc 64
    //   12: iconst_1
    //   13: anewarray 33	java/lang/Class
    //   16: dup
    //   17: iconst_0
    //   18: ldc 66
    //   20: aastore
    //   21: invokevirtual 70	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   24: putstatic 72	androidx/core/h/e:b	Ljava/lang/reflect/Method;
    //   27: goto +4 -> 31
    //   30: pop
    //   31: iconst_1
    //   32: putstatic 58	androidx/core/h/e:a	Z
    //   35: getstatic 72	androidx/core/h/e:b	Ljava/lang/reflect/Method;
    //   38: astore_2
    //   39: aload_2
    //   40: ifnull +25 -> 65
    //   43: aload_2
    //   44: aload_0
    //   45: iconst_1
    //   46: anewarray 4	java/lang/Object
    //   49: dup
    //   50: iconst_0
    //   51: aload_1
    //   52: aastore
    //   53: invokevirtual 78	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   56: checkcast 80	java/lang/Boolean
    //   59: invokevirtual 84	java/lang/Boolean:booleanValue	()Z
    //   62: istore_3
    //   63: iload_3
    //   64: ireturn
    //   65: iconst_0
    //   66: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   6	27	30	java/lang/NoSuchMethodException
    //   43	63	65	java/lang/IllegalAccessException
    //   43	63	65	java/lang/reflect/InvocationTargetException
  }

  private static boolean a(Activity paramActivity, KeyEvent paramKeyEvent)
  {
    paramActivity.onUserInteraction();
    Window localWindow = paramActivity.getWindow();
    if (localWindow.hasFeature(8))
    {
      ActionBar localActionBar = paramActivity.getActionBar();
      if ((paramKeyEvent.getKeyCode() == 82) && (localActionBar != null) && (a(localActionBar, paramKeyEvent)))
        return true;
    }
    if (localWindow.superDispatchKeyEvent(paramKeyEvent))
      return true;
    View localView = localWindow.getDecorView();
    if (t.b(localView, paramKeyEvent))
      return true;
    KeyEvent.DispatcherState localDispatcherState;
    if (localView != null)
      localDispatcherState = localView.getKeyDispatcherState();
    else
      localDispatcherState = null;
    return paramKeyEvent.dispatch(paramActivity, localDispatcherState, paramActivity);
  }

  private static boolean a(Dialog paramDialog, KeyEvent paramKeyEvent)
  {
    DialogInterface.OnKeyListener localOnKeyListener = a(paramDialog);
    if ((localOnKeyListener != null) && (localOnKeyListener.onKey(paramDialog, paramKeyEvent.getKeyCode(), paramKeyEvent)))
      return true;
    Window localWindow = paramDialog.getWindow();
    if (localWindow.superDispatchKeyEvent(paramKeyEvent))
      return true;
    View localView = localWindow.getDecorView();
    if (t.b(localView, paramKeyEvent))
      return true;
    KeyEvent.DispatcherState localDispatcherState;
    if (localView != null)
      localDispatcherState = localView.getKeyDispatcherState();
    else
      localDispatcherState = null;
    return paramKeyEvent.dispatch(paramDialog, localDispatcherState, paramDialog);
  }

  public static boolean a(View paramView, KeyEvent paramKeyEvent)
  {
    return t.a(paramView, paramKeyEvent);
  }

  public static boolean a(a parama, View paramView, Window.Callback paramCallback, KeyEvent paramKeyEvent)
  {
    if (parama == null)
      return false;
    if (Build.VERSION.SDK_INT >= 28)
      return parama.superDispatchKeyEvent(paramKeyEvent);
    if ((paramCallback instanceof Activity))
      return a((Activity)paramCallback, paramKeyEvent);
    if ((paramCallback instanceof Dialog))
      return a((Dialog)paramCallback, paramKeyEvent);
    return ((paramView != null) && (t.b(paramView, paramKeyEvent))) || (parama.superDispatchKeyEvent(paramKeyEvent));
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46268416);
    }

    public abstract boolean superDispatchKeyEvent(KeyEvent paramKeyEvent);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.e
 * JD-Core Version:    0.6.2
 */