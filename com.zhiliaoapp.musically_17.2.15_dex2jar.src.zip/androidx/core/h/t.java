package androidx.core.h;

import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public final class t
{
  private static final AtomicInteger a = new AtomicInteger(1);
  private static Field b;
  private static boolean c;
  private static Field d;
  private static boolean e;
  private static WeakHashMap<View, String> f;
  private static WeakHashMap<View, x> g = null;
  private static Method h;
  private static Field i;
  private static boolean j = false;
  private static ThreadLocal<Rect> k;

  static
  {
    CoverageLogger.Log(46243840);
  }

  public static Rect A(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 18)
      return paramView.getClipBounds();
    return null;
  }

  public static boolean B(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return paramView.isAttachedToWindow();
    return paramView.getWindowToken() != null;
  }

  private static void C(View paramView)
  {
    float f1 = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f1);
    paramView.setTranslationY(f1);
  }

  public static int a(View paramView)
  {
    return paramView.getOverScrollMode();
  }

  private static Rect a()
  {
    if (k == null)
      k = new ThreadLocal();
    Rect localRect = (Rect)k.get();
    if (localRect == null)
    {
      localRect = new Rect();
      k.set(localRect);
    }
    localRect.setEmpty();
    return localRect;
  }

  public static ab a(View paramView, ab paramab)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      WindowInsets localWindowInsets1 = (WindowInsets)ab.a(paramab);
      WindowInsets localWindowInsets2 = paramView.onApplyWindowInsets(localWindowInsets1);
      if (localWindowInsets2 != localWindowInsets1)
        localWindowInsets1 = new WindowInsets(localWindowInsets2);
      return ab.a(localWindowInsets1);
    }
    return paramab;
  }

  public static void a(View paramView, float paramFloat)
  {
    paramView.setScaleX(paramFloat);
  }

  public static void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      paramView.postInvalidateOnAnimation(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    paramView.postInvalidate(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static void a(View paramView, int paramInt, Paint paramPaint)
  {
    paramView.setLayerType(paramInt, paramPaint);
  }

  public static void a(View paramView, ColorStateList paramColorStateList)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramView.setBackgroundTintList(paramColorStateList);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramView.getBackground();
        int m;
        if ((paramView.getBackgroundTintList() == null) && (paramView.getBackgroundTintMode() == null))
          m = 0;
        else
          m = 1;
        if ((localDrawable != null) && (m != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramView.getDrawableState());
          paramView.setBackground(localDrawable);
        }
      }
    }
    else if ((paramView instanceof r))
    {
      ((r)paramView).setSupportBackgroundTintList(paramColorStateList);
    }
  }

  public static void a(View paramView, Paint paramPaint)
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      paramView.setLayerPaint(paramPaint);
      return;
    }
    paramView.setLayerType(paramView.getLayerType(), paramPaint);
    paramView.invalidate();
  }

  public static void a(View paramView, PorterDuff.Mode paramMode)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramView.setBackgroundTintMode(paramMode);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramView.getBackground();
        int m;
        if ((paramView.getBackgroundTintList() == null) && (paramView.getBackgroundTintMode() == null))
          m = 0;
        else
          m = 1;
        if ((localDrawable != null) && (m != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramView.getDrawableState());
          paramView.setBackground(localDrawable);
        }
      }
    }
    else if ((paramView instanceof r))
    {
      ((r)paramView).setSupportBackgroundTintMode(paramMode);
    }
  }

  public static void a(View paramView, Rect paramRect)
  {
    if (Build.VERSION.SDK_INT >= 18)
      paramView.setClipBounds(paramRect);
  }

  public static void a(View paramView, Drawable paramDrawable)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      paramView.setBackground(paramDrawable);
      return;
    }
    paramView.setBackgroundDrawable(paramDrawable);
  }

  public static void a(View paramView, a parama)
  {
    View.AccessibilityDelegate localAccessibilityDelegate;
    if (parama == null)
      localAccessibilityDelegate = null;
    else
      localAccessibilityDelegate = parama.c;
    paramView.setAccessibilityDelegate(localAccessibilityDelegate);
  }

  public static void a(View paramView, o paramo)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      if (paramo == null)
      {
        paramView.setOnApplyWindowInsetsListener(null);
        return;
      }
      paramView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener()
      {
        static
        {
          CoverageLogger.Log(46374912);
        }

        public final WindowInsets onApplyWindowInsets(View paramAnonymousView, WindowInsets paramAnonymousWindowInsets)
        {
          ab localab = ab.a(paramAnonymousWindowInsets);
          return (WindowInsets)ab.a(this.a.a(paramAnonymousView, localab));
        }
      });
    }
  }

  public static void a(View paramView, p paramp)
  {
    if (Build.VERSION.SDK_INT >= 24)
    {
      Object localObject;
      if (paramp != null)
        localObject = paramp.a;
      else
        localObject = null;
      paramView.setPointerIcon((PointerIcon)localObject);
    }
  }

  public static void a(View paramView, Runnable paramRunnable)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      paramView.postOnAnimation(paramRunnable);
      return;
    }
    paramView.postDelayed(paramRunnable, ValueAnimator.getFrameDelay());
  }

  public static void a(View paramView, Runnable paramRunnable, long paramLong)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      paramView.postOnAnimationDelayed(paramRunnable, paramLong);
      return;
    }
    paramView.postDelayed(paramRunnable, paramLong + ValueAnimator.getFrameDelay());
  }

  public static void a(View paramView, String paramString)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramView.setTransitionName(paramString);
      return;
    }
    if (f == null)
      f = new WeakHashMap();
    f.put(paramView, paramString);
  }

  public static void a(View paramView, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramView.setHasTransientState(paramBoolean);
  }

  public static void a(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    if (h == null)
    {
      try
      {
        Class[] arrayOfClass = new Class[1];
        arrayOfClass[0] = Boolean.TYPE;
        h = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", arrayOfClass);
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
      }
      h.setAccessible(true);
    }
    try
    {
      Method localMethod = h;
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Boolean.valueOf(true);
      localMethod.invoke(paramViewGroup, arrayOfObject);
    }
    catch (IllegalAccessException|IllegalArgumentException|InvocationTargetException localIllegalAccessException)
    {
    }
  }

  public static boolean a(View paramView, int paramInt)
  {
    return paramView.canScrollVertically(paramInt);
  }

  static boolean a(View paramView, KeyEvent paramKeyEvent)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return false;
    return b.a(paramView).a(paramKeyEvent);
  }

  public static ab b(View paramView, ab paramab)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      WindowInsets localWindowInsets1 = (WindowInsets)ab.a(paramab);
      WindowInsets localWindowInsets2 = paramView.dispatchApplyWindowInsets(localWindowInsets1);
      if (localWindowInsets2 != localWindowInsets1)
        localWindowInsets1 = new WindowInsets(localWindowInsets2);
      return ab.a(localWindowInsets1);
    }
    return paramab;
  }

  public static void b(View paramView, float paramFloat)
  {
    paramView.setScaleY(paramFloat);
  }

  public static void b(View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT < 19)
    {
      if (Build.VERSION.SDK_INT < 16)
        return;
      if (paramInt == 4)
        paramInt = 2;
    }
    paramView.setImportantForAccessibility(paramInt);
  }

  public static void b(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      paramView.setPaddingRelative(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    paramView.setPadding(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static void b(View paramView, boolean paramBoolean)
  {
    paramView.setFitsSystemWindows(paramBoolean);
  }

  public static boolean b(View paramView)
  {
    if (j)
      return false;
    if (i == null)
      try
      {
        Field localField = View.class.getDeclaredField("mAccessibilityDelegate");
        i = localField;
        localField.setAccessible(true);
      }
      finally
      {
        j = true;
        return false;
      }
    try
    {
      Object localObject = i.get(paramView);
      return localObject != null;
    }
    finally
    {
      j = true;
    }
    return false;
  }

  static boolean b(View paramView, KeyEvent paramKeyEvent)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return false;
    return b.a(paramView).a(paramView, paramKeyEvent);
  }

  public static void c(View paramView, float paramFloat)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setElevation(paramFloat);
  }

  public static void c(View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      paramView.setLayoutDirection(paramInt);
  }

  public static boolean c(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.hasTransientState();
    return false;
  }

  public static <T extends View> T d(View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return paramView.requireViewById(paramInt);
    View localView = paramView.findViewById(paramInt);
    if (localView != null)
      return localView;
    throw new IllegalArgumentException("ID does not reference a View inside this View");
  }

  public static void d(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      paramView.postInvalidateOnAnimation();
      return;
    }
    paramView.postInvalidate();
  }

  public static void d(View paramView, float paramFloat)
  {
    if (Build.VERSION.SDK_INT >= 21)
      paramView.setZ(paramFloat);
  }

  public static int e(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.getImportantForAccessibility();
    return 0;
  }

  public static void e(View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 19)
      paramView.setAccessibilityLiveRegion(paramInt);
  }

  public static int f(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return paramView.getLayoutDirection();
    return 0;
  }

  public static void f(View paramView, int paramInt)
  {
    if ((paramView instanceof j))
      ((j)paramView).a(1);
  }

  public static ViewParent g(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.getParentForAccessibility();
    return paramView.getParent();
  }

  public static void g(View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      paramView.offsetTopAndBottom(paramInt);
      return;
    }
    if (Build.VERSION.SDK_INT >= 21)
    {
      Rect localRect = a();
      ViewParent localViewParent = paramView.getParent();
      boolean bool1 = localViewParent instanceof View;
      boolean bool2 = false;
      if (bool1)
      {
        View localView = (View)localViewParent;
        localRect.set(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom());
        bool2 = true ^ localRect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
      }
      i(paramView, paramInt);
      if ((bool2) && (localRect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())))
        ((View)localViewParent).invalidate(localRect);
      return;
    }
    i(paramView, paramInt);
  }

  public static int h(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return paramView.getAccessibilityLiveRegion();
    return 0;
  }

  public static void h(View paramView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      paramView.offsetLeftAndRight(paramInt);
      return;
    }
    if (Build.VERSION.SDK_INT >= 21)
    {
      Rect localRect = a();
      ViewParent localViewParent = paramView.getParent();
      boolean bool1 = localViewParent instanceof View;
      boolean bool2 = false;
      if (bool1)
      {
        View localView = (View)localViewParent;
        localRect.set(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom());
        bool2 = true ^ localRect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
      }
      j(paramView, paramInt);
      if ((bool2) && (localRect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())))
        ((View)localViewParent).invalidate(localRect);
      return;
    }
    j(paramView, paramInt);
  }

  public static int i(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return paramView.getPaddingStart();
    return paramView.getPaddingLeft();
  }

  private static void i(View paramView, int paramInt)
  {
    paramView.offsetTopAndBottom(paramInt);
    if (paramView.getVisibility() == 0)
    {
      C(paramView);
      ViewParent localViewParent = paramView.getParent();
      if ((localViewParent instanceof View))
        C((View)localViewParent);
    }
  }

  public static int j(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return paramView.getPaddingEnd();
    return paramView.getPaddingRight();
  }

  private static void j(View paramView, int paramInt)
  {
    paramView.offsetLeftAndRight(paramInt);
    if (paramView.getVisibility() == 0)
    {
      C(paramView);
      ViewParent localViewParent = paramView.getParent();
      if ((localViewParent instanceof View))
        C((View)localViewParent);
    }
  }

  // ERROR //
  public static int k(View paramView)
  {
    // Byte code:
    //   0: getstatic 52	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 16
    //   5: if_icmplt +8 -> 13
    //   8: aload_0
    //   9: invokevirtual 476	android/view/View:getMinimumWidth	()I
    //   12: ireturn
    //   13: getstatic 478	androidx/core/h/t:c	Z
    //   16: ifne +32 -> 48
    //   19: ldc 54
    //   21: ldc_w 480
    //   24: invokevirtual 357	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   27: astore 4
    //   29: aload 4
    //   31: putstatic 482	androidx/core/h/t:b	Ljava/lang/reflect/Field;
    //   34: aload 4
    //   36: iconst_1
    //   37: invokevirtual 360	java/lang/reflect/Field:setAccessible	(Z)V
    //   40: goto +4 -> 44
    //   43: pop
    //   44: iconst_1
    //   45: putstatic 478	androidx/core/h/t:c	Z
    //   48: getstatic 482	androidx/core/h/t:b	Ljava/lang/reflect/Field;
    //   51: astore_1
    //   52: aload_1
    //   53: ifnull +17 -> 70
    //   56: aload_1
    //   57: aload_0
    //   58: invokevirtual 363	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   61: checkcast 484	java/lang/Integer
    //   64: invokevirtual 487	java/lang/Integer:intValue	()I
    //   67: istore_2
    //   68: iload_2
    //   69: ireturn
    //   70: iconst_0
    //   71: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   19	40	43	java/lang/NoSuchFieldException
    //   56	68	70	java/lang/Exception
  }

  // ERROR //
  public static int l(View paramView)
  {
    // Byte code:
    //   0: getstatic 52	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 16
    //   5: if_icmplt +8 -> 13
    //   8: aload_0
    //   9: invokevirtual 491	android/view/View:getMinimumHeight	()I
    //   12: ireturn
    //   13: getstatic 493	androidx/core/h/t:e	Z
    //   16: ifne +32 -> 48
    //   19: ldc 54
    //   21: ldc_w 495
    //   24: invokevirtual 357	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   27: astore 4
    //   29: aload 4
    //   31: putstatic 497	androidx/core/h/t:d	Ljava/lang/reflect/Field;
    //   34: aload 4
    //   36: iconst_1
    //   37: invokevirtual 360	java/lang/reflect/Field:setAccessible	(Z)V
    //   40: goto +4 -> 44
    //   43: pop
    //   44: iconst_1
    //   45: putstatic 493	androidx/core/h/t:e	Z
    //   48: getstatic 497	androidx/core/h/t:d	Ljava/lang/reflect/Field;
    //   51: astore_1
    //   52: aload_1
    //   53: ifnull +17 -> 70
    //   56: aload_1
    //   57: aload_0
    //   58: invokevirtual 363	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   61: checkcast 484	java/lang/Integer
    //   64: invokevirtual 487	java/lang/Integer:intValue	()I
    //   67: istore_2
    //   68: iload_2
    //   69: ireturn
    //   70: iconst_0
    //   71: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   19	40	43	java/lang/NoSuchFieldException
    //   56	68	70	java/lang/Exception
  }

  public static x m(View paramView)
  {
    if (g == null)
      g = new WeakHashMap();
    x localx = (x)g.get(paramView);
    if (localx == null)
    {
      localx = new x(paramView);
      g.put(paramView, localx);
    }
    return localx;
  }

  public static float n(View paramView)
  {
    return paramView.getScaleX();
  }

  public static float o(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getElevation();
    return 0.0F;
  }

  public static String p(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getTransitionName();
    WeakHashMap localWeakHashMap = f;
    if (localWeakHashMap == null)
      return null;
    return (String)localWeakHashMap.get(paramView);
  }

  public static int q(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.getWindowSystemUiVisibility();
    return 0;
  }

  public static void r(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 20)
    {
      paramView.requestApplyInsets();
      return;
    }
    if (Build.VERSION.SDK_INT >= 16)
      paramView.requestFitSystemWindows();
  }

  public static boolean s(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.getFitsSystemWindows();
    return false;
  }

  public static boolean t(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return paramView.hasOverlappingRendering();
    return true;
  }

  public static boolean u(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return paramView.isPaddingRelative();
    return false;
  }

  public static ColorStateList v(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getBackgroundTintList();
    if ((paramView instanceof r))
      return ((r)paramView).getSupportBackgroundTintList();
    return null;
  }

  public static PorterDuff.Mode w(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getBackgroundTintMode();
    if ((paramView instanceof r))
      return ((r)paramView).getSupportBackgroundTintMode();
    return null;
  }

  public static boolean x(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.isNestedScrollingEnabled();
    if ((paramView instanceof i))
      return ((i)paramView).isNestedScrollingEnabled();
    return false;
  }

  public static boolean y(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return paramView.isLaidOut();
    return (paramView.getWidth() > 0) && (paramView.getHeight() > 0);
  }

  public static float z(View paramView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramView.getZ();
    return 0.0F;
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46376960);
    }

    public abstract boolean a(View paramView, KeyEvent paramKeyEvent);
  }

  static final class b
  {
    private static final ArrayList<WeakReference<View>> a = new ArrayList();
    private WeakHashMap<View, Boolean> b;
    private SparseArray<WeakReference<View>> c;
    private WeakReference<KeyEvent> d;

    static
    {
      CoverageLogger.Log(46233600);
    }

    private SparseArray<WeakReference<View>> a()
    {
      if (this.c == null)
        this.c = new SparseArray();
      return this.c;
    }

    static b a(View paramView)
    {
      b localb = (b)paramView.getTag(2131301976);
      if (localb == null)
      {
        localb = new b();
        paramView.setTag(2131301976, localb);
      }
      return localb;
    }

    private View b(View paramView, KeyEvent paramKeyEvent)
    {
      WeakHashMap localWeakHashMap = this.b;
      if (localWeakHashMap != null)
      {
        if (!localWeakHashMap.containsKey(paramView))
          return null;
        if ((paramView instanceof ViewGroup))
        {
          ViewGroup localViewGroup = (ViewGroup)paramView;
          for (int i = -1 + localViewGroup.getChildCount(); i >= 0; i--)
          {
            View localView = b(localViewGroup.getChildAt(i), paramKeyEvent);
            if (localView != null)
              return localView;
          }
        }
        if (c(paramView, paramKeyEvent))
          return paramView;
      }
      return null;
    }

    private void b()
    {
      WeakHashMap localWeakHashMap = this.b;
      if (localWeakHashMap != null)
        localWeakHashMap.clear();
      if (a.isEmpty())
        return;
      int i;
      synchronized (a)
      {
        if (this.b == null)
          this.b = new WeakHashMap();
        i = -1 + a.size();
        if (i >= 0)
        {
          View localView = (View)((WeakReference)a.get(i)).get();
          if (localView == null)
          {
            a.remove(i);
          }
          else
          {
            this.b.put(localView, Boolean.TRUE);
            for (ViewParent localViewParent = localView.getParent(); (localViewParent instanceof View); localViewParent = localViewParent.getParent())
              this.b.put((View)localViewParent, Boolean.TRUE);
          }
        }
        else
        {
          return;
        }
      }
    }

    private static boolean c(View paramView, KeyEvent paramKeyEvent)
    {
      ArrayList localArrayList = (ArrayList)paramView.getTag(2131301977);
      if (localArrayList != null)
        for (int i = localArrayList.size() - 1; i >= 0; i--)
          if (((t.a)localArrayList.get(i)).a(paramView, paramKeyEvent))
            return true;
      return false;
    }

    final boolean a(KeyEvent paramKeyEvent)
    {
      WeakReference localWeakReference1 = this.d;
      if ((localWeakReference1 != null) && (localWeakReference1.get() == paramKeyEvent))
        return false;
      this.d = new WeakReference(paramKeyEvent);
      SparseArray localSparseArray = a();
      int i = paramKeyEvent.getAction();
      WeakReference localWeakReference2 = null;
      if (i == 1)
      {
        int j = localSparseArray.indexOfKey(paramKeyEvent.getKeyCode());
        localWeakReference2 = null;
        if (j >= 0)
        {
          localWeakReference2 = (WeakReference)localSparseArray.valueAt(j);
          localSparseArray.removeAt(j);
        }
      }
      if (localWeakReference2 == null)
        localWeakReference2 = (WeakReference)localSparseArray.get(paramKeyEvent.getKeyCode());
      if (localWeakReference2 != null)
      {
        View localView = (View)localWeakReference2.get();
        if ((localView != null) && (t.B(localView)))
          c(localView, paramKeyEvent);
        return true;
      }
      return false;
    }

    final boolean a(View paramView, KeyEvent paramKeyEvent)
    {
      if (paramKeyEvent.getAction() == 0)
        b();
      View localView = b(paramView, paramKeyEvent);
      if (paramKeyEvent.getAction() == 0)
      {
        int i = paramKeyEvent.getKeyCode();
        if ((localView != null) && (!KeyEvent.isModifierKey(i)))
          a().put(i, new WeakReference(localView));
      }
      return localView != null;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.t
 * JD-Core Version:    0.6.2
 */