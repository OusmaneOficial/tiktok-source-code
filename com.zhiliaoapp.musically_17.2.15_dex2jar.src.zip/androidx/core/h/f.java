package androidx.core.h;

import android.os.Build.VERSION;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.LayoutInflater.Factory2;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;

public final class f
{
  private static Field a;
  private static boolean b;

  static
  {
    CoverageLogger.Log(46338048);
  }

  public static void a(LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2)
  {
    paramLayoutInflater.setFactory2(paramFactory2);
    if (Build.VERSION.SDK_INT < 21)
    {
      LayoutInflater.Factory localFactory = paramLayoutInflater.getFactory();
      if ((localFactory instanceof LayoutInflater.Factory2))
      {
        b(paramLayoutInflater, (LayoutInflater.Factory2)localFactory);
        return;
      }
      b(paramLayoutInflater, paramFactory2);
    }
  }

  private static void b(LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2)
  {
    if (!b)
    {
      try
      {
        Field localField2 = LayoutInflater.class.getDeclaredField("mFactory2");
        a = localField2;
        localField2.setAccessible(true);
      }
      catch (NoSuchFieldException localNoSuchFieldException)
      {
      }
      b = true;
    }
    Field localField1 = a;
    if (localField1 != null);
    try
    {
      localField1.set(paramLayoutInflater, paramFactory2);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.f
 * JD-Core Version:    0.6.2
 */