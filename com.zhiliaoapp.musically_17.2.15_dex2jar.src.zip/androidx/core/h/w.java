package androidx.core.h;

import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewParent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class w
{
  static
  {
    CoverageLogger.Log(46223360);
  }

  public static void a(ViewParent paramViewParent, View paramView, int paramInt)
  {
    if ((paramViewParent instanceof m))
    {
      ((m)paramViewParent).b(paramView, paramInt);
      return;
    }
    if (paramInt == 0)
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        try
        {
          paramViewParent.onStopNestedScroll(paramView);
        }
        catch (AbstractMethodError localAbstractMethodError)
        {
        }
        return;
      }
      if ((paramViewParent instanceof l))
        ((l)paramViewParent).onStopNestedScroll(paramView);
    }
  }

  public static void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if ((paramViewParent instanceof m))
    {
      ((m)paramViewParent).a(paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return;
    }
    if (paramInt5 == 0)
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        try
        {
          paramViewParent.onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
        }
        catch (AbstractMethodError localAbstractMethodError)
        {
        }
        return;
      }
      if ((paramViewParent instanceof l))
        ((l)paramViewParent).onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
    }
  }

  public static void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3)
  {
    if ((paramViewParent instanceof m))
    {
      ((m)paramViewParent).a(paramView, paramInt1, paramInt2, paramArrayOfInt, paramInt3);
      return;
    }
    if (paramInt3 == 0)
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        try
        {
          paramViewParent.onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfInt);
        }
        catch (AbstractMethodError localAbstractMethodError)
        {
        }
        return;
      }
      if ((paramViewParent instanceof l))
        ((l)paramViewParent).onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfInt);
    }
  }

  // ERROR //
  public static boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2)
  {
    // Byte code:
    //   0: getstatic 29	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 21
    //   5: if_icmplt +17 -> 22
    //   8: aload_0
    //   9: aload_1
    //   10: fload_2
    //   11: fload_3
    //   12: invokeinterface 61 4 0
    //   17: istore 4
    //   19: iload 4
    //   21: ireturn
    //   22: aload_0
    //   23: instanceof 37
    //   26: ifeq +16 -> 42
    //   29: aload_0
    //   30: checkcast 37	androidx/core/h/l
    //   33: aload_1
    //   34: fload_2
    //   35: fload_3
    //   36: invokeinterface 62 4 0
    //   41: ireturn
    //   42: iconst_0
    //   43: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   8	19	42	java/lang/AbstractMethodError
  }

  // ERROR //
  public static boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    // Byte code:
    //   0: getstatic 29	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 21
    //   5: if_icmplt +19 -> 24
    //   8: aload_0
    //   9: aload_1
    //   10: fload_2
    //   11: fload_3
    //   12: iload 4
    //   14: invokeinterface 67 5 0
    //   19: istore 5
    //   21: iload 5
    //   23: ireturn
    //   24: aload_0
    //   25: instanceof 37
    //   28: ifeq +18 -> 46
    //   31: aload_0
    //   32: checkcast 37	androidx/core/h/l
    //   35: aload_1
    //   36: fload_2
    //   37: fload_3
    //   38: iload 4
    //   40: invokeinterface 68 5 0
    //   45: ireturn
    //   46: iconst_0
    //   47: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   8	21	46	java/lang/AbstractMethodError
  }

  // ERROR //
  public static boolean a(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: aload_0
    //   1: instanceof 19
    //   4: ifeq +18 -> 22
    //   7: aload_0
    //   8: checkcast 19	androidx/core/h/m
    //   11: aload_1
    //   12: aload_2
    //   13: iload_3
    //   14: iload 4
    //   16: invokeinterface 72 5 0
    //   21: ireturn
    //   22: iload 4
    //   24: ifne +45 -> 69
    //   27: getstatic 29	android/os/Build$VERSION:SDK_INT	I
    //   30: bipush 21
    //   32: if_icmplt +17 -> 49
    //   35: aload_0
    //   36: aload_1
    //   37: aload_2
    //   38: iload_3
    //   39: invokeinterface 76 4 0
    //   44: istore 5
    //   46: iload 5
    //   48: ireturn
    //   49: aload_0
    //   50: instanceof 37
    //   53: ifeq +16 -> 69
    //   56: aload_0
    //   57: checkcast 37	androidx/core/h/l
    //   60: aload_1
    //   61: aload_2
    //   62: iload_3
    //   63: invokeinterface 77 4 0
    //   68: ireturn
    //   69: iconst_0
    //   70: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   35	46	69	java/lang/AbstractMethodError
  }

  public static void b(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    if ((paramViewParent instanceof m))
    {
      ((m)paramViewParent).b(paramView1, paramView2, paramInt1, paramInt2);
      return;
    }
    if (paramInt2 == 0)
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        try
        {
          paramViewParent.onNestedScrollAccepted(paramView1, paramView2, paramInt1);
        }
        catch (AbstractMethodError localAbstractMethodError)
        {
        }
        return;
      }
      if ((paramViewParent instanceof l))
        ((l)paramViewParent).onNestedScrollAccepted(paramView1, paramView2, paramInt1);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.w
 * JD-Core Version:    0.6.2
 */