package androidx.core.h;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c
{
  private final a a;

  static
  {
    CoverageLogger.Log(46272512);
  }

  public c(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener)
  {
    this(paramContext, paramOnGestureListener, null);
  }

  private c(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler)
  {
    if (Build.VERSION.SDK_INT > 17)
    {
      this.a = new c(paramContext, paramOnGestureListener, null);
      return;
    }
    this.a = new b(paramContext, paramOnGestureListener, null);
  }

  public final void a(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener)
  {
    this.a.a(paramOnDoubleTapListener);
  }

  public final void a(boolean paramBoolean)
  {
    this.a.a(false);
  }

  public final boolean a(MotionEvent paramMotionEvent)
  {
    return this.a.a(paramMotionEvent);
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46327808);
    }

    public abstract void a(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener);

    public abstract void a(boolean paramBoolean);

    public abstract boolean a(MotionEvent paramMotionEvent);
  }

  static final class b
    implements c.a
  {
    private static final int l = ViewConfiguration.getLongPressTimeout();
    private static final int m = ViewConfiguration.getTapTimeout();
    private static final int n = ViewConfiguration.getDoubleTapTimeout();
    final Handler a;
    final GestureDetector.OnGestureListener b;
    GestureDetector.OnDoubleTapListener c;
    boolean d;
    boolean e;
    boolean f;
    MotionEvent g;
    private int h;
    private int i;
    private int j;
    private int k;
    private boolean o;
    private boolean p;
    private MotionEvent q;
    private boolean r;
    private float s;
    private float t;
    private float u;
    private float v;
    private boolean w;
    private VelocityTracker x;

    static
    {
      CoverageLogger.Log(46317568);
    }

    b(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler)
    {
      if (paramHandler != null)
        this.a = new a(paramHandler);
      else
        this.a = new a();
      this.b = paramOnGestureListener;
      if ((paramOnGestureListener instanceof GestureDetector.OnDoubleTapListener))
        a((GestureDetector.OnDoubleTapListener)paramOnGestureListener);
      if (paramContext != null)
      {
        if (this.b != null)
        {
          this.w = true;
          ViewConfiguration localViewConfiguration = ViewConfiguration.get(paramContext);
          int i1 = localViewConfiguration.getScaledTouchSlop();
          int i2 = localViewConfiguration.getScaledDoubleTapSlop();
          this.j = localViewConfiguration.getScaledMinimumFlingVelocity();
          this.k = localViewConfiguration.getScaledMaximumFlingVelocity();
          this.h = (i1 * i1);
          this.i = (i2 * i2);
          return;
        }
        throw new IllegalArgumentException("OnGestureListener must not be null");
      }
      throw new IllegalArgumentException("Context must not be null");
    }

    public final void a(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener)
    {
      this.c = paramOnDoubleTapListener;
    }

    public final void a(boolean paramBoolean)
    {
      this.w = paramBoolean;
    }

    public final boolean a(MotionEvent paramMotionEvent)
    {
      int i1 = paramMotionEvent.getAction();
      if (this.x == null)
        this.x = VelocityTracker.obtain();
      this.x.addMovement(paramMotionEvent);
      int i2 = i1 & 0xFF;
      int i3;
      if (i2 == 6)
        i3 = 1;
      else
        i3 = 0;
      int i4;
      if (i3 != 0)
        i4 = paramMotionEvent.getActionIndex();
      else
        i4 = -1;
      int i5 = paramMotionEvent.getPointerCount();
      int i6 = 0;
      float f1 = 0.0F;
      float f2 = 0.0F;
      while (i6 < i5)
      {
        if (i4 != i6)
        {
          f1 += paramMotionEvent.getX(i6);
          f2 += paramMotionEvent.getY(i6);
        }
        i6++;
      }
      int i7;
      if (i3 != 0)
        i7 = i5 - 1;
      else
        i7 = i5;
      float f3 = i7;
      float f4 = f1 / f3;
      float f5 = f2 / f3;
      boolean bool2;
      if (i2 != 0)
      {
        boolean bool4;
        if (i2 != 1)
        {
          if (i2 != 2)
          {
            if (i2 != 3)
            {
              if (i2 != 5)
              {
                if (i2 != 6)
                  return false;
                this.s = f4;
                this.u = f4;
                this.t = f5;
                this.v = f5;
                this.x.computeCurrentVelocity(1000, this.k);
                int i15 = paramMotionEvent.getActionIndex();
                int i16 = paramMotionEvent.getPointerId(i15);
                float f10 = this.x.getXVelocity(i16);
                float f11 = this.x.getYVelocity(i16);
                for (int i17 = 0; ; i17++)
                {
                  bool2 = false;
                  if (i17 >= i5)
                    break;
                  if (i17 != i15)
                  {
                    int i18 = paramMotionEvent.getPointerId(i17);
                    if (f10 * this.x.getXVelocity(i18) + f11 * this.x.getYVelocity(i18) < 0.0F)
                    {
                      this.x.clear();
                      return false;
                    }
                  }
                }
              }
              this.s = f4;
              this.u = f4;
              this.t = f5;
              this.v = f5;
              this.a.removeMessages(1);
              this.a.removeMessages(2);
              this.a.removeMessages(3);
              this.r = false;
              this.o = false;
              this.p = false;
              this.e = false;
              boolean bool10 = this.f;
              bool2 = false;
              if (!bool10)
                break label1385;
              this.f = false;
              return false;
            }
            this.a.removeMessages(1);
            this.a.removeMessages(2);
            this.a.removeMessages(3);
            this.x.recycle();
            this.x = null;
            this.r = false;
            this.d = false;
            this.o = false;
            this.p = false;
            this.e = false;
            boolean bool9 = this.f;
            bool2 = false;
            if (!bool9)
              break label1385;
            this.f = false;
            return false;
          }
          boolean bool6 = this.f;
          bool2 = false;
          if (bool6)
            break label1385;
          float f8 = this.s - f4;
          float f9 = this.t - f5;
          if (this.r)
            return false | this.c.onDoubleTapEvent(paramMotionEvent);
          if (this.o)
          {
            int i12 = (int)(f4 - this.u);
            int i13 = (int)(f5 - this.v);
            int i14 = i12 * i12 + i13 * i13;
            if (i14 > this.h)
            {
              bool4 = this.b.onScroll(this.g, paramMotionEvent, f8, f9);
              this.s = f4;
              this.t = f5;
              this.o = false;
              this.a.removeMessages(3);
              this.a.removeMessages(1);
              this.a.removeMessages(2);
            }
            else
            {
              bool4 = false;
            }
            if (i14 > this.h)
              this.p = false;
          }
          else
          {
            if (Math.abs(f8) < 1.0F)
            {
              boolean bool8 = Math.abs(f9) < 1.0F;
              bool2 = false;
              if (bool8)
                break label1385;
            }
            boolean bool7 = this.b.onScroll(this.g, paramMotionEvent, f8, f9);
            this.s = f4;
            this.t = f5;
            return bool7;
          }
        }
        else
        {
          this.d = false;
          MotionEvent localMotionEvent4 = MotionEvent.obtain(paramMotionEvent);
          if (this.r)
          {
            bool4 = false | this.c.onDoubleTapEvent(paramMotionEvent);
          }
          else
          {
            float f6;
            float f7;
            if (this.f)
            {
              this.a.removeMessages(3);
              this.f = false;
            }
            else
            {
              if (this.o)
              {
                boolean bool5 = this.b.onSingleTapUp(paramMotionEvent);
                if (this.e)
                {
                  GestureDetector.OnDoubleTapListener localOnDoubleTapListener = this.c;
                  if (localOnDoubleTapListener != null)
                    localOnDoubleTapListener.onSingleTapConfirmed(paramMotionEvent);
                }
                bool4 = bool5;
                break label969;
              }
              VelocityTracker localVelocityTracker1 = this.x;
              int i11 = paramMotionEvent.getPointerId(0);
              localVelocityTracker1.computeCurrentVelocity(1000, this.k);
              f6 = localVelocityTracker1.getYVelocity(i11);
              f7 = localVelocityTracker1.getXVelocity(i11);
              if ((Math.abs(f6) > this.j) || (Math.abs(f7) > this.j))
                break label949;
            }
            bool4 = false;
            break label969;
            label949: bool4 = this.b.onFling(this.g, paramMotionEvent, f7, f6);
          }
          label969: MotionEvent localMotionEvent5 = this.q;
          if (localMotionEvent5 != null)
            localMotionEvent5.recycle();
          this.q = localMotionEvent4;
          VelocityTracker localVelocityTracker2 = this.x;
          if (localVelocityTracker2 != null)
          {
            localVelocityTracker2.recycle();
            this.x = null;
          }
          this.r = false;
          this.e = false;
          this.a.removeMessages(1);
          this.a.removeMessages(2);
        }
        return bool4;
      }
      else
      {
        label1178: boolean bool1;
        if (this.c != null)
        {
          boolean bool3 = this.a.hasMessages(3);
          if (bool3)
            this.a.removeMessages(3);
          MotionEvent localMotionEvent2 = this.g;
          if (localMotionEvent2 != null)
          {
            MotionEvent localMotionEvent3 = this.q;
            if ((localMotionEvent3 != null) && (bool3))
            {
              if ((this.p) && (paramMotionEvent.getEventTime() - localMotionEvent3.getEventTime() <= n))
              {
                int i9 = (int)localMotionEvent2.getX() - (int)paramMotionEvent.getX();
                int i10 = (int)localMotionEvent2.getY() - (int)paramMotionEvent.getY();
                if (i9 * i9 + i10 * i10 < this.i)
                {
                  i8 = 1;
                  break label1178;
                }
              }
              int i8 = 0;
              if (i8 != 0)
              {
                this.r = true;
                bool1 = false | this.c.onDoubleTap(this.g) | this.c.onDoubleTapEvent(paramMotionEvent);
                break label1235;
              }
            }
          }
          this.a.sendEmptyMessageDelayed(3, n);
        }
        else
        {
          bool1 = false;
        }
        label1235: this.s = f4;
        this.u = f4;
        this.t = f5;
        this.v = f5;
        MotionEvent localMotionEvent1 = this.g;
        if (localMotionEvent1 != null)
          localMotionEvent1.recycle();
        this.g = MotionEvent.obtain(paramMotionEvent);
        this.o = true;
        this.p = true;
        this.d = true;
        this.f = false;
        this.e = false;
        if (this.w)
        {
          this.a.removeMessages(2);
          this.a.sendEmptyMessageAtTime(2, this.g.getDownTime() + m + l);
        }
        this.a.sendEmptyMessageAtTime(1, this.g.getDownTime() + m);
        bool2 = bool1 | this.b.onDown(paramMotionEvent);
      }
      label1385: return bool2;
    }

    final class a extends Handler
    {
      static
      {
        CoverageLogger.Log(46323712);
      }

      a()
      {
      }

      a(Handler arg2)
      {
        super();
      }

      public final void handleMessage(Message paramMessage)
      {
        int i = paramMessage.what;
        if (i != 1)
        {
          if (i != 2)
          {
            if (i == 3)
            {
              if (c.b.this.c != null)
              {
                if (!c.b.this.d)
                {
                  c.b.this.c.onSingleTapConfirmed(c.b.this.g);
                  return;
                }
                c.b.this.e = true;
              }
              return;
            }
            StringBuilder localStringBuilder = new StringBuilder("Unknown message ");
            localStringBuilder.append(paramMessage);
            throw new RuntimeException(localStringBuilder.toString());
          }
          c.b localb = c.b.this;
          localb.a.removeMessages(3);
          localb.e = false;
          localb.f = true;
          localb.b.onLongPress(localb.g);
          return;
        }
        c.b.this.b.onShowPress(c.b.this.g);
      }
    }
  }

  static final class c
    implements c.a
  {
    private final GestureDetector a;

    static
    {
      CoverageLogger.Log(46331904);
    }

    c(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler)
    {
      this.a = new GestureDetector(paramContext, paramOnGestureListener, paramHandler);
    }

    public final void a(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener)
    {
      this.a.setOnDoubleTapListener(paramOnDoubleTapListener);
    }

    public final void a(boolean paramBoolean)
    {
      this.a.setIsLongpressEnabled(paramBoolean);
    }

    public final boolean a(MotionEvent paramMotionEvent)
    {
      return this.a.onTouchEvent(paramMotionEvent);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.c
 * JD-Core Version:    0.6.2
 */