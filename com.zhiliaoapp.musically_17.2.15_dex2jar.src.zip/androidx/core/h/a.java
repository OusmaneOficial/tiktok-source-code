package androidx.core.h;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import androidx.core.h.a.c;
import androidx.core.h.a.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class a
{
  static final View.AccessibilityDelegate b = new View.AccessibilityDelegate();
  public final View.AccessibilityDelegate c = new a(this);

  static
  {
    CoverageLogger.Log(46288896);
  }

  public static void a(View paramView, int paramInt)
  {
    b.sendAccessibilityEvent(paramView, paramInt);
  }

  public void a(View paramView, c paramc)
  {
    b.onInitializeAccessibilityNodeInfo(paramView, paramc.a);
  }

  public boolean a(View paramView, int paramInt, Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return b.performAccessibilityAction(paramView, paramInt, paramBundle);
    return false;
  }

  public boolean a(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    return b.dispatchPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }

  public boolean a(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    return b.onRequestSendAccessibilityEvent(paramViewGroup, paramView, paramAccessibilityEvent);
  }

  public void b(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    b.onPopulateAccessibilityEvent(paramView, paramAccessibilityEvent);
  }

  public void c(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    b.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
  }

  static final class a extends View.AccessibilityDelegate
  {
    private final a a;

    static
    {
      CoverageLogger.Log(46290944);
    }

    a(a parama)
    {
      this.a = parama;
    }

    public final boolean dispatchPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      return this.a.a(paramView, paramAccessibilityEvent);
    }

    public final AccessibilityNodeProvider getAccessibilityNodeProvider(View paramView)
    {
      if (Build.VERSION.SDK_INT >= 16)
      {
        AccessibilityNodeProvider localAccessibilityNodeProvider = a.b.getAccessibilityNodeProvider(paramView);
        if (localAccessibilityNodeProvider != null)
        {
          locald = new d(localAccessibilityNodeProvider);
          break label34;
        }
      }
      d locald = null;
      label34: if (locald != null)
        return (AccessibilityNodeProvider)locald.a;
      return null;
    }

    public final void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      this.a.c(paramView, paramAccessibilityEvent);
    }

    public final void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfo paramAccessibilityNodeInfo)
    {
      this.a.a(paramView, c.a(paramAccessibilityNodeInfo));
    }

    public final void onPopulateAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      this.a.b(paramView, paramAccessibilityEvent);
    }

    public final boolean onRequestSendAccessibilityEvent(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      return this.a.a(paramViewGroup, paramView, paramAccessibilityEvent);
    }

    public final boolean performAccessibilityAction(View paramView, int paramInt, Bundle paramBundle)
    {
      return this.a.a(paramView, paramInt, paramBundle);
    }

    public final void sendAccessibilityEvent(View paramView, int paramInt)
    {
      a.a(paramView, paramInt);
    }

    public final void sendAccessibilityEventUnchecked(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      a.b.sendAccessibilityEventUnchecked(paramView, paramAccessibilityEvent);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.a
 * JD-Core Version:    0.6.2
 */