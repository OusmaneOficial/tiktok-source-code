package androidx.core.h;

import android.view.VelocityTracker;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class s
{
  static
  {
    CoverageLogger.Log(46364672);
  }

  public static float a(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return paramVelocityTracker.getXVelocity(paramInt);
  }

  public static float b(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return paramVelocityTracker.getYVelocity(paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.s
 * JD-Core Version:    0.6.2
 */