package androidx.core.h;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface y
{
  static
  {
    CoverageLogger.Log(46395392);
  }

  public abstract void a(View paramView);

  public abstract void b(View paramView);

  public abstract void c(View paramView);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.y
 * JD-Core Version:    0.6.2
 */