package androidx.core.h.b;

import android.graphics.Path;
import android.graphics.PathMeasure;
import android.view.animation.Interpolator;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
  implements Interpolator
{
  private final float[] a;
  private final float[] b;

  static
  {
    CoverageLogger.Log(46422016);
  }

  public a(float paramFloat1, float paramFloat2)
  {
    this(localPath);
  }

  a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    this(localPath);
  }

  private a(Path paramPath)
  {
    PathMeasure localPathMeasure = new PathMeasure(paramPath, false);
    float f = localPathMeasure.getLength();
    int i = 1 + (int)(f / 0.002F);
    this.a = new float[i];
    this.b = new float[i];
    float[] arrayOfFloat = new float[2];
    for (int j = 0; j < i; j++)
    {
      localPathMeasure.getPosTan(f * j / (i - 1), arrayOfFloat, null);
      this.a[j] = arrayOfFloat[0];
      this.b[j] = arrayOfFloat[1];
    }
  }

  public final float getInterpolation(float paramFloat)
  {
    if (paramFloat <= 0.0F)
      return 0.0F;
    if (paramFloat >= 1.0F)
      return 1.0F;
    int i = 0;
    int j = this.a.length - 1;
    while (j - i > 1)
    {
      int k = (i + j) / 2;
      if (paramFloat < this.a[k])
        j = k;
      else
        i = k;
    }
    float[] arrayOfFloat1 = this.a;
    float f1 = arrayOfFloat1[j] - arrayOfFloat1[i];
    if (f1 == 0.0F)
      return this.b[i];
    float f2 = (paramFloat - arrayOfFloat1[i]) / f1;
    float[] arrayOfFloat2 = this.b;
    float f3 = arrayOfFloat2[i];
    return f3 + f2 * (arrayOfFloat2[j] - f3);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.b.a
 * JD-Core Version:    0.6.2
 */