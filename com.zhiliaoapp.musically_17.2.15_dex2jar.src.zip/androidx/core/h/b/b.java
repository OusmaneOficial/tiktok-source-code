package androidx.core.h.b;

import android.os.Build.VERSION;
import android.view.animation.Interpolator;
import android.view.animation.PathInterpolator;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b
{
  static
  {
    CoverageLogger.Log(46426112);
  }

  public static Interpolator a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return new PathInterpolator(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    return new a(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.b.b
 * JD-Core Version:    0.6.2
 */