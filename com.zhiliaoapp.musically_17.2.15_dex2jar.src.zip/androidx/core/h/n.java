package androidx.core.h;

import android.view.View;
import android.view.ViewGroup;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class n
{
  public int a;
  private final ViewGroup b;

  static
  {
    CoverageLogger.Log(46245888);
  }

  public n(ViewGroup paramViewGroup)
  {
    this.b = paramViewGroup;
  }

  public final void a(View paramView)
  {
    a(paramView, 0);
  }

  public final void a(View paramView, int paramInt)
  {
    this.a = 0;
  }

  public final void a(View paramView1, View paramView2, int paramInt)
  {
    a(paramView1, paramView2, paramInt, 0);
  }

  public final void a(View paramView1, View paramView2, int paramInt1, int paramInt2)
  {
    this.a = paramInt1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.n
 * JD-Core Version:    0.6.2
 */