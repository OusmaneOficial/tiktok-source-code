package androidx.core.h;

import android.os.Build.VERSION;
import android.view.WindowInsets;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class ab
{
  public final Object a;

  static
  {
    CoverageLogger.Log(46405632);
  }

  public ab(ab paramab)
  {
    if (Build.VERSION.SDK_INT >= 20)
    {
      WindowInsets localWindowInsets;
      if (paramab == null)
        localWindowInsets = null;
      else
        localWindowInsets = new WindowInsets((WindowInsets)paramab.a);
      this.a = localWindowInsets;
      return;
    }
    this.a = null;
  }

  public ab(Object paramObject)
  {
    this.a = paramObject;
  }

  static ab a(Object paramObject)
  {
    if (paramObject == null)
      return null;
    return new ab(paramObject);
  }

  static Object a(ab paramab)
  {
    if (paramab == null)
      return null;
    return paramab.a;
  }

  public final int a()
  {
    if (Build.VERSION.SDK_INT >= 20)
      return ((WindowInsets)this.a).getSystemWindowInsetLeft();
    return 0;
  }

  public final ab a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (Build.VERSION.SDK_INT >= 20)
      return new ab(((WindowInsets)this.a).replaceSystemWindowInsets(paramInt1, paramInt2, paramInt3, paramInt4));
    return null;
  }

  public final int b()
  {
    if (Build.VERSION.SDK_INT >= 20)
      return ((WindowInsets)this.a).getSystemWindowInsetTop();
    return 0;
  }

  public final int c()
  {
    if (Build.VERSION.SDK_INT >= 20)
      return ((WindowInsets)this.a).getSystemWindowInsetRight();
    return 0;
  }

  public final int d()
  {
    if (Build.VERSION.SDK_INT >= 20)
      return ((WindowInsets)this.a).getSystemWindowInsetBottom();
    return 0;
  }

  public final boolean e()
  {
    if (Build.VERSION.SDK_INT >= 21)
      return ((WindowInsets)this.a).isConsumed();
    return false;
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass())
        return false;
      ab localab = (ab)paramObject;
      Object localObject1 = this.a;
      Object localObject2 = localab.a;
      if (localObject1 == null)
        return localObject2 == null;
      return localObject1.equals(localObject2);
    }
    return false;
  }

  public final int hashCode()
  {
    Object localObject = this.a;
    if (localObject == null)
      return 0;
    return localObject.hashCode();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.ab
 * JD-Core Version:    0.6.2
 */