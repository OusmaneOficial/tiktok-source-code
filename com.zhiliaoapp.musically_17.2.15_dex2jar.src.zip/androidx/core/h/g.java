package androidx.core.h;

import android.os.Build.VERSION;
import android.view.ViewGroup.MarginLayoutParams;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class g
{
  static
  {
    CoverageLogger.Log(46344192);
  }

  public static int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return paramMarginLayoutParams.getMarginStart();
    return paramMarginLayoutParams.leftMargin;
  }

  public static void a(ViewGroup.MarginLayoutParams paramMarginLayoutParams, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      paramMarginLayoutParams.setMarginEnd(paramInt);
      return;
    }
    paramMarginLayoutParams.rightMargin = paramInt;
  }

  public static int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return paramMarginLayoutParams.getMarginEnd();
    return paramMarginLayoutParams.rightMargin;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.g
 * JD-Core Version:    0.6.2
 */