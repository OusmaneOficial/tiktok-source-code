package androidx.core.h;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class b
{
  public final Context e;
  public a f;
  public b g;

  static
  {
    CoverageLogger.Log(46282752);
  }

  public b(Context paramContext)
  {
    this.e = paramContext;
  }

  public abstract View a();

  public View a(MenuItem paramMenuItem)
  {
    return a();
  }

  public void a(SubMenu paramSubMenu)
  {
  }

  public void a(b paramb)
  {
    this.g = paramb;
  }

  public final void a(boolean paramBoolean)
  {
    a locala = this.f;
    if (locala != null)
      locala.c(paramBoolean);
  }

  public boolean b()
  {
    return false;
  }

  public boolean c()
  {
    return false;
  }

  public boolean d()
  {
    return false;
  }

  public boolean e()
  {
    return true;
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46321664);
    }

    public abstract void c(boolean paramBoolean);
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(46284800);
    }

    public abstract void a(boolean paramBoolean);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.h.b
 * JD-Core Version:    0.6.2
 */