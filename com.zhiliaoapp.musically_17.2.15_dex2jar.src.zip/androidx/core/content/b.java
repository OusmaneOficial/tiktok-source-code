package androidx.core.content;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Process;
import android.util.TypedValue;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.File;

public class b
{
  private static final Object a = new Object();
  private static TypedValue b;

  static
  {
    CoverageLogger.Log(46503936);
  }

  public static int a(Context paramContext, String paramString)
  {
    if (paramString != null)
      return paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
    throw new IllegalArgumentException("permission is null");
  }

  public static Drawable a(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramContext.getDrawable(paramInt);
    if (Build.VERSION.SDK_INT >= 16)
      return paramContext.getResources().getDrawable(paramInt);
    synchronized (a)
    {
      if (b == null)
        b = new TypedValue();
      paramContext.getResources().getValue(paramInt, b, true);
      int i = b.resourceId;
      return paramContext.getResources().getDrawable(i);
    }
  }

  public static File a(Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramContext.getNoBackupFilesDir();
    return a(new File(paramContext.getApplicationInfo().dataDir, "no_backup"));
  }

  private static File a(File paramFile)
  {
    try
    {
      if ((!paramFile.exists()) && (!paramFile.mkdirs()))
      {
        boolean bool = paramFile.exists();
        if (bool)
          return paramFile;
        return null;
      }
      return paramFile;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public static void a(Context paramContext, Intent paramIntent, Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      paramContext.startActivity(paramIntent, paramBundle);
      return;
    }
    paramContext.startActivity(paramIntent);
  }

  public static boolean a(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle)
  {
    if (Build.VERSION.SDK_INT >= 16)
      paramContext.startActivities(paramArrayOfIntent, paramBundle);
    else
      paramContext.startActivities(paramArrayOfIntent);
    return true;
  }

  public static int b(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      return paramContext.getColor(paramInt);
    return paramContext.getResources().getColor(paramInt);
  }

  public static File b(Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramContext.getCodeCacheDir();
    return a(new File(paramContext.getApplicationInfo().dataDir, "code_cache"));
  }

  public static boolean c(Context paramContext)
  {
    if (Build.VERSION.SDK_INT >= 24)
      return paramContext.isDeviceProtectedStorage();
    return false;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.b
 * JD-Core Version:    0.6.2
 */