package androidx.core.content;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.xmlpull.v1.XmlPullParserException;

public class FileProvider extends ContentProvider
{
  private static final String[] COLUMNS = { "_display_name", "_size" };
  private static final File DEVICE_ROOT = new File("/");
  private static HashMap<String, a> sCache = new HashMap();
  public Object mLazyProviderInfo;
  private a mStrategy;

  static
  {
    CoverageLogger.Log(46694400);
  }

  private static File buildPath(File paramFile, String[] paramArrayOfString)
  {
    int i = paramArrayOfString.length;
    for (int j = 0; j < i; j++)
    {
      String str = paramArrayOfString[j];
      if (str != null)
        paramFile = new File(paramFile, str);
    }
    return paramFile;
  }

  private static Object[] copyOf(Object[] paramArrayOfObject, int paramInt)
  {
    Object[] arrayOfObject = new Object[paramInt];
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject, 0, paramInt);
    return arrayOfObject;
  }

  private static String[] copyOf(String[] paramArrayOfString, int paramInt)
  {
    String[] arrayOfString = new String[paramInt];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramInt);
    return arrayOfString;
  }

  private static a getPathStrategy(Context paramContext, String paramString)
  {
    synchronized (sCache)
    {
      a locala = (a)sCache.get(paramString);
      if (locala == null)
        try
        {
          locala = parsePathStrategy(paramContext, paramString);
          sCache.put(paramString, locala);
        }
        catch (XmlPullParserException localXmlPullParserException)
        {
          throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", localXmlPullParserException);
        }
        catch (IOException localIOException)
        {
          throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", localIOException);
        }
      return locala;
    }
  }

  public static Uri getUriForFile(Context paramContext, String paramString, File paramFile)
  {
    return getPathStrategy(paramContext, paramString).a(paramFile);
  }

  private static int modeToMode(String paramString)
  {
    if ("r".equals(paramString))
      return 268435456;
    if ((!"w".equals(paramString)) && (!"wt".equals(paramString)))
    {
      if ("wa".equals(paramString))
        return 704643072;
      if ("rw".equals(paramString))
        return 939524096;
      if ("rwt".equals(paramString))
        return 1006632960;
      StringBuilder localStringBuilder = new StringBuilder("Invalid mode: ");
      localStringBuilder.append(paramString);
      throw new IllegalArgumentException(localStringBuilder.toString());
    }
    return 738197504;
  }

  private static a parsePathStrategy(Context paramContext, String paramString)
    throws IOException, XmlPullParserException
  {
    b localb = new b(paramString);
    XmlResourceParser localXmlResourceParser = paramContext.getPackageManager().resolveContentProvider(paramString, 128).loadXmlMetaData(paramContext.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
    if (localXmlResourceParser != null)
    {
      while (true)
      {
        int i = localXmlResourceParser.next();
        if (i == 1)
          break label440;
        if (i == 2)
        {
          String str1 = localXmlResourceParser.getName();
          String str2 = localXmlResourceParser.getAttributeValue(null, "name");
          String str3 = localXmlResourceParser.getAttributeValue(null, "path");
          File localFile1;
          if ("root-path".equals(str1))
          {
            localFile1 = DEVICE_ROOT;
          }
          else if ("files-path".equals(str1))
          {
            localFile1 = paramContext.getFilesDir();
          }
          else if ("cache-path".equals(str1))
          {
            localFile1 = paramContext.getCacheDir();
          }
          else if ("external-path".equals(str1))
          {
            localFile1 = Environment.getExternalStorageDirectory();
          }
          else if ("external-files-path".equals(str1))
          {
            File[] arrayOfFile3;
            if (Build.VERSION.SDK_INT >= 19)
            {
              arrayOfFile3 = paramContext.getExternalFilesDirs(null);
            }
            else
            {
              arrayOfFile3 = new File[1];
              arrayOfFile3[0] = paramContext.getExternalFilesDir(null);
            }
            int n = arrayOfFile3.length;
            localFile1 = null;
            if (n > 0)
              localFile1 = arrayOfFile3[0];
          }
          else if ("external-cache-path".equals(str1))
          {
            File[] arrayOfFile2;
            if (Build.VERSION.SDK_INT >= 19)
            {
              arrayOfFile2 = paramContext.getExternalCacheDirs();
            }
            else
            {
              arrayOfFile2 = new File[1];
              arrayOfFile2[0] = paramContext.getExternalCacheDir();
            }
            int m = arrayOfFile2.length;
            localFile1 = null;
            if (m > 0)
              localFile1 = arrayOfFile2[0];
          }
          else
          {
            int j = Build.VERSION.SDK_INT;
            localFile1 = null;
            if (j >= 21)
            {
              boolean bool = "external-media-path".equals(str1);
              localFile1 = null;
              if (bool)
              {
                File[] arrayOfFile1 = paramContext.getExternalMediaDirs();
                int k = arrayOfFile1.length;
                localFile1 = null;
                if (k > 0)
                  localFile1 = arrayOfFile1[0];
              }
            }
          }
          if (localFile1 != null)
          {
            File localFile2 = buildPath(localFile1, new String[] { str3 });
            if (!TextUtils.isEmpty(str2))
              try
              {
                File localFile3 = localFile2.getCanonicalFile();
                localb.a.put(str2, localFile3);
              }
              catch (IOException localIOException)
              {
                StringBuilder localStringBuilder = new StringBuilder("Failed to resolve canonical path for ");
                localStringBuilder.append(localFile2);
                throw new IllegalArgumentException(localStringBuilder.toString(), localIOException);
              }
          }
        }
      }
      throw new IllegalArgumentException("Name must not be empty");
      label440: return localb;
    }
    IllegalArgumentException localIllegalArgumentException = new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
    while (true)
      throw localIllegalArgumentException;
  }

  public void FileProvider__attachInfo$___twin___(Context paramContext, ProviderInfo paramProviderInfo)
  {
    super.attachInfo(paramContext, paramProviderInfo);
    if (!paramProviderInfo.exported)
    {
      if (paramProviderInfo.grantUriPermissions)
      {
        this.mStrategy = getPathStrategy(paramContext, paramProviderInfo.authority);
        return;
      }
      throw new SecurityException("Provider must grant uri permissions");
    }
    throw new SecurityException("Provider must not be exported");
  }

  public int FileProvider__delete$___twin___(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    if (this.mStrategy.a(paramUri).delete())
      return 1;
    return 0;
  }

  public String FileProvider__getType$___twin___(Uri paramUri)
  {
    File localFile = this.mStrategy.a(paramUri);
    int i = localFile.getName().lastIndexOf('.');
    if (i >= 0)
    {
      String str1 = localFile.getName().substring(i + 1);
      String str2 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str1);
      if (str2 != null)
        return str2;
    }
    return "application/octet-stream";
  }

  public ParcelFileDescriptor FileProvider__openFile$___twin___(Uri paramUri, String paramString)
    throws FileNotFoundException
  {
    return ParcelFileDescriptor.open(this.mStrategy.a(paramUri), modeToMode(paramString));
  }

  public Cursor FileProvider__query$___twin___(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    File localFile = this.mStrategy.a(paramUri);
    if (paramArrayOfString1 == null)
      paramArrayOfString1 = COLUMNS;
    String[] arrayOfString1 = new String[paramArrayOfString1.length];
    Object[] arrayOfObject1 = new Object[paramArrayOfString1.length];
    int i = paramArrayOfString1.length;
    int j = 0;
    int k = 0;
    while (j < i)
    {
      String str = paramArrayOfString1[j];
      int m;
      if ("_display_name".equals(str))
      {
        arrayOfString1[k] = "_display_name";
        m = k + 1;
        arrayOfObject1[k] = localFile.getName();
      }
      while (true)
      {
        k = m;
        break;
        if (!"_size".equals(str))
          break;
        arrayOfString1[k] = "_size";
        m = k + 1;
        arrayOfObject1[k] = Long.valueOf(localFile.length());
      }
      j++;
    }
    String[] arrayOfString2 = copyOf(arrayOfString1, k);
    Object[] arrayOfObject2 = copyOf(arrayOfObject1, k);
    MatrixCursor localMatrixCursor = new MatrixCursor(arrayOfString2, 1);
    localMatrixCursor.addRow(arrayOfObject2);
    return localMatrixCursor;
  }

  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo)
  {
    if (((FileProvider)this).getContext() == null)
    {
      if (!paramProviderInfo.exported)
      {
        if (paramProviderInfo.grantUriPermissions)
        {
          this.mLazyProviderInfo = paramProviderInfo;
          paramProviderInfo.grantUriPermissions = false;
          try
          {
            FileProvider__attachInfo$___twin___(paramContext, paramProviderInfo);
          }
          catch (SecurityException localSecurityException)
          {
          }
          paramProviderInfo.grantUriPermissions = true;
          return;
        }
        throw new SecurityException("Provider must grant uri permissions");
      }
      throw new SecurityException("Provider must not be exported");
    }
    FileProvider__attachInfo$___twin___(paramContext, paramProviderInfo);
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    return c.a(this, paramUri, paramString, paramArrayOfString);
  }

  public String getType(Uri paramUri)
  {
    return c.a(this, paramUri);
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    throw new UnsupportedOperationException("No external inserts");
  }

  public boolean onCreate()
  {
    return true;
  }

  public ParcelFileDescriptor openFile(Uri paramUri, String paramString)
    throws FileNotFoundException
  {
    return c.a(this, paramUri, paramString);
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    return c.a(this, paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2);
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    throw new UnsupportedOperationException("No external updates");
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46696448);
    }

    public abstract Uri a(File paramFile);

    public abstract File a(Uri paramUri);
  }

  static final class b
    implements FileProvider.a
  {
    final HashMap<String, File> a = new HashMap();
    private final String b;

    static
    {
      CoverageLogger.Log(46501888);
    }

    b(String paramString)
    {
      this.b = paramString;
    }

    public final Uri a(File paramFile)
    {
      StringBuilder localStringBuilder1;
      IllegalArgumentException localIllegalArgumentException;
      try
      {
        String str1 = paramFile.getCanonicalPath();
        Object localObject = null;
        Iterator localIterator = this.a.entrySet().iterator();
        while (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          String str5 = ((File)localEntry.getValue()).getPath();
          if ((str1.startsWith(str5)) && ((localObject == null) || (str5.length() > ((File)localObject.getValue()).getPath().length())))
            localObject = localEntry;
        }
        if (localObject != null)
        {
          String str2 = ((File)localObject.getValue()).getPath();
          String str3;
          if (str2.endsWith("/"))
            str3 = str1.substring(str2.length());
          else
            str3 = str1.substring(1 + str2.length());
          StringBuilder localStringBuilder3 = new StringBuilder();
          localStringBuilder3.append(Uri.encode((String)localObject.getKey()));
          localStringBuilder3.append('/');
          localStringBuilder3.append(Uri.encode(str3, "/"));
          String str4 = localStringBuilder3.toString();
          return new Uri.Builder().scheme("content").authority(this.b).encodedPath(str4).build();
        }
        StringBuilder localStringBuilder2 = new StringBuilder("Failed to find configured root that contains ");
        localStringBuilder2.append(str1);
        throw new IllegalArgumentException(localStringBuilder2.toString());
      }
      catch (IOException localIOException)
      {
        localStringBuilder1 = new StringBuilder("Failed to resolve canonical path for ");
        localStringBuilder1.append(paramFile);
        localIllegalArgumentException = new IllegalArgumentException(localStringBuilder1.toString());
        tmpTernaryOp = localIOException;
      }
      while (true)
        throw localIllegalArgumentException;
    }

    // ERROR //
    public final File a(Uri paramUri)
    {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual 147	android/net/Uri:getEncodedPath	()Ljava/lang/String;
      //   4: astore_2
      //   5: aload_2
      //   6: bipush 47
      //   8: iconst_1
      //   9: invokevirtual 151	java/lang/String:indexOf	(II)I
      //   12: istore_3
      //   13: aload_2
      //   14: iconst_1
      //   15: iload_3
      //   16: invokevirtual 154	java/lang/String:substring	(II)Ljava/lang/String;
      //   19: invokestatic 157	android/net/Uri:decode	(Ljava/lang/String;)Ljava/lang/String;
      //   22: astore 4
      //   24: aload_2
      //   25: iload_3
      //   26: iconst_1
      //   27: iadd
      //   28: invokevirtual 87	java/lang/String:substring	(I)Ljava/lang/String;
      //   31: invokestatic 157	android/net/Uri:decode	(Ljava/lang/String;)Ljava/lang/String;
      //   34: astore 5
      //   36: aload_0
      //   37: getfield 29	androidx/core/content/FileProvider$b:a	Ljava/util/HashMap;
      //   40: aload 4
      //   42: invokevirtual 161	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
      //   45: checkcast 36	java/io/File
      //   48: astore 6
      //   50: aload 6
      //   52: ifnull +84 -> 136
      //   55: new 36	java/io/File
      //   58: dup
      //   59: aload 6
      //   61: aload 5
      //   63: invokespecial 164	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
      //   66: astore 7
      //   68: aload 7
      //   70: invokevirtual 168	java/io/File:getCanonicalFile	()Ljava/io/File;
      //   73: astore 10
      //   75: aload 10
      //   77: invokevirtual 68	java/io/File:getPath	()Ljava/lang/String;
      //   80: aload 6
      //   82: invokevirtual 68	java/io/File:getPath	()Ljava/lang/String;
      //   85: invokevirtual 74	java/lang/String:startsWith	(Ljava/lang/String;)Z
      //   88: ifeq +6 -> 94
      //   91: aload 10
      //   93: areturn
      //   94: new 170	java/lang/SecurityException
      //   97: dup
      //   98: ldc 172
      //   100: invokespecial 173	java/lang/SecurityException:<init>	(Ljava/lang/String;)V
      //   103: athrow
      //   104: new 89	java/lang/StringBuilder
      //   107: dup
      //   108: ldc 140
      //   110: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   113: astore 8
      //   115: aload 8
      //   117: aload 7
      //   119: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   122: pop
      //   123: new 137	java/lang/IllegalArgumentException
      //   126: dup
      //   127: aload 8
      //   129: invokevirtual 112	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   132: invokespecial 138	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
      //   135: athrow
      //   136: new 89	java/lang/StringBuilder
      //   139: dup
      //   140: ldc 175
      //   142: invokespecial 135	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   145: astore 11
      //   147: aload 11
      //   149: aload_1
      //   150: invokevirtual 143	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   153: pop
      //   154: new 137	java/lang/IllegalArgumentException
      //   157: dup
      //   158: aload 11
      //   160: invokevirtual 112	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   163: invokespecial 138	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
      //   166: athrow
      //
      // Exception table:
      //   from	to	target	type
      //   68	75	104	java/io/IOException
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.FileProvider
 * JD-Core Version:    0.6.2
 */