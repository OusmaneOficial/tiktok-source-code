package androidx.core.content;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.CancellationSignal;
import android.os.OperationCanceledException;
import androidx.core.d.c;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  static
  {
    CoverageLogger.Log(46508032);
  }

  public static Cursor a(ContentResolver paramContentResolver, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, androidx.core.d.a parama)
  {
    if ((Build.VERSION.SDK_INT < 16) || (parama != null));
    while (true)
    {
      try
      {
        localObject1 = parama.c();
        Cursor localCursor = paramContentResolver.query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2, (CancellationSignal)localObject1);
        return localCursor;
        Object localObject2;
        if ((localObject2 instanceof OperationCanceledException))
          throw new c();
        throw localObject2;
        if ((parama != null) && (parama.a()))
          throw new c();
        return paramContentResolver.query(paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2);
      }
      catch (Exception localException)
      {
        continue;
      }
      Object localObject1 = null;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.a
 * JD-Core Version:    0.6.2
 */