package androidx.core.content.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.StateSet;
import android.util.Xml;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.IOException;
import java.lang.reflect.Array;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class a
{
  static
  {
    CoverageLogger.Log(46698496);
  }

  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, Resources.Theme paramTheme)
    throws XmlPullParserException, IOException
  {
    AttributeSet localAttributeSet = Xml.asAttributeSet(paramXmlPullParser);
    int i;
    do
      i = paramXmlPullParser.next();
    while ((i != 2) && (i != 1));
    if (i == 2)
      return a(paramResources, paramXmlPullParser, localAttributeSet, paramTheme);
    XmlPullParserException localXmlPullParserException = new XmlPullParserException("No start tag found");
    while (true)
      throw localXmlPullParserException;
  }

  public static ColorStateList a(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    throws XmlPullParserException, IOException
  {
    String str = paramXmlPullParser.getName();
    if (str.equals("selector"))
      return b(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(paramXmlPullParser.getPositionDescription());
    localStringBuilder.append(": invalid color state list tag ");
    localStringBuilder.append(str);
    throw new XmlPullParserException(localStringBuilder.toString());
  }

  private static ColorStateList b(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    throws XmlPullParserException, IOException
  {
    int i = paramXmlPullParser.getDepth();
    int j = 1;
    int k = i + j;
    Object localObject1 = new int[20][];
    Object localObject2 = new int[20];
    int m = 0;
    while (true)
    {
      int n = paramXmlPullParser.next();
      if (n == j)
        break;
      int i1 = paramXmlPullParser.getDepth();
      if ((i1 < k) && (n == 3))
        break;
      if ((n == 2) && (i1 <= k) && (paramXmlPullParser.getName().equals("item")))
      {
        int[] arrayOfInt2 = { 16843173, 16843551, 2130968640 };
        TypedArray localTypedArray;
        if (paramTheme == null)
          localTypedArray = paramResources.obtainAttributes(paramAttributeSet, arrayOfInt2);
        else
          localTypedArray = paramTheme.obtainStyledAttributes(paramAttributeSet, arrayOfInt2, 0, 0);
        int i2 = localTypedArray.getColor(0, -65281);
        boolean bool = localTypedArray.hasValue(j);
        float f = 1.0F;
        if (bool)
          f = localTypedArray.getFloat(j, f);
        else if (localTypedArray.hasValue(2))
          f = localTypedArray.getFloat(2, f);
        localTypedArray.recycle();
        int i3 = paramAttributeSet.getAttributeCount();
        int[] arrayOfInt3 = new int[i3];
        int i4 = 0;
        int i5 = 0;
        while (i4 < i3)
        {
          int i9 = paramAttributeSet.getAttributeNameResource(i4);
          if ((i9 != 16843173) && (i9 != 16843551) && (i9 != 2130968640))
          {
            int i10 = i5 + 1;
            if (!paramAttributeSet.getAttributeBooleanValue(i4, false))
              i9 = -i9;
            arrayOfInt3[i5] = i9;
            i5 = i10;
          }
          i4++;
        }
        int[] arrayOfInt4 = StateSet.trimStateSet(arrayOfInt3, i5);
        int i6 = Math.round(f * Color.alpha(i2));
        int i7 = i2 & 0xFFFFFF | i6 << 24;
        if ((!e.a) && (m > localObject2.length))
          throw new AssertionError();
        int i8 = m + 1;
        if (i8 > localObject2.length)
        {
          int[] arrayOfInt5 = new int[e.a(m)];
          System.arraycopy(localObject2, 0, arrayOfInt5, 0, m);
          localObject2 = arrayOfInt5;
        }
        localObject2[m] = i7;
        if ((!e.a) && (m > localObject1.length))
          throw new AssertionError();
        if (i8 > localObject1.length)
        {
          Object[] arrayOfObject = (Object[])Array.newInstance(localObject1.getClass().getComponentType(), e.a(m));
          System.arraycopy(localObject1, 0, arrayOfObject, 0, m);
          localObject1 = arrayOfObject;
        }
        localObject1[m] = arrayOfInt4;
        localObject1 = (int[][])localObject1;
        m = i8;
      }
      j = 1;
    }
    int[] arrayOfInt1 = new int[m];
    int[][] arrayOfInt = new int[m][];
    System.arraycopy(localObject2, 0, arrayOfInt1, 0, m);
    System.arraycopy(localObject1, 0, arrayOfInt, 0, m);
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.a.a
 * JD-Core Version:    0.6.2
 */