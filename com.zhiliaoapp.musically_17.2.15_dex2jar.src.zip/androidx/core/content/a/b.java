package androidx.core.content.a;

import android.content.res.ColorStateList;
import android.graphics.Shader;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b
{
  public final Shader a;
  public int b;
  private final ColorStateList c;

  static
  {
    CoverageLogger.Log(46704640);
  }

  private b(Shader paramShader, ColorStateList paramColorStateList, int paramInt)
  {
    this.a = paramShader;
    this.c = paramColorStateList;
    this.b = paramInt;
  }

  static b a(int paramInt)
  {
    return new b(null, null, paramInt);
  }

  // ERROR //
  public static b a(android.content.res.Resources paramResources, int paramInt, android.content.res.Resources.Theme paramTheme)
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: invokevirtual 41	android/content/res/Resources:getXml	(I)Landroid/content/res/XmlResourceParser;
    //   5: astore_3
    //   6: aload_3
    //   7: invokestatic 47	android/util/Xml:asAttributeSet	(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    //   10: astore 4
    //   12: aload_3
    //   13: invokeinterface 53 1 0
    //   18: istore 5
    //   20: iload 5
    //   22: iconst_2
    //   23: if_icmpeq +9 -> 32
    //   26: iload 5
    //   28: iconst_1
    //   29: if_icmpne -17 -> 12
    //   32: iload 5
    //   34: iconst_2
    //   35: if_icmpne +690 -> 725
    //   38: aload_3
    //   39: invokeinterface 57 1 0
    //   44: astore 6
    //   46: iconst_m1
    //   47: istore 7
    //   49: aload 6
    //   51: invokevirtual 62	java/lang/String:hashCode	()I
    //   54: istore 8
    //   56: iload 8
    //   58: ldc 63
    //   60: if_icmpeq +29 -> 89
    //   63: iload 8
    //   65: ldc 64
    //   67: if_icmpeq +6 -> 73
    //   70: goto +32 -> 102
    //   73: aload 6
    //   75: ldc 66
    //   77: invokevirtual 70	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   80: ifeq +22 -> 102
    //   83: iconst_0
    //   84: istore 7
    //   86: goto +16 -> 102
    //   89: aload 6
    //   91: ldc 72
    //   93: invokevirtual 70	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   96: ifeq +6 -> 102
    //   99: iconst_1
    //   100: istore 7
    //   102: iload 7
    //   104: ifeq +585 -> 689
    //   107: iload 7
    //   109: iconst_1
    //   110: if_icmpne +529 -> 639
    //   113: aload_3
    //   114: invokeinterface 57 1 0
    //   119: astore 12
    //   121: aload 12
    //   123: ldc 72
    //   125: invokevirtual 70	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   128: ifeq +461 -> 589
    //   131: aload_0
    //   132: aload_2
    //   133: aload 4
    //   135: bipush 12
    //   137: newarray int
    //   139: dup
    //   140: iconst_0
    //   141: ldc 73
    //   143: iastore
    //   144: dup
    //   145: iconst_1
    //   146: ldc 74
    //   148: iastore
    //   149: dup
    //   150: iconst_2
    //   151: ldc 75
    //   153: iastore
    //   154: dup
    //   155: iconst_3
    //   156: ldc 76
    //   158: iastore
    //   159: dup
    //   160: iconst_4
    //   161: ldc 77
    //   163: iastore
    //   164: dup
    //   165: iconst_5
    //   166: ldc 78
    //   168: iastore
    //   169: dup
    //   170: bipush 6
    //   172: ldc 79
    //   174: iastore
    //   175: dup
    //   176: bipush 7
    //   178: ldc 80
    //   180: iastore
    //   181: dup
    //   182: bipush 8
    //   184: ldc 81
    //   186: iastore
    //   187: dup
    //   188: bipush 9
    //   190: ldc 82
    //   192: iastore
    //   193: dup
    //   194: bipush 10
    //   196: ldc 83
    //   198: iastore
    //   199: dup
    //   200: bipush 11
    //   202: ldc 84
    //   204: iastore
    //   205: invokestatic 89	androidx/core/content/a/g:a	(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   208: astore 17
    //   210: aload 17
    //   212: aload_3
    //   213: ldc 91
    //   215: bipush 8
    //   217: fconst_0
    //   218: invokestatic 94	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F
    //   221: fstore 18
    //   223: aload 17
    //   225: aload_3
    //   226: ldc 96
    //   228: bipush 9
    //   230: fconst_0
    //   231: invokestatic 94	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F
    //   234: fstore 19
    //   236: aload 17
    //   238: aload_3
    //   239: ldc 98
    //   241: bipush 10
    //   243: fconst_0
    //   244: invokestatic 94	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F
    //   247: fstore 20
    //   249: aload 17
    //   251: aload_3
    //   252: ldc 100
    //   254: bipush 11
    //   256: fconst_0
    //   257: invokestatic 94	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F
    //   260: fstore 21
    //   262: aload 17
    //   264: aload_3
    //   265: ldc 102
    //   267: iconst_3
    //   268: fconst_0
    //   269: invokestatic 94	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F
    //   272: fstore 22
    //   274: aload 17
    //   276: aload_3
    //   277: ldc 104
    //   279: iconst_4
    //   280: fconst_0
    //   281: invokestatic 94	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F
    //   284: fstore 23
    //   286: aload 17
    //   288: aload_3
    //   289: ldc 106
    //   291: iconst_2
    //   292: iconst_0
    //   293: invokestatic 109	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I
    //   296: istore 24
    //   298: aload 17
    //   300: aload_3
    //   301: ldc 111
    //   303: iconst_0
    //   304: iconst_0
    //   305: invokestatic 113	androidx/core/content/a/g:b	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I
    //   308: istore 25
    //   310: aload_3
    //   311: ldc 115
    //   313: invokestatic 118	androidx/core/content/a/g:a	(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z
    //   316: istore 26
    //   318: aload 17
    //   320: aload_3
    //   321: ldc 115
    //   323: bipush 7
    //   325: iconst_0
    //   326: invokestatic 113	androidx/core/content/a/g:b	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I
    //   329: istore 27
    //   331: aload 17
    //   333: aload_3
    //   334: ldc 120
    //   336: iconst_1
    //   337: iconst_0
    //   338: invokestatic 113	androidx/core/content/a/g:b	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I
    //   341: istore 28
    //   343: aload 17
    //   345: aload_3
    //   346: ldc 122
    //   348: bipush 6
    //   350: iconst_0
    //   351: invokestatic 109	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I
    //   354: istore 29
    //   356: aload 17
    //   358: aload_3
    //   359: ldc 124
    //   361: iconst_5
    //   362: fconst_0
    //   363: invokestatic 94	androidx/core/content/a/g:a	(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F
    //   366: fstore 30
    //   368: aload 17
    //   370: invokevirtual 129	android/content/res/TypedArray:recycle	()V
    //   373: aload_0
    //   374: aload_3
    //   375: aload 4
    //   377: aload_2
    //   378: invokestatic 134	androidx/core/content/a/d:a	(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/core/content/a/d$a;
    //   381: astore 31
    //   383: aload 31
    //   385: ifnull +6 -> 391
    //   388: goto +39 -> 427
    //   391: iload 26
    //   393: ifeq +21 -> 414
    //   396: new 136	androidx/core/content/a/d$a
    //   399: dup
    //   400: iload 25
    //   402: iload 27
    //   404: iload 28
    //   406: invokespecial 139	androidx/core/content/a/d$a:<init>	(III)V
    //   409: astore 31
    //   411: goto +16 -> 427
    //   414: new 136	androidx/core/content/a/d$a
    //   417: dup
    //   418: iload 25
    //   420: iload 28
    //   422: invokespecial 142	androidx/core/content/a/d$a:<init>	(II)V
    //   425: astore 31
    //   427: iload 24
    //   429: iconst_1
    //   430: if_icmpeq +82 -> 512
    //   433: iload 24
    //   435: iconst_2
    //   436: if_icmpeq +50 -> 486
    //   439: aload 31
    //   441: getfield 145	androidx/core/content/a/d$a:a	[I
    //   444: astore 37
    //   446: aload 31
    //   448: getfield 148	androidx/core/content/a/d$a:b	[F
    //   451: astore 38
    //   453: iload 29
    //   455: invokestatic 151	androidx/core/content/a/d:a	(I)Landroid/graphics/Shader$TileMode;
    //   458: astore 39
    //   460: new 153	android/graphics/LinearGradient
    //   463: dup
    //   464: fload 18
    //   466: fload 19
    //   468: fload 20
    //   470: fload 21
    //   472: aload 37
    //   474: aload 38
    //   476: aload 39
    //   478: invokespecial 156	android/graphics/LinearGradient:<init>	(FFFF[I[FLandroid/graphics/Shader$TileMode;)V
    //   481: astore 35
    //   483: goto +78 -> 561
    //   486: new 158	android/graphics/SweepGradient
    //   489: dup
    //   490: fload 22
    //   492: fload 23
    //   494: aload 31
    //   496: getfield 145	androidx/core/content/a/d$a:a	[I
    //   499: aload 31
    //   501: getfield 148	androidx/core/content/a/d$a:b	[F
    //   504: invokespecial 161	android/graphics/SweepGradient:<init>	(FF[I[F)V
    //   507: astore 35
    //   509: goto +52 -> 561
    //   512: fload 30
    //   514: fconst_0
    //   515: fcmpg
    //   516: ifle +63 -> 579
    //   519: aload 31
    //   521: getfield 145	androidx/core/content/a/d$a:a	[I
    //   524: astore 32
    //   526: aload 31
    //   528: getfield 148	androidx/core/content/a/d$a:b	[F
    //   531: astore 33
    //   533: iload 29
    //   535: invokestatic 151	androidx/core/content/a/d:a	(I)Landroid/graphics/Shader$TileMode;
    //   538: astore 34
    //   540: new 163	android/graphics/RadialGradient
    //   543: dup
    //   544: fload 22
    //   546: fload 23
    //   548: fload 30
    //   550: aload 32
    //   552: aload 33
    //   554: aload 34
    //   556: invokespecial 166	android/graphics/RadialGradient:<init>	(FFF[I[FLandroid/graphics/Shader$TileMode;)V
    //   559: astore 35
    //   561: new 2	androidx/core/content/a/b
    //   564: dup
    //   565: aload 35
    //   567: aconst_null
    //   568: iconst_0
    //   569: invokespecial 32	androidx/core/content/a/b:<init>	(Landroid/graphics/Shader;Landroid/content/res/ColorStateList;I)V
    //   572: astore 36
    //   574: aload 36
    //   576: areturn
    //   577: aconst_null
    //   578: areturn
    //   579: new 168	org/xmlpull/v1/XmlPullParserException
    //   582: dup
    //   583: ldc 170
    //   585: invokespecial 173	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   588: athrow
    //   589: new 175	java/lang/StringBuilder
    //   592: dup
    //   593: invokespecial 176	java/lang/StringBuilder:<init>	()V
    //   596: astore 13
    //   598: aload 13
    //   600: aload_3
    //   601: invokeinterface 179 1 0
    //   606: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   609: pop
    //   610: aload 13
    //   612: ldc 185
    //   614: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   617: pop
    //   618: aload 13
    //   620: aload 12
    //   622: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   625: pop
    //   626: new 168	org/xmlpull/v1/XmlPullParserException
    //   629: dup
    //   630: aload 13
    //   632: invokevirtual 188	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   635: invokespecial 173	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   638: athrow
    //   639: new 175	java/lang/StringBuilder
    //   642: dup
    //   643: invokespecial 176	java/lang/StringBuilder:<init>	()V
    //   646: astore 40
    //   648: aload 40
    //   650: aload_3
    //   651: invokeinterface 179 1 0
    //   656: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   659: pop
    //   660: aload 40
    //   662: ldc 190
    //   664: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   667: pop
    //   668: aload 40
    //   670: aload 6
    //   672: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   675: pop
    //   676: new 168	org/xmlpull/v1/XmlPullParserException
    //   679: dup
    //   680: aload 40
    //   682: invokevirtual 188	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   685: invokespecial 173	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   688: athrow
    //   689: aload_0
    //   690: aload_3
    //   691: aload 4
    //   693: aload_2
    //   694: invokestatic 195	androidx/core/content/a/a:a	(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    //   697: astore 9
    //   699: aload 9
    //   701: invokevirtual 200	android/content/res/ColorStateList:getDefaultColor	()I
    //   704: istore 10
    //   706: new 2	androidx/core/content/a/b
    //   709: dup
    //   710: aconst_null
    //   711: aload 9
    //   713: iload 10
    //   715: invokespecial 32	androidx/core/content/a/b:<init>	(Landroid/graphics/Shader;Landroid/content/res/ColorStateList;I)V
    //   718: astore 11
    //   720: aload 11
    //   722: areturn
    //   723: aconst_null
    //   724: areturn
    //   725: new 168	org/xmlpull/v1/XmlPullParserException
    //   728: dup
    //   729: ldc 202
    //   731: invokespecial 173	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   734: athrow
    //   735: aconst_null
    //   736: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   561	574	577	java/lang/Exception
    //   706	720	723	java/lang/Exception
    //   0	12	735	java/lang/Exception
    //   12	20	735	java/lang/Exception
    //   38	46	735	java/lang/Exception
    //   49	56	735	java/lang/Exception
    //   73	83	735	java/lang/Exception
    //   89	99	735	java/lang/Exception
    //   113	383	735	java/lang/Exception
    //   396	411	735	java/lang/Exception
    //   414	427	735	java/lang/Exception
    //   439	483	735	java/lang/Exception
    //   486	509	735	java/lang/Exception
    //   519	561	735	java/lang/Exception
    //   579	589	735	java/lang/Exception
    //   589	639	735	java/lang/Exception
    //   639	689	735	java/lang/Exception
    //   689	706	735	java/lang/Exception
    //   725	735	735	java/lang/Exception
  }

  public final boolean a()
  {
    return this.a != null;
  }

  public final boolean a(int[] paramArrayOfInt)
  {
    if (b())
    {
      ColorStateList localColorStateList = this.c;
      int i = localColorStateList.getColorForState(paramArrayOfInt, localColorStateList.getDefaultColor());
      if (i != this.b)
      {
        this.b = i;
        return true;
      }
    }
    return false;
  }

  public final boolean b()
  {
    if (this.a == null)
    {
      ColorStateList localColorStateList = this.c;
      if ((localColorStateList != null) && (localColorStateList.isStateful()))
        return true;
    }
    return false;
  }

  public final boolean c()
  {
    return (a()) || (this.b != 0);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.a.b
 * JD-Core Version:    0.6.2
 */