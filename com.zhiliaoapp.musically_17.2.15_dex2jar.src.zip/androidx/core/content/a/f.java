package androidx.core.content.a;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class f
{
  static
  {
    CoverageLogger.Log(46475264);
  }

  public static Typeface a(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, a parama)
    throws Resources.NotFoundException
  {
    if (paramContext.isRestricted())
      return null;
    return a(paramContext, paramInt1, paramTypedValue, paramInt2, parama, null, true);
  }

  private static Typeface a(Context paramContext, int paramInt1, TypedValue paramTypedValue, int paramInt2, a parama, Handler paramHandler, boolean paramBoolean)
  {
    Resources localResources = paramContext.getResources();
    localResources.getValue(paramInt1, paramTypedValue, true);
    Typeface localTypeface = a(paramContext, localResources, paramTypedValue, paramInt1, paramInt2, parama, null, true);
    if (localTypeface == null)
    {
      if (parama != null)
        return localTypeface;
      StringBuilder localStringBuilder = new StringBuilder("Font resource ID #0x");
      localStringBuilder.append(Integer.toHexString(paramInt1));
      localStringBuilder.append(" could not be retrieved.");
      throw new Resources.NotFoundException(localStringBuilder.toString());
    }
    return localTypeface;
  }

  // ERROR //
  private static Typeface a(Context paramContext, Resources paramResources, TypedValue paramTypedValue, int paramInt1, int paramInt2, a parama, Handler paramHandler, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_2
    //   1: getfield 74	android/util/TypedValue:string	Ljava/lang/CharSequence;
    //   4: ifnull +329 -> 333
    //   7: aload_2
    //   8: getfield 74	android/util/TypedValue:string	Ljava/lang/CharSequence;
    //   11: invokeinterface 77 1 0
    //   16: astore 14
    //   18: aload 14
    //   20: ldc 79
    //   22: invokevirtual 85	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   25: ifne +19 -> 44
    //   28: aload 5
    //   30: ifnull +12 -> 42
    //   33: aload 5
    //   35: bipush 253
    //   37: aload 6
    //   39: invokevirtual 90	androidx/core/content/a/f$a:a	(ILandroid/os/Handler;)V
    //   42: aconst_null
    //   43: areturn
    //   44: getstatic 96	androidx/core/graphics/c:b	Landroidx/c/e;
    //   47: aload_1
    //   48: iload_3
    //   49: iload 4
    //   51: invokestatic 99	androidx/core/graphics/c:a	(Landroid/content/res/Resources;II)Ljava/lang/String;
    //   54: invokevirtual 104	androidx/c/e:a	(Ljava/lang/Object;)Ljava/lang/Object;
    //   57: checkcast 106	android/graphics/Typeface
    //   60: astore 15
    //   62: aload 15
    //   64: ifnull +20 -> 84
    //   67: aload 5
    //   69: ifnull +12 -> 81
    //   72: aload 5
    //   74: aload 15
    //   76: aload 6
    //   78: invokevirtual 109	androidx/core/content/a/f$a:a	(Landroid/graphics/Typeface;Landroid/os/Handler;)V
    //   81: aload 15
    //   83: areturn
    //   84: aload 14
    //   86: invokevirtual 112	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   89: ldc 114
    //   91: invokevirtual 117	java/lang/String:endsWith	(Ljava/lang/String;)Z
    //   94: ifeq +177 -> 271
    //   97: aload_1
    //   98: iload_3
    //   99: invokevirtual 121	android/content/res/Resources:getXml	(I)Landroid/content/res/XmlResourceParser;
    //   102: aload_1
    //   103: invokestatic 126	androidx/core/content/a/c:a	(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/a/c$a;
    //   106: astore 17
    //   108: aload 17
    //   110: ifnonnull +19 -> 129
    //   113: aload 5
    //   115: ifnull +286 -> 401
    //   118: aload 5
    //   120: bipush 253
    //   122: aload 6
    //   124: invokevirtual 90	androidx/core/content/a/f$a:a	(ILandroid/os/Handler;)V
    //   127: aconst_null
    //   128: areturn
    //   129: aload 17
    //   131: instanceof 128
    //   134: ifeq +65 -> 199
    //   137: aload 17
    //   139: checkcast 128	androidx/core/content/a/c$d
    //   142: astore 20
    //   144: iload 7
    //   146: ifeq +257 -> 403
    //   149: aload 20
    //   151: getfield 132	androidx/core/content/a/c$d:c	I
    //   154: ifne +260 -> 414
    //   157: goto +251 -> 408
    //   160: iload 7
    //   162: ifeq +258 -> 420
    //   165: aload 20
    //   167: getfield 134	androidx/core/content/a/c$d:b	I
    //   170: istore 22
    //   172: goto +3 -> 175
    //   175: aload_0
    //   176: aload 20
    //   178: getfield 137	androidx/core/content/a/c$d:a	Landroidx/core/e/a;
    //   181: aload 5
    //   183: aload 6
    //   185: iload 21
    //   187: iload 22
    //   189: iload 4
    //   191: invokestatic 142	androidx/core/e/b:a	(Landroid/content/Context;Landroidx/core/e/a;Landroidx/core/content/a/f$a;Landroid/os/Handler;ZII)Landroid/graphics/Typeface;
    //   194: astore 18
    //   196: goto +51 -> 247
    //   199: getstatic 145	androidx/core/graphics/c:a	Landroidx/core/graphics/h;
    //   202: aload_0
    //   203: aload 17
    //   205: checkcast 147	androidx/core/content/a/c$b
    //   208: aload_1
    //   209: iload 4
    //   211: invokevirtual 152	androidx/core/graphics/h:a	(Landroid/content/Context;Landroidx/core/content/a/c$b;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;
    //   214: astore 18
    //   216: aload 5
    //   218: ifnull +29 -> 247
    //   221: aload 18
    //   223: ifnull +15 -> 238
    //   226: aload 5
    //   228: aload 18
    //   230: aload 6
    //   232: invokevirtual 109	androidx/core/content/a/f$a:a	(Landroid/graphics/Typeface;Landroid/os/Handler;)V
    //   235: goto +12 -> 247
    //   238: aload 5
    //   240: bipush 253
    //   242: aload 6
    //   244: invokevirtual 90	androidx/core/content/a/f$a:a	(ILandroid/os/Handler;)V
    //   247: aload 18
    //   249: ifnull +177 -> 426
    //   252: getstatic 96	androidx/core/graphics/c:b	Landroidx/c/e;
    //   255: aload_1
    //   256: iload_3
    //   257: iload 4
    //   259: invokestatic 99	androidx/core/graphics/c:a	(Landroid/content/res/Resources;II)Ljava/lang/String;
    //   262: aload 18
    //   264: invokevirtual 155	androidx/c/e:a	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   267: pop
    //   268: aload 18
    //   270: areturn
    //   271: aload_0
    //   272: aload_1
    //   273: iload_3
    //   274: aload 14
    //   276: iload 4
    //   278: invokestatic 158	androidx/core/graphics/c:a	(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;I)Landroid/graphics/Typeface;
    //   281: astore 16
    //   283: aload 5
    //   285: ifnull +29 -> 314
    //   288: aload 16
    //   290: ifnull +15 -> 305
    //   293: aload 5
    //   295: aload 16
    //   297: aload 6
    //   299: invokevirtual 109	androidx/core/content/a/f$a:a	(Landroid/graphics/Typeface;Landroid/os/Handler;)V
    //   302: aload 16
    //   304: areturn
    //   305: aload 5
    //   307: bipush 253
    //   309: aload 6
    //   311: invokevirtual 90	androidx/core/content/a/f$a:a	(ILandroid/os/Handler;)V
    //   314: aload 16
    //   316: areturn
    //   317: aload 5
    //   319: ifnull +12 -> 331
    //   322: aload 5
    //   324: bipush 253
    //   326: aload 6
    //   328: invokevirtual 90	androidx/core/content/a/f$a:a	(ILandroid/os/Handler;)V
    //   331: aconst_null
    //   332: areturn
    //   333: new 41	java/lang/StringBuilder
    //   336: dup
    //   337: ldc 160
    //   339: invokespecial 47	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   342: astore 8
    //   344: aload 8
    //   346: aload_1
    //   347: iload_3
    //   348: invokevirtual 163	android/content/res/Resources:getResourceName	(I)Ljava/lang/String;
    //   351: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: pop
    //   355: aload 8
    //   357: ldc 165
    //   359: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: pop
    //   363: aload 8
    //   365: iload_3
    //   366: invokestatic 53	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   369: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   372: pop
    //   373: aload 8
    //   375: ldc 167
    //   377: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   380: pop
    //   381: aload 8
    //   383: aload_2
    //   384: invokevirtual 170	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   387: pop
    //   388: new 17	android/content/res/Resources$NotFoundException
    //   391: dup
    //   392: aload 8
    //   394: invokevirtual 63	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   397: invokespecial 64	android/content/res/Resources$NotFoundException:<init>	(Ljava/lang/String;)V
    //   400: athrow
    //   401: aconst_null
    //   402: areturn
    //   403: aload 5
    //   405: ifnonnull +9 -> 414
    //   408: iconst_1
    //   409: istore 21
    //   411: goto -251 -> 160
    //   414: iconst_0
    //   415: istore 21
    //   417: goto -257 -> 160
    //   420: iconst_m1
    //   421: istore 22
    //   423: goto -248 -> 175
    //   426: aload 18
    //   428: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   84	108	317	org/xmlpull/v1/XmlPullParserException
    //   84	108	317	java/io/IOException
    //   118	127	317	org/xmlpull/v1/XmlPullParserException
    //   118	127	317	java/io/IOException
    //   129	144	317	org/xmlpull/v1/XmlPullParserException
    //   129	144	317	java/io/IOException
    //   149	157	317	org/xmlpull/v1/XmlPullParserException
    //   149	157	317	java/io/IOException
    //   165	172	317	org/xmlpull/v1/XmlPullParserException
    //   165	172	317	java/io/IOException
    //   175	196	317	org/xmlpull/v1/XmlPullParserException
    //   175	196	317	java/io/IOException
    //   199	216	317	org/xmlpull/v1/XmlPullParserException
    //   199	216	317	java/io/IOException
    //   226	235	317	org/xmlpull/v1/XmlPullParserException
    //   226	235	317	java/io/IOException
    //   238	247	317	org/xmlpull/v1/XmlPullParserException
    //   238	247	317	java/io/IOException
    //   252	268	317	org/xmlpull/v1/XmlPullParserException
    //   252	268	317	java/io/IOException
    //   271	283	317	org/xmlpull/v1/XmlPullParserException
    //   271	283	317	java/io/IOException
    //   293	302	317	org/xmlpull/v1/XmlPullParserException
    //   293	302	317	java/io/IOException
    //   305	314	317	org/xmlpull/v1/XmlPullParserException
    //   305	314	317	java/io/IOException
  }

  public static Drawable a(Resources paramResources, int paramInt, Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramResources.getDrawable(paramInt, paramTheme);
    return paramResources.getDrawable(paramInt);
  }

  public static int b(Resources paramResources, int paramInt, Resources.Theme paramTheme)
    throws Resources.NotFoundException
  {
    if (Build.VERSION.SDK_INT >= 23)
      return paramResources.getColor(paramInt, paramTheme);
    return paramResources.getColor(paramInt);
  }

  public static abstract class a
  {
    static
    {
      CoverageLogger.Log(46753792);
    }

    public final void a(final int paramInt, Handler paramHandler)
    {
      if (paramHandler == null)
        paramHandler = new Handler(Looper.getMainLooper());
      paramHandler.post(new Runnable()
      {
        static
        {
          CoverageLogger.Log(46745600);
        }

        public final void run()
        {
        }
      });
    }

    public abstract void a(Typeface paramTypeface);

    public final void a(final Typeface paramTypeface, Handler paramHandler)
    {
      if (paramHandler == null)
        paramHandler = new Handler(Looper.getMainLooper());
      paramHandler.post(new Runnable()
      {
        static
        {
          CoverageLogger.Log(46741504);
        }

        public final void run()
        {
          f.a.this.a(paramTypeface);
        }
      });
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.a.f
 * JD-Core Version:    0.6.2
 */