package androidx.core.content.a;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.util.Base64;
import android.util.TypedValue;
import android.util.Xml;
import androidx.core.e.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class c
{
  static
  {
    CoverageLogger.Log(46708736);
  }

  public static a a(XmlPullParser paramXmlPullParser, Resources paramResources)
    throws XmlPullParserException, IOException
  {
    int i;
    do
      i = paramXmlPullParser.next();
    while ((i != 2) && (i != 1));
    if (i == 2)
    {
      paramXmlPullParser.require(2, null, "font-family");
      if (paramXmlPullParser.getName().equals("font-family"))
        return b(paramXmlPullParser, paramResources);
      a(paramXmlPullParser);
      return null;
    }
    XmlPullParserException localXmlPullParserException = new XmlPullParserException("No start tag found");
    while (true)
      throw localXmlPullParserException;
  }

  public static List<List<byte[]>> a(Resources paramResources, int paramInt)
  {
    if (paramInt == 0)
      return Collections.emptyList();
    TypedArray localTypedArray = paramResources.obtainTypedArray(paramInt);
    try
    {
      if (localTypedArray.length() == 0)
      {
        List localList = Collections.emptyList();
        localTypedArray.recycle();
        return localList;
      }
      ArrayList localArrayList = new ArrayList();
      if (Build.VERSION.SDK_INT >= 21)
      {
        i = localTypedArray.getType(0);
      }
      else
      {
        TypedValue localTypedValue = new TypedValue();
        localTypedArray.getValue(0, localTypedValue);
        i = localTypedValue.type;
        break label166;
        if (j < localTypedArray.length())
        {
          int k = localTypedArray.getResourceId(j, 0);
          if (k == 0)
            break label178;
          localArrayList.add(a(paramResources.getStringArray(k)));
          break label178;
          localArrayList.add(a(paramResources.getStringArray(paramInt)));
        }
        localTypedArray.recycle();
        return localArrayList;
      }
    }
    finally
    {
      while (true)
      {
        int i;
        int j;
        localTypedArray.recycle();
        while (true)
          throw localObject;
        label166: if (i == 1)
        {
          j = 0;
          continue;
          label178: j++;
        }
      }
    }
  }

  private static List<byte[]> a(String[] paramArrayOfString)
  {
    ArrayList localArrayList = new ArrayList();
    int i = paramArrayOfString.length;
    for (int j = 0; j < i; j++)
      localArrayList.add(Base64.decode(paramArrayOfString[j], 0));
    return localArrayList;
  }

  private static void a(XmlPullParser paramXmlPullParser)
    throws XmlPullParserException, IOException
  {
    int i = 1;
    while (i > 0)
    {
      int j = paramXmlPullParser.next();
      if (j != 2)
      {
        if (j == 3)
          i--;
      }
      else
        i++;
    }
  }

  private static a b(XmlPullParser paramXmlPullParser, Resources paramResources)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(Xml.asAttributeSet(paramXmlPullParser), new int[] { 2130969115, 2130969116, 2130969117, 2130969118, 2130969119, 2130969120 });
    String str1 = localTypedArray.getString(0);
    String str2 = localTypedArray.getString(4);
    String str3 = localTypedArray.getString(5);
    int i = localTypedArray.getResourceId(1, 0);
    int j = localTypedArray.getInteger(2, 1);
    int k = localTypedArray.getInteger(3, 500);
    localTypedArray.recycle();
    if ((str1 != null) && (str2 != null) && (str3 != null))
    {
      while (paramXmlPullParser.next() != 3)
        a(paramXmlPullParser);
      return new d(new a(str1, str2, str3, a(paramResources, i)), j, k);
    }
    ArrayList localArrayList = new ArrayList();
    while (paramXmlPullParser.next() != 3)
      if (paramXmlPullParser.getEventType() == 2)
        if (paramXmlPullParser.getName().equals("font"))
          localArrayList.add(c(paramXmlPullParser, paramResources));
        else
          a(paramXmlPullParser);
    if (localArrayList.isEmpty())
      return null;
    return new b((c[])localArrayList.toArray(new c[localArrayList.size()]));
  }

  private static c c(XmlPullParser paramXmlPullParser, Resources paramResources)
    throws XmlPullParserException, IOException
  {
    TypedArray localTypedArray = paramResources.obtainAttributes(Xml.asAttributeSet(paramXmlPullParser), new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130969113, 2130969121, 2130969123, 2130969124, 2130969997 });
    int i = 8;
    if (!localTypedArray.hasValue(i))
      i = 1;
    int j = localTypedArray.getInt(i, 400);
    int k = 6;
    if (!localTypedArray.hasValue(k))
      k = 2;
    boolean bool;
    if (1 == localTypedArray.getInt(k, 0))
      bool = true;
    else
      bool = false;
    int m = 9;
    if (!localTypedArray.hasValue(m))
      m = 3;
    int n = 7;
    if (!localTypedArray.hasValue(n))
      n = 4;
    String str1 = localTypedArray.getString(n);
    int i1 = localTypedArray.getInt(m, 0);
    int i2 = 5;
    if (!localTypedArray.hasValue(i2))
      i2 = 0;
    int i3 = localTypedArray.getResourceId(i2, 0);
    String str2 = localTypedArray.getString(i2);
    localTypedArray.recycle();
    while (paramXmlPullParser.next() != 3)
      a(paramXmlPullParser);
    c localc = new c(str2, j, bool, str1, i1, i3);
    return localc;
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46710784);
    }
  }

  public static final class b
    implements c.a
  {
    public final c.c[] a;

    static
    {
      CoverageLogger.Log(46723072);
    }

    public b(c.c[] paramArrayOfc)
    {
      this.a = paramArrayOfc;
    }
  }

  public static final class c
  {
    public final String a;
    public int b;
    public boolean c;
    public String d;
    public int e;
    public int f;

    static
    {
      CoverageLogger.Log(46485504);
    }

    public c(String paramString1, int paramInt1, boolean paramBoolean, String paramString2, int paramInt2, int paramInt3)
    {
      this.a = paramString1;
      this.b = paramInt1;
      this.c = paramBoolean;
      this.d = paramString2;
      this.e = paramInt2;
      this.f = paramInt3;
    }
  }

  public static final class d
    implements c.a
  {
    public final a a;
    public final int b;
    public final int c;

    static
    {
      CoverageLogger.Log(46733312);
    }

    public d(a parama, int paramInt1, int paramInt2)
    {
      this.a = parama;
      this.c = paramInt1;
      this.b = paramInt2;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.a.c
 * JD-Core Version:    0.6.2
 */