package androidx.core.content.a;

import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Shader.TileMode;
import android.util.AttributeSet;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

final class d
{
  static
  {
    CoverageLogger.Log(46483456);
  }

  static Shader.TileMode a(int paramInt)
  {
    if (paramInt != 1)
    {
      if (paramInt != 2)
        return Shader.TileMode.CLAMP;
      return Shader.TileMode.MIRROR;
    }
    return Shader.TileMode.REPEAT;
  }

  static a a(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    throws XmlPullParserException, IOException
  {
    int i = 1 + paramXmlPullParser.getDepth();
    ArrayList localArrayList1 = new ArrayList(20);
    ArrayList localArrayList2 = new ArrayList(20);
    while (true)
    {
      int j = paramXmlPullParser.next();
      if (j == 1)
        break label235;
      int k = paramXmlPullParser.getDepth();
      if ((k < i) && (j == 3))
        break label235;
      if ((j == 2) && (k <= i) && (paramXmlPullParser.getName().equals("item")))
      {
        TypedArray localTypedArray = g.a(paramResources, paramTheme, paramAttributeSet, new int[] { 16843173, 16844052 });
        boolean bool1 = localTypedArray.hasValue(0);
        boolean bool2 = localTypedArray.hasValue(1);
        if ((!bool1) || (!bool2))
          break;
        int m = localTypedArray.getColor(0, 0);
        float f = localTypedArray.getFloat(1, 0.0F);
        localTypedArray.recycle();
        localArrayList2.add(Integer.valueOf(m));
        localArrayList1.add(Float.valueOf(f));
      }
    }
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(paramXmlPullParser.getPositionDescription());
    localStringBuilder.append(": <item> tag requires a 'color' attribute and a 'offset' attribute!");
    throw new XmlPullParserException(localStringBuilder.toString());
    label235: if (localArrayList2.size() > 0)
      return new a(localArrayList2, localArrayList1);
    return null;
  }

  static final class a
  {
    final int[] a;
    final float[] b;

    static
    {
      CoverageLogger.Log(46737408);
    }

    a(int paramInt1, int paramInt2)
    {
      this.a = new int[] { paramInt1, paramInt2 };
      this.b = new float[] { 0.0F, 1.0F };
    }

    a(int paramInt1, int paramInt2, int paramInt3)
    {
      this.a = new int[] { paramInt1, paramInt2, paramInt3 };
      this.b = new float[] { 0.0F, 0.5F, 1.0F };
    }

    a(List<Integer> paramList, List<Float> paramList1)
    {
      int i = paramList.size();
      this.a = new int[i];
      this.b = new float[i];
      for (int j = 0; j < i; j++)
      {
        this.a[j] = ((Integer)paramList.get(j)).intValue();
        this.b[j] = ((Float)paramList1.get(j)).floatValue();
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.a.d
 * JD-Core Version:    0.6.2
 */