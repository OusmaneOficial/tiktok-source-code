package androidx.core.content;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build.VERSION;
import android.os.Process;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
{
  static
  {
    CoverageLogger.Log(46702592);
  }

  public static int a(Context paramContext, String paramString)
  {
    return a(paramContext, paramString, Process.myPid(), Process.myUid(), paramContext.getPackageName());
  }

  private static int a(Context paramContext, String paramString1, int paramInt1, int paramInt2, String paramString2)
  {
    if (paramContext.checkPermission(paramString1, paramInt1, paramInt2) == -1)
      return -1;
    String str;
    if (Build.VERSION.SDK_INT >= 23)
      str = AppOpsManager.permissionToOp(paramString1);
    else
      str = null;
    if (str == null)
      return 0;
    if (paramString2 == null)
    {
      String[] arrayOfString = paramContext.getPackageManager().getPackagesForUid(paramInt2);
      if (arrayOfString != null)
      {
        if (arrayOfString.length <= 0)
          return -1;
        paramString2 = arrayOfString[0];
      }
      else
      {
        return -1;
      }
    }
    int i;
    if (Build.VERSION.SDK_INT >= 23)
      i = ((AppOpsManager)paramContext.getSystemService(AppOpsManager.class)).noteProxyOpNoThrow(str, paramString2);
    else
      i = 1;
    if (i != 0)
      return -2;
    return 0;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.d
 * JD-Core Version:    0.6.2
 */