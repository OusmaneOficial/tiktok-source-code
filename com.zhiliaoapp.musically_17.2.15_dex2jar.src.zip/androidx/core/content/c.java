package androidx.core.content;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c
{
  static
  {
    CoverageLogger.Log(1181696);
  }

  // ERROR //
  public static int a(FileProvider paramFileProvider, android.net.Uri paramUri, java.lang.String paramString, java.lang.String[] paramArrayOfString)
  {
    // Byte code:
    //   0: aload_0
    //   1: checkcast 6	androidx/core/content/FileProvider
    //   4: astore 4
    //   6: aload 4
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield 21	androidx/core/content/FileProvider:mLazyProviderInfo	Ljava/lang/Object;
    //   13: astore 6
    //   15: aload 6
    //   17: ifnull +45 -> 62
    //   20: aload 6
    //   22: instanceof 23
    //   25: istore 7
    //   27: iload 7
    //   29: ifeq +33 -> 62
    //   32: aload 4
    //   34: aload 4
    //   36: invokevirtual 27	androidx/core/content/FileProvider:getContext	()Landroid/content/Context;
    //   39: aload 6
    //   41: checkcast 23	android/content/pm/ProviderInfo
    //   44: invokevirtual 31	androidx/core/content/FileProvider:attachInfo	(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    //   47: goto +15 -> 62
    //   50: astore 8
    //   52: new 33	java/lang/RuntimeException
    //   55: dup
    //   56: aload 8
    //   58: invokespecial 37	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   61: athrow
    //   62: aload 4
    //   64: monitorexit
    //   65: aload_0
    //   66: aload_1
    //   67: aload_2
    //   68: aload_3
    //   69: invokevirtual 41	androidx/core/content/FileProvider:FileProvider__delete$___twin___	(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    //   72: ireturn
    //   73: astore 5
    //   75: aload 4
    //   77: monitorexit
    //   78: aload 5
    //   80: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   32	47	50	finally
    //   9	15	73	finally
    //   20	27	73	finally
    //   52	62	73	finally
    //   62	65	73	finally
    //   75	78	73	finally
  }

  // ERROR //
  public static android.database.Cursor a(FileProvider paramFileProvider, android.net.Uri paramUri, java.lang.String[] paramArrayOfString1, java.lang.String paramString1, java.lang.String[] paramArrayOfString2, java.lang.String paramString2)
  {
    // Byte code:
    //   0: aload_0
    //   1: checkcast 6	androidx/core/content/FileProvider
    //   4: astore 6
    //   6: aload 6
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield 21	androidx/core/content/FileProvider:mLazyProviderInfo	Ljava/lang/Object;
    //   13: astore 8
    //   15: aload 8
    //   17: ifnull +45 -> 62
    //   20: aload 8
    //   22: instanceof 23
    //   25: istore 9
    //   27: iload 9
    //   29: ifeq +33 -> 62
    //   32: aload 6
    //   34: aload 6
    //   36: invokevirtual 27	androidx/core/content/FileProvider:getContext	()Landroid/content/Context;
    //   39: aload 8
    //   41: checkcast 23	android/content/pm/ProviderInfo
    //   44: invokevirtual 31	androidx/core/content/FileProvider:attachInfo	(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    //   47: goto +15 -> 62
    //   50: astore 10
    //   52: new 33	java/lang/RuntimeException
    //   55: dup
    //   56: aload 10
    //   58: invokespecial 37	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   61: athrow
    //   62: aload 6
    //   64: monitorexit
    //   65: aload_0
    //   66: aload_1
    //   67: aload_2
    //   68: aload_3
    //   69: aload 4
    //   71: aload 5
    //   73: invokevirtual 46	androidx/core/content/FileProvider:FileProvider__query$___twin___	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   76: areturn
    //   77: astore 7
    //   79: aload 6
    //   81: monitorexit
    //   82: aload 7
    //   84: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   32	47	50	finally
    //   9	15	77	finally
    //   20	27	77	finally
    //   52	62	77	finally
    //   62	65	77	finally
    //   79	82	77	finally
  }

  // ERROR //
  public static android.os.ParcelFileDescriptor a(FileProvider paramFileProvider, android.net.Uri paramUri, java.lang.String paramString)
    throws java.io.FileNotFoundException
  {
    // Byte code:
    //   0: aload_0
    //   1: checkcast 6	androidx/core/content/FileProvider
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 21	androidx/core/content/FileProvider:mLazyProviderInfo	Ljava/lang/Object;
    //   11: astore 5
    //   13: aload 5
    //   15: ifnull +43 -> 58
    //   18: aload 5
    //   20: instanceof 23
    //   23: istore 6
    //   25: iload 6
    //   27: ifeq +31 -> 58
    //   30: aload_3
    //   31: aload_3
    //   32: invokevirtual 27	androidx/core/content/FileProvider:getContext	()Landroid/content/Context;
    //   35: aload 5
    //   37: checkcast 23	android/content/pm/ProviderInfo
    //   40: invokevirtual 31	androidx/core/content/FileProvider:attachInfo	(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    //   43: goto +15 -> 58
    //   46: astore 7
    //   48: new 33	java/lang/RuntimeException
    //   51: dup
    //   52: aload 7
    //   54: invokespecial 37	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   57: athrow
    //   58: aload_3
    //   59: monitorexit
    //   60: aload_0
    //   61: aload_1
    //   62: aload_2
    //   63: invokevirtual 53	androidx/core/content/FileProvider:FileProvider__openFile$___twin___	(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
    //   66: areturn
    //   67: astore 4
    //   69: aload_3
    //   70: monitorexit
    //   71: aload 4
    //   73: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   30	43	46	finally
    //   7	13	67	finally
    //   18	25	67	finally
    //   48	58	67	finally
    //   58	60	67	finally
    //   69	71	67	finally
  }

  // ERROR //
  public static java.lang.String a(FileProvider paramFileProvider, android.net.Uri paramUri)
  {
    // Byte code:
    //   0: aload_0
    //   1: checkcast 6	androidx/core/content/FileProvider
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 21	androidx/core/content/FileProvider:mLazyProviderInfo	Ljava/lang/Object;
    //   11: astore 4
    //   13: aload 4
    //   15: ifnull +43 -> 58
    //   18: aload 4
    //   20: instanceof 23
    //   23: istore 5
    //   25: iload 5
    //   27: ifeq +31 -> 58
    //   30: aload_2
    //   31: aload_2
    //   32: invokevirtual 27	androidx/core/content/FileProvider:getContext	()Landroid/content/Context;
    //   35: aload 4
    //   37: checkcast 23	android/content/pm/ProviderInfo
    //   40: invokevirtual 31	androidx/core/content/FileProvider:attachInfo	(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    //   43: goto +15 -> 58
    //   46: astore 6
    //   48: new 33	java/lang/RuntimeException
    //   51: dup
    //   52: aload 6
    //   54: invokespecial 37	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   57: athrow
    //   58: aload_2
    //   59: monitorexit
    //   60: aload_0
    //   61: aload_1
    //   62: invokevirtual 58	androidx/core/content/FileProvider:FileProvider__getType$___twin___	(Landroid/net/Uri;)Ljava/lang/String;
    //   65: areturn
    //   66: astore_3
    //   67: aload_2
    //   68: monitorexit
    //   69: aload_3
    //   70: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   30	43	46	finally
    //   7	13	66	finally
    //   18	25	66	finally
    //   48	58	66	finally
    //   58	60	66	finally
    //   67	69	66	finally
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.content.c
 * JD-Core Version:    0.6.2
 */