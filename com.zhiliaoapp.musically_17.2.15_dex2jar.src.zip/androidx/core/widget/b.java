package androidx.core.widget;

import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface b
{
  public static final boolean d = bool;

  static
  {
    CoverageLogger.Log(46170112);
    boolean bool;
    if (Build.VERSION.SDK_INT >= 27)
      bool = true;
    else
      bool = false;
  }

  public abstract void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IllegalArgumentException;

  public abstract void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfInt, int paramInt)
    throws IllegalArgumentException;

  public abstract void setAutoSizeTextTypeWithDefaults(int paramInt);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.b
 * JD-Core Version:    0.6.2
 */