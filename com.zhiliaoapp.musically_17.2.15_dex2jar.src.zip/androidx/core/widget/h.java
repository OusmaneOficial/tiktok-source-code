package androidx.core.widget;

import android.content.Context;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class h
{
  public OverScroller a;

  static
  {
    CoverageLogger.Log(46155776);
  }

  public h(Context paramContext, Interpolator paramInterpolator)
  {
    OverScroller localOverScroller;
    if (paramInterpolator != null)
      localOverScroller = new OverScroller(paramContext, paramInterpolator);
    else
      localOverScroller.<init>(paramContext);
    this.a = localOverScroller;
  }

  public final void a()
  {
    this.a.abortAnimation();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.h
 * JD-Core Version:    0.6.2
 */