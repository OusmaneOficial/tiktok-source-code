package androidx.core.widget;

import android.content.Intent;
import android.graphics.Paint.FontMetricsInt;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.PasswordTransformationMethod;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.core.f.c;
import androidx.core.f.c.a;
import androidx.core.f.c.a.a;
import androidx.core.g.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class i
{
  private static Field a;
  private static boolean b;
  private static Field c;
  private static boolean d;

  static
  {
    CoverageLogger.Log(46151680);
  }

  public static int a(TextView paramTextView)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return paramTextView.getMaxLines();
    if (!d)
    {
      c = a("mMaxMode");
      d = true;
    }
    Field localField1 = c;
    if ((localField1 != null) && (a(localField1, paramTextView) == 1))
    {
      if (!b)
      {
        a = a("mMaximum");
        b = true;
      }
      Field localField2 = a;
      if (localField2 != null)
        return a(localField2, paramTextView);
    }
    return -1;
  }

  // ERROR //
  private static int a(Field paramField, TextView paramTextView)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 58	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
    //   5: istore_2
    //   6: iload_2
    //   7: ireturn
    //   8: iconst_m1
    //   9: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	6	8	java/lang/IllegalAccessException
  }

  public static ActionMode.Callback a(TextView paramTextView, ActionMode.Callback paramCallback)
  {
    if ((Build.VERSION.SDK_INT >= 26) && (Build.VERSION.SDK_INT <= 27))
    {
      if ((paramCallback instanceof a))
        return paramCallback;
      return new a(paramCallback, paramTextView);
    }
    return paramCallback;
  }

  // ERROR //
  private static Field a(String paramString)
  {
    // Byte code:
    //   0: ldc 28
    //   2: aload_0
    //   3: invokevirtual 72	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   6: astore_1
    //   7: aload_1
    //   8: iconst_1
    //   9: invokevirtual 76	java/lang/reflect/Field:setAccessible	(Z)V
    //   12: aload_1
    //   13: areturn
    //   14: aconst_null
    //   15: astore_1
    //   16: goto +4 -> 20
    //   19: pop
    //   20: aload_1
    //   21: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	7	14	java/lang/NoSuchFieldException
    //   7	12	19	java/lang/NoSuchFieldException
  }

  public static void a(TextView paramTextView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      paramTextView.setTextAppearance(paramInt);
      return;
    }
    paramTextView.setTextAppearance(paramTextView.getContext(), paramInt);
  }

  public static void a(TextView paramTextView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IllegalArgumentException
  {
    if (Build.VERSION.SDK_INT >= 27)
    {
      paramTextView.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, 1, 2);
      return;
    }
    if ((paramTextView instanceof b))
      ((b)paramTextView).setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, 1, 2);
  }

  public static void a(TextView paramTextView, Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4)
  {
    if (Build.VERSION.SDK_INT >= 18)
    {
      paramTextView.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
      return;
    }
    if (Build.VERSION.SDK_INT >= 17)
    {
      int i = paramTextView.getLayoutDirection();
      int j = 1;
      if (i != j)
        j = 0;
      Drawable localDrawable;
      if (j != 0)
        localDrawable = paramDrawable3;
      else
        localDrawable = paramDrawable1;
      if (j == 0)
        paramDrawable1 = paramDrawable3;
      paramTextView.setCompoundDrawables(localDrawable, paramDrawable2, paramDrawable1, paramDrawable4);
      return;
    }
    paramTextView.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
  }

  public static void a(TextView paramTextView, c paramc)
  {
    if (Build.VERSION.SDK_INT >= 28)
    {
      paramTextView.setText(paramc.a());
      return;
    }
    if (c(paramTextView).equals(paramc.a))
    {
      paramTextView.setText(paramc);
      return;
    }
    throw new IllegalArgumentException("Given text can not be applied to TextView.");
  }

  public static void b(TextView paramTextView, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 27)
    {
      paramTextView.setAutoSizeTextTypeWithDefaults(paramInt);
      return;
    }
    if ((paramTextView instanceof b))
      ((b)paramTextView).setAutoSizeTextTypeWithDefaults(paramInt);
  }

  public static Drawable[] b(TextView paramTextView)
  {
    if (Build.VERSION.SDK_INT >= 18)
      return paramTextView.getCompoundDrawablesRelative();
    if (Build.VERSION.SDK_INT >= 17)
    {
      int i = paramTextView.getLayoutDirection();
      int j = 1;
      if (i != j)
        j = 0;
      Drawable[] arrayOfDrawable = paramTextView.getCompoundDrawables();
      if (j != 0)
      {
        Drawable localDrawable1 = arrayOfDrawable[2];
        Drawable localDrawable2 = arrayOfDrawable[0];
        arrayOfDrawable[0] = localDrawable1;
        arrayOfDrawable[2] = localDrawable2;
      }
      return arrayOfDrawable;
    }
    return paramTextView.getCompoundDrawables();
  }

  public static c.a c(TextView paramTextView)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return new c.a(paramTextView.getTextMetricsParams());
    c.a.a locala = new c.a.a(new TextPaint(paramTextView.getPaint()));
    if (Build.VERSION.SDK_INT >= 23)
    {
      locala.a(paramTextView.getBreakStrategy());
      locala.b(paramTextView.getHyphenationFrequency());
    }
    if (Build.VERSION.SDK_INT >= 18)
      locala.a(d(paramTextView));
    return locala.a();
  }

  public static void c(TextView paramTextView, int paramInt)
  {
    g.a(paramInt);
    if (Build.VERSION.SDK_INT >= 28)
    {
      paramTextView.setFirstBaselineToTopHeight(paramInt);
      return;
    }
    Paint.FontMetricsInt localFontMetricsInt = paramTextView.getPaint().getFontMetricsInt();
    int i;
    if ((Build.VERSION.SDK_INT >= 16) && (!paramTextView.getIncludeFontPadding()))
      i = localFontMetricsInt.ascent;
    else
      i = localFontMetricsInt.top;
    if (paramInt > Math.abs(i))
    {
      int j = paramInt - -i;
      paramTextView.setPadding(paramTextView.getPaddingLeft(), j, paramTextView.getPaddingRight(), paramTextView.getPaddingBottom());
    }
  }

  private static TextDirectionHeuristic d(TextView paramTextView)
  {
    if ((paramTextView.getTransformationMethod() instanceof PasswordTransformationMethod))
      return TextDirectionHeuristics.LTR;
    if ((Build.VERSION.SDK_INT >= 28) && ((0xF & paramTextView.getInputType()) == 3))
    {
      int k = Character.getDirectionality(android.icu.text.DecimalFormatSymbols.getInstance(paramTextView.getTextLocale()).getDigitStrings()[0].codePointAt(0));
      if ((k != 1) && (k != 2))
        return TextDirectionHeuristics.LTR;
      return TextDirectionHeuristics.RTL;
    }
    int i = paramTextView.getLayoutDirection();
    int j = 0;
    if (i == 1)
      j = 1;
    switch (paramTextView.getTextDirection())
    {
    default:
      if (j != 0)
        return TextDirectionHeuristics.FIRSTSTRONG_RTL;
      break;
    case 7:
      return TextDirectionHeuristics.FIRSTSTRONG_RTL;
    case 6:
      return TextDirectionHeuristics.FIRSTSTRONG_LTR;
    case 5:
      return TextDirectionHeuristics.LOCALE;
    case 4:
      return TextDirectionHeuristics.RTL;
    case 3:
      return TextDirectionHeuristics.LTR;
    case 2:
      return TextDirectionHeuristics.ANYRTL_LTR;
    }
    return TextDirectionHeuristics.FIRSTSTRONG_LTR;
  }

  public static void d(TextView paramTextView, int paramInt)
  {
    g.a(paramInt);
    Paint.FontMetricsInt localFontMetricsInt = paramTextView.getPaint().getFontMetricsInt();
    int i;
    if ((Build.VERSION.SDK_INT >= 16) && (!paramTextView.getIncludeFontPadding()))
      i = localFontMetricsInt.descent;
    else
      i = localFontMetricsInt.bottom;
    if (paramInt > Math.abs(i))
    {
      int j = paramInt - i;
      paramTextView.setPadding(paramTextView.getPaddingLeft(), paramTextView.getPaddingTop(), paramTextView.getPaddingRight(), j);
    }
  }

  public static void e(TextView paramTextView, int paramInt)
  {
    g.a(paramInt);
    int i = paramTextView.getPaint().getFontMetricsInt(null);
    if (paramInt != i)
      paramTextView.setLineSpacing(paramInt - i, 1.0F);
  }

  static final class a
    implements ActionMode.Callback
  {
    private final ActionMode.Callback a;
    private final TextView b;
    private Class c;
    private Method d;
    private boolean e;
    private boolean f;

    static
    {
      CoverageLogger.Log(46145536);
    }

    a(ActionMode.Callback paramCallback, TextView paramTextView)
    {
      this.a = paramCallback;
      this.b = paramTextView;
    }

    private static Intent a()
    {
      return new Intent().setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
    }

    public final boolean onActionItemClicked(ActionMode paramActionMode, MenuItem paramMenuItem)
    {
      return this.a.onActionItemClicked(paramActionMode, paramMenuItem);
    }

    public final boolean onCreateActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      return this.a.onCreateActionMode(paramActionMode, paramMenu);
    }

    public final void onDestroyActionMode(ActionMode paramActionMode)
    {
      this.a.onDestroyActionMode(paramActionMode);
    }

    // ERROR //
    public final boolean onPrepareActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 34	androidx/core/widget/i$a:b	Landroid/widget/TextView;
      //   4: invokevirtual 76	android/widget/TextView:getContext	()Landroid/content/Context;
      //   7: astore_3
      //   8: aload_3
      //   9: invokevirtual 82	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
      //   12: astore 4
      //   14: aload_0
      //   15: getfield 84	androidx/core/widget/i$a:f	Z
      //   18: ifne +72 -> 90
      //   21: aload_0
      //   22: iconst_1
      //   23: putfield 84	androidx/core/widget/i$a:f	Z
      //   26: aload_0
      //   27: ldc 86
      //   29: invokestatic 92	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
      //   32: putfield 94	androidx/core/widget/i$a:c	Ljava/lang/Class;
      //   35: aload_0
      //   36: getfield 94	androidx/core/widget/i$a:c	Ljava/lang/Class;
      //   39: astore 23
      //   41: iconst_1
      //   42: anewarray 88	java/lang/Class
      //   45: astore 24
      //   47: aload 24
      //   49: iconst_0
      //   50: getstatic 99	java/lang/Integer:TYPE	Ljava/lang/Class;
      //   53: aastore
      //   54: aload_0
      //   55: aload 23
      //   57: ldc 101
      //   59: aload 24
      //   61: invokevirtual 105	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   64: putfield 107	androidx/core/widget/i$a:d	Ljava/lang/reflect/Method;
      //   67: aload_0
      //   68: iconst_1
      //   69: putfield 109	androidx/core/widget/i$a:e	Z
      //   72: goto +18 -> 90
      //   75: aload_0
      //   76: aconst_null
      //   77: putfield 94	androidx/core/widget/i$a:c	Ljava/lang/Class;
      //   80: aload_0
      //   81: aconst_null
      //   82: putfield 107	androidx/core/widget/i$a:d	Ljava/lang/reflect/Method;
      //   85: aload_0
      //   86: iconst_0
      //   87: putfield 109	androidx/core/widget/i$a:e	Z
      //   90: aload_0
      //   91: getfield 109	androidx/core/widget/i$a:e	Z
      //   94: ifeq +23 -> 117
      //   97: aload_0
      //   98: getfield 94	androidx/core/widget/i$a:c	Ljava/lang/Class;
      //   101: aload_2
      //   102: invokevirtual 113	java/lang/Class:isInstance	(Ljava/lang/Object;)Z
      //   105: ifeq +12 -> 117
      //   108: aload_0
      //   109: getfield 107	androidx/core/widget/i$a:d	Ljava/lang/reflect/Method;
      //   112: astore 7
      //   114: goto +33 -> 147
      //   117: aload_2
      //   118: invokevirtual 117	java/lang/Object:getClass	()Ljava/lang/Class;
      //   121: astore 5
      //   123: iconst_1
      //   124: anewarray 88	java/lang/Class
      //   127: astore 6
      //   129: aload 6
      //   131: iconst_0
      //   132: getstatic 99	java/lang/Integer:TYPE	Ljava/lang/Class;
      //   135: aastore
      //   136: aload 5
      //   138: ldc 101
      //   140: aload 6
      //   142: invokevirtual 105	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   145: astore 7
      //   147: aload_2
      //   148: invokeinterface 123 1 0
      //   153: iconst_1
      //   154: isub
      //   155: istore 8
      //   157: iload 8
      //   159: iflt +71 -> 230
      //   162: aload_2
      //   163: iload 8
      //   165: invokeinterface 127 2 0
      //   170: astore 9
      //   172: aload 9
      //   174: invokeinterface 132 1 0
      //   179: ifnull +45 -> 224
      //   182: ldc 40
      //   184: aload 9
      //   186: invokeinterface 132 1 0
      //   191: invokevirtual 136	android/content/Intent:getAction	()Ljava/lang/String;
      //   194: invokevirtual 141	java/lang/String:equals	(Ljava/lang/Object;)Z
      //   197: ifeq +27 -> 224
      //   200: iconst_1
      //   201: anewarray 4	java/lang/Object
      //   204: astore 10
      //   206: aload 10
      //   208: iconst_0
      //   209: iload 8
      //   211: invokestatic 145	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
      //   214: aastore
      //   215: aload 7
      //   217: aload_2
      //   218: aload 10
      //   220: invokevirtual 151	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   223: pop
      //   224: iinc 8 255
      //   227: goto -70 -> 157
      //   230: new 153	java/util/ArrayList
      //   233: dup
      //   234: invokespecial 154	java/util/ArrayList:<init>	()V
      //   237: astore 12
      //   239: aload_3
      //   240: instanceof 156
      //   243: ifeq +126 -> 369
      //   246: aload 4
      //   248: invokestatic 158	androidx/core/widget/i$a:a	()Landroid/content/Intent;
      //   251: iconst_0
      //   252: invokevirtual 164	android/content/pm/PackageManager:queryIntentActivities	(Landroid/content/Intent;I)Ljava/util/List;
      //   255: invokeinterface 170 1 0
      //   260: astore 19
      //   262: aload 19
      //   264: invokeinterface 176 1 0
      //   269: ifeq +100 -> 369
      //   272: aload 19
      //   274: invokeinterface 180 1 0
      //   279: checkcast 182	android/content/pm/ResolveInfo
      //   282: astore 20
      //   284: aload_3
      //   285: invokevirtual 185	android/content/Context:getPackageName	()Ljava/lang/String;
      //   288: aload 20
      //   290: getfield 189	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
      //   293: getfield 195	android/content/pm/ActivityInfo:packageName	Ljava/lang/String;
      //   296: invokevirtual 141	java/lang/String:equals	(Ljava/lang/Object;)Z
      //   299: ifeq +9 -> 308
      //   302: iconst_1
      //   303: istore 21
      //   305: goto +46 -> 351
      //   308: aload 20
      //   310: getfield 189	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
      //   313: getfield 198	android/content/pm/ActivityInfo:exported	Z
      //   316: ifeq +32 -> 348
      //   319: aload 20
      //   321: getfield 189	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
      //   324: getfield 201	android/content/pm/ActivityInfo:permission	Ljava/lang/String;
      //   327: ifnull -25 -> 302
      //   330: aload_3
      //   331: aload 20
      //   333: getfield 189	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
      //   336: getfield 201	android/content/pm/ActivityInfo:permission	Ljava/lang/String;
      //   339: invokevirtual 205	android/content/Context:checkSelfPermission	(Ljava/lang/String;)I
      //   342: ifne +6 -> 348
      //   345: goto -43 -> 302
      //   348: iconst_0
      //   349: istore 21
      //   351: iload 21
      //   353: ifeq -91 -> 262
      //   356: aload 12
      //   358: aload 20
      //   360: invokeinterface 208 2 0
      //   365: pop
      //   366: goto -104 -> 262
      //   369: iconst_0
      //   370: istore 13
      //   372: iload 13
      //   374: aload 12
      //   376: invokeinterface 209 1 0
      //   381: if_icmpge +132 -> 513
      //   384: aload 12
      //   386: iload 13
      //   388: invokeinterface 213 2 0
      //   393: checkcast 182	android/content/pm/ResolveInfo
      //   396: astore 14
      //   398: aload_2
      //   399: iconst_0
      //   400: iconst_0
      //   401: iload 13
      //   403: bipush 100
      //   405: iadd
      //   406: aload 14
      //   408: aload 4
      //   410: invokevirtual 217	android/content/pm/ResolveInfo:loadLabel	(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
      //   413: invokeinterface 220 5 0
      //   418: astore 15
      //   420: aload_0
      //   421: getfield 34	androidx/core/widget/i$a:b	Landroid/widget/TextView;
      //   424: astore 16
      //   426: invokestatic 158	androidx/core/widget/i$a:a	()Landroid/content/Intent;
      //   429: astore 17
      //   431: aload 16
      //   433: instanceof 222
      //   436: ifeq +25 -> 461
      //   439: aload 16
      //   441: invokevirtual 225	android/widget/TextView:onCheckIsTextEditor	()Z
      //   444: ifeq +17 -> 461
      //   447: aload 16
      //   449: invokevirtual 228	android/widget/TextView:isEnabled	()Z
      //   452: ifeq +9 -> 461
      //   455: iconst_1
      //   456: istore 18
      //   458: goto +6 -> 464
      //   461: iconst_0
      //   462: istore 18
      //   464: aload 15
      //   466: aload 17
      //   468: ldc 230
      //   470: iload 18
      //   472: iconst_1
      //   473: ixor
      //   474: invokevirtual 234	android/content/Intent:putExtra	(Ljava/lang/String;Z)Landroid/content/Intent;
      //   477: aload 14
      //   479: getfield 189	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
      //   482: getfield 195	android/content/pm/ActivityInfo:packageName	Ljava/lang/String;
      //   485: aload 14
      //   487: getfield 189	android/content/pm/ResolveInfo:activityInfo	Landroid/content/pm/ActivityInfo;
      //   490: getfield 237	android/content/pm/ActivityInfo:name	Ljava/lang/String;
      //   493: invokevirtual 241	android/content/Intent:setClassName	(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
      //   496: invokeinterface 245 2 0
      //   501: iconst_1
      //   502: invokeinterface 248 2 0
      //   507: iinc 13 1
      //   510: goto -138 -> 372
      //   513: aload_0
      //   514: getfield 32	androidx/core/widget/i$a:a	Landroid/view/ActionMode$Callback;
      //   517: aload_1
      //   518: aload_2
      //   519: invokeinterface 250 3 0
      //   524: ireturn
      //
      // Exception table:
      //   from	to	target	type
      //   26	72	75	java/lang/ClassNotFoundException
      //   26	72	75	java/lang/NoSuchMethodException
      //   90	114	513	java/lang/NoSuchMethodException
      //   90	114	513	java/lang/IllegalAccessException
      //   90	114	513	java/lang/reflect/InvocationTargetException
      //   117	147	513	java/lang/NoSuchMethodException
      //   117	147	513	java/lang/IllegalAccessException
      //   117	147	513	java/lang/reflect/InvocationTargetException
      //   147	157	513	java/lang/NoSuchMethodException
      //   147	157	513	java/lang/IllegalAccessException
      //   147	157	513	java/lang/reflect/InvocationTargetException
      //   162	224	513	java/lang/NoSuchMethodException
      //   162	224	513	java/lang/IllegalAccessException
      //   162	224	513	java/lang/reflect/InvocationTargetException
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.i
 * JD-Core Version:    0.6.2
 */