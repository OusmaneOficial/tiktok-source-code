package androidx.core.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build.VERSION;
import android.widget.EdgeEffect;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
{
  private EdgeEffect a;

  static
  {
    CoverageLogger.Log(46432256);
  }

  public d(Context paramContext)
  {
    this.a = new EdgeEffect(paramContext);
  }

  public static void a(EdgeEffect paramEdgeEffect, float paramFloat1, float paramFloat2)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramEdgeEffect.onPull(paramFloat1, paramFloat2);
      return;
    }
    paramEdgeEffect.onPull(paramFloat1);
  }

  public final void a(int paramInt1, int paramInt2)
  {
    this.a.setSize(paramInt1, paramInt2);
  }

  public final boolean a()
  {
    return this.a.isFinished();
  }

  public final boolean a(float paramFloat)
  {
    this.a.onPull(paramFloat);
    return true;
  }

  public final boolean a(Canvas paramCanvas)
  {
    return this.a.draw(paramCanvas);
  }

  public final void b()
  {
    this.a.finish();
  }

  public final boolean c()
  {
    this.a.onRelease();
    return this.a.isFinished();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.d
 * JD-Core Version:    0.6.2
 */