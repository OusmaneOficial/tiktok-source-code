package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface j
{
  static
  {
    CoverageLogger.Log(46139392);
  }

  public abstract void setSupportButtonTintList(ColorStateList paramColorStateList);

  public abstract void setSupportButtonTintMode(PorterDuff.Mode paramMode);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.j
 * JD-Core Version:    0.6.2
 */