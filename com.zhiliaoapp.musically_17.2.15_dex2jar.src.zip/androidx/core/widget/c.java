package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.widget.CompoundButton;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;

public final class c
{
  private static Field a;
  private static boolean b;

  static
  {
    CoverageLogger.Log(46172160);
  }

  // ERROR //
  public static android.graphics.drawable.Drawable a(CompoundButton paramCompoundButton)
  {
    // Byte code:
    //   0: getstatic 28	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 23
    //   5: if_icmplt +8 -> 13
    //   8: aload_0
    //   9: invokevirtual 34	android/widget/CompoundButton:getButtonDrawable	()Landroid/graphics/drawable/Drawable;
    //   12: areturn
    //   13: getstatic 36	androidx/core/widget/c:b	Z
    //   16: ifne +31 -> 47
    //   19: ldc 30
    //   21: ldc 38
    //   23: invokevirtual 44	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   26: astore 4
    //   28: aload 4
    //   30: putstatic 46	androidx/core/widget/c:a	Ljava/lang/reflect/Field;
    //   33: aload 4
    //   35: iconst_1
    //   36: invokevirtual 52	java/lang/reflect/Field:setAccessible	(Z)V
    //   39: goto +4 -> 43
    //   42: pop
    //   43: iconst_1
    //   44: putstatic 36	androidx/core/widget/c:b	Z
    //   47: getstatic 46	androidx/core/widget/c:a	Ljava/lang/reflect/Field;
    //   50: astore_1
    //   51: aload_1
    //   52: ifnull +18 -> 70
    //   55: aload_1
    //   56: aload_0
    //   57: invokevirtual 56	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   60: checkcast 58	android/graphics/drawable/Drawable
    //   63: astore_2
    //   64: aload_2
    //   65: areturn
    //   66: aconst_null
    //   67: putstatic 46	androidx/core/widget/c:a	Ljava/lang/reflect/Field;
    //   70: aconst_null
    //   71: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   19	39	42	java/lang/NoSuchFieldException
    //   55	64	66	java/lang/IllegalAccessException
  }

  public static void a(CompoundButton paramCompoundButton, ColorStateList paramColorStateList)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramCompoundButton.setButtonTintList(paramColorStateList);
      return;
    }
    if ((paramCompoundButton instanceof j))
      ((j)paramCompoundButton).setSupportButtonTintList(paramColorStateList);
  }

  public static void a(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramCompoundButton.setButtonTintMode(paramMode);
      return;
    }
    if ((paramCompoundButton instanceof j))
      ((j)paramCompoundButton).setSupportButtonTintMode(paramMode);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.c
 * JD-Core Version:    0.6.2
 */