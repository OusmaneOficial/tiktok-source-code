package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface k
{
  static
  {
    CoverageLogger.Log(46137344);
  }

  public abstract ColorStateList getSupportImageTintList();

  public abstract PorterDuff.Mode getSupportImageTintMode();

  public abstract void setSupportImageTintList(ColorStateList paramColorStateList);

  public abstract void setSupportImageTintMode(PorterDuff.Mode paramMode);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.k
 * JD-Core Version:    0.6.2
 */