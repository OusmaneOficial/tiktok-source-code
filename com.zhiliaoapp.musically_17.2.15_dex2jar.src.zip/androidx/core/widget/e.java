package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.widget.ImageView;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
{
  static
  {
    CoverageLogger.Log(46434304);
  }

  public static ColorStateList a(ImageView paramImageView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramImageView.getImageTintList();
    if ((paramImageView instanceof k))
      return ((k)paramImageView).getSupportImageTintList();
    return null;
  }

  public static void a(ImageView paramImageView, ColorStateList paramColorStateList)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramImageView.setImageTintList(paramColorStateList);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramImageView.getDrawable();
        int i;
        if ((paramImageView.getImageTintList() != null) && (paramImageView.getImageTintMode() != null))
          i = 1;
        else
          i = 0;
        if ((localDrawable != null) && (i != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramImageView.getDrawableState());
          paramImageView.setImageDrawable(localDrawable);
        }
      }
    }
    else if ((paramImageView instanceof k))
    {
      ((k)paramImageView).setSupportImageTintList(paramColorStateList);
    }
  }

  public static void a(ImageView paramImageView, PorterDuff.Mode paramMode)
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      paramImageView.setImageTintMode(paramMode);
      if (Build.VERSION.SDK_INT == 21)
      {
        Drawable localDrawable = paramImageView.getDrawable();
        int i;
        if ((paramImageView.getImageTintList() != null) && (paramImageView.getImageTintMode() != null))
          i = 1;
        else
          i = 0;
        if ((localDrawable != null) && (i != 0))
        {
          if (localDrawable.isStateful())
            localDrawable.setState(paramImageView.getDrawableState());
          paramImageView.setImageDrawable(localDrawable);
        }
      }
    }
    else if ((paramImageView instanceof k))
    {
      ((k)paramImageView).setSupportImageTintMode(paramMode);
    }
  }

  public static PorterDuff.Mode b(ImageView paramImageView)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramImageView.getImageTintMode();
    if ((paramImageView instanceof k))
      return ((k)paramImageView).getSupportImageTintMode();
    return null;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.e
 * JD-Core Version:    0.6.2
 */