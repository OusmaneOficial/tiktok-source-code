package androidx.core.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class a
  implements View.OnTouchListener
{
  private static final int r = ViewConfiguration.getTapTimeout();
  final a a = new a();
  final View b;
  boolean c;
  boolean d;
  boolean e;
  public boolean f;
  public boolean g;
  private final Interpolator h = new AccelerateInterpolator();
  private Runnable i;
  private float[] j = { 0.0F, 0.0F };
  private float[] k = { 3.4028235E+38F, 3.4028235E+38F };
  private int l;
  private int m;
  private float[] n = { 0.0F, 0.0F };
  private float[] o = { 0.0F, 0.0F };
  private float[] p = { 3.4028235E+38F, 3.4028235E+38F };
  private boolean q;

  static
  {
    CoverageLogger.Log(46430208);
  }

  public a(View paramView)
  {
    this.b = paramView;
    DisplayMetrics localDisplayMetrics = Resources.getSystem().getDisplayMetrics();
    int i1 = (int)(0.5F + 1575.0F * localDisplayMetrics.density);
    int i2 = (int)(0.5F + 315.0F * localDisplayMetrics.density);
    float f1 = i1;
    float[] arrayOfFloat1 = this.p;
    float f2 = f1 / 1000.0F;
    arrayOfFloat1[0] = f2;
    arrayOfFloat1[1] = f2;
    float f3 = i2;
    float[] arrayOfFloat2 = this.o;
    float f4 = f3 / 1000.0F;
    arrayOfFloat2[0] = f4;
    arrayOfFloat2[1] = f4;
    this.l = 1;
    float[] arrayOfFloat3 = this.k;
    arrayOfFloat3[0] = 3.4028235E+38F;
    arrayOfFloat3[1] = 3.4028235E+38F;
    float[] arrayOfFloat4 = this.j;
    arrayOfFloat4[0] = 0.2F;
    arrayOfFloat4[1] = 0.2F;
    float[] arrayOfFloat5 = this.n;
    arrayOfFloat5[0] = 0.001F;
    arrayOfFloat5[1] = 0.001F;
    this.m = r;
    a locala = this.a;
    locala.a = 500;
    locala.b = 500;
  }

  private float a(float paramFloat1, float paramFloat2)
  {
    if (paramFloat2 == 0.0F)
      return 0.0F;
    int i1 = this.l;
    if ((i1 != 0) && (i1 != 1))
    {
      if (i1 != 2)
        return 0.0F;
      if (paramFloat1 < 0.0F)
        return paramFloat1 / -paramFloat2;
    }
    else if (paramFloat1 < paramFloat2)
    {
      if (paramFloat1 >= 0.0F)
        return 1.0F - paramFloat1 / paramFloat2;
      if ((this.e) && (this.l == 1))
        return 1.0F;
    }
    return 0.0F;
  }

  static float a(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if (paramFloat1 > paramFloat3)
      return paramFloat3;
    if (paramFloat1 < paramFloat2)
      return paramFloat2;
    return paramFloat1;
  }

  private float a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    float f1 = a(paramFloat1 * paramFloat2, 0.0F, paramFloat3);
    float f2 = a(paramFloat4, f1);
    float f3 = a(paramFloat2 - paramFloat4, f1) - f2;
    float f4;
    if (f3 < 0.0F)
    {
      f4 = -this.h.getInterpolation(-f3);
    }
    else
    {
      if (f3 <= 0.0F)
        break label89;
      f4 = this.h.getInterpolation(f3);
    }
    return a(f4, -1.0F, 1.0F);
    label89: return 0.0F;
  }

  private float a(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
  {
    float f1 = a(this.j[paramInt], paramFloat2, this.k[paramInt], paramFloat1);
    if (f1 == 0.0F)
      return 0.0F;
    float f2 = this.n[paramInt];
    float f3 = this.o[paramInt];
    float f4 = this.p[paramInt];
    float f5 = f2 * paramFloat3;
    if (f1 > 0.0F)
      return a(f1 * f5, f3, f4);
    return -a(f5 * -f1, f3, f4);
  }

  static int a(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 > paramInt3)
      return paramInt3;
    if (paramInt1 < 0)
      paramInt1 = 0;
    return paramInt1;
  }

  private void b()
  {
    if (this.c)
    {
      this.e = false;
      return;
    }
    this.a.a();
  }

  public final a a(boolean paramBoolean)
  {
    if ((this.f) && (!paramBoolean))
      b();
    this.f = paramBoolean;
    return this;
  }

  public abstract void a(int paramInt1, int paramInt2);

  final boolean a()
  {
    a locala = this.a;
    int i1 = locala.c();
    locala.b();
    return (i1 != 0) && (a(i1));
  }

  public abstract boolean a(int paramInt);

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    if (!this.f)
      return false;
    int i1 = paramMotionEvent.getActionMasked();
    if (i1 != 0)
    {
      if (i1 != 1)
      {
        if (i1 != 2)
          if (i1 != 3)
            break label213;
      }
      else
      {
        b();
        break label213;
      }
    }
    else
    {
      this.d = true;
      this.q = false;
    }
    float f1 = a(0, paramMotionEvent.getX(), paramView.getWidth(), this.b.getWidth());
    float f2 = a(1, paramMotionEvent.getY(), paramView.getHeight(), this.b.getHeight());
    a locala = this.a;
    locala.c = f1;
    locala.d = f2;
    if ((!this.e) && (a()))
    {
      if (this.i == null)
        this.i = new b();
      this.e = true;
      this.c = true;
      if (!this.q)
      {
        int i2 = this.m;
        if (i2 > 0)
        {
          t.a(this.b, this.i, i2);
          break label208;
        }
      }
      this.i.run();
      label208: this.q = true;
    }
    label213: return (this.g) && (this.e);
  }

  static final class a
  {
    public int a;
    public int b;
    float c;
    float d;
    long e = -9223372036854775808L;
    long f;
    public int g;
    public int h;
    long i = -1L;
    float j;
    int k;

    static
    {
      CoverageLogger.Log(46428160);
    }

    float a(long paramLong)
    {
      if (paramLong < this.e)
        return 0.0F;
      long l1 = this.i;
      if ((l1 >= 0L) && (paramLong >= l1))
      {
        long l2 = paramLong - l1;
        float f1 = this.j;
        return 1.0F - f1 + f1 * a.a((float)l2 / this.k, 0.0F, 1.0F);
      }
      return 0.5F * a.a((float)(paramLong - this.e) / this.a, 0.0F, 1.0F);
    }

    public final void a()
    {
      long l = AnimationUtils.currentAnimationTimeMillis();
      this.k = a.a((int)(l - this.e), 0, this.b);
      this.j = a(l);
      this.i = l;
    }

    public final int b()
    {
      float f1 = this.c;
      return (int)(f1 / Math.abs(f1));
    }

    public final int c()
    {
      float f1 = this.d;
      return (int)(f1 / Math.abs(f1));
    }
  }

  final class b
    implements Runnable
  {
    static
    {
      CoverageLogger.Log(46176256);
    }

    b()
    {
    }

    public final void run()
    {
      if (!a.this.e)
        return;
      if (a.this.c)
      {
        a locala3 = a.this;
        locala3.c = false;
        a.a locala4 = locala3.a;
        locala4.e = AnimationUtils.currentAnimationTimeMillis();
        locala4.i = -1L;
        locala4.f = locala4.e;
        locala4.j = 0.5F;
        locala4.g = 0;
        locala4.h = 0;
      }
      a.a locala1 = a.this.a;
      int i;
      if ((locala1.i > 0L) && (AnimationUtils.currentAnimationTimeMillis() > locala1.i + locala1.k))
        i = 1;
      else
        i = 0;
      if ((i == 0) && (a.this.a()))
      {
        if (a.this.d)
        {
          a locala2 = a.this;
          locala2.d = false;
          long l3 = SystemClock.uptimeMillis();
          MotionEvent localMotionEvent = MotionEvent.obtain(l3, l3, 3, 0.0F, 0.0F, 0);
          locala2.b.onTouchEvent(localMotionEvent);
          localMotionEvent.recycle();
        }
        if (locala1.f != 0L)
        {
          long l1 = AnimationUtils.currentAnimationTimeMillis();
          float f1 = locala1.a(l1);
          float f2 = f1 * (-4.0F * f1) + f1 * 4.0F;
          long l2 = l1 - locala1.f;
          locala1.f = l1;
          float f3 = f2 * (float)l2;
          locala1.g = ((int)(f3 * locala1.c));
          locala1.h = ((int)(f3 * locala1.d));
          int j = locala1.g;
          int k = locala1.h;
          a.this.a(j, k);
          t.a(a.this.b, this);
          return;
        }
        throw new RuntimeException("Cannot compute scroll delta before calling start()");
      }
      a.this.e = false;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.a
 * JD-Core Version:    0.6.2
 */