package androidx.core.widget;

import android.os.Build.VERSION;
import android.view.View;
import android.widget.PopupWindow;
import androidx.core.h.d;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class g
{
  private static Method a;
  private static boolean b;
  private static Field c;
  private static boolean d;

  static
  {
    CoverageLogger.Log(46153728);
  }

  public static void a(PopupWindow paramPopupWindow, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      paramPopupWindow.setWindowLayoutType(paramInt);
      return;
    }
    if (!b)
    {
      try
      {
        Class[] arrayOfClass = new Class[1];
        arrayOfClass[0] = Integer.TYPE;
        Method localMethod2 = PopupWindow.class.getDeclaredMethod("setWindowLayoutType", arrayOfClass);
        a = localMethod2;
        localMethod2.setAccessible(true);
      }
      catch (Exception localException1)
      {
      }
      b = true;
    }
    Method localMethod1 = a;
    if (localMethod1 != null);
    try
    {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(paramInt);
      localMethod1.invoke(paramPopupWindow, arrayOfObject);
    }
    catch (Exception localException2)
    {
    }
  }

  public static void a(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      paramPopupWindow.showAsDropDown(paramView, paramInt1, paramInt2, paramInt3);
      return;
    }
    if ((0x7 & d.a(paramInt3, t.f(paramView))) == 5)
      paramInt1 -= paramPopupWindow.getWidth() - paramView.getWidth();
    paramPopupWindow.showAsDropDown(paramView, paramInt1, paramInt2);
  }

  public static void a(PopupWindow paramPopupWindow, boolean paramBoolean)
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      paramPopupWindow.setOverlapAnchor(paramBoolean);
      return;
    }
    Field localField1;
    if (Build.VERSION.SDK_INT >= 21)
    {
      if (!d)
      {
        try
        {
          Field localField2 = PopupWindow.class.getDeclaredField("mOverlapAnchor");
          c = localField2;
          localField2.setAccessible(true);
        }
        catch (NoSuchFieldException localNoSuchFieldException)
        {
        }
        d = true;
      }
      localField1 = c;
      if (localField1 == null);
    }
    try
    {
      localField1.set(paramPopupWindow, Boolean.valueOf(paramBoolean));
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.widget.g
 * JD-Core Version:    0.6.2
 */