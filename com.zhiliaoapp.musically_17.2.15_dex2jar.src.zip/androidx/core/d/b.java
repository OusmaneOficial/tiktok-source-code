package androidx.core.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b
{
  static
  {
    CoverageLogger.Log(46512128);
  }

  // ERROR //
  public static java.lang.String a(java.io.File paramFile)
  {
    // Byte code:
    //   0: getstatic 23	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 19
    //   5: if_icmplt +8 -> 13
    //   8: aload_0
    //   9: invokestatic 28	android/os/Environment:getStorageState	(Ljava/io/File;)Ljava/lang/String;
    //   12: areturn
    //   13: aload_0
    //   14: invokevirtual 34	java/io/File:getCanonicalPath	()Ljava/lang/String;
    //   17: invokestatic 38	android/os/Environment:getExternalStorageDirectory	()Ljava/io/File;
    //   20: invokevirtual 34	java/io/File:getCanonicalPath	()Ljava/lang/String;
    //   23: invokevirtual 44	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   26: ifeq +9 -> 35
    //   29: invokestatic 47	android/os/Environment:getExternalStorageState	()Ljava/lang/String;
    //   32: astore_1
    //   33: aload_1
    //   34: areturn
    //   35: ldc 49
    //   37: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   13	33	35	java/io/IOException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.d.b
 * JD-Core Version:    0.6.2
 */