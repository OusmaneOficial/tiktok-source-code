package androidx.core.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c extends RuntimeException
{
  static
  {
    CoverageLogger.Log(46389248);
  }

  public c()
  {
    this(null);
  }

  public c(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.d.c
 * JD-Core Version:    0.6.2
 */