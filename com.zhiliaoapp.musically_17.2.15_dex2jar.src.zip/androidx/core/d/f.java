package androidx.core.d;

import android.os.Build.VERSION;
import android.os.Trace;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class f
{
  static
  {
    CoverageLogger.Log(46516224);
  }

  public static void a()
  {
    if (Build.VERSION.SDK_INT >= 18)
      Trace.endSection();
  }

  public static void a(String paramString)
  {
    if (Build.VERSION.SDK_INT >= 18)
      Trace.beginSection(paramString);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.d.f
 * JD-Core Version:    0.6.2
 */