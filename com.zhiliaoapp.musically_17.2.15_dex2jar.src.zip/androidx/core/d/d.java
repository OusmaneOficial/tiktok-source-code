package androidx.core.d;

import android.os.Parcel;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
{
  static
  {
    CoverageLogger.Log(46514176);
  }

  public static <T> Parcelable.Creator<T> a(e<T> parame)
  {
    return new a(parame);
  }

  static final class a<T>
    implements Parcelable.ClassLoaderCreator<T>
  {
    private final e<T> a;

    static
    {
      CoverageLogger.Log(46385152);
    }

    a(e<T> parame)
    {
      this.a = parame;
    }

    public final T createFromParcel(Parcel paramParcel)
    {
      return this.a.a(paramParcel, null);
    }

    public final T createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      return this.a.a(paramParcel, paramClassLoader);
    }

    public final T[] newArray(int paramInt)
    {
      return this.a.a(paramInt);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.d.d
 * JD-Core Version:    0.6.2
 */