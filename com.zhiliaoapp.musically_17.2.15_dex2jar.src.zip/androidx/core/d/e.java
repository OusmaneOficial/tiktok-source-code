package androidx.core.d;

import android.os.Parcel;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface e<T>
{
  static
  {
    CoverageLogger.Log(46381056);
  }

  public abstract T a(Parcel paramParcel, ClassLoader paramClassLoader);

  public abstract T[] a(int paramInt);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.d.e
 * JD-Core Version:    0.6.2
 */