package androidx.core.d;

import android.os.Build.VERSION;
import android.os.CancellationSignal;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  private boolean a;
  private a b;
  private Object c;
  private boolean d;

  static
  {
    CoverageLogger.Log(46499840);
  }

  // ERROR //
  public final void a(a parama)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: goto +4 -> 6
    //   5: pop
    //   6: aload_0
    //   7: getfield 28	androidx/core/d/a:d	Z
    //   10: istore_3
    //   11: iload_3
    //   12: ifeq +10 -> 22
    //   15: aload_0
    //   16: invokevirtual 31	java/lang/Object:wait	()V
    //   19: goto -14 -> 5
    //   22: aload_0
    //   23: getfield 33	androidx/core/d/a:b	Landroidx/core/d/a$a;
    //   26: aload_1
    //   27: if_acmpne +6 -> 33
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: aload_0
    //   34: aload_1
    //   35: putfield 33	androidx/core/d/a:b	Landroidx/core/d/a$a;
    //   38: aload_0
    //   39: getfield 35	androidx/core/d/a:a	Z
    //   42: ifeq +19 -> 61
    //   45: aload_1
    //   46: ifnonnull +6 -> 52
    //   49: goto +12 -> 61
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_1
    //   55: invokeinterface 39 1 0
    //   60: return
    //   61: aload_0
    //   62: monitorexit
    //   63: return
    //   64: astore_2
    //   65: aload_0
    //   66: monitorexit
    //   67: goto +5 -> 72
    //   70: aload_2
    //   71: athrow
    //   72: goto -2 -> 70
    //
    // Exception table:
    //   from	to	target	type
    //   15	19	5	java/lang/InterruptedException
    //   5	6	64	finally
    //   6	11	64	finally
    //   15	19	64	finally
    //   22	32	64	finally
    //   33	45	64	finally
    //   52	54	64	finally
    //   61	63	64	finally
    //   65	67	64	finally
  }

  public final boolean a()
  {
    try
    {
      boolean bool = this.a;
      return bool;
    }
    finally
    {
    }
  }

  // ERROR //
  public final void b()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 35	androidx/core/d/a:a	Z
    //   6: ifeq +6 -> 12
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: aload_0
    //   13: iconst_1
    //   14: putfield 35	androidx/core/d/a:a	Z
    //   17: aload_0
    //   18: iconst_1
    //   19: putfield 28	androidx/core/d/a:d	Z
    //   22: aload_0
    //   23: getfield 33	androidx/core/d/a:b	Landroidx/core/d/a$a;
    //   26: astore_2
    //   27: aload_0
    //   28: getfield 42	androidx/core/d/a:c	Ljava/lang/Object;
    //   31: astore_3
    //   32: aload_0
    //   33: monitorexit
    //   34: aload_2
    //   35: ifnull +12 -> 47
    //   38: aload_2
    //   39: invokeinterface 39 1 0
    //   44: goto +3 -> 47
    //   47: aload_3
    //   48: ifnull +44 -> 92
    //   51: getstatic 48	android/os/Build$VERSION:SDK_INT	I
    //   54: bipush 16
    //   56: if_icmplt +36 -> 92
    //   59: aload_3
    //   60: checkcast 50	android/os/CancellationSignal
    //   63: invokevirtual 53	android/os/CancellationSignal:cancel	()V
    //   66: goto +26 -> 92
    //   69: aload_0
    //   70: monitorenter
    //   71: aload_0
    //   72: iconst_0
    //   73: putfield 28	androidx/core/d/a:d	Z
    //   76: aload_0
    //   77: invokevirtual 56	java/lang/Object:notifyAll	()V
    //   80: aload_0
    //   81: monitorexit
    //   82: aload 5
    //   84: athrow
    //   85: astore 6
    //   87: aload_0
    //   88: monitorexit
    //   89: aload 6
    //   91: athrow
    //   92: aload_0
    //   93: monitorenter
    //   94: aload_0
    //   95: iconst_0
    //   96: putfield 28	androidx/core/d/a:d	Z
    //   99: aload_0
    //   100: invokevirtual 56	java/lang/Object:notifyAll	()V
    //   103: aload_0
    //   104: monitorexit
    //   105: return
    //   106: astore 4
    //   108: aload_0
    //   109: monitorexit
    //   110: aload 4
    //   112: athrow
    //   113: astore_1
    //   114: aload_0
    //   115: monitorexit
    //   116: aload_1
    //   117: athrow
    //   118: astore 5
    //   120: goto -51 -> 69
    //
    // Exception table:
    //   from	to	target	type
    //   71	82	85	finally
    //   87	89	85	finally
    //   94	105	106	finally
    //   108	110	106	finally
    //   2	11	113	finally
    //   12	34	113	finally
    //   114	116	113	finally
    //   38	44	118	finally
    //   51	66	118	finally
  }

  public final Object c()
  {
    if (Build.VERSION.SDK_INT < 16)
      return null;
    try
    {
      if (this.c == null)
      {
        this.c = new CancellationSignal();
        if (this.a)
          ((CancellationSignal)this.c).cancel();
      }
      Object localObject2 = this.c;
      return localObject2;
    }
    finally
    {
    }
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(46505984);
    }

    public abstract void a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.d.a
 * JD-Core Version:    0.6.2
 */