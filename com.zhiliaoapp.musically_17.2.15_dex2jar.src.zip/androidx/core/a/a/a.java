package androidx.core.a.a;

import android.view.Menu;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a extends Menu
{
  static
  {
    CoverageLogger.Log(46495744);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.a.a.a
 * JD-Core Version:    0.6.2
 */