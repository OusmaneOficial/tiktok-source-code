package androidx.core.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  static
  {
    CoverageLogger.Log(46497792);
  }

  public static int a(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 < paramInt2)
      return paramInt2;
    if (paramInt1 > paramInt3)
      return paramInt3;
    return paramInt1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.b.a
 * JD-Core Version:    0.6.2
 */