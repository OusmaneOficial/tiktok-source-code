package androidx.core.g;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class g
{
  static
  {
    CoverageLogger.Log(46315520);
  }

  public static int a(int paramInt)
  {
    if (paramInt >= 0)
      return paramInt;
    throw new IllegalArgumentException();
  }

  public static <T> T a(T paramT)
  {
    if (paramT != null)
      return paramT;
    throw new NullPointerException();
  }

  public static <T> T a(T paramT, Object paramObject)
  {
    if (paramT != null)
      return paramT;
    throw new NullPointerException(String.valueOf(paramObject));
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.g.g
 * JD-Core Version:    0.6.2
 */