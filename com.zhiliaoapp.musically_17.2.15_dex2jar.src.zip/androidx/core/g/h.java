package androidx.core.g;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.PrintWriter;

public final class h
{
  private static final Object a = new Object();
  private static char[] b = new char[24];

  static
  {
    CoverageLogger.Log(46311424);
  }

  private static int a(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    if ((paramInt1 <= 99) && ((!paramBoolean) || (paramInt3 < 3)))
    {
      if ((paramInt1 <= 9) && ((!paramBoolean) || (paramInt3 < 2)))
      {
        if ((!paramBoolean) && (paramInt1 <= 0))
          return 0;
        return paramInt2 + 1;
      }
      return paramInt2 + 2;
    }
    return paramInt2 + 3;
  }

  private static int a(char[] paramArrayOfChar, int paramInt1, char paramChar, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    if ((paramBoolean) || (paramInt1 > 0))
    {
      int i;
      if (((paramBoolean) && (paramInt3 >= 3)) || (paramInt1 > 99))
      {
        int m = paramInt1 / 100;
        paramArrayOfChar[paramInt2] = ((char)(m + 48));
        i = paramInt2 + 1;
        paramInt1 -= m * 100;
      }
      else
      {
        i = paramInt2;
      }
      if (((paramBoolean) && (paramInt3 >= 2)) || (paramInt1 > 9) || (paramInt2 != i))
      {
        int j = paramInt1 / 10;
        paramArrayOfChar[i] = ((char)(j + 48));
        i++;
        paramInt1 -= j * 10;
      }
      paramArrayOfChar[i] = ((char)(paramInt1 + 48));
      int k = i + 1;
      paramArrayOfChar[k] = paramChar;
      paramInt2 = k + 1;
    }
    return paramInt2;
  }

  public static void a(long paramLong, PrintWriter paramPrintWriter, int paramInt)
  {
    while (true)
    {
      int m;
      int n;
      int i1;
      int i3;
      int i4;
      int j;
      boolean bool1;
      boolean bool2;
      boolean bool3;
      synchronized (a)
      {
        if (b.length < 0)
          b = new char[0];
        char[] arrayOfChar = b;
        int i = 1;
        if (paramLong == 0L)
        {
          arrayOfChar[0] = '0';
          continue;
          int k = (int)(paramLong % 1000L);
          m = (int)Math.floor(paramLong / 1000L);
          if (m <= 86400)
            break label333;
          n = m / 86400;
          m -= 86400 * n;
          if (m <= 3600)
            break label339;
          i1 = m / 3600;
          m -= i1 * 3600;
          if (m <= 60)
            break label345;
          int i2 = m / 60;
          i3 = m - i2 * 60;
          i4 = i2;
          arrayOfChar[0] = j;
          int i5 = a(arrayOfChar, n, 'd', 1, false, 0);
          if (i5 == 1)
            break label355;
          bool1 = true;
          int i6 = a(arrayOfChar, i1, 'h', i5, bool1, 0);
          if (i6 == 1)
            break label361;
          bool2 = true;
          int i7 = a(arrayOfChar, i4, 'm', i6, bool2, 0);
          if (i7 == 1)
            break label367;
          bool3 = true;
          int i8 = a(arrayOfChar, k, 'm', a(arrayOfChar, i3, 's', i7, bool3, 0), true, 0);
          arrayOfChar[i8] = 's';
          i += i8;
          paramPrintWriter.print(new String(b, 0, i));
          return;
        }
      }
      if (paramLong > 0L)
      {
        j = 43;
      }
      else
      {
        j = 45;
        paramLong = -paramLong;
        continue;
        label333: n = 0;
        continue;
        label339: i1 = 0;
        continue;
        label345: i3 = m;
        i4 = 0;
        continue;
        label355: bool1 = false;
        continue;
        label361: bool2 = false;
        continue;
        label367: bool3 = false;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.g.h
 * JD-Core Version:    0.6.2
 */