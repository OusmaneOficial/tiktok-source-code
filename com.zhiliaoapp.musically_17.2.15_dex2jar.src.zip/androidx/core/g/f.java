package androidx.core.g;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class f
{
  static
  {
    CoverageLogger.Log(46297088);
  }

  public static abstract interface a<T>
  {
    static
    {
      CoverageLogger.Log(46305280);
    }

    public abstract T acquire();

    public abstract boolean release(T paramT);
  }

  public static class b<T>
    implements f.a<T>
  {
    private final Object[] a;
    private int b;

    static
    {
      CoverageLogger.Log(46307328);
    }

    public b(int paramInt)
    {
      if (paramInt > 0)
      {
        this.a = new Object[paramInt];
        return;
      }
      throw new IllegalArgumentException("The max pool size must be > 0");
    }

    public T acquire()
    {
      int i = this.b;
      if (i > 0)
      {
        int j = i - 1;
        Object[] arrayOfObject = this.a;
        Object localObject = arrayOfObject[j];
        arrayOfObject[j] = null;
        this.b = (i - 1);
        return localObject;
      }
      return null;
    }

    public boolean release(T paramT)
    {
      for (int i = 0; i < this.b; i++)
        if (this.a[i] == paramT)
        {
          j = 1;
          break label33;
        }
      int j = 0;
      label33: if (j == 0)
      {
        int k = this.b;
        Object[] arrayOfObject = this.a;
        if (k < arrayOfObject.length)
        {
          arrayOfObject[k] = paramT;
          this.b = (k + 1);
          return true;
        }
        return false;
      }
      IllegalStateException localIllegalStateException = new IllegalStateException("Already in the pool!");
      while (true)
        throw localIllegalStateException;
    }
  }

  public static final class c<T> extends f.b<T>
  {
    private final Object a = new Object();

    static
    {
      CoverageLogger.Log(46301184);
    }

    public c(int paramInt)
    {
      super();
    }

    public final T acquire()
    {
      synchronized (this.a)
      {
        Object localObject3 = super.acquire();
        return localObject3;
      }
    }

    public final boolean release(T paramT)
    {
      synchronized (this.a)
      {
        boolean bool = super.release(paramT);
        return bool;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.g.f
 * JD-Core Version:    0.6.2
 */