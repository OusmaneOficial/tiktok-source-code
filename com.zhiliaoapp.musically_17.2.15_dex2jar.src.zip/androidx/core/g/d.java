package androidx.core.g;

import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Arrays;
import java.util.Objects;

public final class d
{
  static
  {
    CoverageLogger.Log(46594048);
  }

  public static int a(Object[] paramArrayOfObject)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return Objects.hash(paramArrayOfObject);
    return Arrays.hashCode(paramArrayOfObject);
  }

  public static boolean a(Object paramObject1, Object paramObject2)
  {
    if (Build.VERSION.SDK_INT >= 19)
      return Objects.equals(paramObject1, paramObject2);
    return (paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2)));
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.g.d
 * JD-Core Version:    0.6.2
 */