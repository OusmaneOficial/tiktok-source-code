package androidx.core.g;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.Writer;

public final class c extends Writer
{
  private final String a;
  private StringBuilder b = new StringBuilder(128);

  static
  {
    CoverageLogger.Log(46592000);
  }

  public c(String paramString)
  {
    this.a = paramString;
  }

  private void a()
  {
    if (this.b.length() > 0)
    {
      StringBuilder localStringBuilder = this.b;
      localStringBuilder.delete(0, localStringBuilder.length());
    }
  }

  public final void close()
  {
    a();
  }

  public final void flush()
  {
    a();
  }

  public final void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    for (int i = 0; i < paramInt2; i++)
    {
      char c = paramArrayOfChar[(paramInt1 + i)];
      if (c == '\n')
        a();
      else
        this.b.append(c);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.g.c
 * JD-Core Version:    0.6.2
 */