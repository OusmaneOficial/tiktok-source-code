package androidx.core.g;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e<F, S>
{
  public final F a;
  public final S b;

  static
  {
    CoverageLogger.Log(46309376);
  }

  public e(F paramF, S paramS)
  {
    this.a = paramF;
    this.b = paramS;
  }

  public static <A, B> e<A, B> a(A paramA, B paramB)
  {
    return new e(paramA, paramB);
  }

  public final boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof e))
      return false;
    e locale = (e)paramObject;
    return (d.a(locale.a, this.a)) && (d.a(locale.b, this.b));
  }

  public final int hashCode()
  {
    Object localObject1 = this.a;
    int i;
    if (localObject1 == null)
      i = 0;
    else
      i = localObject1.hashCode();
    Object localObject2 = this.b;
    int j;
    if (localObject2 == null)
      j = 0;
    else
      j = localObject2.hashCode();
    return i ^ j;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("Pair{");
    localStringBuilder.append(String.valueOf(this.a));
    localStringBuilder.append(" ");
    localStringBuilder.append(String.valueOf(this.b));
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.g.e
 * JD-Core Version:    0.6.2
 */