package androidx.core.g;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a<T>
{
  static
  {
    CoverageLogger.Log(46589952);
  }

  public abstract void accept(T paramT);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.g.a
 * JD-Core Version:    0.6.2
 */