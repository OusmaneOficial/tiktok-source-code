package androidx.core.e;

import android.util.Base64;
import androidx.core.g.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public final class a
{
  public final String a;
  public final String b;
  public final String c;
  public final List<List<byte[]>> d;
  public final int e;
  public final String f;

  static
  {
    CoverageLogger.Log(46379008);
  }

  public a(String paramString1, String paramString2, String paramString3, List<List<byte[]>> paramList)
  {
    this.a = ((String)g.a(paramString1));
    this.b = ((String)g.a(paramString2));
    this.c = ((String)g.a(paramString3));
    this.d = ((List)g.a(paramList));
    this.e = 0;
    StringBuilder localStringBuilder = new StringBuilder(this.a);
    localStringBuilder.append("-");
    localStringBuilder.append(this.b);
    localStringBuilder.append("-");
    localStringBuilder.append(this.c);
    this.f = localStringBuilder.toString();
  }

  public final String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    StringBuilder localStringBuilder2 = new StringBuilder("FontRequest {mProviderAuthority: ");
    localStringBuilder2.append(this.a);
    localStringBuilder2.append(", mProviderPackage: ");
    localStringBuilder2.append(this.b);
    localStringBuilder2.append(", mQuery: ");
    localStringBuilder2.append(this.c);
    localStringBuilder2.append(", mCertificates:");
    localStringBuilder1.append(localStringBuilder2.toString());
    for (int i = 0; i < this.d.size(); i++)
    {
      localStringBuilder1.append(" [");
      List localList = (List)this.d.get(i);
      for (int j = 0; j < localList.size(); j++)
      {
        localStringBuilder1.append(" \"");
        localStringBuilder1.append(Base64.encodeToString((byte[])localList.get(j), 0));
        localStringBuilder1.append("\"");
      }
      localStringBuilder1.append(" ]");
    }
    localStringBuilder1.append("}");
    StringBuilder localStringBuilder3 = new StringBuilder("mCertificatesArray: ");
    localStringBuilder3.append(this.e);
    localStringBuilder1.append(localStringBuilder3.toString());
    return localStringBuilder1.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.e.a
 * JD-Core Version:    0.6.2
 */