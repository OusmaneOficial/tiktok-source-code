package androidx.core.e;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public final class c
{
  final Object a = new Object();
  HandlerThread b;
  Handler c;
  final int d;
  private int e;
  private Handler.Callback f = new Handler.Callback()
  {
    static
    {
      CoverageLogger.Log(46360576);
    }

    public final boolean handleMessage(Message paramAnonymousMessage)
    {
      int i = paramAnonymousMessage.what;
      if (i != 0)
      {
        if (i != 1)
          return true;
        c localc2 = c.this;
        ((Runnable)paramAnonymousMessage.obj).run();
        synchronized (localc2.a)
        {
          localc2.c.removeMessages(0);
          localc2.c.sendMessageDelayed(localc2.c.obtainMessage(0), localc2.d);
          return true;
        }
      }
      c localc1 = c.this;
      synchronized (localc1.a)
      {
        if (localc1.c.hasMessages(1))
          return true;
        localc1.b.quit();
        localc1.b = null;
        localc1.c = null;
        return true;
      }
    }
  };
  private final int g;
  private final String h;

  static
  {
    CoverageLogger.Log(46538752);
  }

  public c(String paramString, int paramInt1, int paramInt2)
  {
    this.h = paramString;
    this.g = 10;
    this.d = 10000;
    this.e = 0;
  }

  public final <T> T a(final Callable<T> paramCallable, int paramInt)
    throws InterruptedException
  {
    final ReentrantLock localReentrantLock = new ReentrantLock();
    final Condition localCondition = localReentrantLock.newCondition();
    final AtomicReference localAtomicReference = new AtomicReference();
    final AtomicBoolean localAtomicBoolean = new AtomicBoolean(true);
    Runnable local3 = new Runnable()
    {
      static
      {
        CoverageLogger.Log(46534656);
      }

      public final void run()
      {
        try
        {
          localAtomicReference.set(paramCallable.call());
        }
        catch (Exception localException)
        {
        }
        localReentrantLock.lock();
        try
        {
          localAtomicBoolean.set(false);
          localCondition.signal();
          return;
        }
        finally
        {
          localReentrantLock.unlock();
        }
      }
    };
    a(local3);
    localReentrantLock.lock();
    try
    {
      if (!localAtomicBoolean.get())
      {
        Object localObject3 = localAtomicReference.get();
        localReentrantLock.unlock();
        return localObject3;
      }
      long l = TimeUnit.MILLISECONDS.toNanos(paramInt);
      do
      {
        try
        {
          l = localCondition.awaitNanos(l);
        }
        catch (InterruptedException localInterruptedException)
        {
        }
        if (!localAtomicBoolean.get())
        {
          Object localObject2 = localAtomicReference.get();
          localReentrantLock.unlock();
          return localObject2;
        }
      }
      while (l > 0L);
      throw new InterruptedException("timeout");
    }
    finally
    {
      localReentrantLock.unlock();
    }
    while (true)
      throw localObject1;
  }

  void a(Runnable paramRunnable)
  {
    synchronized (this.a)
    {
      if (this.b == null)
      {
        this.b = new HandlerThread(this.h, this.g);
        this.b.start();
        this.c = new Handler(this.b.getLooper(), this.f);
        this.e = (1 + this.e);
      }
      this.c.removeMessages(0);
      this.c.sendMessage(this.c.obtainMessage(1, paramRunnable));
      return;
    }
  }

  public static abstract interface a<T>
  {
    static
    {
      CoverageLogger.Log(46540800);
    }

    public abstract void a(T paramT);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.core.e.c
 * JD-Core Version:    0.6.2
 */