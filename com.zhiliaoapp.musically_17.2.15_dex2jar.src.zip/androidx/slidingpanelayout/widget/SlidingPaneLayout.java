package androidx.slidingpanelayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import androidx.core.content.b;
import androidx.core.h.t;
import androidx.customview.a.a;
import androidx.customview.view.AbsSavedState;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public final class SlidingPaneLayout extends ViewGroup
{
  public boolean a;
  View b;
  float c;
  int d;
  boolean e;
  final a f;
  boolean g;
  final ArrayList<a> h;
  private int i;
  private int j;
  private Drawable k;
  private Drawable l;
  private final int m;
  private float n;
  private int o;
  private float p;
  private float q;
  private b r;
  private boolean s;
  private final Rect t;
  private Method u;
  private Field v;
  private boolean w;

  static
  {
    CoverageLogger.Log(65458176);
  }

  private void a()
  {
    int i1 = getChildCount();
    for (int i2 = 0; i2 < i1; i2++)
    {
      View localView = getChildAt(i2);
      if (localView.getVisibility() == 4)
        localView.setVisibility(0);
    }
  }

  private void a(View paramView, float paramFloat, int paramInt)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    if ((paramFloat > 0.0F) && (paramInt != 0))
    {
      int i1 = (int)(paramFloat * ((0xFF000000 & paramInt) >>> 24)) << 24 | paramInt & 0xFFFFFF;
      if (localLayoutParams.d == null)
        localLayoutParams.d = new Paint();
      localLayoutParams.d.setColorFilter(new PorterDuffColorFilter(i1, PorterDuff.Mode.SRC_OVER));
      if (paramView.getLayerType() != 2)
        paramView.setLayerType(2, localLayoutParams.d);
      a(paramView);
      return;
    }
    if (paramView.getLayerType() != 0)
    {
      if (localLayoutParams.d != null)
        localLayoutParams.d.setColorFilter(null);
      a locala = new a(paramView);
      this.h.add(locala);
      t.a(this, locala);
    }
  }

  private boolean a(float paramFloat, int paramInt)
  {
    if (!this.a)
      return false;
    boolean bool = b();
    LayoutParams localLayoutParams = (LayoutParams)this.b.getLayoutParams();
    int i1;
    if (bool)
    {
      int i2 = getPaddingRight() + localLayoutParams.rightMargin;
      int i3 = this.b.getWidth();
      i1 = (int)(getWidth() - (i2 + paramFloat * this.d + i3));
    }
    else
    {
      i1 = (int)(getPaddingLeft() + localLayoutParams.leftMargin + paramFloat * this.d);
    }
    a locala = this.f;
    View localView = this.b;
    if (locala.a(localView, i1, localView.getTop()))
    {
      a();
      t.d(this);
      return true;
    }
    return false;
  }

  private boolean a(View paramView, int paramInt)
  {
    if ((!this.s) && (!a(0.0F, 0)))
      return false;
    this.g = false;
    return true;
  }

  private boolean b()
  {
    return t.f(this) == 1;
  }

  private boolean b(View paramView)
  {
    if (paramView == null)
      return false;
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    return (this.a) && (localLayoutParams.c) && (this.c > 0.0F);
  }

  // ERROR //
  final void a(View paramView)
  {
    // Byte code:
    //   0: getstatic 190	android/os/Build$VERSION:SDK_INT	I
    //   3: bipush 17
    //   5: if_icmplt +18 -> 23
    //   8: aload_1
    //   9: aload_1
    //   10: invokevirtual 69	android/view/View:getLayoutParams	()Landroid/view/ViewGroup$LayoutParams;
    //   13: checkcast 71	androidx/slidingpanelayout/widget/SlidingPaneLayout$LayoutParams
    //   16: getfield 76	androidx/slidingpanelayout/widget/SlidingPaneLayout$LayoutParams:d	Landroid/graphics/Paint;
    //   19: invokestatic 193	androidx/core/h/t:a	(Landroid/view/View;Landroid/graphics/Paint;)V
    //   22: return
    //   23: getstatic 190	android/os/Build$VERSION:SDK_INT	I
    //   26: bipush 16
    //   28: if_icmplt +97 -> 125
    //   31: aload_0
    //   32: getfield 195	androidx/slidingpanelayout/widget/SlidingPaneLayout:w	Z
    //   35: ifne +47 -> 82
    //   38: aload_0
    //   39: ldc 58
    //   41: ldc 197
    //   43: aconst_null
    //   44: invokevirtual 203	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   47: putfield 205	androidx/slidingpanelayout/widget/SlidingPaneLayout:u	Ljava/lang/reflect/Method;
    //   50: goto +4 -> 54
    //   53: pop
    //   54: aload_0
    //   55: ldc 58
    //   57: ldc 207
    //   59: invokevirtual 211	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   62: putfield 213	androidx/slidingpanelayout/widget/SlidingPaneLayout:v	Ljava/lang/reflect/Field;
    //   65: aload_0
    //   66: getfield 213	androidx/slidingpanelayout/widget/SlidingPaneLayout:v	Ljava/lang/reflect/Field;
    //   69: iconst_1
    //   70: invokevirtual 219	java/lang/reflect/Field:setAccessible	(Z)V
    //   73: goto +4 -> 77
    //   76: pop
    //   77: aload_0
    //   78: iconst_1
    //   79: putfield 195	androidx/slidingpanelayout/widget/SlidingPaneLayout:w	Z
    //   82: aload_0
    //   83: getfield 205	androidx/slidingpanelayout/widget/SlidingPaneLayout:u	Ljava/lang/reflect/Method;
    //   86: ifnull +34 -> 120
    //   89: aload_0
    //   90: getfield 213	androidx/slidingpanelayout/widget/SlidingPaneLayout:v	Ljava/lang/reflect/Field;
    //   93: astore_2
    //   94: aload_2
    //   95: ifnonnull +6 -> 101
    //   98: goto +22 -> 120
    //   101: aload_2
    //   102: aload_1
    //   103: iconst_1
    //   104: invokevirtual 223	java/lang/reflect/Field:setBoolean	(Ljava/lang/Object;Z)V
    //   107: aload_0
    //   108: getfield 205	androidx/slidingpanelayout/widget/SlidingPaneLayout:u	Ljava/lang/reflect/Method;
    //   111: aload_1
    //   112: aconst_null
    //   113: invokevirtual 229	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   116: pop
    //   117: goto +8 -> 125
    //   120: aload_1
    //   121: invokevirtual 232	android/view/View:invalidate	()V
    //   124: return
    //   125: aload_0
    //   126: aload_1
    //   127: invokevirtual 235	android/view/View:getLeft	()I
    //   130: aload_1
    //   131: invokevirtual 155	android/view/View:getTop	()I
    //   134: aload_1
    //   135: invokevirtual 238	android/view/View:getRight	()I
    //   138: aload_1
    //   139: invokevirtual 241	android/view/View:getBottom	()I
    //   142: invokestatic 244	androidx/core/h/t:a	(Landroid/view/View;IIII)V
    //   145: return
    //
    // Exception table:
    //   from	to	target	type
    //   38	50	53	java/lang/NoSuchMethodException
    //   53	54	76	java/lang/NoSuchFieldException
    //   54	73	76	java/lang/NoSuchFieldException
    //   101	117	125	java/lang/Exception
  }

  protected final boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return ((paramLayoutParams instanceof LayoutParams)) && (super.checkLayoutParams(paramLayoutParams));
  }

  public final void computeScroll()
  {
    if (this.f.a(true))
    {
      if (!this.a)
      {
        this.f.b();
        return;
      }
      t.d(this);
    }
  }

  public final void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    Drawable localDrawable;
    if (b())
      localDrawable = this.l;
    else
      localDrawable = this.k;
    View localView;
    if (getChildCount() > 1)
      localView = getChildAt(1);
    else
      localView = null;
    if (localView != null)
    {
      if (localDrawable == null)
        return;
      int i1 = localView.getTop();
      int i2 = localView.getBottom();
      int i3 = localDrawable.getIntrinsicWidth();
      int i7;
      int i6;
      if (b())
      {
        i7 = localView.getRight();
        i6 = i3 + i7;
      }
      else
      {
        int i4 = localView.getLeft();
        int i5 = i4 - i3;
        i6 = i4;
        i7 = i5;
      }
      localDrawable.setBounds(i7, i1, i6, i2);
      localDrawable.draw(paramCanvas);
    }
  }

  protected final boolean drawChild(Canvas paramCanvas, View paramView, long paramLong)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i1 = paramCanvas.save();
    if ((this.a) && (!localLayoutParams.b) && (this.b != null))
    {
      paramCanvas.getClipBounds(this.t);
      if (b())
      {
        Rect localRect2 = this.t;
        localRect2.left = Math.max(localRect2.left, this.b.getRight());
      }
      else
      {
        Rect localRect1 = this.t;
        localRect1.right = Math.min(localRect1.right, this.b.getLeft());
      }
      paramCanvas.clipRect(this.t);
    }
    boolean bool = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(i1);
    return bool;
  }

  protected final ViewGroup.LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams();
  }

  public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }

  protected final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams))
      return new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams);
    return new LayoutParams(paramLayoutParams);
  }

  public final int getCoveredFadeColor()
  {
    return this.j;
  }

  public final int getParallaxDistance()
  {
    return this.o;
  }

  public final int getSliderFadeColor()
  {
    return this.i;
  }

  protected final void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    this.s = true;
  }

  protected final void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.s = true;
    int i1 = this.h.size();
    for (int i2 = 0; i2 < i1; i2++)
      ((a)this.h.get(i2)).run();
    this.h.clear();
  }

  public final boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    int i1 = paramMotionEvent.getActionMasked();
    if ((!this.a) && (i1 == 0) && (getChildCount() > 1))
    {
      View localView = getChildAt(1);
      if (localView != null)
        this.g = (true ^ a.b(localView, (int)paramMotionEvent.getX(), (int)paramMotionEvent.getY()));
    }
    if ((this.a) && ((!this.e) || (i1 == 0)))
    {
      if ((i1 != 3) && (i1 != 1))
      {
        if (i1 != 0)
        {
          if (i1 == 2)
          {
            float f3 = paramMotionEvent.getX();
            float f4 = paramMotionEvent.getY();
            float f5 = Math.abs(f3 - this.p);
            float f6 = Math.abs(f4 - this.q);
            if ((f5 > this.f.b) && (f6 > f5))
            {
              this.f.a();
              this.e = true;
              return false;
            }
          }
        }
        else
        {
          this.e = false;
          float f1 = paramMotionEvent.getX();
          float f2 = paramMotionEvent.getY();
          this.p = f1;
          this.q = f2;
          if ((a.b(this.b, (int)f1, (int)f2)) && (b(this.b)))
          {
            i2 = 1;
            break label237;
          }
        }
        int i2 = 0;
        label237: if (!this.f.a(paramMotionEvent))
          return i2 != 0;
        return true;
      }
      this.f.a();
      return false;
    }
    this.f.a();
    return super.onInterceptTouchEvent(paramMotionEvent);
  }

  protected final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    boolean bool1 = b();
    if (bool1)
      this.f.j = 2;
    else
      this.f.j = 1;
    int i1 = paramInt3 - paramInt1;
    int i2;
    if (bool1)
      i2 = getPaddingRight();
    else
      i2 = getPaddingLeft();
    int i3;
    if (bool1)
      i3 = getPaddingLeft();
    else
      i3 = getPaddingRight();
    int i4 = getPaddingTop();
    int i5 = getChildCount();
    if (this.s)
    {
      float f4;
      if ((this.a) && (this.g))
        f4 = 1.0F;
      else
        f4 = 0.0F;
      this.c = f4;
    }
    int i6 = i2;
    int i7 = i6;
    int i9;
    for (int i8 = 0; ; i8++)
    {
      i9 = 8;
      if (i8 >= i5)
        break;
      View localView3 = getChildAt(i8);
      if (localView3.getVisibility() != i9)
      {
        LayoutParams localLayoutParams2 = (LayoutParams)localView3.getLayoutParams();
        int i36 = localView3.getMeasuredWidth();
        int i38;
        int i37;
        if (localLayoutParams2.b)
        {
          int i42 = localLayoutParams2.leftMargin + localLayoutParams2.rightMargin;
          int i43 = i1 - i3;
          int i44 = Math.min(i6, i43 - this.m) - i7 - i42;
          this.d = i44;
          int i45;
          if (bool1)
            i45 = localLayoutParams2.rightMargin;
          else
            i45 = localLayoutParams2.leftMargin;
          boolean bool5;
          if (i44 + (i7 + i45) + i36 / 2 > i43)
            bool5 = true;
          else
            bool5 = false;
          localLayoutParams2.c = bool5;
          int i46 = (int)(i44 * this.c);
          i38 = i7 + (i45 + i46);
          this.c = (i46 / this.d);
          i37 = 0;
        }
        else
        {
          if (this.a)
          {
            int i41 = this.o;
            if (i41 != 0)
            {
              i37 = (int)((1.0F - this.c) * i41);
              break label368;
            }
          }
          i37 = 0;
          label368: i38 = i6;
        }
        int i40;
        int i39;
        if (bool1)
        {
          i40 = i37 + (i1 - i38);
          i39 = i40 - i36;
        }
        else
        {
          i39 = i38 - i37;
          i40 = i39 + i36;
        }
        localView3.layout(i39, i4, i40, i4 + localView3.getMeasuredHeight());
        i6 += localView3.getWidth();
        i7 = i38;
      }
    }
    if (this.s)
    {
      if (this.a)
      {
        if (this.o != 0)
        {
          float f1 = this.c;
          boolean bool4 = b();
          LayoutParams localLayoutParams1 = (LayoutParams)this.b.getLayoutParams();
          if (localLayoutParams1.c)
          {
            int i35;
            if (bool4)
              i35 = localLayoutParams1.rightMargin;
            else
              i35 = localLayoutParams1.leftMargin;
            if (i35 <= 0)
            {
              i29 = 1;
              break label539;
            }
          }
          int i29 = 0;
          label539: int i30 = getChildCount();
          for (int i31 = 0; i31 < i30; i31++)
          {
            View localView2 = getChildAt(i31);
            int i10;
            Object localObject1;
            boolean bool2;
            int i11;
            int i12;
            int i13;
            int i14;
            int i28;
            Drawable localDrawable;
            int i16;
            int i15;
            int i17;
            int i18;
            int i19;
            int i20;
            if (localView2 != this.b)
            {
              float f2 = 1.0F - this.n;
              int i32 = this.o;
              int i33 = (int)(f2 * i32);
              this.n = f1;
              int i34 = i33 - (int)((1.0F - f1) * i32);
              if (bool4)
                i34 = -i34;
              localView2.offsetLeftAndRight(i34);
              if (i29 != 0)
              {
                float f3;
                if (bool4)
                  f3 = this.n - 1.0F;
                else
                  f3 = 1.0F - this.n;
                a(localView2, f3, this.j);
              }
            }
          }
        }
        if (((LayoutParams)this.b.getLayoutParams()).c)
          a(this.b, this.c, this.i);
      }
      else
      {
        for (i10 = 0; i10 < i5; i10++)
          a(getChildAt(i10), 0.0F, this.i);
      }
      localObject1 = this.b;
      bool2 = b();
      if (bool2)
        i11 = getWidth() - getPaddingRight();
      else
        i11 = getPaddingLeft();
      if (bool2)
        i12 = getPaddingLeft();
      else
        i12 = getWidth() - getPaddingRight();
      i13 = getPaddingTop();
      i14 = getHeight() - getPaddingBottom();
      if (localObject1 != null)
      {
        if (((View)localObject1).isOpaque());
        do
        {
          i28 = 1;
          break label881;
          if (Build.VERSION.SDK_INT >= 18)
            break;
          localDrawable = ((View)localObject1).getBackground();
        }
        while ((localDrawable != null) && (localDrawable.getOpacity() == -1));
        i28 = 0;
        label881: if (i28 != 0)
        {
          i16 = ((View)localObject1).getLeft();
          i15 = ((View)localObject1).getRight();
          i17 = ((View)localObject1).getTop();
          i18 = ((View)localObject1).getBottom();
          break label929;
        }
      }
      i15 = 0;
      i16 = 0;
      i17 = 0;
      i18 = 0;
      label929: i19 = getChildCount();
      i20 = 0;
      while (i20 < i19)
      {
        View localView1 = getChildAt(i20);
        if (localView1 == localObject1)
          break;
        Object localObject2;
        boolean bool3;
        if (localView1.getVisibility() != i9)
        {
          int i21;
          if (bool2)
            i21 = i12;
          else
            i21 = i11;
          int i22 = Math.max(i21, localView1.getLeft());
          int i23 = Math.max(i13, localView1.getTop());
          localObject2 = localObject1;
          bool3 = bool2;
          int i24;
          if (bool2)
            i24 = i11;
          else
            i24 = i12;
          int i25 = Math.min(i24, localView1.getRight());
          int i26 = Math.min(i14, localView1.getBottom());
          int i27;
          if ((i22 >= i16) && (i23 >= i17) && (i25 <= i15) && (i26 <= i18))
            i27 = 4;
          else
            i27 = 0;
          localView1.setVisibility(i27);
        }
        else
        {
          localObject2 = localObject1;
          bool3 = bool2;
        }
        i20++;
        bool2 = bool3;
        localObject1 = localObject2;
        i9 = 8;
      }
    }
    this.s = false;
  }

  protected final void onMeasure(int paramInt1, int paramInt2)
  {
    int i1 = View.MeasureSpec.getMode(paramInt1);
    int i2 = View.MeasureSpec.getSize(paramInt1);
    int i3 = View.MeasureSpec.getMode(paramInt2);
    int i4 = View.MeasureSpec.getSize(paramInt2);
    if (i1 != 1073741824)
    {
      if (isInEditMode())
      {
        if ((i1 != -2147483648) && (i1 == 0))
          i2 = 300;
      }
      else
        throw new IllegalStateException("Width must have an exact value or MATCH_PARENT");
    }
    else if (i3 == 0)
      if (isInEditMode())
      {
        if (i3 == 0)
        {
          i3 = -2147483648;
          i4 = 300;
        }
      }
      else
        throw new IllegalStateException("Height must not be UNSPECIFIED");
    int i6;
    int i5;
    if (i3 != -2147483648)
    {
      if (i3 != 1073741824)
      {
        i6 = 0;
        i5 = 0;
      }
      else
      {
        i6 = i4 - getPaddingTop() - getPaddingBottom();
        i5 = i6;
      }
    }
    else
    {
      i5 = i4 - getPaddingTop() - getPaddingBottom();
      i6 = 0;
    }
    int i7 = i2 - getPaddingLeft() - getPaddingRight();
    int i8 = getChildCount();
    this.b = null;
    int i9 = i6;
    int i10 = i7;
    int i11 = 0;
    boolean bool1 = false;
    float f1 = 0.0F;
    int i12;
    while (true)
    {
      i12 = 8;
      if (i11 >= i8)
        break;
      View localView2 = getChildAt(i11);
      LayoutParams localLayoutParams2 = (LayoutParams)localView2.getLayoutParams();
      if (localView2.getVisibility() == i12)
      {
        localLayoutParams2.c = false;
      }
      else if (localLayoutParams2.a > 0.0F)
      {
        f1 += localLayoutParams2.a;
        if (localLayoutParams2.width == 0);
      }
      else
      {
        int i24 = localLayoutParams2.leftMargin + localLayoutParams2.rightMargin;
        int i25;
        if (localLayoutParams2.width == -2)
          i25 = View.MeasureSpec.makeMeasureSpec(i7 - i24, -2147483648);
        else if (localLayoutParams2.width == -1)
          i25 = View.MeasureSpec.makeMeasureSpec(i7 - i24, 1073741824);
        else
          i25 = View.MeasureSpec.makeMeasureSpec(localLayoutParams2.width, 1073741824);
        int i26;
        if (localLayoutParams2.height == -2)
          i26 = View.MeasureSpec.makeMeasureSpec(i5, -2147483648);
        else if (localLayoutParams2.height == -1)
          i26 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        else
          i26 = View.MeasureSpec.makeMeasureSpec(localLayoutParams2.height, 1073741824);
        localView2.measure(i25, i26);
        int i27 = localView2.getMeasuredWidth();
        int i28 = localView2.getMeasuredHeight();
        if ((i3 == -2147483648) && (i28 > i9))
          i9 = Math.min(i28, i5);
        i10 -= i27;
        boolean bool2;
        if (i10 < 0)
          bool2 = true;
        else
          bool2 = false;
        localLayoutParams2.b = bool2;
        boolean bool3 = bool2 | bool1;
        if (localLayoutParams2.b)
          this.b = localView2;
        bool1 = bool3;
      }
      i11++;
    }
    if ((bool1) || (f1 > 0.0F))
    {
      int i13 = i7 - this.m;
      int i14 = 0;
      while (i14 < i8)
      {
        View localView1 = getChildAt(i14);
        if (localView1.getVisibility() != i12)
        {
          LayoutParams localLayoutParams1 = (LayoutParams)localView1.getLayoutParams();
          if (localView1.getVisibility() != i12)
          {
            int i16;
            if ((localLayoutParams1.width == 0) && (localLayoutParams1.a > 0.0F))
              i16 = 1;
            else
              i16 = 0;
            int i17;
            if (i16 != 0)
              i17 = 0;
            else
              i17 = localView1.getMeasuredWidth();
            if ((bool1) && (localView1 != this.b))
            {
              if ((localLayoutParams1.width < 0) && ((i17 > i13) || (localLayoutParams1.a > 0.0F)))
              {
                int i23;
                int i22;
                if (i16 != 0)
                {
                  if (localLayoutParams1.height == -2)
                  {
                    i23 = View.MeasureSpec.makeMeasureSpec(i5, -2147483648);
                    i22 = 1073741824;
                  }
                  else if (localLayoutParams1.height == -1)
                  {
                    i22 = 1073741824;
                    i23 = View.MeasureSpec.makeMeasureSpec(i5, i22);
                  }
                  else
                  {
                    i22 = 1073741824;
                    i23 = View.MeasureSpec.makeMeasureSpec(localLayoutParams1.height, i22);
                  }
                }
                else
                {
                  i22 = 1073741824;
                  i23 = View.MeasureSpec.makeMeasureSpec(localView1.getMeasuredHeight(), i22);
                }
                localView1.measure(View.MeasureSpec.makeMeasureSpec(i13, i22), i23);
              }
            }
            else if (localLayoutParams1.a > 0.0F)
            {
              int i18;
              if (localLayoutParams1.width == 0)
              {
                if (localLayoutParams1.height == -2)
                  i18 = View.MeasureSpec.makeMeasureSpec(i5, -2147483648);
                else if (localLayoutParams1.height == -1)
                  i18 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
                else
                  i18 = View.MeasureSpec.makeMeasureSpec(localLayoutParams1.height, 1073741824);
              }
              else
                i18 = View.MeasureSpec.makeMeasureSpec(localView1.getMeasuredHeight(), 1073741824);
              if (bool1)
              {
                int i20 = i7 - (localLayoutParams1.leftMargin + localLayoutParams1.rightMargin);
                i15 = i13;
                int i21 = View.MeasureSpec.makeMeasureSpec(i20, 1073741824);
                if (i17 == i20)
                  break label990;
                localView1.measure(i21, i18);
                break label990;
              }
              i15 = i13;
              int i19 = Math.max(0, i10);
              localView1.measure(View.MeasureSpec.makeMeasureSpec(i17 + (int)(localLayoutParams1.a * i19 / f1), 1073741824), i18);
              break label990;
            }
          }
        }
        int i15 = i13;
        label990: i14++;
        i13 = i15;
        i12 = 8;
      }
    }
    setMeasuredDimension(i2, i9 + getPaddingTop() + getPaddingBottom());
    this.a = bool1;
    if ((this.f.a != 0) && (!bool1))
      this.f.b();
  }

  protected final void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.d);
    if (localSavedState.a)
    {
      if ((this.s) || (a(1.0F, 0)))
        this.g = true;
    }
    else
      a(this.b, 0);
    this.g = localSavedState.a;
  }

  protected final Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    boolean bool1 = this.a;
    boolean bool2;
    if (bool1)
    {
      if ((bool1) && (this.c != 1.0F))
        bool2 = false;
      else
        bool2 = true;
    }
    else
      bool2 = this.g;
    localSavedState.a = bool2;
    return localSavedState;
  }

  protected final void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3)
      this.s = true;
  }

  public final boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (!this.a)
      return super.onTouchEvent(paramMotionEvent);
    this.f.b(paramMotionEvent);
    int i1 = paramMotionEvent.getActionMasked();
    if (i1 != 0)
    {
      if (i1 != 1)
        return true;
      if (b(this.b))
      {
        float f3 = paramMotionEvent.getX();
        float f4 = paramMotionEvent.getY();
        float f5 = f3 - this.p;
        float f6 = f4 - this.q;
        int i2 = this.f.b;
        if ((f5 * f5 + f6 * f6 < i2 * i2) && (a.b(this.b, (int)f3, (int)f4)))
        {
          a(this.b, 0);
          return true;
        }
      }
    }
    else
    {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      this.p = f1;
      this.q = f2;
    }
    return true;
  }

  public final void requestChildFocus(View paramView1, View paramView2)
  {
    super.requestChildFocus(paramView1, paramView2);
    if ((!isInTouchMode()) && (!this.a))
    {
      boolean bool;
      if (paramView1 == this.b)
        bool = true;
      else
        bool = false;
      this.g = bool;
    }
  }

  public final void setCoveredFadeColor(int paramInt)
  {
    this.j = paramInt;
  }

  public final void setPanelSlideListener(b paramb)
  {
    this.r = paramb;
  }

  public final void setParallaxDistance(int paramInt)
  {
    this.o = paramInt;
    requestLayout();
  }

  public final void setShadowDrawable(Drawable paramDrawable)
  {
    setShadowDrawableLeft(paramDrawable);
  }

  public final void setShadowDrawableLeft(Drawable paramDrawable)
  {
    this.k = paramDrawable;
  }

  public final void setShadowDrawableRight(Drawable paramDrawable)
  {
    this.l = paramDrawable;
  }

  public final void setShadowResource(int paramInt)
  {
    setShadowDrawable(getResources().getDrawable(paramInt));
  }

  public final void setShadowResourceLeft(int paramInt)
  {
    setShadowDrawableLeft(b.a(getContext(), paramInt));
  }

  public final void setShadowResourceRight(int paramInt)
  {
    setShadowDrawableRight(b.a(getContext(), paramInt));
  }

  public final void setSliderFadeColor(int paramInt)
  {
    this.i = paramInt;
  }

  public static class LayoutParams extends ViewGroup.MarginLayoutParams
  {
    private static final int[] e = { 16843137 };
    public float a;
    boolean b;
    boolean c;
    Paint d;

    static
    {
      CoverageLogger.Log(65124352);
    }

    public LayoutParams()
    {
      super(-1);
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, e);
      this.a = localTypedArray.getFloat(0, 0.0F);
      localTypedArray.recycle();
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
  }

  static class SavedState extends AbsSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.ClassLoaderCreator()
    {
      static
      {
        CoverageLogger.Log(65480704);
      }
    };
    boolean a;

    static
    {
      CoverageLogger.Log(65118208);
    }

    SavedState(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      super(null);
      boolean bool;
      if (paramParcel.readInt() != 0)
        bool = true;
      else
        bool = false;
      this.a = bool;
    }

    SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(this.a);
    }
  }

  final class a
    implements Runnable
  {
    final View a;

    static
    {
      CoverageLogger.Log(65466368);
    }

    a(View arg2)
    {
      Object localObject;
      this.a = localObject;
    }

    public final void run()
    {
      if (this.a.getParent() == SlidingPaneLayout.this)
      {
        this.a.setLayerType(0, null);
        SlidingPaneLayout.this.a(this.a);
      }
      SlidingPaneLayout.this.h.remove(this);
    }
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(65470464);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.slidingpanelayout.widget.SlidingPaneLayout
 * JD-Core Version:    0.6.2
 */