package androidx.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class b<E>
  implements Collection<E>, Set<E>
{
  private static final int[] c = new int[0];
  private static final Object[] d = new Object[0];
  private static Object[] e;
  private static int f;
  private static Object[] g;
  private static int h;
  Object[] a;
  int b;
  private int[] i;
  private f<E, E> j;

  static
  {
    CoverageLogger.Log(77006848);
  }

  public b()
  {
    this(0);
  }

  public b(int paramInt)
  {
    if (paramInt == 0)
    {
      this.i = c;
      this.a = d;
    }
    else
    {
      c(paramInt);
    }
    this.b = 0;
  }

  public b(Collection<E> paramCollection)
  {
    this();
    if (paramCollection != null)
      addAll(paramCollection);
  }

  private int a()
  {
    int k = this.b;
    if (k == 0)
      return -1;
    int m = c.a(this.i, k, 0);
    if (m < 0)
      return m;
    if (this.a[m] == null)
      return m;
    for (int n = m + 1; (n < k) && (this.i[n] == 0); n++)
      if (this.a[n] == null)
        return n;
    for (int i1 = m - 1; (i1 >= 0) && (this.i[i1] == 0); i1--)
      if (this.a[i1] == null)
        return i1;
    return n ^ 0xFFFFFFFF;
  }

  private int a(Object paramObject, int paramInt)
  {
    int k = this.b;
    if (k == 0)
      return -1;
    int m = c.a(this.i, k, paramInt);
    if (m < 0)
      return m;
    if (paramObject.equals(this.a[m]))
      return m;
    for (int n = m + 1; (n < k) && (this.i[n] == paramInt); n++)
      if (paramObject.equals(this.a[n]))
        return n;
    for (int i1 = m - 1; (i1 >= 0) && (this.i[i1] == paramInt); i1--)
      if (paramObject.equals(this.a[i1]))
        return i1;
    return n ^ 0xFFFFFFFF;
  }

  private static void a(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8)
      try
      {
        if (h < 10)
        {
          paramArrayOfObject[0] = g;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int m = paramInt - 1; m >= 2; m--)
            paramArrayOfObject[m] = null;
          g = paramArrayOfObject;
          h = 1 + h;
        }
        return;
      }
      finally
      {
      }
    if (paramArrayOfInt.length == 4)
      try
      {
        if (f < 10)
        {
          paramArrayOfObject[0] = e;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int k = paramInt - 1; k >= 2; k--)
            paramArrayOfObject[k] = null;
          e = paramArrayOfObject;
          f = 1 + f;
        }
        return;
      }
      finally
      {
      }
  }

  private void c(int paramInt)
  {
    if (paramInt == 8)
      try
      {
        if (g != null)
        {
          Object[] arrayOfObject2 = g;
          this.a = arrayOfObject2;
          g = (Object[])arrayOfObject2[0];
          this.i = ((int[])arrayOfObject2[1]);
          arrayOfObject2[1] = null;
          arrayOfObject2[0] = null;
          h -= 1;
          return;
        }
      }
      finally
      {
      }
    else if (paramInt == 4)
      try
      {
        if (e != null)
        {
          Object[] arrayOfObject1 = e;
          this.a = arrayOfObject1;
          e = (Object[])arrayOfObject1[0];
          this.i = ((int[])arrayOfObject1[1]);
          arrayOfObject1[1] = null;
          arrayOfObject1[0] = null;
          f -= 1;
          return;
        }
      }
      finally
      {
      }
    this.i = new int[paramInt];
    this.a = new Object[paramInt];
  }

  public final int a(Object paramObject)
  {
    if (paramObject == null)
      return a();
    return a(paramObject, paramObject.hashCode());
  }

  public final E a(int paramInt)
  {
    return this.a[paramInt];
  }

  public final boolean add(E paramE)
  {
    int i1;
    int n;
    if (paramE == null)
    {
      i1 = a();
      n = 0;
    }
    else
    {
      int k = paramE.hashCode();
      int m = a(paramE, k);
      n = k;
      i1 = m;
    }
    if (i1 >= 0)
      return false;
    int i2 = i1 ^ 0xFFFFFFFF;
    int i3 = this.b;
    if (i3 >= this.i.length)
    {
      int i6 = 4;
      if (i3 >= 8)
        i6 = i3 + (i3 >> 1);
      else if (i3 >= i6)
        i6 = 8;
      int[] arrayOfInt2 = this.i;
      Object[] arrayOfObject2 = this.a;
      c(i6);
      int[] arrayOfInt3 = this.i;
      if (arrayOfInt3.length > 0)
      {
        System.arraycopy(arrayOfInt2, 0, arrayOfInt3, 0, arrayOfInt2.length);
        System.arraycopy(arrayOfObject2, 0, this.a, 0, arrayOfObject2.length);
      }
      a(arrayOfInt2, arrayOfObject2, this.b);
    }
    int i4 = this.b;
    if (i2 < i4)
    {
      int[] arrayOfInt1 = this.i;
      int i5 = i2 + 1;
      System.arraycopy(arrayOfInt1, i2, arrayOfInt1, i5, i4 - i2);
      Object[] arrayOfObject1 = this.a;
      System.arraycopy(arrayOfObject1, i2, arrayOfObject1, i5, this.b - i2);
    }
    this.i[i2] = n;
    this.a[i2] = paramE;
    this.b = (1 + this.b);
    return true;
  }

  public final boolean addAll(Collection<? extends E> paramCollection)
  {
    int k = this.b + paramCollection.size();
    int[] arrayOfInt = this.i;
    int m = arrayOfInt.length;
    boolean bool = false;
    if (m < k)
    {
      Object[] arrayOfObject = this.a;
      c(k);
      int n = this.b;
      if (n > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.i, 0, n);
        System.arraycopy(arrayOfObject, 0, this.a, 0, this.b);
      }
      a(arrayOfInt, arrayOfObject, this.b);
    }
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      bool |= add(localIterator.next());
    return bool;
  }

  public final E b(int paramInt)
  {
    Object[] arrayOfObject1 = this.a;
    Object localObject = arrayOfObject1[paramInt];
    int k = this.b;
    if (k <= 1)
    {
      a(this.i, arrayOfObject1, k);
      this.i = c;
      this.a = d;
      this.b = 0;
      return localObject;
    }
    int[] arrayOfInt1 = this.i;
    int m = arrayOfInt1.length;
    int n = 8;
    if ((m > n) && (k < arrayOfInt1.length / 3))
    {
      if (k > n)
        n = k + (k >> 1);
      int[] arrayOfInt3 = this.i;
      Object[] arrayOfObject3 = this.a;
      c(n);
      this.b -= 1;
      if (paramInt > 0)
      {
        System.arraycopy(arrayOfInt3, 0, this.i, 0, paramInt);
        System.arraycopy(arrayOfObject3, 0, this.a, 0, paramInt);
      }
      int i3 = this.b;
      if (paramInt < i3)
      {
        int i4 = paramInt + 1;
        System.arraycopy(arrayOfInt3, i4, this.i, paramInt, i3 - paramInt);
        System.arraycopy(arrayOfObject3, i4, this.a, paramInt, this.b - paramInt);
        return localObject;
      }
    }
    else
    {
      this.b -= 1;
      int i1 = this.b;
      if (paramInt < i1)
      {
        int[] arrayOfInt2 = this.i;
        int i2 = paramInt + 1;
        System.arraycopy(arrayOfInt2, i2, arrayOfInt2, paramInt, i1 - paramInt);
        Object[] arrayOfObject2 = this.a;
        System.arraycopy(arrayOfObject2, i2, arrayOfObject2, paramInt, this.b - paramInt);
      }
      this.a[this.b] = null;
    }
    return localObject;
  }

  public final void clear()
  {
    int k = this.b;
    if (k != 0)
    {
      a(this.i, this.a, k);
      this.i = c;
      this.a = d;
      this.b = 0;
    }
  }

  public final boolean contains(Object paramObject)
  {
    return a(paramObject) >= 0;
  }

  public final boolean containsAll(Collection<?> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    while (localIterator.hasNext())
      if (!contains(localIterator.next()))
        return false;
    return true;
  }

  // ERROR //
  public final boolean equals(Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: if_acmpne +5 -> 7
    //   5: iconst_1
    //   6: ireturn
    //   7: aload_1
    //   8: instanceof 9
    //   11: ifeq +61 -> 72
    //   14: aload_1
    //   15: checkcast 9	java/util/Set
    //   18: astore_2
    //   19: aload_0
    //   20: invokevirtual 127	androidx/c/b:size	()I
    //   23: aload_2
    //   24: invokeinterface 128 1 0
    //   29: if_icmpeq +5 -> 34
    //   32: iconst_0
    //   33: ireturn
    //   34: iconst_0
    //   35: istore_3
    //   36: iload_3
    //   37: aload_0
    //   38: getfield 50	androidx/c/b:b	I
    //   41: if_icmpge +29 -> 70
    //   44: aload_2
    //   45: aload_0
    //   46: iload_3
    //   47: invokevirtual 130	androidx/c/b:a	(I)Ljava/lang/Object;
    //   50: invokeinterface 131 2 0
    //   55: istore 4
    //   57: iload 4
    //   59: ifne +5 -> 64
    //   62: iconst_0
    //   63: ireturn
    //   64: iinc 3 1
    //   67: goto -31 -> 36
    //   70: iconst_1
    //   71: ireturn
    //   72: iconst_0
    //   73: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   36	57	72	java/lang/NullPointerException
    //   36	57	72	java/lang/ClassCastException
  }

  public final int hashCode()
  {
    int[] arrayOfInt = this.i;
    int k = this.b;
    int m = 0;
    int n = 0;
    while (m < k)
    {
      n += arrayOfInt[m];
      m++;
    }
    return n;
  }

  public final boolean isEmpty()
  {
    return this.b <= 0;
  }

  public final Iterator<E> iterator()
  {
    if (this.j == null)
      this.j = new f()
      {
        static
        {
          CoverageLogger.Log(76996608);
        }

        protected final int a()
        {
          return b.this.b;
        }

        protected final int a(Object paramAnonymousObject)
        {
          return b.this.a(paramAnonymousObject);
        }

        protected final Object a(int paramAnonymousInt1, int paramAnonymousInt2)
        {
          return b.this.a[paramAnonymousInt1];
        }

        protected final E a(int paramAnonymousInt, E paramAnonymousE)
        {
          throw new UnsupportedOperationException("not a map");
        }

        protected final void a(int paramAnonymousInt)
        {
          b.this.b(paramAnonymousInt);
        }

        protected final void a(E paramAnonymousE1, E paramAnonymousE2)
        {
          b.this.add(paramAnonymousE1);
        }

        protected final int b(Object paramAnonymousObject)
        {
          return b.this.a(paramAnonymousObject);
        }

        protected final Map<E, E> b()
        {
          throw new UnsupportedOperationException("not a map");
        }

        protected final void c()
        {
          b.this.clear();
        }
      };
    return this.j.d().iterator();
  }

  public final boolean remove(Object paramObject)
  {
    int k = a(paramObject);
    if (k >= 0)
    {
      b(k);
      return true;
    }
    return false;
  }

  public final boolean removeAll(Collection<?> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    boolean bool = false;
    while (localIterator.hasNext())
      bool |= remove(localIterator.next());
    return bool;
  }

  public final boolean retainAll(Collection<?> paramCollection)
  {
    int k = this.b - 1;
    boolean bool = false;
    while (k >= 0)
    {
      if (!paramCollection.contains(this.a[k]))
      {
        b(k);
        bool = true;
      }
      k--;
    }
    return bool;
  }

  public final int size()
  {
    return this.b;
  }

  public final Object[] toArray()
  {
    int k = this.b;
    Object[] arrayOfObject = new Object[k];
    System.arraycopy(this.a, 0, arrayOfObject, 0, k);
    return arrayOfObject;
  }

  public final <T> T[] toArray(T[] paramArrayOfT)
  {
    if (paramArrayOfT.length < this.b)
      paramArrayOfT = (Object[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), this.b);
    System.arraycopy(this.a, 0, paramArrayOfT, 0, this.b);
    int k = paramArrayOfT.length;
    int m = this.b;
    if (k > m)
      paramArrayOfT[m] = null;
    return paramArrayOfT;
  }

  public final String toString()
  {
    if (isEmpty())
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(14 * this.b);
    localStringBuilder.append('{');
    for (int k = 0; k < this.b; k++)
    {
      if (k > 0)
        localStringBuilder.append(", ");
      Object localObject = a(k);
      if (localObject != this)
        localStringBuilder.append(localObject);
      else
        localStringBuilder.append("(this Set)");
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.c.b
 * JD-Core Version:    0.6.2
 */