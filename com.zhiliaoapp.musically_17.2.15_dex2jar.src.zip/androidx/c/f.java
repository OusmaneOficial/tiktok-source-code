package androidx.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;

abstract class f<K, V>
{
  f<K, V>.b b;
  f<K, V>.c c;
  f<K, V>.e d;

  static
  {
    CoverageLogger.Log(77213696);
  }

  public static <K, V> boolean a(Map<K, V> paramMap, Collection<?> paramCollection)
  {
    int i = paramMap.size();
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
      if (!paramCollection.contains(localIterator.next()))
        localIterator.remove();
    return i != paramMap.size();
  }

  // ERROR //
  public static <T> boolean a(Set<T> paramSet, Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: if_acmpne +5 -> 7
    //   5: iconst_1
    //   6: ireturn
    //   7: aload_1
    //   8: instanceof 40
    //   11: ifeq +37 -> 48
    //   14: aload_1
    //   15: checkcast 40	java/util/Set
    //   18: astore_2
    //   19: aload_0
    //   20: invokeinterface 69 1 0
    //   25: aload_2
    //   26: invokeinterface 69 1 0
    //   31: if_icmpne +17 -> 48
    //   34: aload_0
    //   35: aload_2
    //   36: invokeinterface 73 2 0
    //   41: istore_3
    //   42: iload_3
    //   43: ifeq +5 -> 48
    //   46: iconst_1
    //   47: ireturn
    //   48: iconst_0
    //   49: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   19	42	48	java/lang/NullPointerException
    //   19	42	48	java/lang/ClassCastException
  }

  protected abstract int a();

  protected abstract int a(Object paramObject);

  protected abstract Object a(int paramInt1, int paramInt2);

  protected abstract V a(int paramInt, V paramV);

  protected abstract void a(int paramInt);

  protected abstract void a(K paramK, V paramV);

  public final <T> T[] a(T[] paramArrayOfT, int paramInt)
  {
    int i = a();
    if (paramArrayOfT.length < i)
      paramArrayOfT = (Object[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), i);
    for (int j = 0; j < i; j++)
      paramArrayOfT[j] = a(j, paramInt);
    if (paramArrayOfT.length > i)
      paramArrayOfT[i] = null;
    return paramArrayOfT;
  }

  protected abstract int b(Object paramObject);

  protected abstract Map<K, V> b();

  public final Object[] b(int paramInt)
  {
    int i = a();
    Object[] arrayOfObject = new Object[i];
    for (int j = 0; j < i; j++)
      arrayOfObject[j] = a(j, paramInt);
    return arrayOfObject;
  }

  protected abstract void c();

  public final Set<K> d()
  {
    if (this.c == null)
      this.c = new c();
    return this.c;
  }

  final class a<T>
    implements Iterator<T>
  {
    final int a;
    int b;
    int c;
    boolean d;

    static
    {
      CoverageLogger.Log(77205504);
    }

    a(int arg2)
    {
      int i;
      this.a = i;
      this.b = f.this.a();
    }

    public final boolean hasNext()
    {
      return this.c < this.b;
    }

    public final T next()
    {
      if (hasNext())
      {
        Object localObject = f.this.a(this.c, this.a);
        this.c = (1 + this.c);
        this.d = true;
        return localObject;
      }
      throw new NoSuchElementException();
    }

    public final void remove()
    {
      if (this.d)
      {
        this.c = (-1 + this.c);
        this.b = (-1 + this.b);
        this.d = false;
        f.this.a(this.c);
        return;
      }
      throw new IllegalStateException();
    }
  }

  final class b
    implements Set<Map.Entry<K, V>>
  {
    static
    {
      CoverageLogger.Log(77199360);
    }

    b()
    {
    }

    public final boolean addAll(Collection<? extends Map.Entry<K, V>> paramCollection)
    {
      int i = f.this.a();
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        f.this.a(localEntry.getKey(), localEntry.getValue());
      }
      return i != f.this.a();
    }

    public final void clear()
    {
      f.this.c();
    }

    public final boolean contains(Object paramObject)
    {
      if (!(paramObject instanceof Map.Entry))
        return false;
      Map.Entry localEntry = (Map.Entry)paramObject;
      int i = f.this.a(localEntry.getKey());
      if (i < 0)
        return false;
      return c.a(f.this.a(i, 1), localEntry.getValue());
    }

    public final boolean containsAll(Collection<?> paramCollection)
    {
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
        if (!contains(localIterator.next()))
          return false;
      return true;
    }

    public final boolean equals(Object paramObject)
    {
      return f.a(this, paramObject);
    }

    public final int hashCode()
    {
      int i = f.this.a() - 1;
      int j = 0;
      while (i >= 0)
      {
        Object localObject1 = f.this.a(i, 0);
        Object localObject2 = f.this.a(i, 1);
        int k;
        if (localObject1 == null)
          k = 0;
        else
          k = localObject1.hashCode();
        int m;
        if (localObject2 == null)
          m = 0;
        else
          m = localObject2.hashCode();
        j += (k ^ m);
        i--;
      }
      return j;
    }

    public final boolean isEmpty()
    {
      return f.this.a() == 0;
    }

    public final Iterator<Map.Entry<K, V>> iterator()
    {
      return new f.d(f.this);
    }

    public final boolean remove(Object paramObject)
    {
      throw new UnsupportedOperationException();
    }

    public final boolean removeAll(Collection<?> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public final boolean retainAll(Collection<?> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public final int size()
    {
      return f.this.a();
    }

    public final Object[] toArray()
    {
      throw new UnsupportedOperationException();
    }

    public final <T> T[] toArray(T[] paramArrayOfT)
    {
      throw new UnsupportedOperationException();
    }
  }

  final class c
    implements Set<K>
  {
    static
    {
      CoverageLogger.Log(77203456);
    }

    c()
    {
    }

    public final boolean add(K paramK)
    {
      throw new UnsupportedOperationException();
    }

    public final boolean addAll(Collection<? extends K> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public final void clear()
    {
      f.this.c();
    }

    public final boolean contains(Object paramObject)
    {
      return f.this.a(paramObject) >= 0;
    }

    public final boolean containsAll(Collection<?> paramCollection)
    {
      Map localMap = f.this.b();
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
        if (!localMap.containsKey(localIterator.next()))
          return false;
      return true;
    }

    public final boolean equals(Object paramObject)
    {
      return f.a(this, paramObject);
    }

    public final int hashCode()
    {
      int i = -1 + f.this.a();
      int j = 0;
      while (i >= 0)
      {
        Object localObject = f.this.a(i, 0);
        int k;
        if (localObject == null)
          k = 0;
        else
          k = localObject.hashCode();
        j += k;
        i--;
      }
      return j;
    }

    public final boolean isEmpty()
    {
      return f.this.a() == 0;
    }

    public final Iterator<K> iterator()
    {
      return new f.a(f.this, 0);
    }

    public final boolean remove(Object paramObject)
    {
      int i = f.this.a(paramObject);
      if (i >= 0)
      {
        f.this.a(i);
        return true;
      }
      return false;
    }

    public final boolean removeAll(Collection<?> paramCollection)
    {
      Map localMap = f.this.b();
      int i = localMap.size();
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
        localMap.remove(localIterator.next());
      return i != localMap.size();
    }

    public final boolean retainAll(Collection<?> paramCollection)
    {
      return f.a(f.this.b(), paramCollection);
    }

    public final int size()
    {
      return f.this.a();
    }

    public final Object[] toArray()
    {
      return f.this.b(0);
    }

    public final <T> T[] toArray(T[] paramArrayOfT)
    {
      return f.this.a(paramArrayOfT, 0);
    }
  }

  final class d
    implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V>
  {
    int a = -1 + f.this.a();
    int b = -1;
    boolean c;

    static
    {
      CoverageLogger.Log(77207552);
    }

    d()
    {
    }

    public final boolean equals(Object paramObject)
    {
      if (this.c)
      {
        if (!(paramObject instanceof Map.Entry))
          return false;
        Map.Entry localEntry = (Map.Entry)paramObject;
        return (c.a(localEntry.getKey(), f.this.a(this.b, 0))) && (c.a(localEntry.getValue(), f.this.a(this.b, 1)));
      }
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final K getKey()
    {
      if (this.c)
        return f.this.a(this.b, 0);
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final V getValue()
    {
      if (this.c)
        return f.this.a(this.b, 1);
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final boolean hasNext()
    {
      return this.b < this.a;
    }

    public final int hashCode()
    {
      if (this.c)
      {
        Object localObject1 = f.this.a(this.b, 0);
        Object localObject2 = f.this.a(this.b, 1);
        int i;
        if (localObject1 == null)
          i = 0;
        else
          i = localObject1.hashCode();
        int j;
        if (localObject2 == null)
          j = 0;
        else
          j = localObject2.hashCode();
        return i ^ j;
      }
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final void remove()
    {
      if (this.c)
      {
        f.this.a(this.b);
        this.b = (-1 + this.b);
        this.a = (-1 + this.a);
        this.c = false;
        return;
      }
      throw new IllegalStateException();
    }

    public final V setValue(V paramV)
    {
      if (this.c)
        return f.this.a(this.b, paramV);
      throw new IllegalStateException("This container does not support retaining Map.Entry objects");
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(getKey());
      localStringBuilder.append("=");
      localStringBuilder.append(getValue());
      return localStringBuilder.toString();
    }
  }

  final class e
    implements Collection<V>
  {
    static
    {
      CoverageLogger.Log(77209600);
    }

    e()
    {
    }

    public final boolean add(V paramV)
    {
      throw new UnsupportedOperationException();
    }

    public final boolean addAll(Collection<? extends V> paramCollection)
    {
      throw new UnsupportedOperationException();
    }

    public final void clear()
    {
      f.this.c();
    }

    public final boolean contains(Object paramObject)
    {
      return f.this.b(paramObject) >= 0;
    }

    public final boolean containsAll(Collection<?> paramCollection)
    {
      Iterator localIterator = paramCollection.iterator();
      while (localIterator.hasNext())
        if (!contains(localIterator.next()))
          return false;
      return true;
    }

    public final boolean isEmpty()
    {
      return f.this.a() == 0;
    }

    public final Iterator<V> iterator()
    {
      return new f.a(f.this, 1);
    }

    public final boolean remove(Object paramObject)
    {
      int i = f.this.b(paramObject);
      if (i >= 0)
      {
        f.this.a(i);
        return true;
      }
      return false;
    }

    public final boolean removeAll(Collection<?> paramCollection)
    {
      int i = f.this.a();
      int j = 0;
      boolean bool = false;
      while (j < i)
      {
        if (paramCollection.contains(f.this.a(j, 1)))
        {
          f.this.a(j);
          j--;
          i--;
          bool = true;
        }
        j++;
      }
      return bool;
    }

    public final boolean retainAll(Collection<?> paramCollection)
    {
      int i = f.this.a();
      int j = 0;
      boolean bool = false;
      while (j < i)
      {
        if (!paramCollection.contains(f.this.a(j, 1)))
        {
          f.this.a(j);
          j--;
          i--;
          bool = true;
        }
        j++;
      }
      return bool;
    }

    public final int size()
    {
      return f.this.a();
    }

    public final Object[] toArray()
    {
      return f.this.b(1);
    }

    public final <T> T[] toArray(T[] paramArrayOfT)
    {
      return f.this.a(paramArrayOfT, 1);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.c.f
 * JD-Core Version:    0.6.2
 */