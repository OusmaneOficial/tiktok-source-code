package androidx.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d<E>
  implements Cloneable
{
  private static final Object a = new Object();
  private boolean b;
  private long[] c;
  private Object[] d;
  private int e;

  static
  {
    CoverageLogger.Log(77189120);
  }

  public d()
  {
    this(10);
  }

  public d(int paramInt)
  {
    if (paramInt == 0)
    {
      this.c = c.b;
      this.d = c.c;
    }
    else
    {
      int i = c.b(paramInt);
      this.c = new long[i];
      this.d = new Object[i];
    }
    this.e = 0;
  }

  private void d()
  {
    int i = this.e;
    long[] arrayOfLong = this.c;
    Object[] arrayOfObject = this.d;
    int j = 0;
    int k = 0;
    while (j < i)
    {
      Object localObject = arrayOfObject[j];
      if (localObject != a)
      {
        if (j != k)
        {
          arrayOfLong[k] = arrayOfLong[j];
          arrayOfObject[k] = localObject;
          arrayOfObject[j] = null;
        }
        k++;
      }
      j++;
    }
    this.b = false;
    this.e = k;
  }

  public final d<E> a()
  {
    try
    {
      d locald = (d)super.clone();
      locald.c = ((long[])this.c.clone());
      locald.d = ((Object[])this.d.clone());
      return locald;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new AssertionError(localCloneNotSupportedException);
    }
  }

  public final E a(long paramLong)
  {
    return a(paramLong, null);
  }

  public final E a(long paramLong, E paramE)
  {
    int i = c.a(this.c, this.e, paramLong);
    if (i >= 0)
    {
      Object[] arrayOfObject = this.d;
      if (arrayOfObject[i] == a)
        return paramE;
      return arrayOfObject[i];
    }
    return paramE;
  }

  public final void a(int paramInt)
  {
    Object[] arrayOfObject = this.d;
    Object localObject1 = arrayOfObject[paramInt];
    Object localObject2 = a;
    if (localObject1 != localObject2)
    {
      arrayOfObject[paramInt] = localObject2;
      this.b = true;
    }
  }

  public final int b()
  {
    if (this.b)
      d();
    return this.e;
  }

  public final long b(int paramInt)
  {
    if (this.b)
      d();
    return this.c[paramInt];
  }

  public final void b(long paramLong)
  {
    int i = c.a(this.c, this.e, paramLong);
    if (i >= 0)
    {
      Object[] arrayOfObject = this.d;
      Object localObject1 = arrayOfObject[i];
      Object localObject2 = a;
      if (localObject1 != localObject2)
      {
        arrayOfObject[i] = localObject2;
        this.b = true;
      }
    }
  }

  public final void b(long paramLong, E paramE)
  {
    int i = c.a(this.c, this.e, paramLong);
    if (i >= 0)
    {
      this.d[i] = paramE;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if (j < this.e)
    {
      Object[] arrayOfObject4 = this.d;
      if (arrayOfObject4[j] == a)
      {
        this.c[j] = paramLong;
        arrayOfObject4[j] = paramE;
        return;
      }
    }
    if ((this.b) && (this.e >= this.c.length))
    {
      d();
      j = 0xFFFFFFFF ^ c.a(this.c, this.e, paramLong);
    }
    int k = this.e;
    if (k >= this.c.length)
    {
      int i1 = c.b(k + 1);
      long[] arrayOfLong2 = new long[i1];
      Object[] arrayOfObject2 = new Object[i1];
      long[] arrayOfLong3 = this.c;
      System.arraycopy(arrayOfLong3, 0, arrayOfLong2, 0, arrayOfLong3.length);
      Object[] arrayOfObject3 = this.d;
      System.arraycopy(arrayOfObject3, 0, arrayOfObject2, 0, arrayOfObject3.length);
      this.c = arrayOfLong2;
      this.d = arrayOfObject2;
    }
    int m = this.e;
    if (m - j != 0)
    {
      long[] arrayOfLong1 = this.c;
      int n = j + 1;
      System.arraycopy(arrayOfLong1, j, arrayOfLong1, n, m - j);
      Object[] arrayOfObject1 = this.d;
      System.arraycopy(arrayOfObject1, j, arrayOfObject1, n, this.e - j);
    }
    this.c[j] = paramLong;
    this.d[j] = paramE;
    this.e = (1 + this.e);
  }

  public final E c(int paramInt)
  {
    if (this.b)
      d();
    return this.d[paramInt];
  }

  public final void c()
  {
    int i = this.e;
    Object[] arrayOfObject = this.d;
    for (int j = 0; j < i; j++)
      arrayOfObject[j] = null;
    this.e = 0;
    this.b = false;
  }

  public final void c(long paramLong)
  {
    b(paramLong);
  }

  public final void c(long paramLong, E paramE)
  {
    int i = this.e;
    if ((i != 0) && (paramLong <= this.c[(i - 1)]))
    {
      b(paramLong, paramE);
      return;
    }
    if ((this.b) && (this.e >= this.c.length))
      d();
    int j = this.e;
    if (j >= this.c.length)
    {
      int k = c.b(j + 1);
      long[] arrayOfLong1 = new long[k];
      Object[] arrayOfObject1 = new Object[k];
      long[] arrayOfLong2 = this.c;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.d;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.c = arrayOfLong1;
      this.d = arrayOfObject1;
    }
    this.c[j] = paramLong;
    this.d[j] = paramE;
    this.e = (j + 1);
  }

  public final int d(long paramLong)
  {
    if (this.b)
      d();
    return c.a(this.c, this.e, paramLong);
  }

  public final String toString()
  {
    if (b() <= 0)
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(28 * this.e);
    localStringBuilder.append('{');
    for (int i = 0; i < this.e; i++)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(b(i));
      localStringBuilder.append('=');
      Object localObject = c(i);
      if (localObject != this)
        localStringBuilder.append(localObject);
      else
        localStringBuilder.append("(this Map)");
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.c.d
 * JD-Core Version:    0.6.2
 */