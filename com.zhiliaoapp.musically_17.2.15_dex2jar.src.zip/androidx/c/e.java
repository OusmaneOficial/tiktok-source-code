package androidx.c;

import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class e<K, V>
{
  private final LinkedHashMap<K, V> a;
  private int b;
  private int c;
  private int d;
  private int e;
  private int f;
  private int g;

  static
  {
    CoverageLogger.Log(77197312);
  }

  public e(int paramInt)
  {
    if (paramInt > 0)
    {
      this.c = paramInt;
      this.a = new LinkedHashMap(0, 0.75F, true);
      return;
    }
    throw new IllegalArgumentException("maxSize <= 0");
  }

  private int c(K paramK, V paramV)
  {
    int i = b(paramK, paramV);
    if (i >= 0)
      return i;
    StringBuilder localStringBuilder = new StringBuilder("Negative size: ");
    localStringBuilder.append(paramK);
    localStringBuilder.append("=");
    localStringBuilder.append(paramV);
    throw new IllegalStateException(localStringBuilder.toString());
  }

  public final V a(K paramK)
  {
    if (paramK != null)
      try
      {
        Object localObject2 = this.a.get(paramK);
        if (localObject2 != null)
        {
          this.f = (1 + this.f);
          return localObject2;
        }
        this.g = (1 + this.g);
        return null;
      }
      finally
      {
      }
    throw new NullPointerException("key == null");
  }

  public final V a(K paramK, V paramV)
  {
    if ((paramK != null) && (paramV != null))
      try
      {
        this.d = (1 + this.d);
        this.b += c(paramK, paramV);
        Object localObject2 = this.a.put(paramK, paramV);
        if (localObject2 != null)
          this.b -= c(paramK, localObject2);
        a(this.c);
        return localObject2;
      }
      finally
      {
      }
    throw new NullPointerException("key == null || value == null");
  }

  public final void a()
  {
    a(-1);
  }

  public final void a(int paramInt)
  {
    while (true)
      try
      {
        if ((this.b >= 0) && ((!this.a.isEmpty()) || (this.b == 0)))
        {
          if ((this.b > paramInt) && (!this.a.isEmpty()))
          {
            Map.Entry localEntry = (Map.Entry)this.a.entrySet().iterator().next();
            Object localObject2 = localEntry.getKey();
            Object localObject3 = localEntry.getValue();
            this.a.remove(localObject2);
            this.b -= c(localObject2, localObject3);
            this.e = (1 + this.e);
          }
        }
        else
        {
          StringBuilder localStringBuilder = new StringBuilder();
          localStringBuilder.append(getClass().getName());
          localStringBuilder.append(".sizeOf() is reporting inconsistent results!");
          throw new IllegalStateException(localStringBuilder.toString());
        }
      }
      finally
      {
      }
    while (true)
      throw localObject1;
  }

  public final int b()
  {
    try
    {
      int i = this.b;
      return i;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  protected int b(K paramK, V paramV)
  {
    return 1;
  }

  public final V b(K paramK)
  {
    if (paramK != null)
      try
      {
        Object localObject2 = this.a.remove(paramK);
        if (localObject2 != null)
          this.b -= c(paramK, localObject2);
        return localObject2;
      }
      finally
      {
      }
    throw new NullPointerException("key == null");
  }

  public final Map<K, V> c()
  {
    try
    {
      LinkedHashMap localLinkedHashMap = new LinkedHashMap(this.a);
      return localLinkedHashMap;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public final String toString()
  {
    while (true)
    {
      try
      {
        int i = this.f + this.g;
        if (i != 0)
        {
          j = 100 * this.f / i;
          Locale localLocale = Locale.US;
          Object[] arrayOfObject = new Object[4];
          arrayOfObject[0] = Integer.valueOf(this.c);
          arrayOfObject[1] = Integer.valueOf(this.f);
          arrayOfObject[2] = Integer.valueOf(this.g);
          arrayOfObject[3] = Integer.valueOf(j);
          String str = a.a(localLocale, "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]", arrayOfObject);
          return str;
        }
      }
      finally
      {
      }
      int j = 0;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.c.e
 * JD-Core Version:    0.6.2
 */