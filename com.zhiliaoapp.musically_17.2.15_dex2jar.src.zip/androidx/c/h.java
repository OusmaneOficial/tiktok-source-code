package androidx.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class h<E>
  implements Cloneable
{
  public static final Object a = new Object();
  public boolean b;
  public Object[] c;
  private int[] d;
  private int e;

  static
  {
    CoverageLogger.Log(76976128);
  }

  public h()
  {
    this(10);
  }

  public h(int paramInt)
  {
    if (paramInt == 0)
    {
      this.d = c.a;
      this.c = c.c;
    }
    else
    {
      int i = c.a(paramInt);
      this.d = new int[i];
      this.c = new Object[i];
    }
    this.e = 0;
  }

  private void d()
  {
    int i = this.e;
    int[] arrayOfInt = this.d;
    Object[] arrayOfObject = this.c;
    int j = 0;
    int k = 0;
    while (j < i)
    {
      Object localObject = arrayOfObject[j];
      if (localObject != a)
      {
        if (j != k)
        {
          arrayOfInt[k] = arrayOfInt[j];
          arrayOfObject[k] = localObject;
          arrayOfObject[j] = null;
        }
        k++;
      }
      j++;
    }
    this.b = false;
    this.e = k;
  }

  public final h<E> a()
  {
    try
    {
      h localh = (h)super.clone();
      localh.d = ((int[])this.d.clone());
      localh.c = ((Object[])this.c.clone());
      return localh;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new AssertionError(localCloneNotSupportedException);
    }
  }

  public final E a(int paramInt)
  {
    return a(paramInt, null);
  }

  public final E a(int paramInt, E paramE)
  {
    int i = c.a(this.d, this.e, paramInt);
    if (i >= 0)
    {
      Object[] arrayOfObject = this.c;
      if (arrayOfObject[i] == a)
        return paramE;
      return arrayOfObject[i];
    }
    return paramE;
  }

  public final int b()
  {
    if (this.b)
      d();
    return this.e;
  }

  public final void b(int paramInt)
  {
    int i = c.a(this.d, this.e, paramInt);
    if (i >= 0)
    {
      Object[] arrayOfObject = this.c;
      Object localObject1 = arrayOfObject[i];
      Object localObject2 = a;
      if (localObject1 != localObject2)
      {
        arrayOfObject[i] = localObject2;
        this.b = true;
      }
    }
  }

  public final void b(int paramInt, E paramE)
  {
    int i = c.a(this.d, this.e, paramInt);
    if (i >= 0)
    {
      this.c[i] = paramE;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if (j < this.e)
    {
      Object[] arrayOfObject4 = this.c;
      if (arrayOfObject4[j] == a)
      {
        this.d[j] = paramInt;
        arrayOfObject4[j] = paramE;
        return;
      }
    }
    if ((this.b) && (this.e >= this.d.length))
    {
      d();
      j = 0xFFFFFFFF ^ c.a(this.d, this.e, paramInt);
    }
    int k = this.e;
    if (k >= this.d.length)
    {
      int i1 = c.a(k + 1);
      int[] arrayOfInt2 = new int[i1];
      Object[] arrayOfObject2 = new Object[i1];
      int[] arrayOfInt3 = this.d;
      System.arraycopy(arrayOfInt3, 0, arrayOfInt2, 0, arrayOfInt3.length);
      Object[] arrayOfObject3 = this.c;
      System.arraycopy(arrayOfObject3, 0, arrayOfObject2, 0, arrayOfObject3.length);
      this.d = arrayOfInt2;
      this.c = arrayOfObject2;
    }
    int m = this.e;
    if (m - j != 0)
    {
      int[] arrayOfInt1 = this.d;
      int n = j + 1;
      System.arraycopy(arrayOfInt1, j, arrayOfInt1, n, m - j);
      Object[] arrayOfObject1 = this.c;
      System.arraycopy(arrayOfObject1, j, arrayOfObject1, n, this.e - j);
    }
    this.d[j] = paramInt;
    this.c[j] = paramE;
    this.e = (1 + this.e);
  }

  public final int c(int paramInt)
  {
    if (this.b)
      d();
    return this.d[paramInt];
  }

  public final void c()
  {
    int i = this.e;
    Object[] arrayOfObject = this.c;
    for (int j = 0; j < i; j++)
      arrayOfObject[j] = null;
    this.e = 0;
    this.b = false;
  }

  public final void c(int paramInt, E paramE)
  {
    int i = this.e;
    if ((i != 0) && (paramInt <= this.d[(i - 1)]))
    {
      b(paramInt, paramE);
      return;
    }
    if ((this.b) && (this.e >= this.d.length))
      d();
    int j = this.e;
    if (j >= this.d.length)
    {
      int k = c.a(j + 1);
      int[] arrayOfInt1 = new int[k];
      Object[] arrayOfObject1 = new Object[k];
      int[] arrayOfInt2 = this.d;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.c;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.d = arrayOfInt1;
      this.c = arrayOfObject1;
    }
    this.d[j] = paramInt;
    this.c[j] = paramE;
    this.e = (j + 1);
  }

  public final E d(int paramInt)
  {
    if (this.b)
      d();
    return this.c[paramInt];
  }

  public final int e(int paramInt)
  {
    if (this.b)
      d();
    return c.a(this.d, this.e, paramInt);
  }

  public final String toString()
  {
    if (b() <= 0)
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(28 * this.e);
    localStringBuilder.append('{');
    for (int i = 0; i < this.e; i++)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(c(i));
      localStringBuilder.append('=');
      Object localObject = d(i);
      if (localObject != this)
        localStringBuilder.append(localObject);
      else
        localStringBuilder.append("(this Map)");
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.c.h
 * JD-Core Version:    0.6.2
 */