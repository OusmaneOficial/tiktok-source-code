package androidx.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ConcurrentModificationException;

public class g<K, V>
{
  static Object[] b;
  static int c;
  static Object[] d;
  static int e;
  int[] f;
  Object[] g;
  int h;

  static
  {
    CoverageLogger.Log(76986368);
  }

  public g()
  {
    this.f = c.a;
    this.g = c.c;
  }

  public g(int paramInt)
  {
    if (paramInt == 0)
    {
      this.f = c.a;
      this.g = c.c;
    }
    else
    {
      e(paramInt);
    }
    this.h = 0;
  }

  public g(g<K, V> paramg)
  {
    this();
    if (paramg != null)
    {
      int i = paramg.h;
      a(i + this.h);
      int j = this.h;
      int k = 0;
      if (j == 0)
      {
        if (i > 0)
        {
          System.arraycopy(paramg.f, 0, this.f, 0, i);
          System.arraycopy(paramg.g, 0, this.g, 0, i << 1);
          this.h = i;
        }
      }
      else
        while (k < i)
        {
          put(paramg.b(k), paramg.c(k));
          k++;
        }
    }
  }

  private int a()
  {
    int i = this.h;
    if (i == 0)
      return -1;
    int j = a(this.f, i, 0);
    if (j < 0)
      return j;
    if (this.g[(j << 1)] == null)
      return j;
    for (int k = j + 1; (k < i) && (this.f[k] == 0); k++)
      if (this.g[(k << 1)] == null)
        return k;
    for (int m = j - 1; (m >= 0) && (this.f[m] == 0); m--)
      if (this.g[(m << 1)] == null)
        return m;
    return k ^ 0xFFFFFFFF;
  }

  private int a(Object paramObject, int paramInt)
  {
    int i = this.h;
    if (i == 0)
      return -1;
    int j = a(this.f, i, paramInt);
    if (j < 0)
      return j;
    if (paramObject.equals(this.g[(j << 1)]))
      return j;
    for (int k = j + 1; (k < i) && (this.f[k] == paramInt); k++)
      if (paramObject.equals(this.g[(k << 1)]))
        return k;
    for (int m = j - 1; (m >= 0) && (this.f[m] == paramInt); m--)
      if (paramObject.equals(this.g[(m << 1)]))
        return m;
    return k ^ 0xFFFFFFFF;
  }

  // ERROR //
  private static int a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: iload_2
    //   3: invokestatic 73	androidx/c/c:a	([III)I
    //   6: istore_3
    //   7: iload_3
    //   8: ireturn
    //   9: new 75	java/util/ConcurrentModificationException
    //   12: dup
    //   13: invokespecial 76	java/util/ConcurrentModificationException:<init>	()V
    //   16: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	7	9	java/lang/ArrayIndexOutOfBoundsException
  }

  private static void a(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8)
      try
      {
        if (e < 10)
        {
          paramArrayOfObject[0] = d;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int j = (paramInt << 1) - 1; j >= 2; j--)
            paramArrayOfObject[j] = null;
          d = paramArrayOfObject;
          e = 1 + e;
        }
        return;
      }
      finally
      {
      }
    if (paramArrayOfInt.length == 4)
      try
      {
        if (c < 10)
        {
          paramArrayOfObject[0] = b;
          paramArrayOfObject[1] = paramArrayOfInt;
          for (int i = (paramInt << 1) - 1; i >= 2; i--)
            paramArrayOfObject[i] = null;
          b = paramArrayOfObject;
          c = 1 + c;
        }
        return;
      }
      finally
      {
      }
  }

  private void e(int paramInt)
  {
    if (paramInt == 8)
      try
      {
        if (d != null)
        {
          Object[] arrayOfObject2 = d;
          this.g = arrayOfObject2;
          d = (Object[])arrayOfObject2[0];
          this.f = ((int[])arrayOfObject2[1]);
          arrayOfObject2[1] = null;
          arrayOfObject2[0] = null;
          e -= 1;
          return;
        }
      }
      finally
      {
      }
    else if (paramInt == 4)
      try
      {
        if (b != null)
        {
          Object[] arrayOfObject1 = b;
          this.g = arrayOfObject1;
          b = (Object[])arrayOfObject1[0];
          this.f = ((int[])arrayOfObject1[1]);
          arrayOfObject1[1] = null;
          arrayOfObject1[0] = null;
          c -= 1;
          return;
        }
      }
      finally
      {
      }
    this.f = new int[paramInt];
    this.g = new Object[paramInt << 1];
  }

  public final int a(Object paramObject)
  {
    if (paramObject == null)
      return a();
    return a(paramObject, paramObject.hashCode());
  }

  public final void a(int paramInt)
  {
    int i = this.h;
    int[] arrayOfInt = this.f;
    if (arrayOfInt.length < paramInt)
    {
      Object[] arrayOfObject = this.g;
      e(paramInt);
      if (this.h > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.f, 0, i);
        System.arraycopy(arrayOfObject, 0, this.g, 0, i << 1);
      }
      a(arrayOfInt, arrayOfObject, i);
    }
    if (this.h == i)
      return;
    throw new ConcurrentModificationException();
  }

  final int b(Object paramObject)
  {
    int i = 2 * this.h;
    Object[] arrayOfObject = this.g;
    if (paramObject == null)
      for (int k = 1; k < i; k += 2)
        if (arrayOfObject[k] == null)
          return k >> 1;
    for (int j = 1; j < i; j += 2)
      if (paramObject.equals(arrayOfObject[j]))
        return j >> 1;
    return -1;
  }

  public final K b(int paramInt)
  {
    return this.g[(paramInt << 1)];
  }

  public final V c(int paramInt)
  {
    return this.g[(1 + (paramInt << 1))];
  }

  public void clear()
  {
    int i = this.h;
    if (i > 0)
    {
      int[] arrayOfInt = this.f;
      Object[] arrayOfObject = this.g;
      this.f = c.a;
      this.g = c.c;
      this.h = 0;
      a(arrayOfInt, arrayOfObject, i);
    }
    if (this.h <= 0)
      return;
    throw new ConcurrentModificationException();
  }

  public boolean containsKey(Object paramObject)
  {
    return a(paramObject) >= 0;
  }

  public boolean containsValue(Object paramObject)
  {
    return b(paramObject) >= 0;
  }

  public final V d(int paramInt)
  {
    Object[] arrayOfObject1 = this.g;
    int i = paramInt << 1;
    Object localObject = arrayOfObject1[(i + 1)];
    int j = this.h;
    int k;
    if (j <= 1)
    {
      a(this.f, arrayOfObject1, j);
      this.f = c.a;
      this.g = c.c;
      k = 0;
    }
    else
    {
      k = j - 1;
      int[] arrayOfInt1 = this.f;
      int m = arrayOfInt1.length;
      int n = 8;
      if ((m > n) && (j < arrayOfInt1.length / 3))
      {
        if (j > n)
          n = j + (j >> 1);
        int[] arrayOfInt3 = this.f;
        Object[] arrayOfObject4 = this.g;
        e(n);
        if (j == this.h)
        {
          if (paramInt > 0)
          {
            System.arraycopy(arrayOfInt3, 0, this.f, 0, paramInt);
            System.arraycopy(arrayOfObject4, 0, this.g, 0, i);
          }
          if (paramInt < k)
          {
            int i4 = paramInt + 1;
            int[] arrayOfInt4 = this.f;
            int i5 = k - paramInt;
            System.arraycopy(arrayOfInt3, i4, arrayOfInt4, paramInt, i5);
            System.arraycopy(arrayOfObject4, i4 << 1, this.g, i, i5 << 1);
          }
        }
        else
        {
          throw new ConcurrentModificationException();
        }
      }
      else
      {
        if (paramInt < k)
        {
          int[] arrayOfInt2 = this.f;
          int i2 = paramInt + 1;
          int i3 = k - paramInt;
          System.arraycopy(arrayOfInt2, i2, arrayOfInt2, paramInt, i3);
          Object[] arrayOfObject3 = this.g;
          System.arraycopy(arrayOfObject3, i2 << 1, arrayOfObject3, i, i3 << 1);
        }
        Object[] arrayOfObject2 = this.g;
        int i1 = k << 1;
        arrayOfObject2[i1] = null;
        arrayOfObject2[(i1 + 1)] = null;
      }
    }
    if (j == this.h)
    {
      this.h = k;
      return localObject;
    }
    throw new ConcurrentModificationException();
  }

  // ERROR //
  public boolean equals(Object paramObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: if_acmpne +5 -> 7
    //   5: iconst_1
    //   6: ireturn
    //   7: aload_1
    //   8: instanceof 2
    //   11: ifeq +108 -> 119
    //   14: aload_1
    //   15: checkcast 2	androidx/c/g
    //   18: astore 8
    //   20: aload_0
    //   21: invokevirtual 113	androidx/c/g:size	()I
    //   24: aload 8
    //   26: invokevirtual 113	androidx/c/g:size	()I
    //   29: if_icmpeq +5 -> 34
    //   32: iconst_0
    //   33: ireturn
    //   34: iconst_0
    //   35: istore 9
    //   37: iload 9
    //   39: aload_0
    //   40: getfield 42	androidx/c/g:h	I
    //   43: if_icmpge +72 -> 115
    //   46: aload_0
    //   47: iload 9
    //   49: invokevirtual 55	androidx/c/g:b	(I)Ljava/lang/Object;
    //   52: astore 10
    //   54: aload_0
    //   55: iload 9
    //   57: invokevirtual 57	androidx/c/g:c	(I)Ljava/lang/Object;
    //   60: astore 11
    //   62: aload 8
    //   64: aload 10
    //   66: invokevirtual 117	androidx/c/g:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   69: astore 12
    //   71: aload 11
    //   73: ifnonnull +20 -> 93
    //   76: aload 12
    //   78: ifnonnull +151 -> 229
    //   81: aload 8
    //   83: aload 10
    //   85: invokevirtual 119	androidx/c/g:containsKey	(Ljava/lang/Object;)Z
    //   88: ifne +21 -> 109
    //   91: iconst_0
    //   92: ireturn
    //   93: aload 11
    //   95: aload 12
    //   97: invokevirtual 70	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   100: istore 13
    //   102: iload 13
    //   104: ifne +5 -> 109
    //   107: iconst_0
    //   108: ireturn
    //   109: iinc 9 1
    //   112: goto -75 -> 37
    //   115: iconst_1
    //   116: ireturn
    //   117: iconst_0
    //   118: ireturn
    //   119: aload_1
    //   120: instanceof 121
    //   123: ifeq +104 -> 227
    //   126: aload_1
    //   127: checkcast 121	java/util/Map
    //   130: astore_2
    //   131: aload_0
    //   132: invokevirtual 113	androidx/c/g:size	()I
    //   135: aload_2
    //   136: invokeinterface 122 1 0
    //   141: if_icmpeq +5 -> 146
    //   144: iconst_0
    //   145: ireturn
    //   146: iconst_0
    //   147: istore_3
    //   148: iload_3
    //   149: aload_0
    //   150: getfield 42	androidx/c/g:h	I
    //   153: if_icmpge +72 -> 225
    //   156: aload_0
    //   157: iload_3
    //   158: invokevirtual 55	androidx/c/g:b	(I)Ljava/lang/Object;
    //   161: astore 4
    //   163: aload_0
    //   164: iload_3
    //   165: invokevirtual 57	androidx/c/g:c	(I)Ljava/lang/Object;
    //   168: astore 5
    //   170: aload_2
    //   171: aload 4
    //   173: invokeinterface 123 2 0
    //   178: astore 6
    //   180: aload 5
    //   182: ifnonnull +21 -> 203
    //   185: aload 6
    //   187: ifnonnull +44 -> 231
    //   190: aload_2
    //   191: aload 4
    //   193: invokeinterface 124 2 0
    //   198: ifne +21 -> 219
    //   201: iconst_0
    //   202: ireturn
    //   203: aload 5
    //   205: aload 6
    //   207: invokevirtual 70	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   210: istore 7
    //   212: iload 7
    //   214: ifne +5 -> 219
    //   217: iconst_0
    //   218: ireturn
    //   219: iinc 3 1
    //   222: goto -74 -> 148
    //   225: iconst_1
    //   226: ireturn
    //   227: iconst_0
    //   228: ireturn
    //   229: iconst_0
    //   230: ireturn
    //   231: iconst_0
    //   232: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   37	71	117	java/lang/NullPointerException
    //   37	71	117	java/lang/ClassCastException
    //   81	91	117	java/lang/NullPointerException
    //   81	91	117	java/lang/ClassCastException
    //   93	102	117	java/lang/NullPointerException
    //   93	102	117	java/lang/ClassCastException
    //   148	180	227	java/lang/NullPointerException
    //   148	180	227	java/lang/ClassCastException
    //   190	201	227	java/lang/NullPointerException
    //   190	201	227	java/lang/ClassCastException
    //   203	212	227	java/lang/NullPointerException
    //   203	212	227	java/lang/ClassCastException
  }

  public V get(Object paramObject)
  {
    int i = a(paramObject);
    if (i >= 0)
      return this.g[(1 + (i << 1))];
    return null;
  }

  public int hashCode()
  {
    int[] arrayOfInt = this.f;
    Object[] arrayOfObject = this.g;
    int i = this.h;
    int j = 0;
    int k = 0;
    for (int m = 1; j < i; m += 2)
    {
      Object localObject = arrayOfObject[m];
      int n = arrayOfInt[j];
      int i1;
      if (localObject == null)
        i1 = 0;
      else
        i1 = localObject.hashCode();
      k += (i1 ^ n);
      j++;
    }
    return k;
  }

  public boolean isEmpty()
  {
    return this.h <= 0;
  }

  public V put(K paramK, V paramV)
  {
    int i = this.h;
    int n;
    int m;
    if (paramK == null)
    {
      n = a();
      m = 0;
    }
    else
    {
      int j = paramK.hashCode();
      int k = a(paramK, j);
      m = j;
      n = k;
    }
    if (n >= 0)
    {
      int i6 = 1 + (n << 1);
      Object[] arrayOfObject4 = this.g;
      Object localObject = arrayOfObject4[i6];
      arrayOfObject4[i6] = paramV;
      return localObject;
    }
    int i1 = n ^ 0xFFFFFFFF;
    if (i >= this.f.length)
    {
      int i5 = 4;
      if (i >= 8)
        i5 = i + (i >> 1);
      else if (i >= i5)
        i5 = 8;
      int[] arrayOfInt3 = this.f;
      Object[] arrayOfObject3 = this.g;
      e(i5);
      if (i == this.h)
      {
        int[] arrayOfInt4 = this.f;
        if (arrayOfInt4.length > 0)
        {
          System.arraycopy(arrayOfInt3, 0, arrayOfInt4, 0, arrayOfInt3.length);
          System.arraycopy(arrayOfObject3, 0, this.g, 0, arrayOfObject3.length);
        }
        a(arrayOfInt3, arrayOfObject3, i);
      }
      else
      {
        throw new ConcurrentModificationException();
      }
    }
    if (i1 < i)
    {
      int[] arrayOfInt2 = this.f;
      int i4 = i1 + 1;
      System.arraycopy(arrayOfInt2, i1, arrayOfInt2, i4, i - i1);
      Object[] arrayOfObject2 = this.g;
      System.arraycopy(arrayOfObject2, i1 << 1, arrayOfObject2, i4 << 1, this.h - i1 << 1);
    }
    int i2 = this.h;
    if (i == i2)
    {
      int[] arrayOfInt1 = this.f;
      if (i1 < arrayOfInt1.length)
      {
        arrayOfInt1[i1] = m;
        Object[] arrayOfObject1 = this.g;
        int i3 = i1 << 1;
        arrayOfObject1[i3] = paramK;
        arrayOfObject1[(i3 + 1)] = paramV;
        this.h = (i2 + 1);
        return null;
      }
    }
    throw new ConcurrentModificationException();
  }

  public V remove(Object paramObject)
  {
    int i = a(paramObject);
    if (i >= 0)
      return d(i);
    return null;
  }

  public int size()
  {
    return this.h;
  }

  public String toString()
  {
    if (isEmpty())
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(28 * this.h);
    localStringBuilder.append('{');
    for (int i = 0; i < this.h; i++)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      Object localObject1 = b(i);
      if (localObject1 != this)
        localStringBuilder.append(localObject1);
      else
        localStringBuilder.append("(this Map)");
      localStringBuilder.append('=');
      Object localObject2 = c(i);
      if (localObject2 != this)
        localStringBuilder.append(localObject2);
      else
        localStringBuilder.append("(this Map)");
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.c.g
 * JD-Core Version:    0.6.2
 */