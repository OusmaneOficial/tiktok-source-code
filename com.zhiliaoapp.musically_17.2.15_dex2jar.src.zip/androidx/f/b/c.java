package androidx.f.b;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import androidx.core.g.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class c<D>
{
  public int n;
  public b<D> o;
  public Context p;
  public boolean q;
  public boolean r;
  public boolean s = true;
  boolean t;
  boolean u;

  static
  {
    CoverageLogger.Log(7450624);
  }

  public c(Context paramContext)
  {
    this.p = paramContext.getApplicationContext();
  }

  protected void a()
  {
  }

  public final void a(b<D> paramb)
  {
    b localb = this.o;
    if (localb != null)
    {
      if (localb == paramb)
      {
        this.o = null;
        return;
      }
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    }
    throw new IllegalStateException("No listener register");
  }

  public void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mId=");
    paramPrintWriter.print(this.n);
    paramPrintWriter.print(" mListener=");
    paramPrintWriter.println(this.o);
    if ((this.q) || (this.t) || (this.u))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStarted=");
      paramPrintWriter.print(this.q);
      paramPrintWriter.print(" mContentChanged=");
      paramPrintWriter.print(this.t);
      paramPrintWriter.print(" mProcessingChange=");
      paramPrintWriter.println(this.u);
    }
    if ((this.r) || (this.s))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAbandoned=");
      paramPrintWriter.print(this.r);
      paramPrintWriter.print(" mReset=");
      paramPrintWriter.println(this.s);
    }
  }

  public void b(D paramD)
  {
    b localb = this.o;
    if (localb != null)
      localb.a(this, paramD);
  }

  protected boolean b()
  {
    return false;
  }

  protected void g()
  {
  }

  protected void h()
  {
  }

  protected void i()
  {
  }

  public final void j()
  {
    this.q = true;
    this.s = false;
    this.r = false;
    g();
  }

  public final boolean k()
  {
    return b();
  }

  public final void l()
  {
    a();
  }

  public final void m()
  {
    this.q = false;
    h();
  }

  public final void n()
  {
    this.r = true;
  }

  public final void o()
  {
    i();
    this.s = true;
    this.q = false;
    this.r = false;
    this.t = false;
    this.u = false;
  }

  public void p()
  {
    if (this.q)
    {
      l();
      return;
    }
    this.t = true;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    b.a(this, localStringBuilder);
    localStringBuilder.append(" id=");
    localStringBuilder.append(this.n);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }

  public final class a extends ContentObserver
  {
    static
    {
      CoverageLogger.Log(7446528);
    }

    public a()
    {
      super();
    }

    public final boolean deliverSelfNotifications()
    {
      return true;
    }

    public final void onChange(boolean paramBoolean)
    {
      c.this.p();
    }
  }

  public static abstract interface b<D>
  {
    static
    {
      CoverageLogger.Log(7456768);
    }

    public abstract void a(c<D> paramc, D paramD);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.f.b.c
 * JD-Core Version:    0.6.2
 */