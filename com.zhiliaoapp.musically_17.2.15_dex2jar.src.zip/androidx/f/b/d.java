package androidx.f.b;

import android.os.Binder;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

abstract class d<Params, Progress, Result>
{
  private static final ThreadFactory a;
  private static final BlockingQueue<Runnable> b;
  public static final Executor c = localThreadPoolExecutor;
  private static b h;
  private static volatile Executor i = localThreadPoolExecutor;
  final FutureTask<Result> d = new FutureTask(this.j)
  {
    static
    {
      CoverageLogger.Log(7458816);
    }

    // ERROR //
    protected final void done()
    {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual 37	androidx/f/b/d$3:get	()Ljava/lang/Object;
      //   4: astore_3
      //   5: aload_0
      //   6: getfield 23	androidx/f/b/d$3:a	Landroidx/f/b/d;
      //   9: aload_3
      //   10: invokevirtual 41	androidx/f/b/d:c	(Ljava/lang/Object;)V
      //   13: return
      //   14: astore_2
      //   15: new 43	java/lang/RuntimeException
      //   18: dup
      //   19: ldc 45
      //   21: aload_2
      //   22: invokespecial 48	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
      //   25: athrow
      //   26: aload_0
      //   27: getfield 23	androidx/f/b/d$3:a	Landroidx/f/b/d;
      //   30: aconst_null
      //   31: invokevirtual 41	androidx/f/b/d:c	(Ljava/lang/Object;)V
      //   34: return
      //   35: astore_1
      //   36: new 43	java/lang/RuntimeException
      //   39: dup
      //   40: ldc 45
      //   42: aload_1
      //   43: invokevirtual 52	java/util/concurrent/ExecutionException:getCause	()Ljava/lang/Throwable;
      //   46: invokespecial 48	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
      //   49: athrow
      //   50: return
      //
      // Exception table:
      //   from	to	target	type
      //   0	13	14	finally
      //   0	13	26	java/util/concurrent/CancellationException
      //   0	13	35	java/util/concurrent/ExecutionException
      //   0	13	50	java/lang/InterruptedException
    }
  };
  public volatile c e = c.PENDING;
  final AtomicBoolean f = new AtomicBoolean();
  final AtomicBoolean g = new AtomicBoolean();
  private final d<Params, Result> j = new d()
  {
    static
    {
      CoverageLogger.Log(7313408);
    }

    public final Result call()
      throws Exception
    {
      d.this.g.set(true);
      Object localObject1 = null;
      try
      {
        Process.setThreadPriority(10);
        localObject1 = d.this.a(this.b);
        Binder.flushPendingCommands();
        d.this.d(localObject1);
        return localObject1;
      }
      finally
      {
        try
        {
          d.this.f.set(true);
          throw localObject2;
        }
        finally
        {
          d.this.d(localObject1);
        }
      }
    }
  };

  static
  {
    CoverageLogger.Log(7479296);
    a = new ThreadFactory()
    {
      private final AtomicInteger a = new AtomicInteger(1);

      static
      {
        CoverageLogger.Log(7452672);
      }

      public final Thread newThread(Runnable paramAnonymousRunnable)
      {
        StringBuilder localStringBuilder = new StringBuilder("ModernAsyncTask #");
        localStringBuilder.append(this.a.getAndIncrement());
        return new Thread(paramAnonymousRunnable, localStringBuilder.toString());
      }
    };
    b = new LinkedBlockingQueue(10);
    ThreadPoolExecutor localThreadPoolExecutor = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, b, a);
  }

  private static Handler b()
  {
    try
    {
      if (h == null)
        h = new b();
      b localb = h;
      return localb;
    }
    finally
    {
    }
  }

  public final d<Params, Progress, Result> a(Executor paramExecutor, Params[] paramArrayOfParams)
  {
    if (this.e != c.PENDING)
    {
      int k = 4.a[this.e.ordinal()];
      if (k != 1)
      {
        if (k != 2)
          throw new IllegalStateException("We should never reach this state");
        throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
      }
      throw new IllegalStateException("Cannot execute task: the task is already running.");
    }
    this.e = c.RUNNING;
    this.j.b = null;
    paramExecutor.execute(this.d);
    return this;
  }

  protected abstract Result a(Params[] paramArrayOfParams);

  protected void a(Result paramResult)
  {
  }

  public final boolean a()
  {
    return this.f.get();
  }

  protected void b(Result paramResult)
  {
  }

  final void c(Result paramResult)
  {
    if (!this.g.get())
      d(paramResult);
  }

  final Result d(Result paramResult)
  {
    b().obtainMessage(1, new a(this, new Object[] { paramResult })).sendToTarget();
    return paramResult;
  }

  final void e(Result paramResult)
  {
    if (a())
      b(paramResult);
    else
      a(paramResult);
    this.e = c.FINISHED;
  }

  static final class a<Data>
  {
    final d a;
    final Data[] b;

    static
    {
      CoverageLogger.Log(7464960);
    }

    a(d paramd, Data[] paramArrayOfData)
    {
      this.a = paramd;
      this.b = paramArrayOfData;
    }
  }

  static final class b extends Handler
  {
    static
    {
      CoverageLogger.Log(7301120);
    }

    b()
    {
      super();
    }

    public final void handleMessage(Message paramMessage)
    {
      d.a locala = (d.a)paramMessage.obj;
      if (paramMessage.what != 1)
        return;
      locala.a.e(locala.b[0]);
    }
  }

  public static enum c
  {
    static
    {
      CoverageLogger.Log(7475200);
      PENDING = new c("PENDING", 0);
      RUNNING = new c("RUNNING", 1);
      FINISHED = new c("FINISHED", 2);
      c[] arrayOfc = new c[3];
      arrayOfc[0] = PENDING;
      arrayOfc[1] = RUNNING;
      arrayOfc[2] = FINISHED;
    }
  }

  static abstract class d<Params, Result>
    implements Callable<Result>
  {
    Params[] b;

    static
    {
      CoverageLogger.Log(7477248);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.f.b.d
 * JD-Core Version:    0.6.2
 */