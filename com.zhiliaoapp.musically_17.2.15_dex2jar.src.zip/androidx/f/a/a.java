package androidx.f.a;

import android.os.Bundle;
import androidx.f.b.c;
import androidx.lifecycle.ab;
import androidx.lifecycle.l;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class a
{
  static
  {
    CoverageLogger.Log(7426048);
  }

  public static <T extends l,  extends ab> a a(T paramT)
  {
    return new b(paramT, ((ab)paramT).getViewModelStore());
  }

  public abstract <D> c<D> a(int paramInt, Bundle paramBundle, a<D> parama);

  public abstract void a();

  public abstract void a(int paramInt);

  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);

  public static abstract interface a<D>
  {
    static
    {
      CoverageLogger.Log(7344128);
    }

    public abstract c<D> a(int paramInt, Bundle paramBundle);

    public abstract void a(c<D> paramc);

    public abstract void a(c<D> paramc, D paramD);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.f.a.a
 * JD-Core Version:    0.6.2
 */