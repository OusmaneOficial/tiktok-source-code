package androidx.appcompat.a.a;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.SparseArray;
import android.util.TypedValue;
import androidx.appcompat.widget.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.WeakHashMap;

public final class a
{
  private static final ThreadLocal<TypedValue> a = new ThreadLocal();
  private static final WeakHashMap<Context, SparseArray<a>> b = new WeakHashMap(0);
  private static final Object c = new Object();

  static
  {
    CoverageLogger.Log(12603392);
  }

  public static ColorStateList a(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 23)
      return paramContext.getColorStateList(paramInt);
    ColorStateList localColorStateList1 = d(paramContext, paramInt);
    if (localColorStateList1 != null)
      return localColorStateList1;
    ColorStateList localColorStateList2 = c(paramContext, paramInt);
    if (localColorStateList2 != null)
      synchronized (c)
      {
        SparseArray localSparseArray = (SparseArray)b.get(paramContext);
        if (localSparseArray == null)
        {
          localSparseArray = new SparseArray();
          b.put(paramContext, localSparseArray);
        }
        localSparseArray.append(paramInt, new a(localColorStateList2, paramContext.getResources().getConfiguration()));
        return localColorStateList2;
      }
    if (Build.VERSION.SDK_INT >= 23)
      return paramContext.getColorStateList(paramInt);
    return paramContext.getResources().getColorStateList(paramInt);
  }

  public static Drawable b(Context paramContext, int paramInt)
  {
    return f.a().a(paramContext, paramInt);
  }

  // ERROR //
  private static ColorStateList c(Context paramContext, int paramInt)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 72	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   4: astore_2
    //   5: getstatic 28	androidx/appcompat/a/a/a:a	Ljava/lang/ThreadLocal;
    //   8: invokevirtual 99	java/lang/ThreadLocal:get	()Ljava/lang/Object;
    //   11: checkcast 101	android/util/TypedValue
    //   14: astore_3
    //   15: aload_3
    //   16: ifnonnull +18 -> 34
    //   19: new 101	android/util/TypedValue
    //   22: dup
    //   23: invokespecial 102	android/util/TypedValue:<init>	()V
    //   26: astore_3
    //   27: getstatic 28	androidx/appcompat/a/a/a:a	Ljava/lang/ThreadLocal;
    //   30: aload_3
    //   31: invokevirtual 106	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
    //   34: iconst_1
    //   35: istore 4
    //   37: aload_2
    //   38: iload_1
    //   39: aload_3
    //   40: iload 4
    //   42: invokevirtual 110	android/content/res/Resources:getValue	(ILandroid/util/TypedValue;Z)V
    //   45: aload_3
    //   46: getfield 113	android/util/TypedValue:type	I
    //   49: bipush 28
    //   51: if_icmplt +15 -> 66
    //   54: aload_3
    //   55: getfield 113	android/util/TypedValue:type	I
    //   58: bipush 31
    //   60: if_icmpgt +6 -> 66
    //   63: goto +6 -> 69
    //   66: iconst_0
    //   67: istore 4
    //   69: iload 4
    //   71: ifeq +5 -> 76
    //   74: aconst_null
    //   75: areturn
    //   76: aload_0
    //   77: invokevirtual 72	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   80: astore 5
    //   82: aload 5
    //   84: iload_1
    //   85: invokevirtual 117	android/content/res/Resources:getXml	(I)Landroid/content/res/XmlResourceParser;
    //   88: astore 6
    //   90: aload 5
    //   92: aload 6
    //   94: aload_0
    //   95: invokevirtual 121	android/content/Context:getTheme	()Landroid/content/res/Resources$Theme;
    //   98: invokestatic 126	androidx/core/content/a/a:a	(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    //   101: astore 7
    //   103: aload 7
    //   105: areturn
    //   106: aconst_null
    //   107: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   90	103	106	java/lang/Exception
  }

  private static ColorStateList d(Context paramContext, int paramInt)
  {
    synchronized (c)
    {
      SparseArray localSparseArray = (SparseArray)b.get(paramContext);
      if ((localSparseArray != null) && (localSparseArray.size() > 0))
      {
        a locala = (a)localSparseArray.get(paramInt);
        if (locala != null)
        {
          if (locala.b.equals(paramContext.getResources().getConfiguration()))
          {
            ColorStateList localColorStateList = locala.a;
            return localColorStateList;
          }
          localSparseArray.remove(paramInt);
        }
      }
      return null;
    }
  }

  static final class a
  {
    final ColorStateList a;
    final Configuration b;

    static
    {
      CoverageLogger.Log(12601344);
    }

    a(ColorStateList paramColorStateList, Configuration paramConfiguration)
    {
      this.a = paramColorStateList;
      this.b = paramConfiguration;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.a.a.a
 * JD-Core Version:    0.6.2
 */