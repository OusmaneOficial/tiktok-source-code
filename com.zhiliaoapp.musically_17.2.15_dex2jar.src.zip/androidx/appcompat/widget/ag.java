package androidx.appcompat.widget;

import android.os.Build.VERSION;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class ag
{
  static
  {
    CoverageLogger.Log(12017664);
  }

  public static void a(View paramView, CharSequence paramCharSequence)
  {
    if (Build.VERSION.SDK_INT >= 26)
    {
      paramView.setTooltipText(paramCharSequence);
      return;
    }
    ah.a(paramView, paramCharSequence);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ag
 * JD-Core Version:    0.6.2
 */