package androidx.appcompat.widget;

import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class g
{
  static
  {
    CoverageLogger.Log(12238848);
  }

  static InputConnection a(InputConnection paramInputConnection, EditorInfo paramEditorInfo, View paramView)
  {
    if ((paramInputConnection != null) && (paramEditorInfo.hintText == null))
      for (ViewParent localViewParent = paramView.getParent(); (localViewParent instanceof View); localViewParent = localViewParent.getParent())
        if ((localViewParent instanceof al))
        {
          paramEditorInfo.hintText = ((al)localViewParent).a();
          return paramInputConnection;
        }
    return paramInputConnection;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.g
 * JD-Core Version:    0.6.2
 */