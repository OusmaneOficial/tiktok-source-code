package androidx.appcompat.widget;

import android.graphics.Rect;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface r
{
  static
  {
    CoverageLogger.Log(12312576);
  }

  public abstract void setOnFitSystemWindowsListener(a parama);

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(12306432);
    }

    public abstract void a(Rect paramRect);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.r
 * JD-Core Version:    0.6.2
 */