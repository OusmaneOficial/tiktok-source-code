package androidx.appcompat.widget;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface al
{
  static
  {
    CoverageLogger.Log(11999232);
  }

  public abstract CharSequence a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.al
 * JD-Core Version:    0.6.2
 */