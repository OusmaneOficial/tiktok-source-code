package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import androidx.appcompat.a.a.a;
import androidx.core.content.a.f.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class ae
{
  final TypedArray a;
  private final Context b;
  private TypedValue c;

  static
  {
    CoverageLogger.Log(12050432);
  }

  private ae(Context paramContext, TypedArray paramTypedArray)
  {
    this.b = paramContext;
    this.a = paramTypedArray;
  }

  public static ae a(Context paramContext, int paramInt, int[] paramArrayOfInt)
  {
    return new ae(paramContext, paramContext.obtainStyledAttributes(paramInt, paramArrayOfInt));
  }

  public static ae a(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfInt)
  {
    return new ae(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfInt));
  }

  public static ae a(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    return new ae(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfInt, paramInt1, paramInt2));
  }

  public final float a(int paramInt, float paramFloat)
  {
    return this.a.getFloat(paramInt, paramFloat);
  }

  public final int a(int paramInt1, int paramInt2)
  {
    return this.a.getInt(paramInt1, paramInt2);
  }

  public final Typeface a(int paramInt1, int paramInt2, f.a parama)
  {
    int i = this.a.getResourceId(paramInt1, 0);
    if (i == 0)
      return null;
    if (this.c == null)
      this.c = new TypedValue();
    return androidx.core.content.a.f.a(this.b, i, this.c, paramInt2, parama);
  }

  public final Drawable a(int paramInt)
  {
    if (this.a.hasValue(paramInt))
    {
      int i = this.a.getResourceId(paramInt, 0);
      if (i != 0)
        return a.b(this.b, i);
    }
    return this.a.getDrawable(paramInt);
  }

  public final void a()
  {
    this.a.recycle();
  }

  public final boolean a(int paramInt, boolean paramBoolean)
  {
    return this.a.getBoolean(paramInt, paramBoolean);
  }

  public final int b(int paramInt1, int paramInt2)
  {
    return this.a.getColor(paramInt1, paramInt2);
  }

  public final Drawable b(int paramInt)
  {
    if (this.a.hasValue(paramInt))
    {
      int i = this.a.getResourceId(paramInt, 0);
      if (i != 0)
        return f.a().a(this.b, i, true);
    }
    return null;
  }

  public final int c(int paramInt1, int paramInt2)
  {
    return this.a.getInteger(paramInt1, paramInt2);
  }

  public final CharSequence c(int paramInt)
  {
    return this.a.getText(paramInt);
  }

  public final int d(int paramInt1, int paramInt2)
  {
    return this.a.getDimensionPixelOffset(paramInt1, paramInt2);
  }

  public final String d(int paramInt)
  {
    return this.a.getString(paramInt);
  }

  public final int e(int paramInt1, int paramInt2)
  {
    return this.a.getDimensionPixelSize(paramInt1, paramInt2);
  }

  public final ColorStateList e(int paramInt)
  {
    if (this.a.hasValue(paramInt))
    {
      int i = this.a.getResourceId(paramInt, 0);
      if (i != 0)
      {
        ColorStateList localColorStateList = a.a(this.b, i);
        if (localColorStateList != null)
          return localColorStateList;
      }
    }
    return this.a.getColorStateList(paramInt);
  }

  public final int f(int paramInt1, int paramInt2)
  {
    return this.a.getLayoutDimension(paramInt1, paramInt2);
  }

  public final boolean f(int paramInt)
  {
    return this.a.hasValue(paramInt);
  }

  public final int g(int paramInt1, int paramInt2)
  {
    return this.a.getResourceId(paramInt1, paramInt2);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ae
 * JD-Core Version:    0.6.2
 */