package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import androidx.core.h.t;
import androidx.core.h.x;
import androidx.core.h.y;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

abstract class a extends ViewGroup
{
  protected final a a = new a();
  protected final Context b;
  protected ActionMenuView c;
  protected ActionMenuPresenter d;
  protected int e;
  protected x f;
  private boolean g;
  private boolean h;

  static
  {
    CoverageLogger.Log(12341248);
  }

  a(Context paramContext)
  {
    this(paramContext, null);
  }

  a(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  a(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TypedValue localTypedValue = new TypedValue();
    if ((paramContext.getTheme().resolveAttribute(2130968587, localTypedValue, true)) && (localTypedValue.resourceId != 0))
    {
      this.b = new ContextThemeWrapper(paramContext, localTypedValue.resourceId);
      return;
    }
    this.b = paramContext;
  }

  protected static int a(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramBoolean)
      return paramInt1 - paramInt2;
    return paramInt1 + paramInt2;
  }

  protected static int a(View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() - 0);
  }

  protected static int a(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    int k = paramInt2 + (paramInt3 - j) / 2;
    if (paramBoolean)
      paramView.layout(paramInt1 - i, k, paramInt1, j + k);
    else
      paramView.layout(paramInt1, k, paramInt1 + i, j + k);
    if (paramBoolean)
      return -i;
    return i;
  }

  public x a(int paramInt, long paramLong)
  {
    x localx1 = this.f;
    if (localx1 != null)
      localx1.b();
    if (paramInt == 0)
    {
      if (getVisibility() != 0)
        setAlpha(0.0F);
      x localx3 = t.m(this).a(1.0F);
      localx3.a(paramLong);
      localx3.a(this.a.a(localx3, paramInt));
      return localx3;
    }
    x localx2 = t.m(this).a(0.0F);
    localx2.a(paramLong);
    localx2.a(this.a.a(localx2, paramInt));
    return localx2;
  }

  public boolean a()
  {
    ActionMenuPresenter localActionMenuPresenter = this.d;
    if (localActionMenuPresenter != null)
      return localActionMenuPresenter.c();
    return false;
  }

  public int getAnimatedVisibility()
  {
    if (this.f != null)
      return this.a.a;
    return getVisibility();
  }

  public int getContentHeight()
  {
    return this.e;
  }

  protected void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    TypedArray localTypedArray = getContext().obtainStyledAttributes(null, new int[] { 2130968691, 2130968694, 2130968695, 2130968961, 2130968962, 2130968963, 2130968964, 2130968965, 2130968966, 2130969002, 2130969023, 2130969024, 2130969051, 2130969147, 2130969154, 2130969164, 2130969165, 2130969168, 2130969197, 2130969257, 2130969415, 2130969477, 2130969521, 2130969535, 2130969536, 2130969808, 2130969811, 2130969930, 2130969942 }, 2130968590, 0);
    setContentHeight(localTypedArray.getLayoutDimension(13, 0));
    localTypedArray.recycle();
    ActionMenuPresenter localActionMenuPresenter = this.d;
    if (localActionMenuPresenter != null)
      localActionMenuPresenter.a(paramConfiguration);
  }

  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.h = false;
    if (!this.h)
    {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if ((i == 9) && (!bool))
        this.h = true;
    }
    if ((i == 10) || (i == 3))
      this.h = false;
    return true;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.g = false;
    if (!this.g)
    {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if ((i == 0) && (!bool))
        this.g = true;
    }
    if ((i == 1) || (i == 3))
      this.g = false;
    return true;
  }

  public void setContentHeight(int paramInt)
  {
    this.e = paramInt;
    requestLayout();
  }

  public void setVisibility(int paramInt)
  {
    if (paramInt != getVisibility())
    {
      x localx = this.f;
      if (localx != null)
        localx.b();
      super.setVisibility(paramInt);
    }
  }

  protected final class a
    implements y
  {
    int a;
    private boolean c;

    static
    {
      CoverageLogger.Log(12445696);
    }

    protected a()
    {
    }

    public final a a(x paramx, int paramInt)
    {
      a.this.f = paramx;
      this.a = paramInt;
      return this;
    }

    public final void a(View paramView)
    {
      a.a(a.this, 0);
      this.c = false;
    }

    public final void b(View paramView)
    {
      if (this.c)
        return;
      a locala = a.this;
      locala.f = null;
      a.b(locala, this.a);
    }

    public final void c(View paramView)
    {
      this.c = true;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.a
 * JD-Core Version:    0.6.2
 */