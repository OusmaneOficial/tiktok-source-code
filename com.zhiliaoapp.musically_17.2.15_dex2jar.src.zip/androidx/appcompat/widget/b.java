package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class b extends Drawable
{
  final ActionBarContainer a;

  static
  {
    CoverageLogger.Log(12455936);
  }

  public b(ActionBarContainer paramActionBarContainer)
  {
    this.a = paramActionBarContainer;
  }

  public final void draw(Canvas paramCanvas)
  {
    if (this.a.d)
    {
      if (this.a.c != null)
        this.a.c.draw(paramCanvas);
    }
    else
    {
      if (this.a.a != null)
        this.a.a.draw(paramCanvas);
      if ((this.a.b != null) && (this.a.e))
        this.a.b.draw(paramCanvas);
    }
  }

  public final int getOpacity()
  {
    return 0;
  }

  public final void getOutline(Outline paramOutline)
  {
    if (this.a.d)
    {
      if (this.a.c != null)
        this.a.c.getOutline(paramOutline);
    }
    else if (this.a.a != null)
      this.a.a.getOutline(paramOutline);
  }

  public final void setAlpha(int paramInt)
  {
  }

  public final void setColorFilter(ColorFilter paramColorFilter)
  {
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.b
 * JD-Core Version:    0.6.2
 */