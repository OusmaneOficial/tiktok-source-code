package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnHoverListener;
import android.view.View.OnLongClickListener;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class ah
  implements View.OnAttachStateChangeListener, View.OnHoverListener, View.OnLongClickListener
{
  private static ah j;
  private static ah k;
  private final View a;
  private final CharSequence b;
  private final int c;
  private final Runnable d = new Runnable()
  {
    static
    {
      CoverageLogger.Log(12015616);
    }

    public final void run()
    {
      ah.this.a(false);
    }
  };
  private final Runnable e = new Runnable()
  {
    static
    {
      CoverageLogger.Log(12013568);
    }

    public final void run()
    {
      ah.this.a();
    }
  };
  private int f;
  private int g;
  private ai h;
  private boolean i;

  static
  {
    CoverageLogger.Log(12150784);
  }

  private ah(View paramView, CharSequence paramCharSequence)
  {
    this.a = paramView;
    this.b = paramCharSequence;
    ViewConfiguration localViewConfiguration = ViewConfiguration.get(this.a.getContext());
    int m;
    if (Build.VERSION.SDK_INT >= 28)
      m = localViewConfiguration.getScaledHoverSlop();
    else
      m = localViewConfiguration.getScaledTouchSlop() / 2;
    this.c = m;
    d();
    this.a.setOnLongClickListener(this);
    this.a.setOnHoverListener(this);
  }

  public static void a(View paramView, CharSequence paramCharSequence)
  {
    ah localah1 = j;
    if ((localah1 != null) && (localah1.a == paramView))
      a(null);
    if (TextUtils.isEmpty(paramCharSequence))
    {
      ah localah2 = k;
      if ((localah2 != null) && (localah2.a == paramView))
        localah2.a();
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    }
    new ah(paramView, paramCharSequence);
  }

  private static void a(ah paramah)
  {
    ah localah = j;
    if (localah != null)
      localah.c();
    j = paramah;
    if (paramah != null)
      j.b();
  }

  private void b()
  {
    this.a.postDelayed(this.d, ViewConfiguration.getLongPressTimeout());
  }

  private void c()
  {
    this.a.removeCallbacks(this.d);
  }

  private void d()
  {
    this.f = 2147483647;
    this.g = 2147483647;
  }

  final void a()
  {
    if (k == this)
    {
      k = null;
      ai localai = this.h;
      if (localai != null)
      {
        localai.a();
        this.h = null;
        d();
        this.a.removeOnAttachStateChangeListener(this);
      }
    }
    if (j == this)
      a(null);
    this.a.removeCallbacks(this.e);
  }

  final void a(boolean paramBoolean)
  {
    if (!t.B(this.a))
      return;
    a(null);
    ah localah = k;
    if (localah != null)
      localah.a();
    k = this;
    this.i = paramBoolean;
    this.h = new ai(this.a.getContext());
    this.h.a(this.a, this.f, this.g, this.i, this.b);
    this.a.addOnAttachStateChangeListener(this);
    long l2;
    if (this.i)
    {
      l2 = 2500L;
    }
    else
    {
      long l1;
      int m;
      if ((0x1 & t.q(this.a)) == 1)
      {
        l1 = 3000L;
        m = ViewConfiguration.getLongPressTimeout();
      }
      else
      {
        l1 = 15000L;
        m = ViewConfiguration.getLongPressTimeout();
      }
      l2 = l1 - m;
    }
    this.a.removeCallbacks(this.e);
    this.a.postDelayed(this.e, l2);
  }

  public final boolean onHover(View paramView, MotionEvent paramMotionEvent)
  {
    if ((this.h != null) && (this.i))
      return false;
    AccessibilityManager localAccessibilityManager = (AccessibilityManager)this.a.getContext().getSystemService("accessibility");
    if ((localAccessibilityManager.isEnabled()) && (localAccessibilityManager.isTouchExplorationEnabled()))
      return false;
    int m = paramMotionEvent.getAction();
    if (m != 7)
    {
      if (m != 10)
        return false;
      d();
      a();
      return false;
    }
    if ((this.a.isEnabled()) && (this.h == null))
    {
      int n = (int)paramMotionEvent.getX();
      int i1 = (int)paramMotionEvent.getY();
      int i2;
      if ((Math.abs(n - this.f) <= this.c) && (Math.abs(i1 - this.g) <= this.c))
      {
        i2 = 0;
      }
      else
      {
        this.f = n;
        this.g = i1;
        i2 = 1;
      }
      if (i2 != 0)
        a(this);
    }
    return false;
  }

  public final boolean onLongClick(View paramView)
  {
    this.f = (paramView.getWidth() / 2);
    this.g = (paramView.getHeight() / 2);
    a(true);
    return true;
  }

  public final void onViewAttachedToWindow(View paramView)
  {
  }

  public final void onViewDetachedFromWindow(View paramView)
  {
    a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ah
 * JD-Core Version:    0.6.2
 */