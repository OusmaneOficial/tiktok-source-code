package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class ButtonBarLayout extends LinearLayout
{
  private boolean a;
  private int b = -1;
  private int c;

  static
  {
    CoverageLogger.Log(12275712);
  }

  public ButtonBarLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 2130968639 });
    this.a = localTypedArray.getBoolean(0, true);
    localTypedArray.recycle();
  }

  private int a(int paramInt)
  {
    int i = getChildCount();
    while (paramInt < i)
    {
      if (getChildAt(paramInt).getVisibility() == 0)
        return paramInt;
      paramInt++;
    }
    return -1;
  }

  private boolean a()
  {
    return getOrientation() == 1;
  }

  private void setStacked(boolean paramBoolean)
  {
    setOrientation(paramBoolean);
    int i;
    if (paramBoolean)
      i = 5;
    else
      i = 80;
    setGravity(i);
    View localView = findViewById(2131301613);
    if (localView != null)
    {
      int k;
      if (paramBoolean)
        k = 8;
      else
        k = 4;
      localView.setVisibility(k);
    }
    for (int j = -2 + getChildCount(); j >= 0; j--)
      bringChildToFront(getChildAt(j));
  }

  public int getMinimumHeight()
  {
    return Math.max(this.c, super.getMinimumHeight());
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.a)
    {
      if ((i > this.b) && (a()))
        setStacked(false);
      this.b = i;
    }
    int j;
    int k;
    if ((!a()) && (View.MeasureSpec.getMode(paramInt1) == 1073741824))
    {
      j = View.MeasureSpec.makeMeasureSpec(i, -2147483648);
      k = 1;
    }
    else
    {
      j = paramInt1;
      k = 0;
    }
    super.onMeasure(j, paramInt2);
    if ((this.a) && (!a()))
    {
      int i3;
      if ((0xFF000000 & getMeasuredWidthAndState()) == 16777216)
        i3 = 1;
      else
        i3 = 0;
      if (i3 != 0)
      {
        setStacked(true);
        k = 1;
      }
    }
    if (k != 0)
      super.onMeasure(paramInt1, paramInt2);
    int m = a(0);
    int n = 0;
    if (m >= 0)
    {
      View localView = getChildAt(m);
      LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)localView.getLayoutParams();
      int i1 = 0 + (getPaddingTop() + localView.getMeasuredHeight() + localLayoutParams.topMargin + localLayoutParams.bottomMargin);
      if (a())
      {
        int i2 = a(m + 1);
        if (i2 >= 0)
          i1 += getChildAt(i2).getPaddingTop() + (int)(16.0F * getResources().getDisplayMetrics().density);
        n = i1;
      }
      else
      {
        n = i1 + getPaddingBottom();
      }
    }
    if (t.l(this) != n)
      setMinimumHeight(n);
  }

  public void setAllowStacking(boolean paramBoolean)
  {
    if (this.a != paramBoolean)
    {
      this.a = paramBoolean;
      if ((!this.a) && (getOrientation() == 1))
        setStacked(false);
      requestLayout();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ButtonBarLayout
 * JD-Core Version:    0.6.2
 */