package androidx.appcompat.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.DataSetObserver;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import androidx.core.h.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public final class ActivityChooserView extends ViewGroup
{
  final a a;
  final FrameLayout b;
  final FrameLayout c;
  b d;
  final DataSetObserver e;
  PopupWindow.OnDismissListener f;
  boolean g;
  int h;
  private final b i;
  private final View j;
  private final ImageView k;
  private final int l;
  private final ViewTreeObserver.OnGlobalLayoutListener m;
  private ListPopupWindow n;
  private boolean o;
  private int p;

  static
  {
    CoverageLogger.Log(12269568);
  }

  private boolean b()
  {
    return getListPopupWindow().e();
  }

  final void a(int paramInt)
  {
    if (this.a.a != null)
    {
      getViewTreeObserver().addOnGlobalLayoutListener(this.m);
      int i1;
      if (this.c.getVisibility() == 0)
        i1 = 1;
      else
        i1 = 0;
      int i2 = this.a.b();
      if ((paramInt != 2147483647) && (i2 > paramInt + i1))
      {
        this.a.a(true);
        this.a.a(paramInt - 1);
      }
      else
      {
        this.a.a(false);
        this.a.a(paramInt);
      }
      ListPopupWindow localListPopupWindow = getListPopupWindow();
      if (!localListPopupWindow.e())
      {
        if ((!this.g) && (i1 != 0))
          this.a.a(false, false);
        else
          this.a.a(true, i1);
        localListPopupWindow.b(Math.min(this.a.a(), this.l));
        localListPopupWindow.c();
        b localb = this.d;
        if (localb != null)
          localb.a(true);
        localListPopupWindow.g().setContentDescription(getContext().getString(2131820840));
        localListPopupWindow.g().setSelector(new ColorDrawable(0));
      }
      return;
    }
    throw new IllegalStateException("No data model. Did you call #setDataModel?");
  }

  public final boolean a()
  {
    if (b())
    {
      getListPopupWindow().d();
      ViewTreeObserver localViewTreeObserver = getViewTreeObserver();
      if (localViewTreeObserver.isAlive())
        localViewTreeObserver.removeGlobalOnLayoutListener(this.m);
    }
    return true;
  }

  public final c getDataModel()
  {
    return this.a.a;
  }

  final ListPopupWindow getListPopupWindow()
  {
    if (this.n == null)
    {
      this.n = new ListPopupWindow(getContext());
      this.n.a(this.a);
      ListPopupWindow localListPopupWindow1 = this.n;
      localListPopupWindow1.o = this;
      localListPopupWindow1.a(true);
      ListPopupWindow localListPopupWindow2 = this.n;
      b localb = this.i;
      localListPopupWindow2.q = localb;
      localListPopupWindow2.a(localb);
    }
    return this.n;
  }

  protected final void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    c localc = this.a.a;
    if (localc != null)
      localc.registerObserver(this.e);
    this.o = true;
  }

  protected final void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    c localc = this.a.a;
    if (localc != null)
      localc.unregisterObserver(this.e);
    ViewTreeObserver localViewTreeObserver = getViewTreeObserver();
    if (localViewTreeObserver.isAlive())
      localViewTreeObserver.removeGlobalOnLayoutListener(this.m);
    if (b())
      a();
    this.o = false;
  }

  protected final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.j.layout(0, 0, paramInt3 - paramInt1, paramInt4 - paramInt2);
    if (!b())
      a();
  }

  protected final void onMeasure(int paramInt1, int paramInt2)
  {
    View localView = this.j;
    if (this.c.getVisibility() != 0)
      paramInt2 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt2), 1073741824);
    measureChild(localView, paramInt1, paramInt2);
    setMeasuredDimension(localView.getMeasuredWidth(), localView.getMeasuredHeight());
  }

  public final void setActivityChooserModel(c paramc)
  {
    a locala = this.a;
    c localc = locala.c.a.a;
    if ((localc != null) && (locala.c.isShown()))
      localc.unregisterObserver(locala.c.e);
    locala.a = paramc;
    if ((paramc != null) && (locala.c.isShown()))
      paramc.registerObserver(locala.c.e);
    locala.notifyDataSetChanged();
    if (b())
    {
      a();
      if (!b())
      {
        if (!this.o)
          return;
        this.g = false;
        a(this.h);
      }
    }
  }

  public final void setDefaultActionButtonContentDescription(int paramInt)
  {
    this.p = paramInt;
  }

  public final void setExpandActivityOverflowButtonContentDescription(int paramInt)
  {
    String str = getContext().getString(paramInt);
    this.k.setContentDescription(str);
  }

  public final void setExpandActivityOverflowButtonDrawable(Drawable paramDrawable)
  {
    this.k.setImageDrawable(paramDrawable);
  }

  public final void setInitialActivityCount(int paramInt)
  {
    this.h = paramInt;
  }

  public final void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    this.f = paramOnDismissListener;
  }

  public final void setProvider(b paramb)
  {
    this.d = paramb;
  }

  public static class InnerLayout extends LinearLayout
  {
    private static final int[] a = { 16842964 };

    static
    {
      CoverageLogger.Log(12527616);
    }

    public InnerLayout(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      ae localae = ae.a(paramContext, paramAttributeSet, a);
      setBackgroundDrawable(localae.a(0));
      localae.a();
    }
  }

  final class a extends BaseAdapter
  {
    public c a;
    public boolean b;
    private int d;
    private boolean e;
    private boolean f;

    static
    {
      CoverageLogger.Log(12507136);
    }

    public final int a()
    {
      int i = this.d;
      this.d = 2147483647;
      int j = 0;
      int k = View.MeasureSpec.makeMeasureSpec(0, 0);
      int m = View.MeasureSpec.makeMeasureSpec(0, 0);
      int n = getCount();
      View localView = null;
      int i1 = 0;
      while (j < n)
      {
        localView = getView(j, localView, null);
        localView.measure(k, m);
        i1 = Math.max(i1, localView.getMeasuredWidth());
        j++;
      }
      this.d = i;
      return i1;
    }

    public final void a(int paramInt)
    {
      if (this.d != paramInt)
      {
        this.d = paramInt;
        notifyDataSetChanged();
      }
    }

    public final void a(boolean paramBoolean)
    {
      if (this.f != paramBoolean)
      {
        this.f = paramBoolean;
        notifyDataSetChanged();
      }
    }

    public final void a(boolean paramBoolean1, boolean paramBoolean2)
    {
      if ((this.b != paramBoolean1) || (this.e != paramBoolean2))
      {
        this.b = paramBoolean1;
        this.e = paramBoolean2;
        notifyDataSetChanged();
      }
    }

    public final int b()
    {
      return this.a.a();
    }

    public final int getCount()
    {
      int i = this.a.a();
      if ((!this.b) && (this.a.b() != null))
        i--;
      int j = Math.min(i, this.d);
      if (this.f)
        j++;
      return j;
    }

    public final Object getItem(int paramInt)
    {
      int i = getItemViewType(paramInt);
      if (i != 0)
      {
        if (i == 1)
          return null;
        throw new IllegalArgumentException();
      }
      if ((!this.b) && (this.a.b() != null))
        paramInt++;
      return this.a.a(paramInt);
    }

    public final long getItemId(int paramInt)
    {
      return paramInt;
    }

    public final int getItemViewType(int paramInt)
    {
      if ((this.f) && (paramInt == getCount() - 1))
        return 1;
      return 0;
    }

    public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      int i = getItemViewType(paramInt);
      if (i != 0)
      {
        if (i == 1)
        {
          if ((paramView == null) || (paramView.getId() != 1))
          {
            paramView = LayoutInflater.from(this.c.getContext()).inflate(2131492871, paramViewGroup, false);
            paramView.setId(1);
            ((TextView)paramView.findViewById(2131302118)).setText(this.c.getContext().getString(2131820839));
          }
          return paramView;
        }
        throw new IllegalArgumentException();
      }
      if ((paramView == null) || (paramView.getId() != 2131299642))
        paramView = LayoutInflater.from(this.c.getContext()).inflate(2131492871, paramViewGroup, false);
      PackageManager localPackageManager = this.c.getContext().getPackageManager();
      ImageView localImageView = (ImageView)paramView.findViewById(2131298662);
      ResolveInfo localResolveInfo = (ResolveInfo)getItem(paramInt);
      localImageView.setImageDrawable(localResolveInfo.loadIcon(localPackageManager));
      ((TextView)paramView.findViewById(2131302118)).setText(localResolveInfo.loadLabel(localPackageManager));
      if ((this.b) && (paramInt == 0) && (this.e))
      {
        paramView.setActivated(true);
        return paramView;
      }
      paramView.setActivated(false);
      return paramView;
    }

    public final int getViewTypeCount()
    {
      return 3;
    }
  }

  final class b
    implements View.OnClickListener, View.OnLongClickListener, AdapterView.OnItemClickListener, PopupWindow.OnDismissListener
  {
    static
    {
      CoverageLogger.Log(12513280);
    }

    public final void onClick(View paramView)
    {
      if (paramView == this.a.c)
      {
        this.a.a();
        ResolveInfo localResolveInfo = this.a.a.a.b();
        int i = this.a.a.a.a(localResolveInfo);
        Intent localIntent = this.a.a.a.b(i);
        if (localIntent != null)
        {
          localIntent.addFlags(524288);
          this.a.getContext().startActivity(localIntent);
        }
        return;
      }
      if (paramView == this.a.b)
      {
        ActivityChooserView localActivityChooserView = this.a;
        localActivityChooserView.g = false;
        localActivityChooserView.a(localActivityChooserView.h);
        return;
      }
      throw new IllegalArgumentException();
    }

    public final void onDismiss()
    {
      if (this.a.f != null)
        this.a.f.onDismiss();
      if (this.a.d != null)
        this.a.d.a(false);
    }

    public final void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
    {
      int i = ((ActivityChooserView.a)paramAdapterView.getAdapter()).getItemViewType(paramInt);
      if (i != 0)
      {
        if (i == 1)
        {
          this.a.a(2147483647);
          return;
        }
        throw new IllegalArgumentException();
      }
      this.a.a();
      c localc;
      if (this.a.g)
        if (paramInt > 0)
          localc = this.a.a.a;
      while (true)
      {
        synchronized (localc.b)
        {
          localc.c();
          c.a locala1 = (c.a)localc.c.get(paramInt);
          c.a locala2 = (c.a)localc.c.get(0);
          if (locala2 == null)
            break label268;
          f = 5.0F + (locala2.b - locala1.b);
          localc.a(new c.c(new ComponentName(locala1.a.activityInfo.packageName, locala1.a.activityInfo.name), System.currentTimeMillis(), f));
          return;
        }
        return;
        if (!this.a.a.b)
          paramInt++;
        Intent localIntent = this.a.a.a.b(paramInt);
        if (localIntent != null)
        {
          localIntent.addFlags(524288);
          this.a.getContext().startActivity(localIntent);
        }
        return;
        label268: float f = 1.0F;
      }
    }

    public final boolean onLongClick(View paramView)
    {
      if (paramView == this.a.c)
      {
        if (this.a.a.getCount() > 0)
        {
          ActivityChooserView localActivityChooserView = this.a;
          localActivityChooserView.g = true;
          localActivityChooserView.a(localActivityChooserView.h);
        }
        return true;
      }
      throw new IllegalArgumentException();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ActivityChooserView
 * JD-Core Version:    0.6.2
 */