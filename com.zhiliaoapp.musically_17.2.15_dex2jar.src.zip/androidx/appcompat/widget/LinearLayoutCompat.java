package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.core.h.d;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class LinearLayoutCompat extends ViewGroup
{
  private int a = -1;
  private int b;
  private int c;
  private int d = 8388659;
  private int e;
  public boolean f = true;
  public boolean g;
  private float h;
  private int[] i;
  private int[] j;
  private Drawable k;
  private int l;
  private int m;
  private int n;
  private int o;

  static
  {
    CoverageLogger.Log(12285952);
  }

  public LinearLayoutCompat(Context paramContext)
  {
    this(paramContext, null);
  }

  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    ae localae = ae.a(paramContext, paramAttributeSet, new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130969024, 2130969030, 2130969446, 2130969728 }, paramInt, 0);
    int i1 = localae.a(1, -1);
    if (i1 >= 0)
      setOrientation(i1);
    int i2 = localae.a(0, -1);
    if (i2 >= 0)
      setGravity(i2);
    boolean bool = localae.a(2, true);
    if (!bool)
      setBaselineAligned(bool);
    this.h = localae.a(4, -1.0F);
    this.a = localae.a(3, -1);
    this.g = localae.a(7, false);
    setDividerDrawable(localae.a(5));
    this.n = localae.a(8, 0);
    this.o = localae.e(6, 0);
    localae.a();
  }

  private void a(int paramInt1, int paramInt2)
  {
    int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (int i2 = 0; i2 < paramInt1; i2++)
    {
      View localView = b(i2);
      if (localView.getVisibility() != 8)
      {
        LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
        if (localLayoutParams.width == -1)
        {
          int i3 = localLayoutParams.height;
          localLayoutParams.height = localView.getMeasuredHeight();
          measureChildWithMargins(localView, i1, 0, paramInt2, 0);
          localLayoutParams.height = i3;
        }
      }
    }
  }

  private void a(Canvas paramCanvas, int paramInt)
  {
    this.k.setBounds(getPaddingLeft() + this.o, paramInt, getWidth() - getPaddingRight() - this.o, paramInt + this.m);
    this.k.draw(paramCanvas);
  }

  private static void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }

  private void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }

  private View b(int paramInt)
  {
    return getChildAt(paramInt);
  }

  private void b(int paramInt1, int paramInt2)
  {
    this.e = 0;
    int i1 = getVirtualChildCount();
    int i2 = View.MeasureSpec.getMode(paramInt1);
    int i3 = View.MeasureSpec.getMode(paramInt2);
    if ((this.i == null) || (this.j == null))
    {
      this.i = new int[4];
      this.j = new int[4];
    }
    int[] arrayOfInt1 = this.i;
    int[] arrayOfInt2 = this.j;
    arrayOfInt1[3] = -1;
    arrayOfInt1[2] = -1;
    arrayOfInt1[1] = -1;
    arrayOfInt1[0] = -1;
    arrayOfInt2[3] = -1;
    arrayOfInt2[2] = -1;
    arrayOfInt2[1] = -1;
    arrayOfInt2[0] = -1;
    boolean bool1 = this.f;
    boolean bool2 = this.g;
    int i4;
    if (i2 == 1073741824)
      i4 = 1;
    else
      i4 = 0;
    float f1 = 0.0F;
    int i5 = 0;
    int i6 = 0;
    int i7 = 0;
    int i8 = 0;
    int i9 = 0;
    int i10 = 0;
    int i11 = 1;
    int i12 = 0;
    int i13 = 0;
    while (i6 < i1)
    {
      View localView5 = b(i6);
      boolean bool5;
      boolean bool6;
      int i62;
      if (localView5 == null)
      {
        this.e = (0 + this.e);
        bool5 = bool2;
        bool6 = bool1;
        i62 = i5;
      }
      else
      {
        float f7;
        int i60;
        label633: int i61;
        if (localView5.getVisibility() != 8)
        {
          if (a(i6))
            this.e += this.l;
          LayoutParams localLayoutParams4 = (LayoutParams)localView5.getLayoutParams();
          f7 = f1 + localLayoutParams4.g;
          View localView6;
          int i67;
          if ((i2 == 1073741824) && (localLayoutParams4.width == 0) && (localLayoutParams4.g > 0.0F))
          {
            int i81;
            if (i4 != 0)
            {
              int i84 = this.e;
              int i85 = localLayoutParams4.leftMargin;
              i81 = i5;
              this.e = (i84 + (i85 + localLayoutParams4.rightMargin));
            }
            else
            {
              i81 = i5;
              int i82 = this.e;
              this.e = Math.max(i82, i82 + localLayoutParams4.leftMargin + localLayoutParams4.rightMargin);
            }
            if (bool1)
            {
              int i83 = View.MeasureSpec.makeMeasureSpec(0, 0);
              localView5.measure(i83, i83);
              localView6 = localView5;
              bool5 = bool2;
              bool6 = bool1;
              i67 = i81;
              i60 = i6;
            }
            else
            {
              localView6 = localView5;
              bool5 = bool2;
              bool6 = bool1;
              i67 = i81;
              i71 = 1073741824;
              i9 = 1;
              i60 = i6;
              break label633;
            }
          }
          else
          {
            int i63 = i5;
            int i64;
            if ((localLayoutParams4.width == 0) && (localLayoutParams4.g > 0.0F))
            {
              localLayoutParams4.width = -2;
              i64 = 0;
            }
            else
            {
              i64 = -2147483648;
            }
            int i65;
            if (f7 == 0.0F)
              i65 = this.e;
            else
              i65 = 0;
            int i66 = i64;
            i67 = i63;
            i60 = i6;
            localView6 = localView5;
            bool5 = bool2;
            int i68 = i65;
            bool6 = bool1;
            a(localView5, i6, paramInt1, i68, paramInt2, 0);
            if (i66 != -2147483648)
              localLayoutParams4.width = i66;
            int i69 = localView6.getMeasuredWidth();
            if (i4 != 0)
            {
              this.e += 0 + (i69 + localLayoutParams4.leftMargin + localLayoutParams4.rightMargin);
            }
            else
            {
              int i70 = this.e;
              this.e = Math.max(i70, 0 + (i70 + i69 + localLayoutParams4.leftMargin + localLayoutParams4.rightMargin));
            }
            if (bool5)
              i7 = Math.max(i69, i7);
          }
          int i71 = 1073741824;
          int i72;
          if (i3 != i71)
          {
            int i80 = localLayoutParams4.height;
            i72 = -1;
            if (i80 == i72)
            {
              i73 = 1;
              i12 = 1;
              break label672;
            }
          }
          else
          {
            i72 = -1;
          }
          int i73 = 0;
          label672: int i74 = localLayoutParams4.topMargin + localLayoutParams4.bottomMargin;
          int i75 = i74 + localView6.getMeasuredHeight();
          int i76 = localView6.getMeasuredState();
          i13 = View.combineMeasuredStates(i13, i76);
          if (bool6)
          {
            int i77 = localView6.getBaseline();
            if (i77 != i72)
            {
              int i78;
              if (localLayoutParams4.h < 0)
                i78 = this.d;
              else
                i78 = localLayoutParams4.h;
              int i79 = (0xFFFFFFFE & (i78 & 0x70) >> 4) >> 1;
              arrayOfInt1[i79] = Math.max(arrayOfInt1[i79], i77);
              arrayOfInt2[i79] = Math.max(arrayOfInt2[i79], i75 - i77);
            }
          }
          i62 = Math.max(i67, i75);
          if ((i11 != 0) && (localLayoutParams4.height == i72))
            i11 = 1;
          else
            i11 = 0;
          if (localLayoutParams4.g > 0.0F)
          {
            if (i73 == 0)
              i74 = i75;
            i61 = Math.max(i8, i74);
          }
          else
          {
            i61 = i8;
            if (i73 != 0)
              i75 = i74;
            i10 = Math.max(i10, i75);
          }
        }
        else
        {
          i60 = i6;
          bool5 = bool2;
          bool6 = bool1;
          i61 = i8;
          i62 = i5;
          f7 = f1;
        }
        i6 = i60 + 0;
        i8 = i61;
        f1 = f7;
      }
      i6++;
      i5 = i62;
      bool1 = bool6;
      bool2 = bool5;
    }
    boolean bool3 = bool2;
    boolean bool4 = bool1;
    int i14 = i8;
    int i15 = i10;
    int i16 = i5;
    if ((this.e > 0) && (a(i1)))
      this.e += this.l;
    int i17;
    if ((arrayOfInt1[1] == -1) && (arrayOfInt1[0] == -1) && (arrayOfInt1[2] == -1) && (arrayOfInt1[3] == -1))
      i17 = i16;
    else
      i17 = Math.max(i16, Math.max(arrayOfInt1[3], Math.max(arrayOfInt1[0], Math.max(arrayOfInt1[1], arrayOfInt1[2]))) + Math.max(arrayOfInt2[3], Math.max(arrayOfInt2[0], Math.max(arrayOfInt2[1], arrayOfInt2[2]))));
    if ((bool3) && ((i2 == -2147483648) || (i2 == 0)))
    {
      this.e = 0;
      for (int i58 = 0; i58 < i1; i58++)
      {
        View localView4 = b(i58);
        if (localView4 == null)
        {
          this.e = (0 + this.e);
        }
        else if (localView4.getVisibility() == 8)
        {
          i58 += 0;
        }
        else
        {
          LayoutParams localLayoutParams3 = (LayoutParams)localView4.getLayoutParams();
          if (i4 != 0)
          {
            this.e += 0 + (i7 + localLayoutParams3.leftMargin + localLayoutParams3.rightMargin);
          }
          else
          {
            int i59 = this.e;
            this.e = Math.max(i59, 0 + (i59 + i7 + localLayoutParams3.leftMargin + localLayoutParams3.rightMargin));
          }
        }
      }
    }
    this.e += getPaddingLeft() + getPaddingRight();
    int i18 = View.resolveSizeAndState(Math.max(this.e, getSuggestedMinimumWidth()), paramInt1, 0);
    int i19 = (0xFFFFFF & i18) - this.e;
    int i28;
    int i24;
    int i27;
    int i25;
    int i21;
    if ((i9 == 0) && ((i19 == 0) || (f1 <= 0.0F)))
    {
      i28 = Math.max(i15, i14);
      if ((bool3) && (i2 != 1073741824))
        for (int i57 = 0; i57 < i1; i57++)
        {
          View localView3 = b(i57);
          if ((localView3 != null) && (localView3.getVisibility() != 8) && (((LayoutParams)localView3.getLayoutParams()).g > 0.0F))
            localView3.measure(View.MeasureSpec.makeMeasureSpec(i7, 1073741824), View.MeasureSpec.makeMeasureSpec(localView3.getMeasuredHeight(), 1073741824));
        }
      i24 = paramInt2;
      i27 = i17;
      i25 = i1;
      i21 = i13;
    }
    else
    {
      float f2 = this.h;
      if (f2 > 0.0F)
        f1 = f2;
      arrayOfInt1[3] = -1;
      arrayOfInt1[2] = -1;
      arrayOfInt1[1] = -1;
      arrayOfInt1[0] = -1;
      arrayOfInt2[3] = -1;
      arrayOfInt2[2] = -1;
      arrayOfInt2[1] = -1;
      arrayOfInt2[0] = -1;
      this.e = 0;
      float f3 = f1;
      int i20 = i15;
      i21 = i13;
      int i22 = 0;
      int i23 = -1;
      while (i22 < i1)
      {
        View localView2 = b(i22);
        int i35;
        int i36;
        if ((localView2 != null) && (localView2.getVisibility() != 8))
        {
          LayoutParams localLayoutParams2 = (LayoutParams)localView2.getLayoutParams();
          float f4 = localLayoutParams2.g;
          if (f4 > 0.0F)
          {
            i35 = i1;
            int i51 = (int)(f4 * i19 / f3);
            float f6 = f3 - f4;
            int i52 = i19 - i51;
            int i53 = getPaddingTop() + getPaddingBottom() + localLayoutParams2.topMargin + localLayoutParams2.bottomMargin;
            int i54 = localLayoutParams2.height;
            i36 = i52;
            int i55 = getChildMeasureSpec(paramInt2, i53, i54);
            int i56;
            if ((localLayoutParams2.width == 0) && (i2 == 1073741824))
              if (i51 > 0)
              {
                i56 = i51;
                break label1701;
              }
            do
            {
              i56 = 0;
              break;
              i56 = i51 + localView2.getMeasuredWidth();
            }
            while (i56 < 0);
            label1701: localView2.measure(View.MeasureSpec.makeMeasureSpec(i56, 1073741824), i55);
            i21 = View.combineMeasuredStates(i21, 0xFF000000 & localView2.getMeasuredState());
            f3 = f6;
          }
          else
          {
            int i37 = i19;
            i35 = i1;
            i36 = i37;
          }
          float f5;
          if (i4 != 0)
          {
            int i49 = this.e;
            int i50 = localView2.getMeasuredWidth();
            f5 = f3;
            this.e = (i49 + (0 + (i50 + localLayoutParams2.leftMargin + localLayoutParams2.rightMargin)));
          }
          else
          {
            f5 = f3;
            int i38 = this.e;
            this.e = Math.max(i38, 0 + (i38 + localView2.getMeasuredWidth() + localLayoutParams2.leftMargin + localLayoutParams2.rightMargin));
          }
          int i39;
          if ((i3 != 1073741824) && (localLayoutParams2.height == -1))
            i39 = 1;
          else
            i39 = 0;
          int i40 = localLayoutParams2.topMargin + localLayoutParams2.bottomMargin;
          int i41 = i40 + localView2.getMeasuredHeight();
          i23 = Math.max(i23, i41);
          if (i39 == 0)
            i40 = i41;
          int i42 = Math.max(i20, i40);
          int i43;
          if (i11 != 0)
          {
            int i48 = localLayoutParams2.height;
            i43 = -1;
            if (i48 == i43)
            {
              i44 = 1;
              break label1949;
            }
          }
          else
          {
            i43 = -1;
          }
          int i44 = 0;
          label1949: if (bool4)
          {
            int i45 = localView2.getBaseline();
            if (i45 != i43)
            {
              int i46;
              if (localLayoutParams2.h < 0)
                i46 = this.d;
              else
                i46 = localLayoutParams2.h;
              int i47 = (0xFFFFFFFE & (i46 & 0x70) >> 4) >> 1;
              arrayOfInt1[i47] = Math.max(arrayOfInt1[i47], i45);
              arrayOfInt2[i47] = Math.max(arrayOfInt2[i47], i41 - i45);
            }
          }
          i20 = i42;
          i11 = i44;
          f3 = f5;
        }
        else
        {
          int i34 = i19;
          i35 = i1;
          i36 = i34;
        }
        i22++;
        i1 = i35;
        i19 = i36;
      }
      i24 = paramInt2;
      i25 = i1;
      this.e += getPaddingLeft() + getPaddingRight();
      int i26;
      if ((arrayOfInt1[1] == -1) && (arrayOfInt1[0] == -1) && (arrayOfInt1[2] == -1) && (arrayOfInt1[3] == -1))
        i26 = i23;
      else
        i26 = Math.max(i23, Math.max(arrayOfInt1[3], Math.max(arrayOfInt1[0], Math.max(arrayOfInt1[1], arrayOfInt1[2]))) + Math.max(arrayOfInt2[3], Math.max(arrayOfInt2[0], Math.max(arrayOfInt2[1], arrayOfInt2[2]))));
      i27 = i26;
      i28 = i20;
    }
    if ((i11 != 0) || (i3 == 1073741824))
      i28 = i27;
    int i29 = Math.max(i28 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight());
    setMeasuredDimension(i18 | 0xFF000000 & i21, View.resolveSizeAndState(i29, i24, i21 << 16));
    if (i12 != 0)
    {
      int i30 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
      int i31 = i25;
      for (int i32 = 0; i32 < i31; i32++)
      {
        View localView1 = b(i32);
        if (localView1.getVisibility() != 8)
        {
          LayoutParams localLayoutParams1 = (LayoutParams)localView1.getLayoutParams();
          if (localLayoutParams1.height == -1)
          {
            int i33 = localLayoutParams1.width;
            localLayoutParams1.width = localView1.getMeasuredWidth();
            measureChildWithMargins(localView1, paramInt1, 0, i30, 0);
            localLayoutParams1.width = i33;
          }
        }
      }
    }
  }

  private void b(Canvas paramCanvas, int paramInt)
  {
    this.k.setBounds(paramInt, getPaddingTop() + this.o, paramInt + this.l, getHeight() - getPaddingBottom() - this.o);
    this.k.draw(paramCanvas);
  }

  public LayoutParams a(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }

  protected final boolean a(int paramInt)
  {
    if (paramInt == 0)
      return (0x1 & this.n) != 0;
    if (paramInt == getChildCount())
      return (0x4 & this.n) != 0;
    if ((0x2 & this.n) != 0)
      for (int i1 = paramInt - 1; i1 >= 0; i1--)
        if (getChildAt(i1).getVisibility() != 8)
          return true;
    return false;
  }

  protected LayoutParams b(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new LayoutParams(paramLayoutParams);
  }

  protected LayoutParams c()
  {
    int i1 = this.c;
    if (i1 == 0)
      return new LayoutParams(-2, -2);
    if (i1 == 1)
      return new LayoutParams(-1, -2);
    return null;
  }

  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof LayoutParams;
  }

  public int getBaseline()
  {
    if (this.a < 0)
      return super.getBaseline();
    int i1 = getChildCount();
    int i2 = this.a;
    if (i1 > i2)
    {
      View localView = getChildAt(i2);
      int i3 = localView.getBaseline();
      if (i3 == -1)
      {
        if (this.a == 0)
          return -1;
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      }
      int i4 = this.b;
      if (this.c == 1)
      {
        int i5 = 0x70 & this.d;
        if (i5 != 48)
          if (i5 != 16)
          {
            if (i5 == 80)
              i4 = getBottom() - getTop() - getPaddingBottom() - this.e;
          }
          else
            i4 += (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.e) / 2;
      }
      return i3 + (i4 + ((LayoutParams)localView.getLayoutParams()).topMargin);
    }
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }

  public int getBaselineAlignedChildIndex()
  {
    return this.a;
  }

  public Drawable getDividerDrawable()
  {
    return this.k;
  }

  public int getDividerPadding()
  {
    return this.o;
  }

  public int getDividerWidth()
  {
    return this.l;
  }

  public int getGravity()
  {
    return this.d;
  }

  public int getOrientation()
  {
    return this.c;
  }

  public int getShowDividers()
  {
    return this.n;
  }

  int getVirtualChildCount()
  {
    return getChildCount();
  }

  public float getWeightSum()
  {
    return this.h;
  }

  protected void onDraw(Canvas paramCanvas)
  {
    if (this.k == null)
      return;
    int i1 = this.c;
    int i2 = 0;
    if (i1 == 1)
    {
      int i8 = getVirtualChildCount();
      while (i2 < i8)
      {
        View localView4 = b(i2);
        if ((localView4 != null) && (localView4.getVisibility() != 8) && (a(i2)))
        {
          LayoutParams localLayoutParams4 = (LayoutParams)localView4.getLayoutParams();
          a(paramCanvas, localView4.getTop() - localLayoutParams4.topMargin - this.m);
        }
        i2++;
      }
      if (a(i8))
      {
        View localView3 = b(i8 - 1);
        int i9;
        if (localView3 == null)
        {
          i9 = getHeight() - getPaddingBottom() - this.m;
        }
        else
        {
          LayoutParams localLayoutParams3 = (LayoutParams)localView3.getLayoutParams();
          i9 = localView3.getBottom() + localLayoutParams3.bottomMargin;
        }
        a(paramCanvas, i9);
      }
      return;
    }
    int i3 = getVirtualChildCount();
    boolean bool = ak.a(this);
    while (i2 < i3)
    {
      View localView2 = b(i2);
      if ((localView2 != null) && (localView2.getVisibility() != 8) && (a(i2)))
      {
        LayoutParams localLayoutParams2 = (LayoutParams)localView2.getLayoutParams();
        int i7;
        if (bool)
          i7 = localView2.getRight() + localLayoutParams2.rightMargin;
        else
          i7 = localView2.getLeft() - localLayoutParams2.leftMargin - this.l;
        b(paramCanvas, i7);
      }
      i2++;
    }
    if (a(i3))
    {
      View localView1 = b(i3 - 1);
      int i5;
      int i6;
      LayoutParams localLayoutParams1;
      if (localView1 == null)
      {
        if (bool)
        {
          i4 = getPaddingLeft();
          break label398;
        }
        i5 = getWidth() - getPaddingRight();
        i6 = this.l;
      }
      else
      {
        localLayoutParams1 = (LayoutParams)localView1.getLayoutParams();
        if (!bool)
          break label385;
        i5 = localView1.getLeft() - localLayoutParams1.leftMargin;
        i6 = this.l;
      }
      int i4 = i5 - i6;
      break label398;
      label385: i4 = localView1.getRight() + localLayoutParams1.rightMargin;
      label398: b(paramCanvas, i4);
    }
  }

  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(LinearLayoutCompat.class.getName());
  }

  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
  {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(LinearLayoutCompat.class.getName());
  }

  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i1 = this.c;
    int i2 = 8;
    if (i1 == 1)
    {
      int i32 = getPaddingLeft();
      int i33 = paramInt3 - paramInt1;
      int i34 = i33 - getPaddingRight();
      int i35 = i33 - i32 - getPaddingRight();
      int i36 = getVirtualChildCount();
      int i37 = this.d;
      int i38 = i37 & 0x70;
      int i39 = 0x800007 & i37;
      int i40;
      if (i38 != 16)
      {
        if (i38 != 80)
          i40 = getPaddingTop();
        else
          i40 = paramInt4 + getPaddingTop() - paramInt2 - this.e;
      }
      else
        i40 = getPaddingTop() + (paramInt4 - paramInt2 - this.e) / 2;
      int i41 = i40;
      int i42 = 0;
      while (i42 < i36)
      {
        View localView2 = b(i42);
        if (localView2 == null)
        {
          i41 += 0;
        }
        else if (localView2.getVisibility() != i2)
        {
          int i43 = localView2.getMeasuredWidth();
          int i44 = localView2.getMeasuredHeight();
          LayoutParams localLayoutParams2 = (LayoutParams)localView2.getLayoutParams();
          int i45 = localLayoutParams2.h;
          if (i45 < 0)
            i45 = i39;
          int i46 = 0x7 & d.a(i45, t.f(this));
          int i47;
          int i48;
          if (i46 != 1)
          {
            if (i46 != 5)
            {
              i49 = i32 + localLayoutParams2.leftMargin;
              break label307;
            }
            i47 = i34 - i43;
            i48 = localLayoutParams2.rightMargin;
          }
          else
          {
            i47 = i32 + (i35 - i43) / 2 + localLayoutParams2.leftMargin;
            i48 = localLayoutParams2.rightMargin;
          }
          int i49 = i47 - i48;
          label307: if (a(i42))
            i41 += this.m;
          int i50 = i41 + localLayoutParams2.topMargin;
          a(localView2, i49, i50 + 0, i43, i44);
          i41 = i50 + (0 + (i44 + localLayoutParams2.bottomMargin));
          i42 += 0;
        }
        i42++;
        i2 = 8;
      }
      return;
    }
    boolean bool1 = ak.a(this);
    int i3 = getPaddingTop();
    int i4 = paramInt4 - paramInt2;
    int i5 = i4 - getPaddingBottom();
    int i6 = i4 - i3 - getPaddingBottom();
    int i7 = getVirtualChildCount();
    int i8 = this.d;
    int i9 = 0x800007 & i8;
    int i10 = i8 & 0x70;
    boolean bool2 = this.f;
    int[] arrayOfInt1 = this.i;
    int[] arrayOfInt2 = this.j;
    int i11 = d.a(i9, t.f(this));
    int i12;
    if (i11 != 1)
    {
      if (i11 != 5)
        i12 = getPaddingLeft();
      else
        i12 = paramInt3 + getPaddingLeft() - paramInt1 - this.e;
    }
    else
      i12 = getPaddingLeft() + (paramInt3 - paramInt1 - this.e) / 2;
    int i13;
    int i14;
    if (bool1)
    {
      i13 = i7 - 1;
      i14 = -1;
    }
    else
    {
      i13 = 0;
      i14 = 1;
    }
    int i15 = i12;
    int i16 = 0;
    while (i16 < i7)
    {
      int i17 = i13 + i14 * i16;
      View localView1 = b(i17);
      int i18;
      int i19;
      int i20;
      boolean bool3;
      int i21;
      if (localView1 == null)
      {
        i15 += 0;
        i18 = i13;
        i19 = i7;
        i20 = i10;
        bool3 = bool2;
        i21 = 1;
      }
      else
      {
        if (localView1.getVisibility() != 8)
        {
          int i22 = localView1.getMeasuredWidth();
          int i23 = localView1.getMeasuredHeight();
          ViewGroup.LayoutParams localLayoutParams = localView1.getLayoutParams();
          i18 = i13;
          LayoutParams localLayoutParams1 = (LayoutParams)localLayoutParams;
          i19 = i7;
          if (bool2)
          {
            int i31 = localLayoutParams1.height;
            i20 = i10;
            if (i31 != -1)
            {
              i24 = localView1.getBaseline();
              break label702;
            }
          }
          else
          {
            i20 = i10;
          }
          int i24 = -1;
          label702: int i25 = localLayoutParams1.h;
          if (i25 < 0)
            i25 = i20;
          int i26 = i25 & 0x70;
          bool3 = bool2;
          int i27;
          if (i26 != 16)
          {
            int i29;
            if (i26 != 48)
            {
              if (i26 != 80)
              {
                i27 = i3;
                break label863;
              }
              i29 = i5 - i23 - localLayoutParams1.bottomMargin;
              if (i24 != -1)
              {
                int i30 = localView1.getMeasuredHeight() - i24;
                i27 = i29 - (arrayOfInt2[2] - i30);
                break label863;
              }
            }
            else
            {
              i29 = i3 + localLayoutParams1.topMargin;
              if (i24 != -1)
              {
                i27 = i29 + (arrayOfInt1[1] - i24);
                break label863;
              }
            }
            i27 = i29;
          }
          else
          {
            i27 = i3 + (i6 - i23) / 2 + localLayoutParams1.topMargin - localLayoutParams1.bottomMargin;
          }
          label863: if (a(i17))
            i15 += this.l;
          int i28 = i15 + localLayoutParams1.leftMargin;
          a(localView1, i28 + 0, i27, i22, i23);
          i15 = i28 + (0 + (i22 + localLayoutParams1.rightMargin));
          i16 += 0;
        }
        else
        {
          i18 = i13;
          i19 = i7;
          i20 = i10;
          bool3 = bool2;
        }
        i21 = 1;
      }
      i16 += i21;
      i13 = i18;
      i7 = i19;
      i10 = i20;
      bool2 = bool3;
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    if (this.c == 1)
    {
      this.e = 0;
      int i1 = getVirtualChildCount();
      int i2 = View.MeasureSpec.getMode(paramInt1);
      int i3 = View.MeasureSpec.getMode(paramInt2);
      int i4 = this.a;
      boolean bool1 = this.g;
      float f1 = 0.0F;
      int i5 = 0;
      int i6 = 0;
      int i7 = 0;
      int i8 = 0;
      int i9 = 0;
      int i10 = 0;
      int i11 = 1;
      int i12 = 0;
      int i51;
      for (int i13 = 0; i8 < i1; i13 = i51)
      {
        View localView4 = b(i8);
        boolean bool3;
        int i50;
        int i54;
        int i53;
        if (localView4 == null)
        {
          this.e = (0 + this.e);
          bool3 = bool1;
          i50 = i1;
          i51 = i13;
          i54 = 1;
          i53 = i3;
        }
        else
        {
          float f7;
          int i48;
          int i49;
          label558: int i52;
          if (localView4.getVisibility() != 8)
          {
            if (a(i8))
              this.e += this.m;
            LayoutParams localLayoutParams3 = (LayoutParams)localView4.getLayoutParams();
            f7 = f1 + localLayoutParams3.g;
            int i62;
            int i58;
            if ((i3 == 1073741824) && (localLayoutParams3.height == 0) && (localLayoutParams3.g > 0.0F))
            {
              int i70 = this.e;
              int i71 = i70 + localLayoutParams3.topMargin;
              int i72 = i5;
              this.e = Math.max(i70, i71 + localLayoutParams3.bottomMargin);
              i48 = i7;
              i62 = i8;
              bool3 = bool1;
              i50 = i1;
              i51 = i13;
              i58 = i72;
              i10 = 1;
              i53 = i3;
            }
            else
            {
              int i55 = i5;
              int i56;
              if ((localLayoutParams3.height == 0) && (localLayoutParams3.g > 0.0F))
              {
                localLayoutParams3.height = -2;
                i56 = 0;
              }
              else
              {
                i56 = -2147483648;
              }
              int i57;
              if (f7 == 0.0F)
                i57 = this.e;
              else
                i57 = 0;
              i58 = i55;
              int i59 = i6;
              int i60 = i8;
              i48 = i7;
              i50 = i1;
              i51 = i13;
              i53 = i3;
              int i61 = i56;
              i62 = i8;
              bool3 = bool1;
              a(localView4, i60, paramInt1, 0, paramInt2, i57);
              if (i61 != -2147483648)
                localLayoutParams3.height = i61;
              int i63 = localView4.getMeasuredHeight();
              int i64 = this.e;
              this.e = Math.max(i64, 0 + (i64 + i63 + localLayoutParams3.topMargin + localLayoutParams3.bottomMargin));
              if (bool3)
                i6 = Math.max(i63, i59);
              else
                i6 = i59;
            }
            if (i4 >= 0)
            {
              i49 = i62;
              if (i4 == i49 + 1)
                this.b = this.e;
            }
            else
            {
              i49 = i62;
            }
            if ((i49 < i4) && (localLayoutParams3.g > 0.0F))
              throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
            int i65;
            if (i2 != 1073741824)
            {
              int i69 = localLayoutParams3.width;
              i65 = -1;
              if (i69 == i65)
              {
                i66 = 1;
                i12 = 1;
                break label558;
              }
            }
            else
            {
              i65 = -1;
            }
            int i66 = 0;
            int i67 = localLayoutParams3.leftMargin + localLayoutParams3.rightMargin;
            int i68 = i67 + localView4.getMeasuredWidth();
            i52 = Math.max(i58, i68);
            i9 = View.combineMeasuredStates(i9, localView4.getMeasuredState());
            if ((i11 != 0) && (localLayoutParams3.width == i65))
              i11 = 1;
            else
              i11 = 0;
            if (localLayoutParams3.g > 0.0F)
            {
              if (i66 == 0)
                i67 = i68;
              i48 = Math.max(i48, i67);
            }
            else
            {
              if (i66 == 0)
                i67 = i68;
              i51 = Math.max(i51, i67);
            }
          }
          else
          {
            i48 = i7;
            i49 = i8;
            bool3 = bool1;
            i50 = i1;
            i51 = i13;
            i52 = i5;
            i53 = i3;
            f7 = f1;
          }
          i8 = i49 + 0;
          i5 = i52;
          i7 = i48;
          f1 = f7;
          i54 = 1;
        }
        i8 += i54;
        i3 = i53;
        i1 = i50;
        bool1 = bool3;
      }
      int i14 = i7;
      boolean bool2 = bool1;
      int i15 = i1;
      int i16 = i13;
      int i17 = i5;
      int i18 = i6;
      int i19 = i3;
      int i20;
      if (this.e > 0)
      {
        i20 = i15;
        if (a(i20))
          this.e += this.m;
      }
      else
      {
        i20 = i15;
      }
      int i21 = i19;
      if ((bool2) && ((i21 == -2147483648) || (i21 == 0)))
      {
        this.e = 0;
        for (int i46 = 0; i46 < i20; i46++)
        {
          View localView3 = b(i46);
          if (localView3 == null)
          {
            this.e = (0 + this.e);
          }
          else if (localView3.getVisibility() == 8)
          {
            i46 += 0;
          }
          else
          {
            LayoutParams localLayoutParams2 = (LayoutParams)localView3.getLayoutParams();
            int i47 = this.e;
            this.e = Math.max(i47, 0 + (i47 + i18 + localLayoutParams2.topMargin + localLayoutParams2.bottomMargin));
          }
        }
      }
      this.e += getPaddingTop() + getPaddingBottom();
      int i22 = Math.max(this.e, getSuggestedMinimumHeight());
      int i23 = i16;
      int i24 = View.resolveSizeAndState(i22, paramInt2, 0);
      int i25 = (0xFFFFFF & i24) - this.e;
      int i29;
      int i28;
      int i26;
      if ((i10 == 0) && ((i25 == 0) || (f1 <= 0.0F)))
      {
        i29 = Math.max(i23, i14);
        if ((bool2) && (i21 != 1073741824))
          for (int i45 = 0; i45 < i20; i45++)
          {
            View localView2 = b(i45);
            if ((localView2 != null) && (localView2.getVisibility() != 8) && (((LayoutParams)localView2.getLayoutParams()).g > 0.0F))
              localView2.measure(View.MeasureSpec.makeMeasureSpec(localView2.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i18, 1073741824));
          }
        i28 = paramInt1;
        i26 = i17;
      }
      else
      {
        float f2 = this.h;
        if (f2 > 0.0F)
          f1 = f2;
        this.e = 0;
        i26 = i17;
        float f3 = f1;
        int i27 = 0;
        while (i27 < i20)
        {
          View localView1 = b(i27);
          int i31;
          int i30;
          if (localView1.getVisibility() != 8)
          {
            LayoutParams localLayoutParams1 = (LayoutParams)localView1.getLayoutParams();
            float f4 = localLayoutParams1.g;
            float f5;
            if (f4 > 0.0F)
            {
              int i41 = (int)(f4 * i25 / f3);
              float f6 = f3 - f4;
              int i42 = i25 - i41;
              int i43 = getPaddingLeft() + getPaddingRight();
              f5 = f6;
              int i44 = getChildMeasureSpec(paramInt1, i43 + localLayoutParams1.leftMargin + localLayoutParams1.rightMargin, localLayoutParams1.width);
              if ((localLayoutParams1.height == 0) && (i21 == 1073741824))
              {
                if (i41 > 0);
              }
              else
                do
                {
                  i41 = 0;
                  break;
                  i41 += localView1.getMeasuredHeight();
                }
                while (i41 < 0);
              localView1.measure(i44, View.MeasureSpec.makeMeasureSpec(i41, 1073741824));
              i9 = View.combineMeasuredStates(i9, 0xFFFFFF00 & localView1.getMeasuredState());
              i31 = i42;
            }
            else
            {
              i31 = i25;
              f5 = f3;
            }
            int i32 = localLayoutParams1.leftMargin + localLayoutParams1.rightMargin;
            int i33 = i32 + localView1.getMeasuredWidth();
            int i34 = Math.max(i26, i33);
            int i35;
            if (i2 != 1073741824)
            {
              int i40 = localLayoutParams1.width;
              i30 = i21;
              i35 = -1;
              if (i40 == i35)
              {
                i36 = 1;
                break label1462;
              }
            }
            else
            {
              i30 = i21;
              i35 = -1;
            }
            int i36 = 0;
            label1462: if (i36 == 0)
              i32 = i33;
            int i37 = Math.max(i23, i32);
            int i38;
            if ((i11 != 0) && (localLayoutParams1.width == i35))
              i38 = 1;
            else
              i38 = 0;
            int i39 = this.e;
            this.e = Math.max(i39, 0 + (i39 + localView1.getMeasuredHeight() + localLayoutParams1.topMargin + localLayoutParams1.bottomMargin));
            i23 = i37;
            i11 = i38;
            f3 = f5;
            i26 = i34;
          }
          else
          {
            i30 = i21;
            i31 = i25;
          }
          i27++;
          i25 = i31;
          i21 = i30;
        }
        i28 = paramInt1;
        this.e += getPaddingTop() + getPaddingBottom();
        i29 = i23;
      }
      if ((i11 != 0) || (i2 == 1073741824))
        i29 = i26;
      setMeasuredDimension(View.resolveSizeAndState(Math.max(i29 + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), i28, i9), i24);
      if (i12 != 0)
        a(i20, paramInt2);
      return;
    }
    b(paramInt1, paramInt2);
  }

  public void setBaselineAligned(boolean paramBoolean)
  {
    this.f = paramBoolean;
  }

  public void setBaselineAlignedChildIndex(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < getChildCount()))
    {
      this.a = paramInt;
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("base aligned child index out of range (0, ");
    localStringBuilder.append(getChildCount());
    localStringBuilder.append(")");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public void setDividerDrawable(Drawable paramDrawable)
  {
    if (paramDrawable == this.k)
      return;
    this.k = paramDrawable;
    if (paramDrawable != null)
    {
      this.l = paramDrawable.getIntrinsicWidth();
      this.m = paramDrawable.getIntrinsicHeight();
    }
    else
    {
      this.l = 0;
      this.m = 0;
    }
    boolean bool = false;
    if (paramDrawable == null)
      bool = true;
    setWillNotDraw(bool);
    requestLayout();
  }

  public void setDividerPadding(int paramInt)
  {
    this.o = paramInt;
  }

  public void setGravity(int paramInt)
  {
    if (this.d != paramInt)
    {
      if ((0x800007 & paramInt) == 0)
        paramInt |= 8388611;
      if ((paramInt & 0x70) == 0)
        paramInt |= 48;
      this.d = paramInt;
      requestLayout();
    }
  }

  public void setHorizontalGravity(int paramInt)
  {
    int i1 = paramInt & 0x800007;
    int i2 = this.d;
    if ((0x800007 & i2) != i1)
    {
      this.d = (i1 | 0xFF7FFFF8 & i2);
      requestLayout();
    }
  }

  public void setMeasureWithLargestChildEnabled(boolean paramBoolean)
  {
    this.g = paramBoolean;
  }

  public void setOrientation(int paramInt)
  {
    if (this.c != paramInt)
    {
      this.c = paramInt;
      requestLayout();
    }
  }

  public void setShowDividers(int paramInt)
  {
    if (paramInt != this.n)
      requestLayout();
    this.n = paramInt;
  }

  public void setVerticalGravity(int paramInt)
  {
    int i1 = paramInt & 0x70;
    int i2 = this.d;
    if ((i2 & 0x70) != i1)
    {
      this.d = (i1 | i2 & 0xFFFFFF8F);
      requestLayout();
    }
  }

  public void setWeightSum(float paramFloat)
  {
    this.h = Math.max(0.0F, paramFloat);
  }

  public boolean shouldDelayChildPressedState()
  {
    return false;
  }

  public static class LayoutParams extends ViewGroup.MarginLayoutParams
  {
    public float g;
    public int h = -1;

    static
    {
      CoverageLogger.Log(12144640);
    }

    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16842931, 16842996, 16842997, 16843137 });
      this.g = localTypedArray.getFloat(3, 0.0F);
      this.h = localTypedArray.getInt(0, -1);
      localTypedArray.recycle();
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.LinearLayoutCompat
 * JD-Core Version:    0.6.2
 */