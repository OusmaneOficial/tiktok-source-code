package androidx.appcompat.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

class c extends DataSetObservable
{
  static final String a = c.class.getSimpleName();
  private static final Object g = new Object();
  private static final Map<String, c> h = new HashMap();
  final Object b;
  final List<a> c;
  final Context d;
  final String e;
  boolean f;
  private final List<c> i;
  private Intent j;
  private b k;
  private int l;
  private boolean m;
  private boolean n;
  private boolean o;
  private d p;

  static
  {
    CoverageLogger.Log(12500992);
  }

  private void d()
  {
    if (this.m)
    {
      if (!this.n)
        return;
      this.n = false;
      if (!TextUtils.isEmpty(this.e))
      {
        e locale = new e();
        Executor localExecutor = AsyncTask.THREAD_POOL_EXECUTOR;
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = new ArrayList(this.i);
        arrayOfObject[1] = this.e;
        locale.executeOnExecutor(localExecutor, arrayOfObject);
      }
      return;
    }
    throw new IllegalStateException("No preceding call to #readHistoricalData");
  }

  private boolean e()
  {
    if ((this.k != null) && (this.j != null) && (!this.c.isEmpty()) && (!this.i.isEmpty()))
    {
      Collections.unmodifiableList(this.i);
      return true;
    }
    return false;
  }

  private boolean f()
  {
    boolean bool = this.o;
    int i1 = 0;
    if ((bool) && (this.j != null))
    {
      this.o = false;
      this.c.clear();
      List localList = this.d.getPackageManager().queryIntentActivities(this.j, 0);
      int i2 = localList.size();
      while (i1 < i2)
      {
        ResolveInfo localResolveInfo = (ResolveInfo)localList.get(i1);
        this.c.add(new a(localResolveInfo));
        i1++;
      }
      return true;
    }
    return false;
  }

  private boolean g()
  {
    if ((this.f) && (this.n) && (!TextUtils.isEmpty(this.e)))
    {
      this.f = false;
      this.m = true;
      i();
      return true;
    }
    return false;
  }

  private void h()
  {
    int i1 = this.i.size() - this.l;
    if (i1 <= 0)
      return;
    this.n = true;
    for (int i2 = 0; i2 < i1; i2++)
      this.i.remove(0);
  }

  // ERROR //
  private void i()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 127	androidx/appcompat/widget/c:d	Landroid/content/Context;
    //   4: aload_0
    //   5: getfield 68	androidx/appcompat/widget/c:e	Ljava/lang/String;
    //   8: invokevirtual 177	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   11: astore_2
    //   12: invokestatic 183	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore 6
    //   17: aload 6
    //   19: aload_2
    //   20: ldc 185
    //   22: invokeinterface 191 3 0
    //   27: iconst_0
    //   28: istore 7
    //   30: iload 7
    //   32: iconst_1
    //   33: if_icmpeq +21 -> 54
    //   36: iload 7
    //   38: iconst_2
    //   39: if_icmpeq +15 -> 54
    //   42: aload 6
    //   44: invokeinterface 194 1 0
    //   49: istore 7
    //   51: goto -21 -> 30
    //   54: ldc 196
    //   56: aload 6
    //   58: invokeinterface 199 1 0
    //   63: invokevirtual 204	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   66: ifeq +135 -> 201
    //   69: aload_0
    //   70: getfield 89	androidx/appcompat/widget/c:i	Ljava/util/List;
    //   73: astore 8
    //   75: aload 8
    //   77: invokeinterface 125 1 0
    //   82: aload 6
    //   84: invokeinterface 194 1 0
    //   89: istore 9
    //   91: iload 9
    //   93: iconst_1
    //   94: if_icmpeq +94 -> 188
    //   97: iload 9
    //   99: iconst_3
    //   100: if_icmpeq -18 -> 82
    //   103: iload 9
    //   105: iconst_4
    //   106: if_icmpeq -24 -> 82
    //   109: ldc 206
    //   111: aload 6
    //   113: invokeinterface 199 1 0
    //   118: invokevirtual 204	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   121: ifeq +57 -> 178
    //   124: aload 8
    //   126: new 208	androidx/appcompat/widget/c$c
    //   129: dup
    //   130: aload 6
    //   132: aconst_null
    //   133: ldc 210
    //   135: invokeinterface 214 3 0
    //   140: aload 6
    //   142: aconst_null
    //   143: ldc 216
    //   145: invokeinterface 214 3 0
    //   150: invokestatic 222	java/lang/Long:parseLong	(Ljava/lang/String;)J
    //   153: aload 6
    //   155: aconst_null
    //   156: ldc 224
    //   158: invokeinterface 214 3 0
    //   163: invokestatic 230	java/lang/Float:parseFloat	(Ljava/lang/String;)F
    //   166: invokespecial 233	androidx/appcompat/widget/c$c:<init>	(Ljava/lang/String;JF)V
    //   169: invokeinterface 158 2 0
    //   174: pop
    //   175: goto -93 -> 82
    //   178: new 171	org/xmlpull/v1/XmlPullParserException
    //   181: dup
    //   182: ldc 235
    //   184: invokespecial 236	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   187: athrow
    //   188: aload_2
    //   189: ifnull +63 -> 252
    //   192: aload_2
    //   193: invokevirtual 241	java/io/FileInputStream:close	()V
    //   196: goto +4 -> 200
    //   199: pop
    //   200: return
    //   201: new 171	org/xmlpull/v1/XmlPullParserException
    //   204: dup
    //   205: ldc 243
    //   207: invokespecial 236	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   210: athrow
    //   211: astore 4
    //   213: aload_2
    //   214: ifnull +10 -> 224
    //   217: aload_2
    //   218: invokevirtual 241	java/io/FileInputStream:close	()V
    //   221: goto +4 -> 225
    //   224: pop
    //   225: aload 4
    //   227: athrow
    //   228: aload_2
    //   229: ifnull +23 -> 252
    //   232: aload_2
    //   233: invokevirtual 241	java/io/FileInputStream:close	()V
    //   236: goto +4 -> 240
    //   239: pop
    //   240: return
    //   241: aload_2
    //   242: ifnull +10 -> 252
    //   245: aload_2
    //   246: invokevirtual 241	java/io/FileInputStream:close	()V
    //   249: goto +4 -> 253
    //   252: pop
    //   253: return
    //
    // Exception table:
    //   from	to	target	type
    //   192	196	199	java/io/IOException
    //   12	27	211	finally
    //   42	51	211	finally
    //   54	82	211	finally
    //   82	91	211	finally
    //   109	175	211	finally
    //   178	188	211	finally
    //   201	211	211	finally
    //   217	221	224	java/io/IOException
    //   12	27	228	java/io/IOException
    //   42	51	228	java/io/IOException
    //   54	82	228	java/io/IOException
    //   82	91	228	java/io/IOException
    //   109	175	228	java/io/IOException
    //   178	188	228	java/io/IOException
    //   201	211	228	java/io/IOException
    //   232	236	239	java/io/IOException
    //   12	27	241	org/xmlpull/v1/XmlPullParserException
    //   42	51	241	org/xmlpull/v1/XmlPullParserException
    //   54	82	241	org/xmlpull/v1/XmlPullParserException
    //   82	91	241	org/xmlpull/v1/XmlPullParserException
    //   109	175	241	org/xmlpull/v1/XmlPullParserException
    //   178	188	241	org/xmlpull/v1/XmlPullParserException
    //   201	211	241	org/xmlpull/v1/XmlPullParserException
    //   0	12	252	java/io/FileNotFoundException
    //   245	249	252	java/io/IOException
  }

  public final int a()
  {
    synchronized (this.b)
    {
      c();
      int i1 = this.c.size();
      return i1;
    }
  }

  public final int a(ResolveInfo paramResolveInfo)
  {
    int i2;
    synchronized (this.b)
    {
      c();
      List localList = this.c;
      int i1 = localList.size();
      i2 = 0;
      if (i2 < i1)
      {
        if (((a)localList.get(i2)).a == paramResolveInfo)
          return i2;
      }
      else
        return -1;
    }
  }

  public final ResolveInfo a(int paramInt)
  {
    synchronized (this.b)
    {
      c();
      ResolveInfo localResolveInfo = ((a)this.c.get(paramInt)).a;
      return localResolveInfo;
    }
  }

  boolean a(c paramc)
  {
    boolean bool = this.i.add(paramc);
    if (bool)
    {
      this.n = true;
      h();
      d();
      e();
      notifyChanged();
    }
    return bool;
  }

  public final Intent b(int paramInt)
  {
    synchronized (this.b)
    {
      if (this.j == null)
        return null;
      c();
      a locala = (a)this.c.get(paramInt);
      ComponentName localComponentName = new ComponentName(locala.a.activityInfo.packageName, locala.a.activityInfo.name);
      Intent localIntent1 = new Intent(this.j);
      localIntent1.setComponent(localComponentName);
      if (this.p != null)
      {
        Intent localIntent2 = new Intent(localIntent1);
        if (this.p.a(this, localIntent2))
          return null;
      }
      a(new c(localComponentName, System.currentTimeMillis(), 1.0F));
      return localIntent1;
    }
  }

  public final ResolveInfo b()
  {
    synchronized (this.b)
    {
      c();
      if (!this.c.isEmpty())
      {
        ResolveInfo localResolveInfo = ((a)this.c.get(0)).a;
        return localResolveInfo;
      }
      return null;
    }
  }

  void c()
  {
    boolean bool = f() | g();
    h();
    if (bool)
    {
      e();
      notifyChanged();
    }
  }

  public static final class a
    implements Comparable<a>
  {
    public final ResolveInfo a;
    public float b;

    static
    {
      CoverageLogger.Log(12283904);
    }

    public a(ResolveInfo paramResolveInfo)
    {
      this.a = paramResolveInfo;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject == null)
        return false;
      if (getClass() != paramObject.getClass())
        return false;
      a locala = (a)paramObject;
      return Float.floatToIntBits(this.b) == Float.floatToIntBits(locala.b);
    }

    public final int hashCode()
    {
      return 31 + Float.floatToIntBits(this.b);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("resolveInfo:");
      localStringBuilder.append(this.a.toString());
      localStringBuilder.append("; weight:");
      localStringBuilder.append(new BigDecimal(this.b));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(12496896);
    }
  }

  public static final class c
  {
    public final ComponentName a;
    public final long b;
    public final float c;

    static
    {
      CoverageLogger.Log(12498944);
    }

    public c(ComponentName paramComponentName, long paramLong, float paramFloat)
    {
      this.a = paramComponentName;
      this.b = paramLong;
      this.c = paramFloat;
    }

    public c(String paramString, long paramLong, float paramFloat)
    {
      this(ComponentName.unflattenFromString(paramString), paramLong, paramFloat);
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject == null)
        return false;
      if (getClass() != paramObject.getClass())
        return false;
      c localc = (c)paramObject;
      ComponentName localComponentName = this.a;
      if (localComponentName == null)
      {
        if (localc.a != null)
          return false;
      }
      else if (!localComponentName.equals(localc.a))
        return false;
      if (this.b != localc.b)
        return false;
      return Float.floatToIntBits(this.c) == Float.floatToIntBits(localc.c);
    }

    public final int hashCode()
    {
      ComponentName localComponentName = this.a;
      int i;
      if (localComponentName == null)
        i = 0;
      else
        i = localComponentName.hashCode();
      int j = 31 * (i + 31);
      long l = this.b;
      return 31 * (j + (int)(l ^ l >>> 32)) + Float.floatToIntBits(this.c);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("; activity:");
      localStringBuilder.append(this.a);
      localStringBuilder.append("; time:");
      localStringBuilder.append(this.b);
      localStringBuilder.append("; weight:");
      localStringBuilder.append(new BigDecimal(this.c));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface d
  {
    static
    {
      CoverageLogger.Log(12503040);
    }

    public abstract boolean a(c paramc, Intent paramIntent);
  }

  final class e extends AsyncTask<Object, Void, Void>
  {
    static
    {
      CoverageLogger.Log(12277760);
    }

    e()
    {
    }

    // ERROR //
    private Void a(Object[] paramArrayOfObject)
    {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: aaload
      //   3: checkcast 33	java/util/List
      //   6: astore_2
      //   7: aload_1
      //   8: iconst_1
      //   9: aaload
      //   10: checkcast 35	java/lang/String
      //   13: astore_3
      //   14: aload_0
      //   15: getfield 20	androidx/appcompat/widget/c$e:a	Landroidx/appcompat/widget/c;
      //   18: getfield 41	androidx/appcompat/widget/c:d	Landroid/content/Context;
      //   21: aload_3
      //   22: iconst_0
      //   23: invokevirtual 47	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
      //   26: astore 4
      //   28: invokestatic 53	android/util/Xml:newSerializer	()Lorg/xmlpull/v1/XmlSerializer;
      //   31: astore 5
      //   33: aload 5
      //   35: aload 4
      //   37: aconst_null
      //   38: invokeinterface 59 3 0
      //   43: aload 5
      //   45: ldc 61
      //   47: iconst_1
      //   48: invokestatic 67	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
      //   51: invokeinterface 71 3 0
      //   56: aload 5
      //   58: aconst_null
      //   59: ldc 73
      //   61: invokeinterface 77 3 0
      //   66: pop
      //   67: aload_2
      //   68: invokeinterface 81 1 0
      //   73: istore 9
      //   75: iconst_0
      //   76: istore 10
      //   78: iload 10
      //   80: iload 9
      //   82: if_icmpge +100 -> 182
      //   85: aload_2
      //   86: iconst_0
      //   87: invokeinterface 85 2 0
      //   92: checkcast 87	androidx/appcompat/widget/c$c
      //   95: astore 11
      //   97: aload 5
      //   99: aconst_null
      //   100: ldc 89
      //   102: invokeinterface 77 3 0
      //   107: pop
      //   108: aload 5
      //   110: aconst_null
      //   111: ldc 91
      //   113: aload 11
      //   115: getfield 94	androidx/appcompat/widget/c$c:a	Landroid/content/ComponentName;
      //   118: invokevirtual 100	android/content/ComponentName:flattenToString	()Ljava/lang/String;
      //   121: invokeinterface 104 4 0
      //   126: pop
      //   127: aload 5
      //   129: aconst_null
      //   130: ldc 106
      //   132: aload 11
      //   134: getfield 110	androidx/appcompat/widget/c$c:b	J
      //   137: invokestatic 113	java/lang/String:valueOf	(J)Ljava/lang/String;
      //   140: invokeinterface 104 4 0
      //   145: pop
      //   146: aload 5
      //   148: aconst_null
      //   149: ldc 115
      //   151: aload 11
      //   153: getfield 119	androidx/appcompat/widget/c$c:c	F
      //   156: invokestatic 122	java/lang/String:valueOf	(F)Ljava/lang/String;
      //   159: invokeinterface 104 4 0
      //   164: pop
      //   165: aload 5
      //   167: aconst_null
      //   168: ldc 89
      //   170: invokeinterface 125 3 0
      //   175: pop
      //   176: iinc 10 1
      //   179: goto -101 -> 78
      //   182: aload 5
      //   184: aconst_null
      //   185: ldc 73
      //   187: invokeinterface 125 3 0
      //   192: pop
      //   193: aload 5
      //   195: invokeinterface 128 1 0
      //   200: aload_0
      //   201: getfield 20	androidx/appcompat/widget/c$e:a	Landroidx/appcompat/widget/c;
      //   204: iconst_1
      //   205: putfield 132	androidx/appcompat/widget/c:f	Z
      //   208: aload 4
      //   210: ifnull +85 -> 295
      //   213: aload 4
      //   215: invokevirtual 137	java/io/FileOutputStream:close	()V
      //   218: aconst_null
      //   219: areturn
      //   220: astore 6
      //   222: aload_0
      //   223: getfield 20	androidx/appcompat/widget/c$e:a	Landroidx/appcompat/widget/c;
      //   226: iconst_1
      //   227: putfield 132	androidx/appcompat/widget/c:f	Z
      //   230: aload 4
      //   232: ifnull +11 -> 243
      //   235: aload 4
      //   237: invokevirtual 137	java/io/FileOutputStream:close	()V
      //   240: goto +4 -> 244
      //   243: pop
      //   244: aload 6
      //   246: athrow
      //   247: aload_0
      //   248: getfield 20	androidx/appcompat/widget/c$e:a	Landroidx/appcompat/widget/c;
      //   251: iconst_1
      //   252: putfield 132	androidx/appcompat/widget/c:f	Z
      //   255: aload 4
      //   257: ifnull +38 -> 295
      //   260: goto -47 -> 213
      //   263: aload_0
      //   264: getfield 20	androidx/appcompat/widget/c$e:a	Landroidx/appcompat/widget/c;
      //   267: iconst_1
      //   268: putfield 132	androidx/appcompat/widget/c:f	Z
      //   271: aload 4
      //   273: ifnull +22 -> 295
      //   276: goto -63 -> 213
      //   279: aload_0
      //   280: getfield 20	androidx/appcompat/widget/c$e:a	Landroidx/appcompat/widget/c;
      //   283: iconst_1
      //   284: putfield 132	androidx/appcompat/widget/c:f	Z
      //   287: aload 4
      //   289: ifnull +6 -> 295
      //   292: goto -79 -> 213
      //   295: aconst_null
      //   296: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   33	75	220	finally
      //   85	176	220	finally
      //   182	200	220	finally
      //   235	240	243	java/io/IOException
      //   33	75	247	java/io/IOException
      //   85	176	247	java/io/IOException
      //   182	200	247	java/io/IOException
      //   33	75	263	java/lang/IllegalStateException
      //   85	176	263	java/lang/IllegalStateException
      //   182	200	263	java/lang/IllegalStateException
      //   33	75	279	java/lang/IllegalArgumentException
      //   85	176	279	java/lang/IllegalArgumentException
      //   182	200	279	java/lang/IllegalArgumentException
      //   14	28	295	java/io/FileNotFoundException
      //   213	218	295	java/io/IOException
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.c
 * JD-Core Version:    0.6.2
 */