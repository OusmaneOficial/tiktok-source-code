package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.LayerDrawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import androidx.c.d;
import androidx.c.e;
import androidx.c.h;
import androidx.core.content.b;
import androidx.l.a.a.i;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class f
{
  private static final PorterDuff.Mode a = PorterDuff.Mode.SRC_IN;
  private static f b;
  private static final c c = new c(6);
  private static final int[] d = { 2131230808, 2131230806, 2131230727 };
  private static final int[] e = { 2131230749, 2131230790, 2131230756, 2131230751, 2131230752, 2131230755, 2131230754 };
  private static final int[] f = { 2131230805, 2131230807, 2131230742, 2131230798, 2131230799, 2131230801, 2131230803, 2131230800, 2131230802, 2131230804 };
  private static final int[] g = { 2131230780, 2131230740, 2131230779 };
  private static final int[] h = { 2131230796, 2131230809 };
  private static final int[] i = { 2131230730, 2131230735 };
  private WeakHashMap<Context, h<ColorStateList>> j;
  private androidx.c.a<String, d> k;
  private h<String> l;
  private final WeakHashMap<Context, d<WeakReference<Drawable.ConstantState>>> m = new WeakHashMap(0);
  private TypedValue n;
  private boolean o;

  static
  {
    CoverageLogger.Log(12249088);
  }

  private static long a(TypedValue paramTypedValue)
  {
    return paramTypedValue.assetCookie << 32 | paramTypedValue.data;
  }

  private static PorterDuff.Mode a(int paramInt)
  {
    if (paramInt == 2131230794)
      return PorterDuff.Mode.MULTIPLY;
    return null;
  }

  public static PorterDuffColorFilter a(int paramInt, PorterDuff.Mode paramMode)
  {
    try
    {
      PorterDuffColorFilter localPorterDuffColorFilter = (PorterDuffColorFilter)c.a(Integer.valueOf(c.a(paramInt, paramMode)));
      if (localPorterDuffColorFilter == null)
      {
        localPorterDuffColorFilter = new PorterDuffColorFilter(paramInt, paramMode);
        ((PorterDuffColorFilter)c.a(Integer.valueOf(c.a(paramInt, paramMode)), localPorterDuffColorFilter));
      }
      return localPorterDuffColorFilter;
    }
    finally
    {
    }
  }

  private static PorterDuffColorFilter a(ColorStateList paramColorStateList, PorterDuff.Mode paramMode, int[] paramArrayOfInt)
  {
    if ((paramColorStateList != null) && (paramMode != null))
      return a(paramColorStateList.getColorForState(paramArrayOfInt, 0), paramMode);
    return null;
  }

  private Drawable a(Context paramContext, int paramInt, boolean paramBoolean, Drawable paramDrawable)
  {
    ColorStateList localColorStateList = b(paramContext, paramInt);
    if (localColorStateList != null)
    {
      if (p.c(paramDrawable))
        paramDrawable = paramDrawable.mutate();
      paramDrawable = androidx.core.graphics.drawable.a.f(paramDrawable);
      androidx.core.graphics.drawable.a.a(paramDrawable, localColorStateList);
      PorterDuff.Mode localMode = a(paramInt);
      if (localMode != null)
      {
        androidx.core.graphics.drawable.a.a(paramDrawable, localMode);
        return paramDrawable;
      }
    }
    else
    {
      if (paramInt == 2131230791)
      {
        LayerDrawable localLayerDrawable2 = (LayerDrawable)paramDrawable;
        a(localLayerDrawable2.findDrawableByLayerId(16908288), aa.a(paramContext, 2130968927), a);
        a(localLayerDrawable2.findDrawableByLayerId(16908303), aa.a(paramContext, 2130968927), a);
        a(localLayerDrawable2.findDrawableByLayerId(16908301), aa.a(paramContext, 2130968925), a);
        return paramDrawable;
      }
      if ((paramInt != 2131230782) && (paramInt != 2131230781) && (paramInt != 2131230783))
      {
        if ((!a(paramContext, paramInt, paramDrawable)) && (paramBoolean))
          return null;
      }
      else
      {
        LayerDrawable localLayerDrawable1 = (LayerDrawable)paramDrawable;
        a(localLayerDrawable1.findDrawableByLayerId(16908288), aa.c(paramContext, 2130968927), a);
        a(localLayerDrawable1.findDrawableByLayerId(16908303), aa.a(paramContext, 2130968925), a);
        a(localLayerDrawable1.findDrawableByLayerId(16908301), aa.a(paramContext, 2130968925), a);
      }
    }
    return paramDrawable;
  }

  private Drawable a(Context paramContext, long paramLong)
  {
    try
    {
      d locald = (d)this.m.get(paramContext);
      if (locald == null)
        return null;
      WeakReference localWeakReference = (WeakReference)locald.a(paramLong);
      if (localWeakReference != null)
      {
        Drawable.ConstantState localConstantState = (Drawable.ConstantState)localWeakReference.get();
        if (localConstantState != null)
        {
          Drawable localDrawable = localConstantState.newDrawable(paramContext.getResources());
          return localDrawable;
        }
        locald.b(paramLong);
      }
      return null;
    }
    finally
    {
    }
  }

  public static f a()
  {
    try
    {
      if (b == null)
      {
        f localf1 = new f();
        b = localf1;
        if (Build.VERSION.SDK_INT < 24)
        {
          localf1.a("vector", new e());
          localf1.a("animated-vector", new b());
          localf1.a("animated-selector", new a());
        }
      }
      f localf2 = b;
      return localf2;
    }
    finally
    {
    }
  }

  private static void a(Drawable paramDrawable, int paramInt, PorterDuff.Mode paramMode)
  {
    if (p.c(paramDrawable))
      paramDrawable = paramDrawable.mutate();
    if (paramMode == null)
      paramMode = a;
    paramDrawable.setColorFilter(a(paramInt, paramMode));
  }

  static void a(Drawable paramDrawable, ac paramac, int[] paramArrayOfInt)
  {
    if ((p.c(paramDrawable)) && (paramDrawable.mutate() != paramDrawable))
      return;
    if ((!paramac.d) && (!paramac.c))
    {
      paramDrawable.clearColorFilter();
    }
    else
    {
      ColorStateList localColorStateList;
      if (paramac.d)
        localColorStateList = paramac.a;
      else
        localColorStateList = null;
      PorterDuff.Mode localMode;
      if (paramac.c)
        localMode = paramac.b;
      else
        localMode = a;
      paramDrawable.setColorFilter(a(localColorStateList, localMode, paramArrayOfInt));
    }
    if (Build.VERSION.SDK_INT <= 23)
      paramDrawable.invalidateSelf();
  }

  private void a(String paramString, d paramd)
  {
    if (this.k == null)
      this.k = new androidx.c.a();
    this.k.put(paramString, paramd);
  }

  static boolean a(Context paramContext, int paramInt, Drawable paramDrawable)
  {
    PorterDuff.Mode localMode = a;
    boolean bool = a(d, paramInt);
    int i1 = 16842801;
    if (bool)
      i1 = 2130968927;
    do
    {
      while (true)
      {
        i2 = 1;
        i3 = -1;
        break label115;
        if (a(f, paramInt))
        {
          i1 = 2130968925;
        }
        else
        {
          if (!a(g, paramInt))
            break;
          localMode = PorterDuff.Mode.MULTIPLY;
        }
      }
      if (paramInt == 2131230768)
      {
        i1 = 16842800;
        i3 = Math.round(40.799999F);
        i2 = 1;
        break;
      }
    }
    while (paramInt == 2131230744);
    int i2 = 0;
    int i3 = -1;
    i1 = 0;
    label115: if (i2 != 0)
    {
      if (p.c(paramDrawable))
        paramDrawable = paramDrawable.mutate();
      paramDrawable.setColorFilter(a(aa.a(paramContext, i1), localMode));
      if (i3 != -1)
        paramDrawable.setAlpha(i3);
      return true;
    }
    return false;
  }

  private boolean a(Context paramContext, long paramLong, Drawable paramDrawable)
  {
    try
    {
      Drawable.ConstantState localConstantState = paramDrawable.getConstantState();
      if (localConstantState != null)
      {
        d locald = (d)this.m.get(paramContext);
        if (locald == null)
        {
          locald = new d();
          this.m.put(paramContext, locald);
        }
        locald.b(paramLong, new WeakReference(localConstantState));
        return true;
      }
      return false;
    }
    finally
    {
    }
  }

  private static boolean a(int[] paramArrayOfInt, int paramInt)
  {
    int i1 = paramArrayOfInt.length;
    for (int i2 = 0; i2 < i1; i2++)
      if (paramArrayOfInt[i2] == paramInt)
        return true;
    return false;
  }

  private Drawable c(Context paramContext, int paramInt)
  {
    androidx.c.a locala = this.k;
    TypedValue localTypedValue;
    Resources localResources;
    long l1;
    Drawable localDrawable;
    if ((locala != null) && (!locala.isEmpty()))
    {
      h localh = this.l;
      if (localh != null)
      {
        String str2 = (String)localh.a(paramInt);
        if (("appcompat_skip_skip".equals(str2)) || ((str2 != null) && (this.k.get(str2) == null)))
          return null;
      }
      else
      {
        this.l = new h();
      }
      if (this.n == null)
        this.n = new TypedValue();
      localTypedValue = this.n;
      localResources = paramContext.getResources();
      localResources.getValue(paramInt, localTypedValue, true);
      l1 = a(localTypedValue);
      localDrawable = a(paramContext, l1);
      if (localDrawable != null)
        return localDrawable;
      if ((localTypedValue.string == null) || (!localTypedValue.string.toString().endsWith(".xml")));
    }
    try
    {
      XmlResourceParser localXmlResourceParser = localResources.getXml(paramInt);
      AttributeSet localAttributeSet = Xml.asAttributeSet(localXmlResourceParser);
      int i1;
      do
        i1 = localXmlResourceParser.next();
      while ((i1 != 2) && (i1 != 1));
      if (i1 == 2)
      {
        String str1 = localXmlResourceParser.getName();
        this.l.c(paramInt, str1);
        d locald = (d)this.k.get(str1);
        if (locald != null)
          localDrawable = locald.a(paramContext, localXmlResourceParser, localAttributeSet, paramContext.getTheme());
        if (localDrawable != null)
        {
          localDrawable.setChangingConfigurations(localTypedValue.changingConfigurations);
          a(paramContext, l1, localDrawable);
        }
      }
      else
      {
        throw new XmlPullParserException("No start tag found");
      }
      if (localDrawable == null)
        this.l.c(paramInt, "appcompat_skip_skip");
      return localDrawable;
      return null;
    }
    catch (Exception localException)
    {
      while (true)
        tmpTernaryOp = localException;
    }
  }

  private static ColorStateList d(Context paramContext, int paramInt)
  {
    int[][] arrayOfInt = new int[4][];
    int[] arrayOfInt1 = new int[4];
    int i1 = aa.a(paramContext, 2130968926);
    int i2 = aa.c(paramContext, 2130968924);
    arrayOfInt[0] = aa.a;
    arrayOfInt1[0] = i2;
    arrayOfInt[1] = aa.d;
    arrayOfInt1[1] = androidx.core.graphics.a.a(i1, paramInt);
    arrayOfInt[2] = aa.b;
    arrayOfInt1[2] = androidx.core.graphics.a.a(i1, paramInt);
    arrayOfInt[3] = aa.h;
    arrayOfInt1[3] = paramInt;
    return new ColorStateList(arrayOfInt, arrayOfInt1);
  }

  public final Drawable a(Context paramContext, int paramInt)
  {
    try
    {
      Drawable localDrawable = a(paramContext, paramInt, false);
      return localDrawable;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  final Drawable a(Context paramContext, int paramInt, boolean paramBoolean)
  {
    while (true)
    {
      Object localObject2;
      Object localObject3;
      try
      {
        if (!this.o)
        {
          this.o = true;
          Drawable localDrawable = a(paramContext, 2131230810);
          if (localDrawable != null)
          {
            if ((localDrawable instanceof i))
              break label272;
            if ("android.graphics.drawable.VectorDrawable".equals(localDrawable.getClass().getName()))
              break label272;
          }
          else
          {
            this.o = false;
            throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
          }
        }
        else
        {
          localObject2 = c(paramContext, paramInt);
          if (localObject2 == null)
          {
            if (this.n == null)
              this.n = new TypedValue();
            TypedValue localTypedValue = this.n;
            paramContext.getResources().getValue(paramInt, localTypedValue, true);
            long l1 = a(localTypedValue);
            localObject3 = a(paramContext, l1);
            if (localObject3 != null)
              break label283;
            if (paramInt == 2131230741)
            {
              Drawable[] arrayOfDrawable = new Drawable[2];
              arrayOfDrawable[0] = a(paramContext, 2131230740);
              arrayOfDrawable[1] = a(paramContext, 2131230742);
              localObject3 = new LayerDrawable(arrayOfDrawable);
            }
            if (localObject3 == null)
              break label283;
            ((Drawable)localObject3).setChangingConfigurations(localTypedValue.changingConfigurations);
            a(paramContext, l1, (Drawable)localObject3);
            break label283;
          }
          if (localObject2 == null)
            localObject2 = b.a(paramContext, paramInt);
          if (localObject2 != null)
            localObject2 = a(paramContext, paramInt, paramBoolean, (Drawable)localObject2);
          if (localObject2 != null)
            p.b((Drawable)localObject2);
          return localObject2;
        }
      }
      finally
      {
      }
      int i1 = 0;
      break label275;
      label272: i1 = 1;
      label275: if (i1 != 0)
      {
        continue;
        label283: localObject2 = localObject3;
      }
    }
  }

  final Drawable a(Context paramContext, aj paramaj, int paramInt)
  {
    try
    {
      Drawable localDrawable1 = c(paramContext, paramInt);
      if (localDrawable1 == null)
        localDrawable1 = paramaj.a(paramInt);
      if (localDrawable1 != null)
      {
        Drawable localDrawable2 = a(paramContext, paramInt, false, localDrawable1);
        return localDrawable2;
      }
      return null;
    }
    finally
    {
    }
  }

  public final void a(Context paramContext)
  {
    try
    {
      d locald = (d)this.m.get(paramContext);
      if (locald != null)
        locald.c();
      return;
    }
    finally
    {
    }
  }

  final ColorStateList b(Context paramContext, int paramInt)
  {
    try
    {
      WeakHashMap localWeakHashMap = this.j;
      localObject2 = null;
      if (localWeakHashMap != null)
      {
        h localh1 = (h)this.j.get(paramContext);
        localObject2 = null;
        if (localh1 != null)
          localObject2 = (ColorStateList)localh1.a(paramInt);
      }
      if (localObject2 == null)
      {
        if (paramInt == 2131230745)
        {
          localColorStateList1 = androidx.appcompat.a.a.a.a(paramContext, 2131099832);
          break label500;
        }
        if (paramInt == 2131230795)
        {
          localColorStateList1 = androidx.appcompat.a.a.a.a(paramContext, 2131099835);
          break label500;
        }
        if (paramInt == 2131230794)
        {
          int[][] arrayOfInt = new int[3][];
          int[] arrayOfInt1 = new int[3];
          ColorStateList localColorStateList2 = aa.b(paramContext, 2130968933);
          if ((localColorStateList2 != null) && (localColorStateList2.isStateful()))
          {
            arrayOfInt[0] = aa.a;
            arrayOfInt1[0] = localColorStateList2.getColorForState(arrayOfInt[0], 0);
            arrayOfInt[1] = aa.e;
            arrayOfInt1[1] = aa.a(paramContext, 2130968925);
            arrayOfInt[2] = aa.h;
            arrayOfInt1[2] = localColorStateList2.getDefaultColor();
          }
          else
          {
            arrayOfInt[0] = aa.a;
            arrayOfInt1[0] = aa.c(paramContext, 2130968933);
            arrayOfInt[1] = aa.e;
            arrayOfInt1[1] = aa.a(paramContext, 2130968925);
            arrayOfInt[2] = aa.h;
            arrayOfInt1[2] = aa.a(paramContext, 2130968933);
          }
          localObject2 = new ColorStateList(arrayOfInt, arrayOfInt1);
        }
        else
        {
          if (paramInt == 2131230734)
          {
            localColorStateList1 = d(paramContext, aa.a(paramContext, 2130968924));
            break label500;
          }
          if (paramInt == 2131230729)
          {
            localColorStateList1 = d(paramContext, 0);
            break label500;
          }
          if (paramInt != 2131230733)
            break label507;
          localColorStateList1 = d(paramContext, aa.a(paramContext, 2130968922));
          break label500;
          if (a(e, paramInt))
          {
            localColorStateList1 = aa.b(paramContext, 2130968927);
            break label500;
          }
          if (a(h, paramInt))
          {
            localColorStateList1 = androidx.appcompat.a.a.a.a(paramContext, 2131099831);
            break label500;
          }
          if (a(i, paramInt))
          {
            localColorStateList1 = androidx.appcompat.a.a.a.a(paramContext, 2131099830);
            break label500;
          }
          if (paramInt == 2131230789)
          {
            localColorStateList1 = androidx.appcompat.a.a.a.a(paramContext, 2131099833);
            break label500;
            localColorStateList1 = androidx.appcompat.a.a.a.a(paramContext, 2131099834);
            break label500;
          }
        }
        if (localObject2 != null)
        {
          if (this.j == null)
            this.j = new WeakHashMap();
          h localh2 = (h)this.j.get(paramContext);
          if (localh2 == null)
          {
            localh2 = new h();
            this.j.put(paramContext, localh2);
          }
          localh2.c(paramInt, localObject2);
        }
      }
      return localObject2;
    }
    finally
    {
      while (true)
      {
        ColorStateList localColorStateList1;
        while (true)
          throw localObject1;
        label500: Object localObject2 = localColorStateList1;
        continue;
        label507: if (paramInt != 2131230792)
          if (paramInt != 2131230793);
      }
    }
  }

  static final class a
    implements f.d
  {
    static
    {
      CoverageLogger.Log(12539904);
    }

    // ERROR //
    public final Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    {
      // Byte code:
      //   0: aload_1
      //   1: aload_1
      //   2: invokevirtual 28	android/content/Context:getResources	()Landroid/content/res/Resources;
      //   5: aload_2
      //   6: aload_3
      //   7: aload 4
      //   9: invokestatic 33	androidx/appcompat/b/a/a:a	(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/appcompat/b/a/a;
      //   12: astore 5
      //   14: aload 5
      //   16: areturn
      //   17: aconst_null
      //   18: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   0	14	17	java/lang/Exception
    }
  }

  static final class b
    implements f.d
  {
    static
    {
      CoverageLogger.Log(12242944);
    }

    // ERROR //
    public final Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    {
      // Byte code:
      //   0: aload_1
      //   1: aload_1
      //   2: invokevirtual 28	android/content/Context:getResources	()Landroid/content/res/Resources;
      //   5: aload_2
      //   6: aload_3
      //   7: aload 4
      //   9: invokestatic 33	androidx/l/a/a/c:a	(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/l/a/a/c;
      //   12: astore 5
      //   14: aload 5
      //   16: areturn
      //   17: aconst_null
      //   18: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   0	14	17	java/lang/Exception
    }
  }

  static final class c extends e<Integer, PorterDuffColorFilter>
  {
    static
    {
      CoverageLogger.Log(12544000);
    }

    public c(int paramInt)
    {
      super();
    }

    static int a(int paramInt, PorterDuff.Mode paramMode)
    {
      return 31 * (paramInt + 31) + paramMode.hashCode();
    }
  }

  static abstract interface d
  {
    static
    {
      CoverageLogger.Log(12546048);
    }

    public abstract Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme);
  }

  static final class e
    implements f.d
  {
    static
    {
      CoverageLogger.Log(12548096);
    }

    // ERROR //
    public final Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual 28	android/content/Context:getResources	()Landroid/content/res/Resources;
      //   4: aload_2
      //   5: aload_3
      //   6: aload 4
      //   8: invokestatic 33	androidx/l/a/a/i:a	(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/l/a/a/i;
      //   11: astore 5
      //   13: aload 5
      //   15: areturn
      //   16: aconst_null
      //   17: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   0	13	16	java/lang/Exception
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.f
 * JD-Core Version:    0.6.2
 */