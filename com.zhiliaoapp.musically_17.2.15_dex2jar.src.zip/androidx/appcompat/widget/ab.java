package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public final class ab extends ContextWrapper
{
  private static final Object a = new Object();
  private static ArrayList<WeakReference<ab>> b;
  private final Resources c;
  private final Resources.Theme d;

  static
  {
    CoverageLogger.Log(12101632);
  }

  private ab(Context paramContext)
  {
    super(paramContext);
    if (aj.a())
    {
      this.c = new aj(this, paramContext.getResources());
      this.d = this.c.newTheme();
      this.d.setTo(paramContext.getTheme());
      return;
    }
    this.c = new ad(this, paramContext.getResources());
    this.d = null;
  }

  public static Context a(Context paramContext)
  {
    boolean bool1 = paramContext instanceof ab;
    int i = 0;
    if (!bool1)
    {
      boolean bool2 = paramContext.getResources() instanceof ad;
      i = 0;
      if (!bool2)
        if ((paramContext.getResources() instanceof aj))
        {
          i = 0;
        }
        else if (Build.VERSION.SDK_INT >= 21)
        {
          boolean bool3 = aj.a();
          i = 0;
          if (!bool3);
        }
        else
        {
          i = 1;
        }
    }
    if (i != 0);
    while (true)
    {
      int j;
      int k;
      synchronized (a)
      {
        if (b == null)
        {
          b = new ArrayList();
        }
        else
        {
          j = b.size() - 1;
          if (j >= 0)
          {
            WeakReference localWeakReference1 = (WeakReference)b.get(j);
            if ((localWeakReference1 != null) && (localWeakReference1.get() != null))
              break label251;
            b.remove(j);
            break label251;
          }
          k = b.size() - 1;
          if (k >= 0)
          {
            WeakReference localWeakReference2 = (WeakReference)b.get(k);
            if (localWeakReference2 == null)
              break label257;
            localab1 = (ab)localWeakReference2.get();
            if ((localab1 == null) || (localab1.getBaseContext() != paramContext))
              break label263;
            return localab1;
          }
        }
        ab localab2 = new ab(paramContext);
        b.add(new WeakReference(localab2));
        return localab2;
      }
      return paramContext;
      label251: j--;
      continue;
      label257: ab localab1 = null;
      continue;
      label263: k--;
    }
  }

  public final AssetManager getAssets()
  {
    return this.c.getAssets();
  }

  public final Resources getResources()
  {
    return this.c;
  }

  public final Resources.Theme getTheme()
  {
    Resources.Theme localTheme = this.d;
    if (localTheme == null)
      localTheme = super.getTheme();
    return localTheme;
  }

  public final void setTheme(int paramInt)
  {
    Resources.Theme localTheme = this.d;
    if (localTheme == null)
    {
      super.setTheme(paramInt);
      return;
    }
    localTheme.applyStyle(paramInt, true);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ab
 * JD-Core Version:    0.6.2
 */