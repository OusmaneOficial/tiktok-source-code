package androidx.appcompat.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode.Callback;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import androidx.appcompat.a.a.a;
import androidx.core.widget.i;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class AppCompatCheckedTextView extends CheckedTextView
{
  private static final int[] a = { 16843016 };
  private final l b = new l(this);

  static
  {
    CoverageLogger.Log(12537856);
  }

  public AppCompatCheckedTextView(Context paramContext)
  {
    this(paramContext, null);
  }

  public AppCompatCheckedTextView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16843720);
  }

  public AppCompatCheckedTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(ab.a(paramContext), paramAttributeSet, paramInt);
    this.b.a(paramAttributeSet, paramInt);
    this.b.a();
    ae localae = ae.a(getContext(), paramAttributeSet, a, paramInt, 0);
    setCheckMarkDrawable(localae.a(0));
    localae.a();
  }

  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    l locall = this.b;
    if (locall != null)
      locall.a();
  }

  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo)
  {
    return g.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, this);
  }

  public void setCheckMarkDrawable(int paramInt)
  {
    setCheckMarkDrawable(a.b(getContext(), paramInt));
  }

  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback)
  {
    super.setCustomSelectionActionModeCallback(i.a(this, paramCallback));
  }

  public void setTextAppearance(Context paramContext, int paramInt)
  {
    super.setTextAppearance(paramContext, paramInt);
    l locall = this.b;
    if (locall != null)
      locall.a(paramContext, paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.AppCompatCheckedTextView
 * JD-Core Version:    0.6.2
 */