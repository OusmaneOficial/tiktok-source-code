package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class ActionBarContainer extends FrameLayout
{
  Drawable a;
  Drawable b;
  Drawable c;
  boolean d;
  boolean e;
  private boolean f;
  private View g;
  private View h;
  private View i;
  private int j;

  static
  {
    CoverageLogger.Log(12343296);
  }

  public ActionBarContainer(Context paramContext)
  {
    this(paramContext, null);
  }

  public ActionBarContainer(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    t.a(this, new b(this));
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 2130968691, 2130968694, 2130968695, 2130968961, 2130968962, 2130968963, 2130968964, 2130968965, 2130968966, 2130969002, 2130969023, 2130969024, 2130969051, 2130969147, 2130969154, 2130969164, 2130969165, 2130969168, 2130969197, 2130969257, 2130969415, 2130969477, 2130969521, 2130969535, 2130969536, 2130969808, 2130969811, 2130969930, 2130969942 });
    this.a = localTypedArray.getDrawable(0);
    this.b = localTypedArray.getDrawable(2);
    this.j = localTypedArray.getDimensionPixelSize(13, -1);
    if (getId() == 2131301641)
    {
      this.d = true;
      this.c = localTypedArray.getDrawable(1);
    }
    localTypedArray.recycle();
    boolean bool;
    if (this.d)
    {
      Drawable localDrawable3 = this.c;
      bool = false;
      if (localDrawable3 != null);
    }
    else
    {
      Drawable localDrawable2;
      do
      {
        bool = true;
        break;
        Drawable localDrawable1 = this.a;
        bool = false;
        if (localDrawable1 != null)
          break;
        localDrawable2 = this.b;
        bool = false;
      }
      while (localDrawable2 == null);
    }
    setWillNotDraw(bool);
  }

  private static boolean a(View paramView)
  {
    return (paramView == null) || (paramView.getVisibility() == 8) || (paramView.getMeasuredHeight() == 0);
  }

  private static int b(View paramView)
  {
    FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)paramView.getLayoutParams();
    return paramView.getMeasuredHeight() + localLayoutParams.topMargin + localLayoutParams.bottomMargin;
  }

  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    Drawable localDrawable1 = this.a;
    if ((localDrawable1 != null) && (localDrawable1.isStateful()))
      this.a.setState(getDrawableState());
    Drawable localDrawable2 = this.b;
    if ((localDrawable2 != null) && (localDrawable2.isStateful()))
      this.b.setState(getDrawableState());
    Drawable localDrawable3 = this.c;
    if ((localDrawable3 != null) && (localDrawable3.isStateful()))
      this.c.setState(getDrawableState());
  }

  public View getTabContainer()
  {
    return this.g;
  }

  public void jumpDrawablesToCurrentState()
  {
    super.jumpDrawablesToCurrentState();
    Drawable localDrawable1 = this.a;
    if (localDrawable1 != null)
      localDrawable1.jumpToCurrentState();
    Drawable localDrawable2 = this.b;
    if (localDrawable2 != null)
      localDrawable2.jumpToCurrentState();
    Drawable localDrawable3 = this.c;
    if (localDrawable3 != null)
      localDrawable3.jumpToCurrentState();
  }

  public void onFinishInflate()
  {
    super.onFinishInflate();
    this.h = findViewById(2131296278);
    this.i = findViewById(2131296288);
  }

  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    super.onHoverEvent(paramMotionEvent);
    return true;
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    return (this.f) || (super.onInterceptTouchEvent(paramMotionEvent));
  }

  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    View localView1 = this.g;
    int k = 1;
    boolean bool;
    if ((localView1 != null) && (localView1.getVisibility() != 8))
      bool = true;
    else
      bool = false;
    if ((localView1 != null) && (localView1.getVisibility() != 8))
    {
      int n = getMeasuredHeight();
      FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)localView1.getLayoutParams();
      localView1.layout(paramInt1, n - localView1.getMeasuredHeight() - localLayoutParams.bottomMargin, paramInt3, n - localLayoutParams.bottomMargin);
    }
    if (this.d)
    {
      Drawable localDrawable3 = this.c;
      if (localDrawable3 != null)
        localDrawable3.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
      else
        k = 0;
    }
    else
    {
      Drawable localDrawable1 = this.a;
      int m = 0;
      if (localDrawable1 != null)
      {
        if (this.h.getVisibility() == 0)
        {
          this.a.setBounds(this.h.getLeft(), this.h.getTop(), this.h.getRight(), this.h.getBottom());
        }
        else
        {
          View localView2 = this.i;
          if ((localView2 != null) && (localView2.getVisibility() == 0))
            this.a.setBounds(this.i.getLeft(), this.i.getTop(), this.i.getRight(), this.i.getBottom());
          else
            this.a.setBounds(0, 0, 0, 0);
        }
        m = 1;
      }
      this.e = bool;
      if (bool)
      {
        Drawable localDrawable2 = this.b;
        if (localDrawable2 != null)
        {
          localDrawable2.setBounds(localView1.getLeft(), localView1.getTop(), localView1.getRight(), localView1.getBottom());
          break label334;
        }
      }
      k = m;
    }
    label334: if (k != 0)
      invalidate();
  }

  public void onMeasure(int paramInt1, int paramInt2)
  {
    if ((this.h == null) && (View.MeasureSpec.getMode(paramInt2) == -2147483648))
    {
      int i1 = this.j;
      if (i1 >= 0)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.min(i1, View.MeasureSpec.getSize(paramInt2)), -2147483648);
    }
    super.onMeasure(paramInt1, paramInt2);
    if (this.h == null)
      return;
    int k = View.MeasureSpec.getMode(paramInt2);
    View localView = this.g;
    if ((localView != null) && (localView.getVisibility() != 8) && (k != 1073741824))
    {
      int m;
      if (!a(this.h))
        m = b(this.h);
      else if (!a(this.i))
        m = b(this.i);
      else
        m = 0;
      int n;
      if (k == -2147483648)
        n = View.MeasureSpec.getSize(paramInt2);
      else
        n = 2147483647;
      setMeasuredDimension(getMeasuredWidth(), Math.min(m + b(this.g), n));
    }
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    super.onTouchEvent(paramMotionEvent);
    return true;
  }

  public void setPrimaryBackground(Drawable paramDrawable)
  {
    Drawable localDrawable = this.a;
    if (localDrawable != null)
    {
      localDrawable.setCallback(null);
      unscheduleDrawable(this.a);
    }
    this.a = paramDrawable;
    if (paramDrawable != null)
    {
      paramDrawable.setCallback(this);
      View localView = this.h;
      if (localView != null)
        this.a.setBounds(localView.getLeft(), this.h.getTop(), this.h.getRight(), this.h.getBottom());
    }
    boolean bool1 = this.d;
    boolean bool2 = true;
    if (bool1 ? this.c == null : (this.a != null) || (this.b != null))
      bool2 = false;
    setWillNotDraw(bool2);
    invalidate();
  }

  public void setSplitBackground(Drawable paramDrawable)
  {
    Drawable localDrawable1 = this.c;
    if (localDrawable1 != null)
    {
      localDrawable1.setCallback(null);
      unscheduleDrawable(this.c);
    }
    this.c = paramDrawable;
    if (paramDrawable != null)
    {
      paramDrawable.setCallback(this);
      if (this.d)
      {
        Drawable localDrawable5 = this.c;
        if (localDrawable5 != null)
          localDrawable5.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
      }
    }
    boolean bool;
    if (this.d)
    {
      Drawable localDrawable4 = this.c;
      bool = false;
      if (localDrawable4 != null);
    }
    else
    {
      Drawable localDrawable3;
      do
      {
        bool = true;
        break;
        Drawable localDrawable2 = this.a;
        bool = false;
        if (localDrawable2 != null)
          break;
        localDrawable3 = this.b;
        bool = false;
      }
      while (localDrawable3 == null);
    }
    setWillNotDraw(bool);
    invalidate();
  }

  public void setStackedBackground(Drawable paramDrawable)
  {
    Drawable localDrawable1 = this.b;
    if (localDrawable1 != null)
    {
      localDrawable1.setCallback(null);
      unscheduleDrawable(this.b);
    }
    this.b = paramDrawable;
    if (paramDrawable != null)
    {
      paramDrawable.setCallback(this);
      if (this.e)
      {
        Drawable localDrawable2 = this.b;
        if (localDrawable2 != null)
          localDrawable2.setBounds(this.g.getLeft(), this.g.getTop(), this.g.getRight(), this.g.getBottom());
      }
    }
    boolean bool1 = this.d;
    boolean bool2 = true;
    if (bool1 ? this.c == null : (this.a != null) || (this.b != null))
      bool2 = false;
    setWillNotDraw(bool2);
    invalidate();
  }

  public void setTabContainer(y paramy)
  {
    View localView = this.g;
    if (localView != null)
      removeView(localView);
    this.g = paramy;
    if (paramy != null)
    {
      addView(paramy);
      ViewGroup.LayoutParams localLayoutParams = paramy.getLayoutParams();
      localLayoutParams.width = -1;
      localLayoutParams.height = -2;
      paramy.setAllowCollapse(false);
    }
  }

  public void setTransitioning(boolean paramBoolean)
  {
    this.f = paramBoolean;
    int k;
    if (paramBoolean)
      k = 393216;
    else
      k = 262144;
    setDescendantFocusability(k);
  }

  public void setVisibility(int paramInt)
  {
    super.setVisibility(paramInt);
    boolean bool;
    if (paramInt == 0)
      bool = true;
    else
      bool = false;
    Drawable localDrawable1 = this.a;
    if (localDrawable1 != null)
      localDrawable1.setVisible(bool, false);
    Drawable localDrawable2 = this.b;
    if (localDrawable2 != null)
      localDrawable2.setVisible(bool, false);
    Drawable localDrawable3 = this.c;
    if (localDrawable3 != null)
      localDrawable3.setVisible(bool, false);
  }

  public ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback)
  {
    return null;
  }

  public ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback, int paramInt)
  {
    if (paramInt != 0)
      return super.startActionModeForChild(paramView, paramCallback, paramInt);
    return null;
  }

  protected boolean verifyDrawable(Drawable paramDrawable)
  {
    return ((paramDrawable == this.a) && (!this.d)) || ((paramDrawable == this.b) && (this.e)) || ((paramDrawable == this.c) && (this.d)) || (super.verifyDrawable(paramDrawable));
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ActionBarContainer
 * JD-Core Version:    0.6.2
 */