package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.widget.TextView;
import androidx.core.content.a.f.a;
import androidx.core.widget.b;
import androidx.core.widget.i;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;

final class l
{
  int a;
  Typeface b;
  boolean c;
  private final TextView d;
  private ac e;
  private ac f;
  private ac g;
  private ac h;
  private ac i;
  private ac j;
  private final m k;

  static
  {
    CoverageLogger.Log(12197888);
  }

  l(TextView paramTextView)
  {
    this.d = paramTextView;
    this.k = new m(this.d);
  }

  private static ac a(Context paramContext, f paramf, int paramInt)
  {
    ColorStateList localColorStateList = paramf.b(paramContext, paramInt);
    if (localColorStateList != null)
    {
      ac localac = new ac();
      localac.d = true;
      localac.a = localColorStateList;
      return localac;
    }
    return null;
  }

  // ERROR //
  private void a(Context paramContext, ae paramae)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: iconst_2
    //   3: aload_0
    //   4: getfield 63	androidx/appcompat/widget/l:a	I
    //   7: invokevirtual 68	androidx/appcompat/widget/ae:a	(II)I
    //   10: putfield 63	androidx/appcompat/widget/l:a	I
    //   13: bipush 10
    //   15: istore_3
    //   16: aload_2
    //   17: iload_3
    //   18: invokevirtual 71	androidx/appcompat/widget/ae:f	(I)Z
    //   21: ifne +79 -> 100
    //   24: aload_2
    //   25: bipush 11
    //   27: invokevirtual 71	androidx/appcompat/widget/ae:f	(I)Z
    //   30: ifeq +6 -> 36
    //   33: goto +67 -> 100
    //   36: aload_2
    //   37: iconst_1
    //   38: invokevirtual 71	androidx/appcompat/widget/ae:f	(I)Z
    //   41: ifeq +58 -> 99
    //   44: aload_0
    //   45: iconst_0
    //   46: putfield 73	androidx/appcompat/widget/l:c	Z
    //   49: aload_2
    //   50: iconst_1
    //   51: iconst_1
    //   52: invokevirtual 68	androidx/appcompat/widget/ae:a	(II)I
    //   55: istore 8
    //   57: iload 8
    //   59: iconst_1
    //   60: if_icmpeq +32 -> 92
    //   63: iload 8
    //   65: iconst_2
    //   66: if_icmpeq +18 -> 84
    //   69: iload 8
    //   71: iconst_3
    //   72: if_icmpeq +4 -> 76
    //   75: return
    //   76: aload_0
    //   77: getstatic 78	android/graphics/Typeface:MONOSPACE	Landroid/graphics/Typeface;
    //   80: putfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   83: return
    //   84: aload_0
    //   85: getstatic 83	android/graphics/Typeface:SERIF	Landroid/graphics/Typeface;
    //   88: putfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   91: return
    //   92: aload_0
    //   93: getstatic 86	android/graphics/Typeface:SANS_SERIF	Landroid/graphics/Typeface;
    //   96: putfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   99: return
    //   100: aload_0
    //   101: aconst_null
    //   102: putfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   105: aload_2
    //   106: bipush 11
    //   108: invokevirtual 71	androidx/appcompat/widget/ae:f	(I)Z
    //   111: ifeq +6 -> 117
    //   114: bipush 11
    //   116: istore_3
    //   117: aload_1
    //   118: invokevirtual 92	android/content/Context:isRestricted	()Z
    //   121: ifne +65 -> 186
    //   124: new 94	androidx/appcompat/widget/l$1
    //   127: dup
    //   128: aload_0
    //   129: new 96	java/lang/ref/WeakReference
    //   132: dup
    //   133: aload_0
    //   134: getfield 36	androidx/appcompat/widget/l:d	Landroid/widget/TextView;
    //   137: invokespecial 99	java/lang/ref/WeakReference:<init>	(Ljava/lang/Object;)V
    //   140: invokespecial 102	androidx/appcompat/widget/l$1:<init>	(Landroidx/appcompat/widget/l;Ljava/lang/ref/WeakReference;)V
    //   143: astore 4
    //   145: aload_0
    //   146: aload_2
    //   147: iload_3
    //   148: aload_0
    //   149: getfield 63	androidx/appcompat/widget/l:a	I
    //   152: aload 4
    //   154: invokevirtual 105	androidx/appcompat/widget/ae:a	(IILandroidx/core/content/a/f$a;)Landroid/graphics/Typeface;
    //   157: putfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   160: aload_0
    //   161: getfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   164: astore 6
    //   166: iconst_0
    //   167: istore 7
    //   169: aload 6
    //   171: ifnonnull +6 -> 177
    //   174: iconst_1
    //   175: istore 7
    //   177: aload_0
    //   178: iload 7
    //   180: putfield 73	androidx/appcompat/widget/l:c	Z
    //   183: goto +3 -> 186
    //   186: aload_0
    //   187: getfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   190: ifnonnull +28 -> 218
    //   193: aload_2
    //   194: iload_3
    //   195: invokevirtual 108	androidx/appcompat/widget/ae:d	(I)Ljava/lang/String;
    //   198: astore 5
    //   200: aload 5
    //   202: ifnull +16 -> 218
    //   205: aload_0
    //   206: aload 5
    //   208: aload_0
    //   209: getfield 63	androidx/appcompat/widget/l:a	I
    //   212: invokestatic 112	android/graphics/Typeface:create	(Ljava/lang/String;I)Landroid/graphics/Typeface;
    //   215: putfield 80	androidx/appcompat/widget/l:b	Landroid/graphics/Typeface;
    //   218: return
    //
    // Exception table:
    //   from	to	target	type
    //   145	166	186	java/lang/UnsupportedOperationException
    //   145	166	186	android/content/res/Resources$NotFoundException
    //   177	183	186	java/lang/UnsupportedOperationException
    //   177	183	186	android/content/res/Resources$NotFoundException
  }

  private void a(Drawable paramDrawable, ac paramac)
  {
    if ((paramDrawable != null) && (paramac != null))
      f.a(paramDrawable, paramac, this.d.getDrawableState());
  }

  private void b(int paramInt, float paramFloat)
  {
    this.k.a(paramInt, paramFloat);
  }

  final void a()
  {
    if ((this.e != null) || (this.f != null) || (this.g != null) || (this.h != null))
    {
      Drawable[] arrayOfDrawable1 = this.d.getCompoundDrawables();
      a(arrayOfDrawable1[0], this.e);
      a(arrayOfDrawable1[1], this.f);
      a(arrayOfDrawable1[2], this.g);
      a(arrayOfDrawable1[3], this.h);
    }
    if ((Build.VERSION.SDK_INT >= 17) && ((this.i != null) || (this.j != null)))
    {
      Drawable[] arrayOfDrawable2 = this.d.getCompoundDrawablesRelative();
      a(arrayOfDrawable2[0], this.i);
      a(arrayOfDrawable2[2], this.j);
    }
  }

  final void a(int paramInt)
  {
    this.k.a(paramInt);
  }

  final void a(int paramInt, float paramFloat)
  {
    if ((!b.d) && (!c()))
      b(paramInt, paramFloat);
  }

  final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IllegalArgumentException
  {
    this.k.a(paramInt1, paramInt2, paramInt3, paramInt4);
  }

  final void a(Context paramContext, int paramInt)
  {
    ae localae = ae.a(paramContext, paramInt, new int[] { 16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 16843692, 2130969114, 2130969871 });
    if (localae.f(12))
      a(localae.a(12, false));
    if ((Build.VERSION.SDK_INT < 23) && (localae.f(3)))
    {
      ColorStateList localColorStateList = localae.e(3);
      if (localColorStateList != null)
        this.d.setTextColor(localColorStateList);
    }
    if ((localae.f(0)) && (localae.e(0, -1) == 0))
      this.d.setTextSize(0, 0.0F);
    a(paramContext, localae);
    localae.a();
    Typeface localTypeface = this.b;
    if (localTypeface != null)
      this.d.setTypeface(localTypeface, this.a);
  }

  final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    Context localContext = this.d.getContext();
    f localf = f.a();
    ae localae1 = ae.a(localContext, paramAttributeSet, new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 }, paramInt, 0);
    int m = localae1.g(0, -1);
    if (localae1.f(3))
      this.e = a(localContext, localf, localae1.g(3, 0));
    if (localae1.f(1))
      this.f = a(localContext, localf, localae1.g(1, 0));
    if (localae1.f(4))
      this.g = a(localContext, localf, localae1.g(4, 0));
    if (localae1.f(2))
      this.h = a(localContext, localf, localae1.g(2, 0));
    if (Build.VERSION.SDK_INT >= 17)
    {
      if (localae1.f(5))
        this.i = a(localContext, localf, localae1.g(5, 0));
      if (localae1.f(6))
        this.j = a(localContext, localf, localae1.g(6, 0));
    }
    localae1.a();
    boolean bool1 = this.d.getTransformationMethod() instanceof PasswordTransformationMethod;
    boolean bool2;
    int n;
    ColorStateList localColorStateList2;
    ColorStateList localColorStateList1;
    ColorStateList localColorStateList3;
    if (m != -1)
    {
      ae localae4 = ae.a(localContext, m, new int[] { 16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 16843692, 2130969114, 2130969871 });
      if ((!bool1) && (localae4.f(12)))
      {
        bool2 = localae4.a(12, false);
        n = 1;
      }
      else
      {
        n = 0;
        bool2 = false;
      }
      a(localContext, localae4);
      ColorStateList localColorStateList6;
      ColorStateList localColorStateList5;
      if (Build.VERSION.SDK_INT < 23)
      {
        if (localae4.f(3))
          localColorStateList2 = localae4.e(3);
        else
          localColorStateList2 = null;
        if (localae4.f(4))
          localColorStateList6 = localae4.e(4);
        else
          localColorStateList6 = null;
        if (localae4.f(5))
          localColorStateList5 = localae4.e(5);
        else
          localColorStateList5 = null;
      }
      else
      {
        localColorStateList2 = null;
        localColorStateList5 = null;
        localColorStateList6 = null;
      }
      localae4.a();
      localColorStateList1 = localColorStateList5;
      localColorStateList3 = localColorStateList6;
    }
    else
    {
      localColorStateList1 = null;
      n = 0;
      localColorStateList2 = null;
      localColorStateList3 = null;
      bool2 = false;
    }
    ae localae2 = ae.a(localContext, paramAttributeSet, new int[] { 16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 16843692, 2130969114, 2130969871 }, paramInt, 0);
    boolean bool3;
    if ((!bool1) && (localae2.f(12)))
    {
      bool3 = localae2.a(12, false);
      n = 1;
    }
    else
    {
      bool3 = bool2;
    }
    if (Build.VERSION.SDK_INT < 23)
    {
      if (localae2.f(3))
        localColorStateList2 = localae2.e(3);
      if (localae2.f(4))
        localColorStateList3 = localae2.e(4);
      if (localae2.f(5))
        localColorStateList1 = localae2.e(5);
    }
    ColorStateList localColorStateList4 = localColorStateList3;
    if ((Build.VERSION.SDK_INT >= 28) && (localae2.f(0)) && (localae2.e(0, -1) == 0))
      this.d.setTextSize(0, 0.0F);
    a(localContext, localae2);
    localae2.a();
    if (localColorStateList2 != null)
      this.d.setTextColor(localColorStateList2);
    if (localColorStateList4 != null)
      this.d.setHintTextColor(localColorStateList4);
    if (localColorStateList1 != null)
      this.d.setLinkTextColor(localColorStateList1);
    if ((!bool1) && (n != 0))
      a(bool3);
    Typeface localTypeface = this.b;
    if (localTypeface != null)
      this.d.setTypeface(localTypeface, this.a);
    this.k.a(paramAttributeSet, paramInt);
    if ((b.d) && (this.k.a != 0))
    {
      int[] arrayOfInt = this.k.b;
      if (arrayOfInt.length > 0)
        if (this.d.getAutoSizeStepGranularity() != -1.0F)
          this.d.setAutoSizeTextTypeUniformWithConfiguration(this.k.b(), this.k.c(), this.k.a(), 0);
        else
          this.d.setAutoSizeTextTypeUniformWithPresetSizes(arrayOfInt, 0);
    }
    ae localae3 = ae.a(localContext, paramAttributeSet, new int[] { 16842804, 2130968671, 2130968672, 2130968673, 2130968674, 2130968675, 2130969105, 2130969114, 2130969277, 2130969388, 2130969871 });
    int i1 = localae3.e(6, -1);
    int i2 = localae3.e(8, -1);
    int i3 = localae3.e(9, -1);
    localae3.a();
    if (i1 != -1)
      i.c(this.d, i1);
    if (i2 != -1)
      i.d(this.d, i2);
    if (i3 != -1)
      i.e(this.d, i3);
  }

  final void a(boolean paramBoolean)
  {
    this.d.setAllCaps(paramBoolean);
  }

  final void a(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (!b.d)
      b();
  }

  final void a(int[] paramArrayOfInt, int paramInt)
    throws IllegalArgumentException
  {
    this.k.a(paramArrayOfInt, paramInt);
  }

  final void b()
  {
    this.k.d();
  }

  final boolean c()
  {
    return this.k.e();
  }

  final int d()
  {
    return this.k.a;
  }

  final int e()
  {
    return this.k.a();
  }

  final int f()
  {
    return this.k.b();
  }

  final int g()
  {
    return this.k.c();
  }

  final int[] h()
  {
    return this.k.b;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.l
 * JD-Core Version:    0.6.2
 */