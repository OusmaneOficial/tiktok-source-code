package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window.Callback;
import androidx.appcompat.view.menu.o.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface n
{
  static
  {
    CoverageLogger.Log(12290048);
  }

  public abstract void a(int paramInt);

  public abstract void a(Menu paramMenu, o.a parama);

  public abstract boolean b();

  public abstract boolean c();

  public abstract boolean d();

  public abstract boolean e();

  public abstract boolean f();

  public abstract void g();

  public abstract void h();

  public abstract void setWindowCallback(Window.Callback paramCallback);

  public abstract void setWindowTitle(CharSequence paramCharSequence);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.n
 * JD-Core Version:    0.6.2
 */