package androidx.appcompat.widget;

import android.util.SparseArray;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.n;
import androidx.recyclerview.widget.RecyclerView.n.a;
import androidx.recyclerview.widget.RecyclerView.v;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;

public final class t
{
  static
  {
    CoverageLogger.Log(24219648);
  }

  public static final int a(RecyclerView paramRecyclerView, int paramInt)
  {
    l.b(paramRecyclerView, "recyclerView");
    RecyclerView.n.a locala = (RecyclerView.n.a)paramRecyclerView.getRecycledViewPool().mScrap.get(paramInt);
    if (locala != null)
      return locala.mMaxScrap;
    return -1;
  }

  public static final void a(RecyclerView.v paramv)
  {
    l.b(paramv, "viewHolder");
    paramv.resetInternal();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.t
 * JD-Core Version:    0.6.2
 */