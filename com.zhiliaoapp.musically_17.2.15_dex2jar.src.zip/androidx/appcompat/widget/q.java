package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.b.a.c;
import androidx.core.graphics.drawable.a;
import androidx.core.h.x;
import androidx.core.widget.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;

class q extends ListView
{
  public boolean a;
  b b;
  private final Rect c = new Rect();
  private int d = 0;
  private int e = 0;
  private int f = 0;
  private int g = 0;
  private int h;
  private Field i;
  private a j;
  private boolean k;
  private boolean l;
  private x m;
  private f n;

  static
  {
    CoverageLogger.Log(12171264);
  }

  q(Context paramContext, boolean paramBoolean)
  {
    super(paramContext, null, 2130969042);
    this.l = paramBoolean;
    setCacheColorHint(0);
    try
    {
      this.i = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.i.setAccessible(true);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
    }
  }

  private void a()
  {
    Drawable localDrawable = getSelector();
    if ((localDrawable != null) && (this.a) && (isPressed()))
      localDrawable.setState(getDrawableState());
  }

  private void a(int paramInt, View paramView)
  {
    Rect localRect = this.c;
    localRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    localRect.left -= this.d;
    localRect.top -= this.e;
    localRect.right += this.f;
    localRect.bottom += this.g;
    while (true)
    {
      try
      {
        boolean bool1 = this.i.getBoolean(this);
        if (paramView.isEnabled() != bool1)
        {
          Field localField = this.i;
          if (bool1)
            break label138;
          bool2 = true;
          localField.set(this, Boolean.valueOf(bool2));
          if (paramInt != -1)
            refreshDrawableState();
        }
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
      }
      return;
      label138: boolean bool2 = false;
    }
  }

  private void setSelectorEnabled(boolean paramBoolean)
  {
    a locala = this.j;
    if (locala != null)
      locala.b = paramBoolean;
  }

  public int a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i1 = getListPaddingTop();
    int i2 = getListPaddingBottom();
    getListPaddingLeft();
    getListPaddingRight();
    int i3 = getDividerHeight();
    Drawable localDrawable = getDivider();
    ListAdapter localListAdapter = getAdapter();
    if (localListAdapter == null)
      return i1 + i2;
    int i4 = i1 + i2;
    if ((i3 <= 0) || (localDrawable == null))
      i3 = 0;
    int i5 = localListAdapter.getCount();
    int i6 = i4;
    View localView = null;
    int i7 = 0;
    int i8 = 0;
    int i9 = 0;
    while (i7 < i5)
    {
      int i10 = localListAdapter.getItemViewType(i7);
      if (i10 != i8)
      {
        localView = null;
        i8 = i10;
      }
      localView = localListAdapter.getView(i7, localView, this);
      ViewGroup.LayoutParams localLayoutParams = localView.getLayoutParams();
      if (localLayoutParams == null)
      {
        localLayoutParams = generateDefaultLayoutParams();
        localView.setLayoutParams(localLayoutParams);
      }
      int i11;
      if (localLayoutParams.height > 0)
        i11 = View.MeasureSpec.makeMeasureSpec(localLayoutParams.height, 1073741824);
      else
        i11 = View.MeasureSpec.makeMeasureSpec(0, 0);
      localView.measure(paramInt1, i11);
      localView.forceLayout();
      if (i7 > 0)
        i6 += i3;
      i6 += localView.getMeasuredHeight();
      if (i6 >= paramInt4)
      {
        if ((paramInt5 >= 0) && (i7 > paramInt5) && (i9 > 0) && (i6 != paramInt4))
          return i9;
        return paramInt4;
      }
      if ((paramInt5 >= 0) && (i7 >= paramInt5))
        i9 = i6;
      i7++;
    }
    return i6;
  }

  public boolean a(MotionEvent paramMotionEvent, int paramInt)
  {
    int i1 = paramMotionEvent.getActionMasked();
    if (i1 != 1)
      if (i1 != 2)
        if (i1 == 3);
    boolean bool1;
    int i8;
    while (true)
    {
      bool1 = true;
      i8 = 0;
      break;
      label47: int i2;
      do
      {
        bool1 = false;
        i8 = 0;
        break;
        bool1 = true;
        break label47;
        bool1 = false;
        i2 = paramMotionEvent.findPointerIndex(paramInt);
      }
      while (i2 < 0);
      int i3 = (int)paramMotionEvent.getX(i2);
      int i4 = (int)paramMotionEvent.getY(i2);
      int i5 = pointToPosition(i3, i4);
      if (i5 == -1)
      {
        i8 = 1;
        break;
      }
      View localView1 = getChildAt(i5 - getFirstVisiblePosition());
      float f1 = i3;
      float f2 = i4;
      this.a = true;
      if (Build.VERSION.SDK_INT >= 21)
        drawableHotspotChanged(f1, f2);
      if (!isPressed())
        setPressed(true);
      layoutChildren();
      int i6 = this.h;
      if (i6 != -1)
      {
        View localView3 = getChildAt(i6 - getFirstVisiblePosition());
        if ((localView3 != null) && (localView3 != localView1) && (localView3.isPressed()))
          localView3.setPressed(false);
      }
      this.h = i5;
      float f3 = f1 - localView1.getLeft();
      float f4 = f2 - localView1.getTop();
      if (Build.VERSION.SDK_INT >= 21)
        localView1.drawableHotspotChanged(f3, f4);
      if (!localView1.isPressed())
        localView1.setPressed(true);
      Drawable localDrawable1 = getSelector();
      int i7;
      if ((localDrawable1 != null) && (i5 != -1))
        i7 = 1;
      else
        i7 = 0;
      if (i7 != 0)
        localDrawable1.setVisible(false, false);
      a(i5, localView1);
      if (i7 != 0)
      {
        Rect localRect = this.c;
        float f5 = localRect.exactCenterX();
        float f6 = localRect.exactCenterY();
        boolean bool2;
        if (getVisibility() == 0)
          bool2 = true;
        else
          bool2 = false;
        localDrawable1.setVisible(bool2, false);
        a.a(localDrawable1, f5, f6);
      }
      Drawable localDrawable2 = getSelector();
      if ((localDrawable2 != null) && (i5 != -1))
        a.a(localDrawable2, f1, f2);
      setSelectorEnabled(false);
      refreshDrawableState();
      if (i1 == 1)
        performItemClick(localView1, i5, getItemIdAtPosition(i5));
    }
    if ((!bool1) || (i8 != 0))
    {
      this.a = false;
      setPressed(false);
      drawableStateChanged();
      View localView2 = getChildAt(this.h - getFirstVisiblePosition());
      if (localView2 != null)
        localView2.setPressed(false);
      x localx = this.m;
      if (localx != null)
      {
        localx.b();
        this.m = null;
      }
    }
    if (bool1)
    {
      if (this.n == null)
        this.n = new f(this);
      this.n.a(true);
      this.n.onTouch(this, paramMotionEvent);
      return bool1;
    }
    f localf = this.n;
    if (localf != null)
      localf.a(false);
    return bool1;
  }

  protected void dispatchDraw(Canvas paramCanvas)
  {
    if (!this.c.isEmpty())
    {
      Drawable localDrawable = getSelector();
      if (localDrawable != null)
      {
        localDrawable.setBounds(this.c);
        localDrawable.draw(paramCanvas);
      }
    }
    super.dispatchDraw(paramCanvas);
  }

  protected void drawableStateChanged()
  {
    if (this.b != null)
      return;
    super.drawableStateChanged();
    setSelectorEnabled(true);
    a();
  }

  public boolean hasFocus()
  {
    return (this.l) || (super.hasFocus());
  }

  public boolean hasWindowFocus()
  {
    return (this.l) || (super.hasWindowFocus());
  }

  public boolean isFocused()
  {
    return (this.l) || (super.isFocused());
  }

  public boolean isInTouchMode()
  {
    return ((this.l) && (this.k)) || (super.isInTouchMode());
  }

  protected void onDetachedFromWindow()
  {
    this.b = null;
    super.onDetachedFromWindow();
  }

  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    if (Build.VERSION.SDK_INT < 26)
      return super.onHoverEvent(paramMotionEvent);
    int i1 = paramMotionEvent.getActionMasked();
    if ((i1 == 10) && (this.b == null))
    {
      this.b = new b();
      b localb = this.b;
      localb.a.post(localb);
    }
    boolean bool = super.onHoverEvent(paramMotionEvent);
    if ((i1 != 9) && (i1 != 7))
    {
      setSelection(-1);
      return bool;
    }
    int i2 = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
    if ((i2 != -1) && (i2 != getSelectedItemPosition()))
    {
      View localView = getChildAt(i2 - getFirstVisiblePosition());
      if (localView.isEnabled())
        setSelectionFromTop(i2, localView.getTop() - getTop());
      a();
    }
    return bool;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (paramMotionEvent.getAction() == 0)
      this.h = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
    b localb = this.b;
    if (localb != null)
    {
      localb.a.b = null;
      localb.a.removeCallbacks(localb);
    }
    return super.onTouchEvent(paramMotionEvent);
  }

  void setListSelectionHidden(boolean paramBoolean)
  {
    this.k = paramBoolean;
  }

  public void setSelector(Drawable paramDrawable)
  {
    a locala;
    if (paramDrawable != null)
      locala = new a(paramDrawable);
    else
      locala = null;
    this.j = locala;
    super.setSelector(this.j);
    Rect localRect = new Rect();
    if (paramDrawable != null)
      paramDrawable.getPadding(localRect);
    this.d = localRect.left;
    this.e = localRect.top;
    this.f = localRect.right;
    this.g = localRect.bottom;
  }

  static final class a extends c
  {
    public boolean b = true;

    static
    {
      CoverageLogger.Log(12302336);
    }

    a(Drawable paramDrawable)
    {
      super();
    }

    public final void draw(Canvas paramCanvas)
    {
      if (this.b)
        super.draw(paramCanvas);
    }

    public final void setHotspot(float paramFloat1, float paramFloat2)
    {
      if (this.b)
        super.setHotspot(paramFloat1, paramFloat2);
    }

    public final void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      if (this.b)
        super.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    }

    public final boolean setState(int[] paramArrayOfInt)
    {
      if (this.b)
        return super.setState(paramArrayOfInt);
      return false;
    }

    public final boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
    {
      if (this.b)
        return super.setVisible(paramBoolean1, paramBoolean2);
      return false;
    }
  }

  final class b
    implements Runnable
  {
    static
    {
      CoverageLogger.Log(12165120);
    }

    b()
    {
    }

    public final void run()
    {
      q localq = q.this;
      localq.b = null;
      localq.drawableStateChanged();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.q
 * JD-Core Version:    0.6.2
 */