package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;

public final class aj extends Resources
{
  public static boolean a;
  private final WeakReference<Context> b;

  static
  {
    CoverageLogger.Log(12156928);
  }

  public aj(Context paramContext, Resources paramResources)
  {
    super(paramResources.getAssets(), paramResources.getDisplayMetrics(), paramResources.getConfiguration());
    this.b = new WeakReference(paramContext);
  }

  public static boolean a()
  {
    return (b()) && (Build.VERSION.SDK_INT <= 20);
  }

  private static boolean b()
  {
    return a;
  }

  final Drawable a(int paramInt)
  {
    return super.getDrawable(paramInt);
  }

  public final Drawable getDrawable(int paramInt)
    throws Resources.NotFoundException
  {
    Context localContext = (Context)this.b.get();
    if (localContext != null)
      return f.a().a(localContext, this, paramInt);
    return super.getDrawable(paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.aj
 * JD-Core Version:    0.6.2
 */