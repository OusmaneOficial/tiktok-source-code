package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import androidx.core.widget.c;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class e
{
  public ColorStateList a;
  public PorterDuff.Mode b;
  private final CompoundButton c;
  private boolean d;
  private boolean e;
  private boolean f;

  static
  {
    CoverageLogger.Log(12257280);
  }

  e(CompoundButton paramCompoundButton)
  {
    this.c = paramCompoundButton;
  }

  private void b()
  {
    Drawable localDrawable1 = c.a(this.c);
    if ((localDrawable1 != null) && ((this.d) || (this.e)))
    {
      Drawable localDrawable2 = androidx.core.graphics.drawable.a.f(localDrawable1).mutate();
      if (this.d)
        androidx.core.graphics.drawable.a.a(localDrawable2, this.a);
      if (this.e)
        androidx.core.graphics.drawable.a.a(localDrawable2, this.b);
      if (localDrawable2.isStateful())
        localDrawable2.setState(this.c.getDrawableState());
      this.c.setButtonDrawable(localDrawable2);
    }
  }

  final int a(int paramInt)
  {
    if (Build.VERSION.SDK_INT < 17)
    {
      Drawable localDrawable = c.a(this.c);
      if (localDrawable != null)
        paramInt += localDrawable.getIntrinsicWidth();
    }
    return paramInt;
  }

  final void a()
  {
    if (this.f)
    {
      this.f = false;
      return;
    }
    this.f = true;
    b();
  }

  final void a(ColorStateList paramColorStateList)
  {
    this.a = paramColorStateList;
    this.d = true;
    b();
  }

  final void a(PorterDuff.Mode paramMode)
  {
    this.b = paramMode;
    this.e = true;
    b();
  }

  final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    TypedArray localTypedArray = this.c.getContext().obtainStyledAttributes(paramAttributeSet, new int[] { 16843015, 2130968842, 2130968843 }, paramInt, 0);
    try
    {
      if (localTypedArray.hasValue(0))
      {
        int i = localTypedArray.getResourceId(0, 0);
        if (i != 0)
          this.c.setButtonDrawable(androidx.appcompat.a.a.a.b(this.c.getContext(), i));
      }
      if (localTypedArray.hasValue(1))
        c.a(this.c, localTypedArray.getColorStateList(1));
      if (localTypedArray.hasValue(2))
        c.a(this.c, p.a(localTypedArray.getInt(2, -1), null));
      return;
    }
    finally
    {
      localTypedArray.recycle();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.e
 * JD-Core Version:    0.6.2
 */