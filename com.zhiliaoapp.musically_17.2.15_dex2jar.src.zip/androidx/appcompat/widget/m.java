package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.StaticLayout.Builder;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

final class m
{
  private static final RectF c = new RectF();
  private static ConcurrentHashMap<String, Method> d = new ConcurrentHashMap();
  public int a;
  public int[] b = new int[0];
  private boolean e;
  private float f = -1.0F;
  private float g = -1.0F;
  private float h = -1.0F;
  private boolean i;
  private TextPaint j;
  private final TextView k;
  private final Context l;

  static
  {
    CoverageLogger.Log(12265472);
  }

  m(TextView paramTextView)
  {
    this.k = paramTextView;
    this.l = this.k.getContext();
  }

  private int a(RectF paramRectF)
  {
    int m = this.b.length;
    if (m != 0)
    {
      int n = m - 1;
      int i1 = 1;
      int i2 = 0;
      while (i1 <= n)
      {
        int i3 = (i1 + n) / 2;
        if (a(this.b[i3], paramRectF))
        {
          int i4 = i3 + 1;
          i2 = i1;
          i1 = i4;
        }
        else
        {
          i2 = i3 - 1;
          n = i2;
        }
      }
      return this.b[i2];
    }
    IllegalStateException localIllegalStateException = new IllegalStateException("No available text sizes to choose from.");
    while (true)
      throw localIllegalStateException;
  }

  private StaticLayout a(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt)
  {
    float f1;
    float f2;
    boolean bool1;
    if (Build.VERSION.SDK_INT >= 16)
    {
      f1 = this.k.getLineSpacingMultiplier();
      f2 = this.k.getLineSpacingExtra();
      bool1 = this.k.getIncludeFontPadding();
    }
    else
    {
      f1 = ((Float)a(this.k, "getLineSpacingMultiplier", Float.valueOf(1.0F))).floatValue();
      f2 = ((Float)a(this.k, "getLineSpacingExtra", Float.valueOf(0.0F))).floatValue();
      bool1 = ((Boolean)a(this.k, "getIncludeFontPadding", Boolean.valueOf(true))).booleanValue();
    }
    float f3 = f1;
    float f4 = f2;
    boolean bool2 = bool1;
    StaticLayout localStaticLayout = new StaticLayout(paramCharSequence, this.j, paramInt, paramAlignment, f3, f4, bool2);
    return localStaticLayout;
  }

  private StaticLayout a(CharSequence paramCharSequence, Layout.Alignment paramAlignment, int paramInt1, int paramInt2)
  {
    TextDirectionHeuristic localTextDirectionHeuristic = (TextDirectionHeuristic)a(this.k, "getTextDirectionHeuristic", TextDirectionHeuristics.FIRSTSTRONG_LTR);
    StaticLayout.Builder localBuilder = StaticLayout.Builder.obtain(paramCharSequence, 0, paramCharSequence.length(), this.j, paramInt1).setAlignment(paramAlignment).setLineSpacing(this.k.getLineSpacingExtra(), this.k.getLineSpacingMultiplier()).setIncludePad(this.k.getIncludeFontPadding()).setBreakStrategy(this.k.getBreakStrategy()).setHyphenationFrequency(this.k.getHyphenationFrequency());
    if (paramInt2 == -1)
      paramInt2 = 2147483647;
    return localBuilder.setMaxLines(paramInt2).setTextDirection(localTextDirectionHeuristic).build();
  }

  // ERROR //
  private <T> T a(Object paramObject, String paramString, T paramT)
  {
    // Byte code:
    //   0: aload_2
    //   1: invokestatic 191	androidx/appcompat/widget/m:a	(Ljava/lang/String;)Ljava/lang/reflect/Method;
    //   4: aload_1
    //   5: iconst_0
    //   6: anewarray 4	java/lang/Object
    //   9: invokevirtual 197	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   12: astore 5
    //   14: aload 5
    //   16: areturn
    //   17: astore 4
    //   19: aload 4
    //   21: athrow
    //   22: aload_3
    //   23: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	14	17	finally
    //   0	14	22	java/lang/Exception
  }

  // ERROR //
  private static Method a(String paramString)
  {
    // Byte code:
    //   0: getstatic 47	androidx/appcompat/widget/m:d	Ljava/util/concurrent/ConcurrentHashMap;
    //   3: aload_0
    //   4: invokevirtual 201	java/util/concurrent/ConcurrentHashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   7: checkcast 193	java/lang/reflect/Method
    //   10: astore_1
    //   11: aload_1
    //   12: ifnonnull +32 -> 44
    //   15: ldc 62
    //   17: aload_0
    //   18: iconst_0
    //   19: anewarray 203	java/lang/Class
    //   22: invokevirtual 207	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   25: astore_1
    //   26: aload_1
    //   27: ifnull +17 -> 44
    //   30: aload_1
    //   31: iconst_1
    //   32: invokevirtual 211	java/lang/reflect/Method:setAccessible	(Z)V
    //   35: getstatic 47	androidx/appcompat/widget/m:d	Ljava/util/concurrent/ConcurrentHashMap;
    //   38: aload_0
    //   39: aload_1
    //   40: invokevirtual 215	java/util/concurrent/ConcurrentHashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   43: pop
    //   44: aload_1
    //   45: areturn
    //   46: aconst_null
    //   47: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	11	46	java/lang/Exception
    //   15	26	46	java/lang/Exception
    //   30	44	46	java/lang/Exception
  }

  // ERROR //
  private void a(float paramFloat)
  {
    // Byte code:
    //   0: fload_1
    //   1: aload_0
    //   2: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   5: invokevirtual 220	android/widget/TextView:getPaint	()Landroid/text/TextPaint;
    //   8: invokevirtual 225	android/text/TextPaint:getTextSize	()F
    //   11: fcmpl
    //   12: ifeq +104 -> 116
    //   15: aload_0
    //   16: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   19: invokevirtual 220	android/widget/TextView:getPaint	()Landroid/text/TextPaint;
    //   22: fload_1
    //   23: invokevirtual 228	android/text/TextPaint:setTextSize	(F)V
    //   26: getstatic 85	android/os/Build$VERSION:SDK_INT	I
    //   29: bipush 18
    //   31: if_icmplt +14 -> 45
    //   34: aload_0
    //   35: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   38: invokevirtual 231	android/widget/TextView:isInLayout	()Z
    //   41: istore_2
    //   42: goto +5 -> 47
    //   45: iconst_0
    //   46: istore_2
    //   47: aload_0
    //   48: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   51: invokevirtual 235	android/widget/TextView:getLayout	()Landroid/text/Layout;
    //   54: ifnull +62 -> 116
    //   57: aload_0
    //   58: iconst_0
    //   59: putfield 237	androidx/appcompat/widget/m:e	Z
    //   62: ldc 239
    //   64: invokestatic 191	androidx/appcompat/widget/m:a	(Ljava/lang/String;)Ljava/lang/reflect/Method;
    //   67: astore_3
    //   68: aload_3
    //   69: ifnull +19 -> 88
    //   72: aload_3
    //   73: aload_0
    //   74: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   77: iconst_0
    //   78: anewarray 4	java/lang/Object
    //   81: invokevirtual 197	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   84: pop
    //   85: goto +3 -> 88
    //   88: iload_2
    //   89: ifne +13 -> 102
    //   92: aload_0
    //   93: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   96: invokevirtual 242	android/widget/TextView:requestLayout	()V
    //   99: goto +10 -> 109
    //   102: aload_0
    //   103: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   106: invokevirtual 245	android/widget/TextView:forceLayout	()V
    //   109: aload_0
    //   110: getfield 60	androidx/appcompat/widget/m:k	Landroid/widget/TextView;
    //   113: invokevirtual 248	android/widget/TextView:invalidate	()V
    //   116: return
    //
    // Exception table:
    //   from	to	target	type
    //   62	68	88	java/lang/Exception
    //   72	85	88	java/lang/Exception
  }

  private void a(float paramFloat1, float paramFloat2, float paramFloat3)
    throws IllegalArgumentException
  {
    if (paramFloat1 > 0.0F)
    {
      if (paramFloat2 > paramFloat1)
      {
        if (paramFloat3 > 0.0F)
        {
          this.a = 1;
          this.g = paramFloat1;
          this.h = paramFloat2;
          this.f = paramFloat3;
          this.i = false;
          return;
        }
        StringBuilder localStringBuilder3 = new StringBuilder("The auto-size step granularity (");
        localStringBuilder3.append(paramFloat3);
        localStringBuilder3.append("px) is less or equal to (0px)");
        throw new IllegalArgumentException(localStringBuilder3.toString());
      }
      StringBuilder localStringBuilder2 = new StringBuilder("Maximum auto-size text size (");
      localStringBuilder2.append(paramFloat2);
      localStringBuilder2.append("px) is less or equal to minimum auto-size text size (");
      localStringBuilder2.append(paramFloat1);
      localStringBuilder2.append("px)");
      throw new IllegalArgumentException(localStringBuilder2.toString());
    }
    StringBuilder localStringBuilder1 = new StringBuilder("Minimum auto-size text size (");
    localStringBuilder1.append(paramFloat1);
    localStringBuilder1.append("px) is less or equal to (0px)");
    throw new IllegalArgumentException(localStringBuilder1.toString());
  }

  private void a(TypedArray paramTypedArray)
  {
    int m = paramTypedArray.length();
    int[] arrayOfInt = new int[m];
    if (m > 0)
    {
      for (int n = 0; n < m; n++)
        arrayOfInt[n] = paramTypedArray.getDimensionPixelSize(n, -1);
      this.b = a(arrayOfInt);
      f();
    }
  }

  private boolean a(int paramInt, RectF paramRectF)
  {
    Object localObject = this.k.getText();
    TransformationMethod localTransformationMethod = this.k.getTransformationMethod();
    if (localTransformationMethod != null)
    {
      CharSequence localCharSequence = localTransformationMethod.getTransformation((CharSequence)localObject, this.k);
      if (localCharSequence != null)
        localObject = localCharSequence;
    }
    int m;
    if (Build.VERSION.SDK_INT >= 16)
      m = this.k.getMaxLines();
    else
      m = -1;
    TextPaint localTextPaint = this.j;
    if (localTextPaint == null)
      this.j = new TextPaint();
    else
      localTextPaint.reset();
    this.j.set(this.k.getPaint());
    this.j.setTextSize(paramInt);
    Layout.Alignment localAlignment = (Layout.Alignment)a(this.k, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL);
    StaticLayout localStaticLayout;
    if (Build.VERSION.SDK_INT >= 23)
      localStaticLayout = a((CharSequence)localObject, localAlignment, Math.round(paramRectF.right), m);
    else
      localStaticLayout = a((CharSequence)localObject, localAlignment, Math.round(paramRectF.right));
    if ((m != -1) && ((localStaticLayout.getLineCount() > m) || (localStaticLayout.getLineEnd(localStaticLayout.getLineCount() - 1) != ((CharSequence)localObject).length())))
      return false;
    return localStaticLayout.getHeight() <= paramRectF.bottom;
  }

  private static int[] a(int[] paramArrayOfInt)
  {
    int m = paramArrayOfInt.length;
    if (m == 0)
      return paramArrayOfInt;
    Arrays.sort(paramArrayOfInt);
    ArrayList localArrayList = new ArrayList();
    int n = 0;
    for (int i1 = 0; i1 < m; i1++)
    {
      int i3 = paramArrayOfInt[i1];
      if ((i3 > 0) && (Collections.binarySearch(localArrayList, Integer.valueOf(i3)) < 0))
        localArrayList.add(Integer.valueOf(i3));
    }
    if (m == localArrayList.size())
      return paramArrayOfInt;
    int i2 = localArrayList.size();
    int[] arrayOfInt = new int[i2];
    while (n < i2)
    {
      arrayOfInt[n] = ((Integer)localArrayList.get(n)).intValue();
      n++;
    }
    return arrayOfInt;
  }

  private boolean f()
  {
    int m = this.b.length;
    boolean bool;
    if (m > 0)
      bool = true;
    else
      bool = false;
    this.i = bool;
    if (this.i)
    {
      this.a = 1;
      int[] arrayOfInt = this.b;
      this.g = arrayOfInt[0];
      this.h = arrayOfInt[(m - 1)];
      this.f = -1.0F;
    }
    return this.i;
  }

  private boolean g()
  {
    boolean bool = i();
    int m = 0;
    if ((bool) && (this.a == 1))
    {
      if ((!this.i) || (this.b.length == 0))
      {
        float f1 = Math.round(this.g);
        int n = 1;
        while (Math.round(f1 + this.f) <= Math.round(this.h))
        {
          n++;
          f1 += this.f;
        }
        int[] arrayOfInt = new int[n];
        float f2 = this.g;
        while (m < n)
        {
          arrayOfInt[m] = Math.round(f2);
          f2 += this.f;
          m++;
        }
        this.b = a(arrayOfInt);
      }
      this.e = true;
    }
    else
    {
      this.e = false;
    }
    return this.e;
  }

  private void h()
  {
    this.a = 0;
    this.g = -1.0F;
    this.h = -1.0F;
    this.f = -1.0F;
    this.b = new int[0];
    this.e = false;
  }

  private boolean i()
  {
    return !(this.k instanceof AppCompatEditText);
  }

  final int a()
  {
    return Math.round(this.f);
  }

  final void a(int paramInt)
  {
    if (i())
      if (paramInt != 0)
      {
        if (paramInt == 1)
        {
          DisplayMetrics localDisplayMetrics = this.l.getResources().getDisplayMetrics();
          a(TypedValue.applyDimension(2, 12.0F, localDisplayMetrics), TypedValue.applyDimension(2, 112.0F, localDisplayMetrics), 1.0F);
          if (g())
            d();
        }
        else
        {
          StringBuilder localStringBuilder = new StringBuilder("Unknown auto-size text type: ");
          localStringBuilder.append(paramInt);
          throw new IllegalArgumentException(localStringBuilder.toString());
        }
      }
      else
        h();
  }

  final void a(int paramInt, float paramFloat)
  {
    Context localContext = this.l;
    Resources localResources;
    if (localContext == null)
      localResources = Resources.getSystem();
    else
      localResources = localContext.getResources();
    a(TypedValue.applyDimension(paramInt, paramFloat, localResources.getDisplayMetrics()));
  }

  final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws IllegalArgumentException
  {
    if (i())
    {
      DisplayMetrics localDisplayMetrics = this.l.getResources().getDisplayMetrics();
      a(TypedValue.applyDimension(paramInt4, paramInt1, localDisplayMetrics), TypedValue.applyDimension(paramInt4, paramInt2, localDisplayMetrics), TypedValue.applyDimension(paramInt4, paramInt3, localDisplayMetrics));
      if (g())
        d();
    }
  }

  final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    TypedArray localTypedArray1 = this.l.obtainStyledAttributes(paramAttributeSet, new int[] { 16842804, 2130968671, 2130968672, 2130968673, 2130968674, 2130968675, 2130969105, 2130969114, 2130969277, 2130969388, 2130969871 }, paramInt, 0);
    if (localTypedArray1.hasValue(5))
      this.a = localTypedArray1.getInt(5, 0);
    float f1;
    if (localTypedArray1.hasValue(4))
      f1 = localTypedArray1.getDimension(4, -1.0F);
    else
      f1 = -1.0F;
    float f2;
    if (localTypedArray1.hasValue(2))
      f2 = localTypedArray1.getDimension(2, -1.0F);
    else
      f2 = -1.0F;
    float f3;
    if (localTypedArray1.hasValue(1))
      f3 = localTypedArray1.getDimension(1, -1.0F);
    else
      f3 = -1.0F;
    if (localTypedArray1.hasValue(3))
    {
      int m = localTypedArray1.getResourceId(3, 0);
      if (m > 0)
      {
        TypedArray localTypedArray2 = localTypedArray1.getResources().obtainTypedArray(m);
        a(localTypedArray2);
        localTypedArray2.recycle();
      }
    }
    localTypedArray1.recycle();
    if (i())
    {
      if (this.a == 1)
      {
        if (!this.i)
        {
          DisplayMetrics localDisplayMetrics = this.l.getResources().getDisplayMetrics();
          if (f2 == -1.0F)
            f2 = TypedValue.applyDimension(2, 12.0F, localDisplayMetrics);
          if (f3 == -1.0F)
            f3 = TypedValue.applyDimension(2, 112.0F, localDisplayMetrics);
          if (f1 == -1.0F)
            f1 = 1.0F;
          a(f2, f3, f1);
        }
        g();
      }
    }
    else
      this.a = 0;
  }

  final void a(int[] paramArrayOfInt, int paramInt)
    throws IllegalArgumentException
  {
    if (i())
    {
      int m = paramArrayOfInt.length;
      int n = 0;
      if (m > 0)
      {
        int[] arrayOfInt = new int[m];
        if (paramInt == 0)
        {
          arrayOfInt = Arrays.copyOf(paramArrayOfInt, m);
        }
        else
        {
          DisplayMetrics localDisplayMetrics = this.l.getResources().getDisplayMetrics();
          while (n < m)
          {
            arrayOfInt[n] = Math.round(TypedValue.applyDimension(paramInt, paramArrayOfInt[n], localDisplayMetrics));
            n++;
          }
        }
        this.b = a(arrayOfInt);
        if (!f())
        {
          StringBuilder localStringBuilder = new StringBuilder("None of the preset sizes is valid: ");
          localStringBuilder.append(Arrays.toString(paramArrayOfInt));
          throw new IllegalArgumentException(localStringBuilder.toString());
        }
      }
      else
      {
        this.i = false;
      }
      if (g())
        d();
    }
  }

  final int b()
  {
    return Math.round(this.g);
  }

  final int c()
  {
    return Math.round(this.h);
  }

  final void d()
  {
    if (!e())
      return;
    if (this.e)
    {
      if (this.k.getMeasuredHeight() > 0)
      {
        if (this.k.getMeasuredWidth() <= 0)
          return;
        int m;
        if (((Boolean)a(this.k, "getHorizontallyScrolling", Boolean.valueOf(false))).booleanValue())
          m = 1048576;
        else
          m = this.k.getMeasuredWidth() - this.k.getTotalPaddingLeft() - this.k.getTotalPaddingRight();
        int n = this.k.getHeight() - this.k.getCompoundPaddingBottom() - this.k.getCompoundPaddingTop();
        if (m > 0)
        {
          if (n <= 0)
            return;
          synchronized (c)
          {
            c.setEmpty();
            c.right = m;
            c.bottom = n;
            float f1 = a(c);
            if (f1 != this.k.getTextSize())
              a(0, f1);
          }
        }
      }
      return;
    }
    this.e = true;
  }

  final boolean e()
  {
    return (i()) && (this.a != 0);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.m
 * JD-Core Version:    0.6.2
 */