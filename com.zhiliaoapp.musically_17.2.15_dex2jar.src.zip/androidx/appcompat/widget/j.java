package androidx.appcompat.widget;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Paint;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import androidx.core.graphics.drawable.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

class j
{
  private static final int[] b = { 16843067, 16843068 };
  public Bitmap a;
  private final ProgressBar c;

  static
  {
    CoverageLogger.Log(12247040);
  }

  j(ProgressBar paramProgressBar)
  {
    this.c = paramProgressBar;
  }

  private Drawable a(Drawable paramDrawable, boolean paramBoolean)
  {
    if ((paramDrawable instanceof f))
    {
      f localf = (f)paramDrawable;
      Drawable localDrawable2 = localf.a();
      if (localDrawable2 != null)
      {
        localf.a(a(localDrawable2, paramBoolean));
        return paramDrawable;
      }
    }
    else
    {
      if ((paramDrawable instanceof LayerDrawable))
      {
        LayerDrawable localLayerDrawable1 = (LayerDrawable)paramDrawable;
        int i = localLayerDrawable1.getNumberOfLayers();
        Drawable[] arrayOfDrawable = new Drawable[i];
        int j = 0;
        for (int k = 0; k < i; k++)
        {
          int m = localLayerDrawable1.getId(k);
          Drawable localDrawable1 = localLayerDrawable1.getDrawable(k);
          boolean bool;
          if ((m != 16908301) && (m != 16908303))
            bool = false;
          else
            bool = true;
          arrayOfDrawable[k] = a(localDrawable1, bool);
        }
        LayerDrawable localLayerDrawable2 = new LayerDrawable(arrayOfDrawable);
        while (j < i)
        {
          localLayerDrawable2.setId(j, localLayerDrawable1.getId(j));
          j++;
        }
        return localLayerDrawable2;
      }
      if ((paramDrawable instanceof BitmapDrawable))
      {
        BitmapDrawable localBitmapDrawable = (BitmapDrawable)paramDrawable;
        Bitmap localBitmap = localBitmapDrawable.getBitmap();
        if (this.a == null)
          this.a = localBitmap;
        ShapeDrawable localShapeDrawable = new ShapeDrawable(new RoundRectShape(new float[] { 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }, null, null));
        BitmapShader localBitmapShader = new BitmapShader(localBitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP);
        localShapeDrawable.getPaint().setShader(localBitmapShader);
        localShapeDrawable.getPaint().setColorFilter(localBitmapDrawable.getPaint().getColorFilter());
        if (paramBoolean)
          return new ClipDrawable(localShapeDrawable, 3, 1);
        return localShapeDrawable;
      }
    }
    return paramDrawable;
  }

  void a(AttributeSet paramAttributeSet, int paramInt)
  {
    ae localae = ae.a(this.c.getContext(), paramAttributeSet, b, paramInt, 0);
    Object localObject = localae.b(0);
    if (localObject != null)
    {
      ProgressBar localProgressBar = this.c;
      if ((localObject instanceof AnimationDrawable))
      {
        AnimationDrawable localAnimationDrawable1 = (AnimationDrawable)localObject;
        int i = localAnimationDrawable1.getNumberOfFrames();
        AnimationDrawable localAnimationDrawable2 = new AnimationDrawable();
        localAnimationDrawable2.setOneShot(localAnimationDrawable1.isOneShot());
        for (int j = 0; j < i; j++)
        {
          Drawable localDrawable2 = a(localAnimationDrawable1.getFrame(j), true);
          localDrawable2.setLevel(10000);
          localAnimationDrawable2.addFrame(localDrawable2, localAnimationDrawable1.getDuration(j));
        }
        localAnimationDrawable2.setLevel(10000);
        localObject = localAnimationDrawable2;
      }
      localProgressBar.setIndeterminateDrawable((Drawable)localObject);
    }
    Drawable localDrawable1 = localae.b(1);
    if (localDrawable1 != null)
      this.c.setProgressDrawable(a(localDrawable1, false));
    localae.a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.j
 * JD-Core Version:    0.6.2
 */