package androidx.appcompat.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.TextView;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class ai
{
  private final Context a;
  private final View b;
  private final TextView c;
  private final WindowManager.LayoutParams d = new WindowManager.LayoutParams();
  private final Rect e = new Rect();
  private final int[] f = new int[2];
  private final int[] g = new int[2];

  static
  {
    CoverageLogger.Log(12154880);
  }

  ai(Context paramContext)
  {
    this.a = paramContext;
    this.b = LayoutInflater.from(this.a).inflate(2131492891, null);
    this.c = ((TextView)this.b.findViewById(2131300028));
    this.d.setTitle(getClass().getSimpleName());
    this.d.packageName = this.a.getPackageName();
    WindowManager.LayoutParams localLayoutParams = this.d;
    localLayoutParams.type = 1002;
    localLayoutParams.width = -2;
    localLayoutParams.height = -2;
    localLayoutParams.format = -3;
    localLayoutParams.windowAnimations = 2131886089;
    localLayoutParams.flags = 24;
  }

  private static View a(View paramView)
  {
    View localView = paramView.getRootView();
    ViewGroup.LayoutParams localLayoutParams = localView.getLayoutParams();
    if (((localLayoutParams instanceof WindowManager.LayoutParams)) && (((WindowManager.LayoutParams)localLayoutParams).type == 2))
      return localView;
    for (Context localContext = paramView.getContext(); (localContext instanceof ContextWrapper); localContext = ((ContextWrapper)localContext).getBaseContext())
      if ((localContext instanceof Activity))
        return ((Activity)localContext).getWindow().getDecorView();
    return localView;
  }

  private void a(View paramView, int paramInt1, int paramInt2, boolean paramBoolean, WindowManager.LayoutParams paramLayoutParams)
  {
    paramLayoutParams.token = paramView.getApplicationWindowToken();
    int i = this.a.getResources().getDimensionPixelOffset(2131165812);
    if (paramView.getWidth() < i)
      paramInt1 = paramView.getWidth() / 2;
    int j;
    int k;
    if (paramView.getHeight() >= i)
    {
      int i8 = this.a.getResources().getDimensionPixelOffset(2131165811);
      j = paramInt2 + i8;
      k = paramInt2 - i8;
    }
    else
    {
      j = paramView.getHeight();
      k = 0;
    }
    paramLayoutParams.gravity = 49;
    Resources localResources1 = this.a.getResources();
    int m;
    if (paramBoolean)
      m = 2131165815;
    else
      m = 2131165814;
    int n = localResources1.getDimensionPixelOffset(m);
    View localView = a(paramView);
    if (localView == null)
      return;
    localView.getWindowVisibleDisplayFrame(this.e);
    if ((this.e.left < 0) && (this.e.top < 0))
    {
      Resources localResources2 = this.a.getResources();
      int i6 = localResources2.getIdentifier("status_bar_height", "dimen", "android");
      int i7;
      if (i6 != 0)
        i7 = localResources2.getDimensionPixelSize(i6);
      else
        i7 = 0;
      DisplayMetrics localDisplayMetrics = localResources2.getDisplayMetrics();
      this.e.set(0, i7, localDisplayMetrics.widthPixels, localDisplayMetrics.heightPixels);
    }
    localView.getLocationOnScreen(this.g);
    paramView.getLocationOnScreen(this.f);
    int[] arrayOfInt1 = this.f;
    int i1 = arrayOfInt1[0];
    int[] arrayOfInt2 = this.g;
    arrayOfInt1[0] = (i1 - arrayOfInt2[0]);
    arrayOfInt1[1] -= arrayOfInt2[1];
    paramLayoutParams.x = (paramInt1 + arrayOfInt1[0] - localView.getWidth() / 2);
    int i2 = View.MeasureSpec.makeMeasureSpec(0, 0);
    this.b.measure(i2, i2);
    int i3 = this.b.getMeasuredHeight();
    int[] arrayOfInt3 = this.f;
    int i4 = k + arrayOfInt3[1] - n - i3;
    int i5 = n + (j + arrayOfInt3[1]);
    if (paramBoolean)
    {
      if (i4 < 0)
        paramLayoutParams.y = i5;
    }
    else if (i3 + i5 <= this.e.height())
    {
      paramLayoutParams.y = i5;
      return;
    }
    paramLayoutParams.y = i4;
  }

  private boolean b()
  {
    return this.b.getParent() != null;
  }

  final void a()
  {
    if (!b())
      return;
    ((WindowManager)this.a.getSystemService("window")).removeView(this.b);
  }

  final void a(View paramView, int paramInt1, int paramInt2, boolean paramBoolean, CharSequence paramCharSequence)
  {
    if (b())
      a();
    this.c.setText(paramCharSequence);
    a(paramView, paramInt1, paramInt2, paramBoolean, this.d);
    ((WindowManager)this.a.getSystemService("window")).addView(this.b, this.d);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ai
 * JD-Core Version:    0.6.2
 */