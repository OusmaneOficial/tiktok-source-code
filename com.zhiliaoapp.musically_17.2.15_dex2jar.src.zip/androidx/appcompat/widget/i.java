package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.View;
import android.widget.PopupWindow;
import androidx.core.widget.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class i extends PopupWindow
{
  private static final boolean a = bool;
  private boolean b;

  static
  {
    CoverageLogger.Log(12222464);
    boolean bool;
    if (Build.VERSION.SDK_INT < 21)
      bool = true;
    else
      bool = false;
  }

  public i(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    ae localae = ae.a(paramContext, paramAttributeSet, new int[] { 16843126, 16843465, 2130969492 }, paramInt1, paramInt2);
    if (localae.f(2))
    {
      boolean bool = localae.a(2, false);
      if (a)
        this.b = bool;
      else
        g.a(this, bool);
    }
    setBackgroundDrawable(localae.a(0));
    localae.a();
  }

  public final void showAsDropDown(View paramView, int paramInt1, int paramInt2)
  {
    if ((a) && (this.b))
      paramInt2 -= paramView.getHeight();
    super.showAsDropDown(paramView, paramInt1, paramInt2);
  }

  public final void showAsDropDown(View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    if ((a) && (this.b))
      paramInt2 -= paramView.getHeight();
    super.showAsDropDown(paramView, paramInt1, paramInt2, paramInt3);
  }

  public final void update(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((a) && (this.b))
      paramInt2 -= paramView.getHeight();
    super.update(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.i
 * JD-Core Version:    0.6.2
 */