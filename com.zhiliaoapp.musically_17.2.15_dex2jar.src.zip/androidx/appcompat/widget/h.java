package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.appcompat.a.a.a;
import androidx.core.widget.e;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class h
{
  private final ImageView a;
  private ac b;
  private ac c;
  private ac d;

  static
  {
    CoverageLogger.Log(12240896);
  }

  public h(ImageView paramImageView)
  {
    this.a = paramImageView;
  }

  private boolean a(Drawable paramDrawable)
  {
    if (this.d == null)
      this.d = new ac();
    ac localac = this.d;
    localac.a();
    ColorStateList localColorStateList = e.a(this.a);
    if (localColorStateList != null)
    {
      localac.d = true;
      localac.a = localColorStateList;
    }
    PorterDuff.Mode localMode = e.b(this.a);
    if (localMode != null)
    {
      localac.c = true;
      localac.b = localMode;
    }
    if ((!localac.d) && (!localac.c))
      return false;
    f.a(paramDrawable, localac, this.a.getDrawableState());
    return true;
  }

  private boolean e()
  {
    int i = Build.VERSION.SDK_INT;
    if (i > 21)
      return this.b != null;
    return i == 21;
  }

  public final void a(int paramInt)
  {
    if (paramInt != 0)
    {
      Drawable localDrawable = a.b(this.a.getContext(), paramInt);
      if (localDrawable != null)
        p.b(localDrawable);
      this.a.setImageDrawable(localDrawable);
    }
    else
    {
      this.a.setImageDrawable(null);
    }
    d();
  }

  final void a(ColorStateList paramColorStateList)
  {
    if (this.c == null)
      this.c = new ac();
    ac localac = this.c;
    localac.a = paramColorStateList;
    localac.d = true;
    d();
  }

  final void a(PorterDuff.Mode paramMode)
  {
    if (this.c == null)
      this.c = new ac();
    ac localac = this.c;
    localac.b = paramMode;
    localac.c = true;
    d();
  }

  public final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    ae localae = ae.a(this.a.getContext(), paramAttributeSet, new int[] { 16843033, 2130969755, 2130969928, 2130969929 }, paramInt, 0);
    try
    {
      Drawable localDrawable = this.a.getDrawable();
      if (localDrawable == null)
      {
        int i = localae.g(1, -1);
        if (i != -1)
        {
          localDrawable = a.b(this.a.getContext(), i);
          if (localDrawable != null)
            this.a.setImageDrawable(localDrawable);
        }
      }
      if (localDrawable != null)
        p.b(localDrawable);
      if (localae.f(2))
        e.a(this.a, localae.e(2));
      if (localae.f(3))
        e.a(this.a, p.a(localae.a(3, -1), null));
      return;
    }
    finally
    {
      localae.a();
    }
  }

  final boolean a()
  {
    Drawable localDrawable = this.a.getBackground();
    return (Build.VERSION.SDK_INT < 21) || (!(localDrawable instanceof RippleDrawable));
  }

  final ColorStateList b()
  {
    ac localac = this.c;
    if (localac != null)
      return localac.a;
    return null;
  }

  final PorterDuff.Mode c()
  {
    ac localac = this.c;
    if (localac != null)
      return localac.b;
    return null;
  }

  final void d()
  {
    Drawable localDrawable = this.a.getDrawable();
    if (localDrawable != null)
      p.b(localDrawable);
    if (localDrawable != null)
    {
      if ((e()) && (a(localDrawable)))
        return;
      ac localac1 = this.c;
      if (localac1 != null)
      {
        f.a(localDrawable, localac1, this.a.getDrawableState());
        return;
      }
      ac localac2 = this.b;
      if (localac2 != null)
        f.a(localDrawable, localac2, this.a.getDrawableState());
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.h
 * JD-Core Version:    0.6.2
 */