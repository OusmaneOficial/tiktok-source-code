package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar.a;
import androidx.appcompat.view.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class y extends HorizontalScrollView
  implements AdapterView.OnItemSelectedListener
{
  private static final Interpolator i = new DecelerateInterpolator();
  Runnable a;
  LinearLayoutCompat b;
  int c;
  int d;
  int e;
  private Spinner f;
  private boolean g;
  private int h;

  static
  {
    CoverageLogger.Log(12351488);
  }

  private boolean a()
  {
    Spinner localSpinner = this.f;
    return (localSpinner != null) && (localSpinner.getParent() == this);
  }

  private boolean b()
  {
    if (!a())
      return false;
    removeView(this.f);
    addView(this.b, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.f.getSelectedItemPosition());
    return false;
  }

  public final void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    Runnable localRunnable = this.a;
    if (localRunnable != null)
      post(localRunnable);
  }

  protected final void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    a locala = a.a(getContext());
    TypedArray localTypedArray = locala.a.obtainStyledAttributes(null, new int[] { 2130968691, 2130968694, 2130968695, 2130968961, 2130968962, 2130968963, 2130968964, 2130968965, 2130968966, 2130969002, 2130969023, 2130969024, 2130969051, 2130969147, 2130969154, 2130969164, 2130969165, 2130969168, 2130969197, 2130969257, 2130969415, 2130969477, 2130969521, 2130969535, 2130969536, 2130969808, 2130969811, 2130969930, 2130969942 }, 2130968590, 0);
    int j = localTypedArray.getLayoutDimension(13, 0);
    Resources localResources = locala.a.getResources();
    if (!locala.b())
      j = Math.min(j, localResources.getDimensionPixelSize(2131165196));
    localTypedArray.recycle();
    setContentHeight(j);
    this.d = locala.a.getResources().getDimensionPixelSize(2131165197);
  }

  public final void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    Runnable localRunnable = this.a;
    if (localRunnable != null)
      removeCallbacks(localRunnable);
  }

  public final void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    ((b)paramView).b();
  }

  public final void onMeasure(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.getMode(paramInt1);
    int k = 1;
    boolean bool;
    if (j == 1073741824)
      bool = true;
    else
      bool = false;
    setFillViewport(bool);
    int m = this.b.getChildCount();
    if ((m > k) && ((j == 1073741824) || (j == -2147483648)))
    {
      if (m > 2)
        this.c = ((int)(0.4F * View.MeasureSpec.getSize(paramInt1)));
      else
        this.c = (View.MeasureSpec.getSize(paramInt1) / 2);
      this.c = Math.min(this.c, this.d);
    }
    else
    {
      this.c = -1;
    }
    int n = View.MeasureSpec.makeMeasureSpec(this.e, 1073741824);
    if ((bool) || (!this.g))
      k = 0;
    if (k != 0)
    {
      this.b.measure(0, n);
      if (this.b.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1))
      {
        if (!a())
        {
          if (this.f == null)
          {
            AppCompatSpinner localAppCompatSpinner = new AppCompatSpinner(getContext(), null, 2130968597);
            localAppCompatSpinner.setLayoutParams(new LinearLayoutCompat.LayoutParams(-2, -1));
            localAppCompatSpinner.setOnItemSelectedListener(this);
            this.f = localAppCompatSpinner;
          }
          removeView(this.b);
          addView(this.f, new ViewGroup.LayoutParams(-2, -1));
          if (this.f.getAdapter() == null)
            this.f.setAdapter(new a());
          Runnable localRunnable = this.a;
          if (localRunnable != null)
          {
            removeCallbacks(localRunnable);
            this.a = null;
          }
          this.f.setSelection(this.h);
        }
      }
      else
        b();
    }
    else
    {
      b();
    }
    int i1 = getMeasuredWidth();
    super.onMeasure(paramInt1, n);
    int i2 = getMeasuredWidth();
    if ((bool) && (i1 != i2))
      setTabSelected(this.h);
  }

  public final void onNothingSelected(AdapterView<?> paramAdapterView)
  {
  }

  public final void setAllowCollapse(boolean paramBoolean)
  {
    this.g = paramBoolean;
  }

  public final void setContentHeight(int paramInt)
  {
    this.e = paramInt;
    requestLayout();
  }

  public final void setTabSelected(int paramInt)
  {
    this.h = paramInt;
    int j = this.b.getChildCount();
    for (int k = 0; k < j; k++)
    {
      View localView1 = this.b.getChildAt(k);
      boolean bool;
      if (k == paramInt)
        bool = true;
      else
        bool = false;
      localView1.setSelected(bool);
      if (bool)
      {
        final View localView2 = this.b.getChildAt(paramInt);
        Runnable localRunnable = this.a;
        if (localRunnable != null)
          removeCallbacks(localRunnable);
        this.a = new Runnable()
        {
          static
          {
            CoverageLogger.Log(12115968);
          }

          public final void run()
          {
            int i = localView2.getLeft() - (y.this.getWidth() - localView2.getWidth()) / 2;
            y.this.smoothScrollTo(i, 0);
            y.this.a = null;
          }
        };
        post(this.a);
      }
    }
    Spinner localSpinner = this.f;
    if ((localSpinner != null) && (paramInt >= 0))
      localSpinner.setSelection(paramInt);
  }

  final class a extends BaseAdapter
  {
    static
    {
      CoverageLogger.Log(12357632);
    }

    a()
    {
    }

    public final int getCount()
    {
      return y.this.b.getChildCount();
    }

    public final Object getItem(int paramInt)
    {
      return ((y.b)y.this.b.getChildAt(paramInt)).b();
    }

    public final long getItemId(int paramInt)
    {
      return paramInt;
    }

    public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      if (paramView == null)
      {
        y localy = y.this;
        ActionBar.a locala = (ActionBar.a)getItem(paramInt);
        y.b localb2 = new y.b(localy, localy.getContext(), locala, true);
        localb2.setBackgroundDrawable(null);
        localb2.setLayoutParams(new AbsListView.LayoutParams(-1, localy.e));
        return localb2;
      }
      y.b localb1 = (y.b)paramView;
      localb1.a = ((ActionBar.a)getItem(paramInt));
      localb1.a();
      return paramView;
    }
  }

  final class b extends LinearLayout
  {
    ActionBar.a a;
    private final int[] c = { 16842964 };
    private TextView d;
    private ImageView e;
    private View f;

    static
    {
      CoverageLogger.Log(12355584);
    }

    public b(Context parama, ActionBar.a paramBoolean, boolean arg4)
    {
      super(null, 2130968592);
      this.a = paramBoolean;
      ae localae = ae.a(parama, null, this.c, 2130968592, 0);
      if (localae.f(0))
        setBackgroundDrawable(localae.a(0));
      localae.a();
      int i;
      if (i != 0)
        setGravity(8388627);
      a();
    }

    public final void a()
    {
      ActionBar.a locala = this.a;
      View localView1 = locala.c();
      if (localView1 != null)
      {
        ViewParent localViewParent = localView1.getParent();
        if (localViewParent != this)
        {
          if (localViewParent != null)
            ((ViewGroup)localViewParent).removeView(localView1);
          addView(localView1);
        }
        this.f = localView1;
        TextView localTextView2 = this.d;
        if (localTextView2 != null)
          localTextView2.setVisibility(8);
        ImageView localImageView3 = this.e;
        if (localImageView3 != null)
        {
          localImageView3.setVisibility(8);
          this.e.setImageDrawable(null);
        }
        return;
      }
      View localView2 = this.f;
      if (localView2 != null)
      {
        removeView(localView2);
        this.f = null;
      }
      Drawable localDrawable = locala.a();
      CharSequence localCharSequence1 = locala.b();
      if (localDrawable != null)
      {
        if (this.e == null)
        {
          AppCompatImageView localAppCompatImageView = new AppCompatImageView(getContext());
          LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-2, -2);
          localLayoutParams2.gravity = 16;
          localAppCompatImageView.setLayoutParams(localLayoutParams2);
          addView(localAppCompatImageView, 0);
          this.e = localAppCompatImageView;
        }
        this.e.setImageDrawable(localDrawable);
        this.e.setVisibility(0);
      }
      else
      {
        ImageView localImageView1 = this.e;
        if (localImageView1 != null)
        {
          localImageView1.setVisibility(8);
          this.e.setImageDrawable(null);
        }
      }
      boolean bool = true ^ TextUtils.isEmpty(localCharSequence1);
      if (bool)
      {
        if (this.d == null)
        {
          AppCompatTextView localAppCompatTextView = new AppCompatTextView(getContext(), null, 2130968593);
          localAppCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
          LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-2, -2);
          localLayoutParams1.gravity = 16;
          localAppCompatTextView.setLayoutParams(localLayoutParams1);
          addView(localAppCompatTextView);
          this.d = localAppCompatTextView;
        }
        this.d.setText(localCharSequence1);
        this.d.setVisibility(0);
      }
      else
      {
        TextView localTextView1 = this.d;
        if (localTextView1 != null)
        {
          localTextView1.setVisibility(8);
          this.d.setText(null);
        }
      }
      ImageView localImageView2 = this.e;
      if (localImageView2 != null)
        localImageView2.setContentDescription(locala.d());
      CharSequence localCharSequence2;
      if (bool)
        localCharSequence2 = null;
      else
        localCharSequence2 = locala.d();
      ag.a(this, localCharSequence2);
    }

    public final ActionBar.a b()
    {
      return this.a;
    }

    public final void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
    {
      super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(ActionBar.a.class.getName());
    }

    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
    {
      super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
      paramAccessibilityNodeInfo.setClassName(ActionBar.a.class.getName());
    }

    public final void onMeasure(int paramInt1, int paramInt2)
    {
      super.onMeasure(paramInt1, paramInt2);
      if ((y.this.c > 0) && (getMeasuredWidth() > y.this.c))
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(y.this.c, 1073741824), paramInt2);
    }

    public final void setSelected(boolean paramBoolean)
    {
      int i;
      if (isSelected() != paramBoolean)
        i = 1;
      else
        i = 0;
      super.setSelected(paramBoolean);
      if ((i != 0) && (paramBoolean))
        sendAccessibilityEvent(4);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.y
 * JD-Core Version:    0.6.2
 */