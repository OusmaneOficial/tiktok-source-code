package androidx.appcompat.widget;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class x
{
  public int a;
  public int b;
  int c = -2147483648;
  int d = -2147483648;
  int e;
  int f;
  boolean g;
  boolean h;

  static
  {
    CoverageLogger.Log(12349440);
  }

  public final void a(int paramInt1, int paramInt2)
  {
    this.c = paramInt1;
    this.d = paramInt2;
    this.h = true;
    if (this.g)
    {
      if (paramInt2 != -2147483648)
        this.a = paramInt2;
      if (paramInt1 != -2147483648)
        this.b = paramInt1;
    }
    else
    {
      if (paramInt1 != -2147483648)
        this.a = paramInt1;
      if (paramInt2 != -2147483648)
        this.b = paramInt2;
    }
  }

  public final void b(int paramInt1, int paramInt2)
  {
    this.h = false;
    if (paramInt1 != -2147483648)
    {
      this.e = paramInt1;
      this.a = paramInt1;
    }
    if (paramInt2 != -2147483648)
    {
      this.f = paramInt2;
      this.b = paramInt2;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.x
 * JD-Core Version:    0.6.2
 */