package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;

public final class ViewStubCompat extends View
{
  private int a;
  private int b;
  private WeakReference<View> c;
  private LayoutInflater d;
  private a e;

  static
  {
    CoverageLogger.Log(12158976);
  }

  public ViewStubCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public ViewStubCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16842960, 16842994, 16842995 }, paramInt, 0);
    this.b = localTypedArray.getResourceId(2, -1);
    this.a = localTypedArray.getResourceId(1, 0);
    setId(localTypedArray.getResourceId(0, -1));
    localTypedArray.recycle();
    setVisibility(8);
    setWillNotDraw(true);
  }

  public final View a()
  {
    ViewParent localViewParent = getParent();
    if ((localViewParent != null) && ((localViewParent instanceof ViewGroup)))
    {
      if (this.a != 0)
      {
        ViewGroup localViewGroup = (ViewGroup)localViewParent;
        LayoutInflater localLayoutInflater = this.d;
        if (localLayoutInflater == null)
          localLayoutInflater = LayoutInflater.from(getContext());
        View localView = localLayoutInflater.inflate(this.a, localViewGroup, false);
        int i = this.b;
        if (i != -1)
          localView.setId(i);
        int j = localViewGroup.indexOfChild(this);
        localViewGroup.removeViewInLayout(this);
        ViewGroup.LayoutParams localLayoutParams = getLayoutParams();
        if (localLayoutParams != null)
          localViewGroup.addView(localView, j, localLayoutParams);
        else
          localViewGroup.addView(localView, j);
        this.c = new WeakReference(localView);
        return localView;
      }
      throw new IllegalArgumentException("ViewStub must have a valid layoutResource");
    }
    throw new IllegalStateException("ViewStub must have a non-null ViewGroup viewParent");
  }

  protected final void dispatchDraw(Canvas paramCanvas)
  {
  }

  public final void draw(Canvas paramCanvas)
  {
  }

  public final int getInflatedId()
  {
    return this.b;
  }

  public final LayoutInflater getLayoutInflater()
  {
    return this.d;
  }

  public final int getLayoutResource()
  {
    return this.a;
  }

  protected final void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(0, 0);
  }

  public final void setInflatedId(int paramInt)
  {
    this.b = paramInt;
  }

  public final void setLayoutInflater(LayoutInflater paramLayoutInflater)
  {
    this.d = paramLayoutInflater;
  }

  public final void setLayoutResource(int paramInt)
  {
    this.a = paramInt;
  }

  public final void setOnInflateListener(a parama)
  {
    this.e = parama;
  }

  public final void setVisibility(int paramInt)
  {
    WeakReference localWeakReference = this.c;
    if (localWeakReference != null)
    {
      View localView = (View)localWeakReference.get();
      if (localView != null)
      {
        localView.setVisibility(paramInt);
        return;
      }
      throw new IllegalStateException("setVisibility called on un-referenced view");
    }
    super.setVisibility(paramInt);
    if ((paramInt == 0) || (paramInt == 4))
      a();
  }

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(12163072);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ViewStubCompat
 * JD-Core Version:    0.6.2
 */