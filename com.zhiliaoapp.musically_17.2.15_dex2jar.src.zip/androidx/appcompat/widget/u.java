package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.h;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface u
{
  static
  {
    CoverageLogger.Log(12126208);
  }

  public abstract void a(h paramh, MenuItem paramMenuItem);

  public abstract void b(h paramh, MenuItem paramMenuItem);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.u
 * JD-Core Version:    0.6.2
 */