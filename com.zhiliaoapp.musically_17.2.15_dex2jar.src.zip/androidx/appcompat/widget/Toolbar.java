package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.text.Layout;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.a.a.a;
import androidx.appcompat.app.ActionBar.LayoutParams;
import androidx.appcompat.view.c;
import androidx.appcompat.view.menu.h;
import androidx.appcompat.view.menu.h.a;
import androidx.appcompat.view.menu.j;
import androidx.appcompat.view.menu.o.a;
import androidx.appcompat.view.menu.u;
import androidx.core.h.d;
import androidx.core.h.t;
import androidx.customview.view.AbsSavedState;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup
{
  private o.a mActionMenuPresenterCallback;
  int mButtonGravity;
  ImageButton mCollapseButtonView;
  private CharSequence mCollapseDescription;
  private Drawable mCollapseIcon;
  private boolean mCollapsible;
  private int mContentInsetEndWithActions;
  private int mContentInsetStartWithNavigation;
  private x mContentInsets;
  private boolean mEatingHover;
  private boolean mEatingTouch;
  View mExpandedActionView;
  private a mExpandedMenuPresenter;
  private int mGravity = 8388627;
  private final ArrayList<View> mHiddenViews = new ArrayList();
  private ImageView mLogoView;
  private int mMaxButtonHeight;
  private h.a mMenuBuilderCallback;
  private ActionMenuView mMenuView;
  private final ActionMenuView.d mMenuViewItemClickListener = new ActionMenuView.d()
  {
    static
    {
      CoverageLogger.Log(12111872);
    }

    public final boolean a(MenuItem paramAnonymousMenuItem)
    {
      if (Toolbar.this.mOnMenuItemClickListener != null)
        return Toolbar.this.mOnMenuItemClickListener.onMenuItemClick(paramAnonymousMenuItem);
      return false;
    }
  };
  private ImageButton mNavButtonView;
  b mOnMenuItemClickListener;
  private ActionMenuPresenter mOuterActionMenuPresenter;
  private Context mPopupContext;
  private int mPopupTheme;
  private final Runnable mShowOverflowMenuRunnable = new Runnable()
  {
    static
    {
      CoverageLogger.Log(12113920);
    }

    public final void run()
    {
      Toolbar.this.showOverflowMenu();
    }
  };
  private CharSequence mSubtitleText;
  private int mSubtitleTextAppearance;
  private int mSubtitleTextColor;
  private TextView mSubtitleTextView;
  private final int[] mTempMargins = new int[2];
  private final ArrayList<View> mTempViews = new ArrayList();
  private int mTitleMarginBottom;
  private int mTitleMarginEnd;
  private int mTitleMarginStart;
  private int mTitleMarginTop;
  private CharSequence mTitleText;
  private int mTitleTextAppearance;
  private int mTitleTextColor;
  private TextView mTitleTextView;
  private af mWrapper;

  static
  {
    CoverageLogger.Log(12095488);
  }

  public Toolbar(Context paramContext)
  {
    this(paramContext, null);
  }

  public Toolbar(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 2130969948);
  }

  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    ae localae = ae.a(getContext(), paramAttributeSet, new int[] { 16842927, 16843072, 2130968836, 2130968914, 2130968915, 2130968961, 2130968962, 2130968963, 2130968964, 2130968965, 2130968966, 2130969415, 2130969416, 2130969437, 2130969475, 2130969476, 2130969521, 2130969808, 2130969809, 2130969810, 2130969930, 2130969932, 2130969933, 2130969934, 2130969935, 2130969936, 2130969937, 2130969939, 2130969940 }, paramInt, 0);
    this.mTitleTextAppearance = localae.g(27, 0);
    this.mSubtitleTextAppearance = localae.g(18, 0);
    this.mGravity = localae.c(0, this.mGravity);
    this.mButtonGravity = localae.c(2, 48);
    int i = localae.d(21, 0);
    if (localae.f(26))
      i = localae.d(26, i);
    this.mTitleMarginBottom = i;
    this.mTitleMarginTop = i;
    this.mTitleMarginEnd = i;
    this.mTitleMarginStart = i;
    int j = localae.d(24, -1);
    if (j >= 0)
      this.mTitleMarginStart = j;
    int k = localae.d(23, -1);
    if (k >= 0)
      this.mTitleMarginEnd = k;
    int m = localae.d(25, -1);
    if (m >= 0)
      this.mTitleMarginTop = m;
    int n = localae.d(22, -1);
    if (n >= 0)
      this.mTitleMarginBottom = n;
    this.mMaxButtonHeight = localae.e(13, -1);
    int i1 = localae.d(9, -2147483648);
    int i2 = localae.d(5, -2147483648);
    int i3 = localae.e(7, 0);
    int i4 = localae.e(8, 0);
    ensureContentInsets();
    this.mContentInsets.b(i3, i4);
    if ((i1 != -2147483648) || (i2 != -2147483648))
      this.mContentInsets.a(i1, i2);
    this.mContentInsetStartWithNavigation = localae.d(10, -2147483648);
    this.mContentInsetEndWithActions = localae.d(6, -2147483648);
    this.mCollapseIcon = localae.a(4);
    this.mCollapseDescription = localae.c(3);
    CharSequence localCharSequence1 = localae.c(20);
    if (!TextUtils.isEmpty(localCharSequence1))
      setTitle(localCharSequence1);
    CharSequence localCharSequence2 = localae.c(17);
    if (!TextUtils.isEmpty(localCharSequence2))
      setSubtitle(localCharSequence2);
    this.mPopupContext = getContext();
    setPopupTheme(localae.g(16, 0));
    Drawable localDrawable1 = localae.a(15);
    if (localDrawable1 != null)
      setNavigationIcon(localDrawable1);
    CharSequence localCharSequence3 = localae.c(14);
    if (!TextUtils.isEmpty(localCharSequence3))
      setNavigationContentDescription(localCharSequence3);
    Drawable localDrawable2 = localae.a(11);
    if (localDrawable2 != null)
      setLogo(localDrawable2);
    CharSequence localCharSequence4 = localae.c(12);
    if (!TextUtils.isEmpty(localCharSequence4))
      setLogoDescription(localCharSequence4);
    if (localae.f(28))
      setTitleTextColor(localae.b(28, -1));
    if (localae.f(19))
      setSubtitleTextColor(localae.b(19, -1));
    localae.a();
  }

  private void addCustomViewsWithGravity(List<View> paramList, int paramInt)
  {
    int i;
    if (t.f(this) == 1)
      i = 1;
    else
      i = 0;
    int j = getChildCount();
    int k = d.a(paramInt, t.f(this));
    paramList.clear();
    int m = 0;
    if (i != 0)
    {
      for (int n = j - 1; n >= 0; n--)
      {
        View localView2 = getChildAt(n);
        LayoutParams localLayoutParams2 = (LayoutParams)localView2.getLayoutParams();
        if ((localLayoutParams2.b == 0) && (shouldLayout(localView2)) && (getChildHorizontalGravity(localLayoutParams2.a) == k))
          paramList.add(localView2);
      }
      return;
    }
    while (m < j)
    {
      View localView1 = getChildAt(m);
      LayoutParams localLayoutParams1 = (LayoutParams)localView1.getLayoutParams();
      if ((localLayoutParams1.b == 0) && (shouldLayout(localView1)) && (getChildHorizontalGravity(localLayoutParams1.a) == k))
        paramList.add(localView1);
      m++;
    }
  }

  private void addSystemView(View paramView, boolean paramBoolean)
  {
    ViewGroup.LayoutParams localLayoutParams = paramView.getLayoutParams();
    LayoutParams localLayoutParams1;
    if (localLayoutParams == null)
      localLayoutParams1 = generateDefaultLayoutParams();
    else if (!checkLayoutParams(localLayoutParams))
      localLayoutParams1 = generateLayoutParams(localLayoutParams);
    else
      localLayoutParams1 = (LayoutParams)localLayoutParams;
    localLayoutParams1.b = 1;
    if ((paramBoolean) && (this.mExpandedActionView != null))
    {
      paramView.setLayoutParams(localLayoutParams1);
      this.mHiddenViews.add(paramView);
      return;
    }
    addView(paramView, localLayoutParams1);
  }

  private void ensureContentInsets()
  {
    if (this.mContentInsets == null)
      this.mContentInsets = new x();
  }

  private void ensureLogoView()
  {
    if (this.mLogoView == null)
      this.mLogoView = new AppCompatImageView(getContext());
  }

  private void ensureMenu()
  {
    ensureMenuView();
    if (this.mMenuView.a == null)
    {
      h localh = (h)this.mMenuView.getMenu();
      if (this.mExpandedMenuPresenter == null)
        this.mExpandedMenuPresenter = new a();
      this.mMenuView.setExpandedActionViewsExclusive(true);
      localh.a(this.mExpandedMenuPresenter, this.mPopupContext);
    }
  }

  private void ensureMenuView()
  {
    if (this.mMenuView == null)
    {
      this.mMenuView = new ActionMenuView(getContext());
      this.mMenuView.setPopupTheme(this.mPopupTheme);
      this.mMenuView.setOnMenuItemClickListener(this.mMenuViewItemClickListener);
      this.mMenuView.a(this.mActionMenuPresenterCallback, this.mMenuBuilderCallback);
      LayoutParams localLayoutParams = generateDefaultLayoutParams();
      localLayoutParams.a = (0x800005 | 0x70 & this.mButtonGravity);
      this.mMenuView.setLayoutParams(localLayoutParams);
      addSystemView(this.mMenuView, false);
    }
  }

  private void ensureNavButtonView()
  {
    if (this.mNavButtonView == null)
    {
      this.mNavButtonView = new AppCompatImageButton(getContext(), null, 2130969947);
      LayoutParams localLayoutParams = generateDefaultLayoutParams();
      localLayoutParams.a = (0x800003 | 0x70 & this.mButtonGravity);
      this.mNavButtonView.setLayoutParams(localLayoutParams);
    }
  }

  private int getChildHorizontalGravity(int paramInt)
  {
    int i = t.f(this);
    int j = 0x7 & d.a(paramInt, i);
    if ((j != 1) && (j != 3) && (j != 5))
    {
      if (i == 1)
        return 5;
      return 3;
    }
    return j;
  }

  private int getChildTop(View paramView, int paramInt)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = paramView.getMeasuredHeight();
    int j;
    if (paramInt > 0)
      j = (i - paramInt) / 2;
    else
      j = 0;
    int k = getChildVerticalGravity(localLayoutParams.a);
    if (k != 48)
    {
      if (k != 80)
      {
        int m = getPaddingTop();
        int n = getPaddingBottom();
        int i1 = getHeight();
        int i2 = (i1 - m - n - i) / 2;
        if (i2 < localLayoutParams.topMargin)
        {
          i2 = localLayoutParams.topMargin;
        }
        else
        {
          int i3 = i1 - n - i - i2 - m;
          if (i3 < localLayoutParams.bottomMargin)
            i2 = Math.max(0, i2 - (localLayoutParams.bottomMargin - i3));
        }
        return m + i2;
      }
      return getHeight() - getPaddingBottom() - i - localLayoutParams.bottomMargin - j;
    }
    return getPaddingTop() - j;
  }

  private int getChildVerticalGravity(int paramInt)
  {
    int i = paramInt & 0x70;
    if ((i != 16) && (i != 48) && (i != 80))
      i = 0x70 & this.mGravity;
    return i;
  }

  private int getHorizontalMargins(View paramView)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return androidx.core.h.g.a(localMarginLayoutParams) + androidx.core.h.g.b(localMarginLayoutParams);
  }

  private MenuInflater getMenuInflater()
  {
    return new androidx.appcompat.view.g(getContext());
  }

  private int getVerticalMargins(View paramView)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return localMarginLayoutParams.topMargin + localMarginLayoutParams.bottomMargin;
  }

  private int getViewListMeasuredWidth(List<View> paramList, int[] paramArrayOfInt)
  {
    int i = paramArrayOfInt[0];
    int j = paramArrayOfInt[1];
    int k = paramList.size();
    int m = j;
    int n = i;
    int i1 = 0;
    int i2 = 0;
    while (i1 < k)
    {
      View localView = (View)paramList.get(i1);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      int i3 = localLayoutParams.leftMargin - n;
      int i4 = localLayoutParams.rightMargin - m;
      int i5 = Math.max(0, i3);
      int i6 = Math.max(0, i4);
      int i7 = Math.max(0, -i3);
      int i8 = Math.max(0, -i4);
      i2 += i6 + (i5 + localView.getMeasuredWidth());
      i1++;
      m = i8;
      n = i7;
    }
    return i2;
  }

  private boolean isChildOrHidden(View paramView)
  {
    return (paramView.getParent() == this) || (this.mHiddenViews.contains(paramView));
  }

  private static boolean isCustomView(View paramView)
  {
    return ((LayoutParams)paramView.getLayoutParams()).b == 0;
  }

  private int layoutChildLeft(View paramView, int paramInt1, int[] paramArrayOfInt, int paramInt2)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = localLayoutParams.leftMargin - paramArrayOfInt[0];
    int j = paramInt1 + Math.max(0, i);
    paramArrayOfInt[0] = Math.max(0, -i);
    int k = getChildTop(paramView, paramInt2);
    int m = paramView.getMeasuredWidth();
    paramView.layout(j, k, j + m, k + paramView.getMeasuredHeight());
    return j + (m + localLayoutParams.rightMargin);
  }

  private int layoutChildRight(View paramView, int paramInt1, int[] paramArrayOfInt, int paramInt2)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = localLayoutParams.rightMargin - paramArrayOfInt[1];
    int j = paramInt1 - Math.max(0, i);
    paramArrayOfInt[1] = Math.max(0, -i);
    int k = getChildTop(paramView, paramInt2);
    int m = paramView.getMeasuredWidth();
    paramView.layout(j - m, k, j, k + paramView.getMeasuredHeight());
    return j - (m + localLayoutParams.leftMargin);
  }

  private int measureChildCollapseMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = localMarginLayoutParams.leftMargin - paramArrayOfInt[0];
    int j = localMarginLayoutParams.rightMargin - paramArrayOfInt[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfInt[0] = Math.max(0, -i);
    paramArrayOfInt[1] = Math.max(0, -j);
    paramView.measure(getChildMeasureSpec(paramInt1, paramInt2 + (k + (getPaddingLeft() + getPaddingRight())), localMarginLayoutParams.width), getChildMeasureSpec(paramInt3, paramInt4 + (getPaddingTop() + getPaddingBottom() + localMarginLayoutParams.topMargin + localMarginLayoutParams.bottomMargin), localMarginLayoutParams.height));
    return k + paramView.getMeasuredWidth();
  }

  private void measureChildConstrained(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getChildMeasureSpec(paramInt1, paramInt2 + (getPaddingLeft() + getPaddingRight() + localMarginLayoutParams.leftMargin + localMarginLayoutParams.rightMargin), localMarginLayoutParams.width);
    int j = getChildMeasureSpec(paramInt3, paramInt4 + (getPaddingTop() + getPaddingBottom() + localMarginLayoutParams.topMargin + localMarginLayoutParams.bottomMargin), localMarginLayoutParams.height);
    int k = View.MeasureSpec.getMode(j);
    if ((k != 1073741824) && (paramInt5 >= 0))
    {
      if (k != 0)
        paramInt5 = Math.min(View.MeasureSpec.getSize(j), paramInt5);
      j = View.MeasureSpec.makeMeasureSpec(paramInt5, 1073741824);
    }
    paramView.measure(i, j);
  }

  private void postShowOverflowMenu()
  {
    removeCallbacks(this.mShowOverflowMenuRunnable);
    post(this.mShowOverflowMenuRunnable);
  }

  private boolean shouldCollapse()
  {
    if (!this.mCollapsible)
      return false;
    int i = getChildCount();
    for (int j = 0; j < i; j++)
    {
      View localView = getChildAt(j);
      if ((shouldLayout(localView)) && (localView.getMeasuredWidth() > 0) && (localView.getMeasuredHeight() > 0))
        return false;
    }
    return true;
  }

  private boolean shouldLayout(View paramView)
  {
    return (paramView != null) && (paramView.getParent() == this) && (paramView.getVisibility() != 8);
  }

  void addChildrenForExpandedActionView()
  {
    for (int i = -1 + this.mHiddenViews.size(); i >= 0; i--)
      addView((View)this.mHiddenViews.get(i));
    this.mHiddenViews.clear();
  }

  public boolean canShowOverflowMenu()
  {
    if (getVisibility() == 0)
    {
      ActionMenuView localActionMenuView = this.mMenuView;
      if ((localActionMenuView != null) && (localActionMenuView.b))
        return true;
    }
    return false;
  }

  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return (super.checkLayoutParams(paramLayoutParams)) && ((paramLayoutParams instanceof LayoutParams));
  }

  public void collapseActionView()
  {
    a locala = this.mExpandedMenuPresenter;
    j localj;
    if (locala == null)
      localj = null;
    else
      localj = locala.b;
    if (localj != null)
      localj.collapseActionView();
  }

  public void dismissPopupMenus()
  {
    ActionMenuView localActionMenuView = this.mMenuView;
    if (localActionMenuView != null)
      localActionMenuView.b();
  }

  void ensureCollapseButtonView()
  {
    if (this.mCollapseButtonView == null)
    {
      this.mCollapseButtonView = new AppCompatImageButton(getContext(), null, 2130969947);
      this.mCollapseButtonView.setImageDrawable(this.mCollapseIcon);
      this.mCollapseButtonView.setContentDescription(this.mCollapseDescription);
      LayoutParams localLayoutParams = generateDefaultLayoutParams();
      localLayoutParams.a = (0x800003 | 0x70 & this.mButtonGravity);
      localLayoutParams.b = 2;
      this.mCollapseButtonView.setLayoutParams(localLayoutParams);
      this.mCollapseButtonView.setOnClickListener(new View.OnClickListener()
      {
        static
        {
          CoverageLogger.Log(12038144);
        }

        public final void onClick(View paramAnonymousView)
        {
          Toolbar.this.collapseActionView();
        }
      });
    }
  }

  protected LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams(-2, -2);
  }

  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }

  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof LayoutParams))
      return new LayoutParams((LayoutParams)paramLayoutParams);
    if ((paramLayoutParams instanceof ActionBar.LayoutParams))
      return new LayoutParams((ActionBar.LayoutParams)paramLayoutParams);
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams))
      return new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams);
    return new LayoutParams(paramLayoutParams);
  }

  public int getContentInsetEnd()
  {
    x localx = this.mContentInsets;
    if (localx != null)
    {
      if (localx.g)
        return localx.a;
      return localx.b;
    }
    return 0;
  }

  public int getContentInsetEndWithActions()
  {
    int i = this.mContentInsetEndWithActions;
    if (i != -2147483648)
      return i;
    return getContentInsetEnd();
  }

  public int getContentInsetLeft()
  {
    x localx = this.mContentInsets;
    if (localx != null)
      return localx.a;
    return 0;
  }

  public int getContentInsetRight()
  {
    x localx = this.mContentInsets;
    if (localx != null)
      return localx.b;
    return 0;
  }

  public int getContentInsetStart()
  {
    x localx = this.mContentInsets;
    if (localx != null)
    {
      if (localx.g)
        return localx.b;
      return localx.a;
    }
    return 0;
  }

  public int getContentInsetStartWithNavigation()
  {
    int i = this.mContentInsetStartWithNavigation;
    if (i != -2147483648)
      return i;
    return getContentInsetStart();
  }

  public int getCurrentContentInsetEnd()
  {
    ActionMenuView localActionMenuView = this.mMenuView;
    if (localActionMenuView != null)
    {
      h localh = localActionMenuView.a;
      if ((localh != null) && (localh.hasVisibleItems()))
      {
        i = 1;
        break label32;
      }
    }
    int i = 0;
    label32: if (i != 0)
      return Math.max(getContentInsetEnd(), Math.max(this.mContentInsetEndWithActions, 0));
    return getContentInsetEnd();
  }

  public int getCurrentContentInsetLeft()
  {
    if (t.f(this) == 1)
      return getCurrentContentInsetEnd();
    return getCurrentContentInsetStart();
  }

  public int getCurrentContentInsetRight()
  {
    if (t.f(this) == 1)
      return getCurrentContentInsetStart();
    return getCurrentContentInsetEnd();
  }

  public int getCurrentContentInsetStart()
  {
    if (getNavigationIcon() != null)
      return Math.max(getContentInsetStart(), Math.max(this.mContentInsetStartWithNavigation, 0));
    return getContentInsetStart();
  }

  public Drawable getLogo()
  {
    ImageView localImageView = this.mLogoView;
    if (localImageView != null)
      return localImageView.getDrawable();
    return null;
  }

  public CharSequence getLogoDescription()
  {
    ImageView localImageView = this.mLogoView;
    if (localImageView != null)
      return localImageView.getContentDescription();
    return null;
  }

  public Menu getMenu()
  {
    ensureMenu();
    return this.mMenuView.getMenu();
  }

  public CharSequence getNavigationContentDescription()
  {
    ImageButton localImageButton = this.mNavButtonView;
    if (localImageButton != null)
      return localImageButton.getContentDescription();
    return null;
  }

  public Drawable getNavigationIcon()
  {
    ImageButton localImageButton = this.mNavButtonView;
    if (localImageButton != null)
      return localImageButton.getDrawable();
    return null;
  }

  ActionMenuPresenter getOuterActionMenuPresenter()
  {
    return this.mOuterActionMenuPresenter;
  }

  public Drawable getOverflowIcon()
  {
    ensureMenu();
    return this.mMenuView.getOverflowIcon();
  }

  Context getPopupContext()
  {
    return this.mPopupContext;
  }

  public int getPopupTheme()
  {
    return this.mPopupTheme;
  }

  public CharSequence getSubtitle()
  {
    return this.mSubtitleText;
  }

  public CharSequence getTitle()
  {
    return this.mTitleText;
  }

  public int getTitleMarginBottom()
  {
    return this.mTitleMarginBottom;
  }

  public int getTitleMarginEnd()
  {
    return this.mTitleMarginEnd;
  }

  public int getTitleMarginStart()
  {
    return this.mTitleMarginStart;
  }

  public int getTitleMarginTop()
  {
    return this.mTitleMarginTop;
  }

  public o getWrapper()
  {
    if (this.mWrapper == null)
      this.mWrapper = new af(this, true);
    return this.mWrapper;
  }

  public boolean hasExpandedActionView()
  {
    a locala = this.mExpandedMenuPresenter;
    return (locala != null) && (locala.b != null);
  }

  public boolean hideOverflowMenu()
  {
    ActionMenuView localActionMenuView = this.mMenuView;
    if (localActionMenuView != null)
    {
      int i;
      if ((localActionMenuView.c != null) && (localActionMenuView.c.d()))
        i = 1;
      else
        i = 0;
      if (i != 0)
        return true;
    }
    return false;
  }

  public void inflateMenu(int paramInt)
  {
    getMenuInflater().inflate(paramInt, getMenu());
  }

  public boolean isOverflowMenuShowPending()
  {
    ActionMenuView localActionMenuView = this.mMenuView;
    if (localActionMenuView != null)
    {
      if (localActionMenuView.c != null)
      {
        ActionMenuPresenter localActionMenuPresenter = localActionMenuView.c;
        int j;
        if ((localActionMenuPresenter.p == null) && (!localActionMenuPresenter.h()))
          j = 0;
        else
          j = 1;
        if (j != 0)
        {
          i = 1;
          break label59;
        }
      }
      int i = 0;
      label59: if (i != 0)
        return true;
    }
    return false;
  }

  public boolean isOverflowMenuShowing()
  {
    ActionMenuView localActionMenuView = this.mMenuView;
    if (localActionMenuView != null)
    {
      int i;
      if ((localActionMenuView.c != null) && (localActionMenuView.c.h()))
        i = 1;
      else
        i = 0;
      if (i != 0)
        return true;
    }
    return false;
  }

  public boolean isTitleTruncated()
  {
    TextView localTextView = this.mTitleTextView;
    if (localTextView == null)
      return false;
    Layout localLayout = localTextView.getLayout();
    if (localLayout == null)
      return false;
    int i = localLayout.getLineCount();
    for (int j = 0; j < i; j++)
      if (localLayout.getEllipsisCount(j) > 0)
        return true;
    return false;
  }

  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    removeCallbacks(this.mShowOverflowMenuRunnable);
  }

  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.mEatingHover = false;
    if (!this.mEatingHover)
    {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if ((i == 9) && (!bool))
        this.mEatingHover = true;
    }
    if ((i == 10) || (i == 3))
      this.mEatingHover = false;
    return true;
  }

  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i;
    if (t.f(this) == 1)
      i = 1;
    else
      i = 0;
    int j = getWidth();
    int k = getHeight();
    int m = getPaddingLeft();
    int n = getPaddingRight();
    int i1 = getPaddingTop();
    int i2 = getPaddingBottom();
    int i3 = j - n;
    int[] arrayOfInt = this.mTempMargins;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    int i4 = t.l(this);
    int i5;
    if (i4 >= 0)
      i5 = Math.min(i4, paramInt4 - paramInt2);
    else
      i5 = 0;
    int i6;
    if (shouldLayout(this.mNavButtonView))
    {
      if (i != 0)
      {
        i7 = layoutChildRight(this.mNavButtonView, i3, arrayOfInt, i5);
        i6 = m;
        break label170;
      }
      i6 = layoutChildLeft(this.mNavButtonView, m, arrayOfInt, i5);
    }
    else
    {
      i6 = m;
    }
    int i7 = i3;
    label170: if (shouldLayout(this.mCollapseButtonView))
      if (i != 0)
        i7 = layoutChildRight(this.mCollapseButtonView, i7, arrayOfInt, i5);
      else
        i6 = layoutChildLeft(this.mCollapseButtonView, i6, arrayOfInt, i5);
    if (shouldLayout(this.mMenuView))
      if (i != 0)
        i6 = layoutChildLeft(this.mMenuView, i6, arrayOfInt, i5);
      else
        i7 = layoutChildRight(this.mMenuView, i7, arrayOfInt, i5);
    int i8 = getCurrentContentInsetLeft();
    int i9 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, i8 - i6);
    arrayOfInt[1] = Math.max(0, i9 - (i3 - i7));
    int i10 = Math.max(i6, i8);
    int i11 = Math.min(i7, i3 - i9);
    if (shouldLayout(this.mExpandedActionView))
      if (i != 0)
        i11 = layoutChildRight(this.mExpandedActionView, i11, arrayOfInt, i5);
      else
        i10 = layoutChildLeft(this.mExpandedActionView, i10, arrayOfInt, i5);
    if (shouldLayout(this.mLogoView))
      if (i != 0)
        i11 = layoutChildRight(this.mLogoView, i11, arrayOfInt, i5);
      else
        i10 = layoutChildLeft(this.mLogoView, i10, arrayOfInt, i5);
    boolean bool1 = shouldLayout(this.mTitleTextView);
    boolean bool2 = shouldLayout(this.mSubtitleTextView);
    int i12;
    int i13;
    if (bool1)
    {
      LayoutParams localLayoutParams8 = (LayoutParams)this.mTitleTextView.getLayoutParams();
      int i55 = localLayoutParams8.topMargin;
      i12 = n;
      i13 = 0 + (i55 + this.mTitleTextView.getMeasuredHeight() + localLayoutParams8.bottomMargin);
    }
    else
    {
      i12 = n;
      i13 = 0;
    }
    int i14;
    if (bool2)
    {
      LayoutParams localLayoutParams7 = (LayoutParams)this.mSubtitleTextView.getLayoutParams();
      int i54 = localLayoutParams7.topMargin;
      i14 = j;
      i13 += i54 + this.mSubtitleTextView.getMeasuredHeight() + localLayoutParams7.bottomMargin;
    }
    else
    {
      i14 = j;
    }
    int i15;
    int i18;
    if ((!bool1) && (!bool2))
    {
      i15 = m;
      i18 = i5;
    }
    int i16;
    int i19;
    int i20;
    while (true)
    {
      i22 = 0;
      break label1383;
      TextView localTextView1;
      if (bool1)
        localTextView1 = this.mTitleTextView;
      else
        localTextView1 = this.mSubtitleTextView;
      TextView localTextView2;
      if (bool2)
        localTextView2 = this.mSubtitleTextView;
      else
        localTextView2 = this.mTitleTextView;
      LayoutParams localLayoutParams1 = (LayoutParams)localTextView1.getLayoutParams();
      LayoutParams localLayoutParams2 = (LayoutParams)localTextView2.getLayoutParams();
      if (((bool1) && (this.mTitleTextView.getMeasuredWidth() > 0)) || ((bool2) && (this.mSubtitleTextView.getMeasuredWidth() > 0)))
      {
        i15 = m;
        i16 = 1;
      }
      else
      {
        i15 = m;
        i16 = 0;
      }
      int i17 = 0x70 & this.mGravity;
      i18 = i5;
      if (i17 != 48)
      {
        if (i17 != 80)
        {
          int i51 = (k - i1 - i2 - i13) / 2;
          int i52 = localLayoutParams1.topMargin;
          i19 = i10;
          if (i51 < i52 + this.mTitleMarginTop)
          {
            i51 = localLayoutParams1.topMargin + this.mTitleMarginTop;
          }
          else
          {
            int i53 = k - i2 - i13 - i51 - i1;
            if (i53 < localLayoutParams1.bottomMargin + this.mTitleMarginBottom)
              i51 = Math.max(0, i51 - (localLayoutParams2.bottomMargin + this.mTitleMarginBottom - i53));
          }
          i20 = i1 + i51;
        }
        else
        {
          i19 = i10;
          i20 = k - i2 - localLayoutParams2.bottomMargin - this.mTitleMarginBottom - i13;
        }
      }
      else
      {
        i19 = i10;
        i20 = getPaddingTop() + localLayoutParams1.topMargin + this.mTitleMarginTop;
      }
      if (i == 0)
        break;
      int i42;
      int i41;
      if (i16 != 0)
      {
        i42 = this.mTitleMarginStart;
        i41 = 1;
      }
      else
      {
        i41 = 1;
        i42 = 0;
      }
      int i43 = i42 - arrayOfInt[i41];
      i11 -= Math.max(0, i43);
      arrayOfInt[i41] = Math.max(0, -i43);
      int i44;
      if (bool1)
      {
        LayoutParams localLayoutParams6 = (LayoutParams)this.mTitleTextView.getLayoutParams();
        int i49 = i11 - this.mTitleTextView.getMeasuredWidth();
        int i50 = i20 + this.mTitleTextView.getMeasuredHeight();
        this.mTitleTextView.layout(i49, i20, i11, i50);
        i44 = i49 - this.mTitleMarginEnd;
        i20 = i50 + localLayoutParams6.bottomMargin;
      }
      else
      {
        i44 = i11;
      }
      LayoutParams localLayoutParams5;
      int i45;
      if (bool2)
      {
        localLayoutParams5 = (LayoutParams)this.mSubtitleTextView.getLayoutParams();
        int i46 = i20 + localLayoutParams5.topMargin;
        int i47 = i11 - this.mSubtitleTextView.getMeasuredWidth();
        int i48 = i46 + this.mSubtitleTextView.getMeasuredHeight();
        this.mSubtitleTextView.layout(i47, i46, i11, i48);
        i45 = i11 - this.mTitleMarginEnd;
      }
      else
      {
        i45 = i11;
      }
      if (i16 != 0)
        i11 = Math.min(i44, i45);
      i10 = i19;
    }
    int i21;
    if (i16 != 0)
      i21 = this.mTitleMarginStart;
    else
      i21 = 0;
    int i22 = 0;
    int i23 = i21 - arrayOfInt[0];
    i10 = i19 + Math.max(0, i23);
    arrayOfInt[0] = Math.max(0, -i23);
    int i24;
    if (bool1)
    {
      LayoutParams localLayoutParams4 = (LayoutParams)this.mTitleTextView.getLayoutParams();
      int i39 = i10 + this.mTitleTextView.getMeasuredWidth();
      int i40 = i20 + this.mTitleTextView.getMeasuredHeight();
      this.mTitleTextView.layout(i10, i20, i39, i40);
      i24 = i39 + this.mTitleMarginEnd;
      i20 = i40 + localLayoutParams4.bottomMargin;
    }
    else
    {
      i24 = i10;
    }
    LayoutParams localLayoutParams3;
    int i25;
    if (bool2)
    {
      localLayoutParams3 = (LayoutParams)this.mSubtitleTextView.getLayoutParams();
      int i36 = i20 + localLayoutParams3.topMargin;
      int i37 = i10 + this.mSubtitleTextView.getMeasuredWidth();
      int i38 = i36 + this.mSubtitleTextView.getMeasuredHeight();
      this.mSubtitleTextView.layout(i10, i36, i37, i38);
      i25 = i37 + this.mTitleMarginEnd;
    }
    else
    {
      i25 = i10;
    }
    if (i16 != 0)
      i10 = Math.max(i24, i25);
    label1383: addCustomViewsWithGravity(this.mTempViews, 3);
    int i26 = this.mTempViews.size();
    int i27 = i10;
    for (int i28 = 0; i28 < i26; i28++)
      i27 = layoutChildLeft((View)this.mTempViews.get(i28), i27, arrayOfInt, i18);
    int i29 = i18;
    addCustomViewsWithGravity(this.mTempViews, 5);
    int i30 = this.mTempViews.size();
    for (int i31 = 0; i31 < i30; i31++)
      i11 = layoutChildRight((View)this.mTempViews.get(i31), i11, arrayOfInt, i29);
    addCustomViewsWithGravity(this.mTempViews, 1);
    int i32 = getViewListMeasuredWidth(this.mTempViews, arrayOfInt);
    int i33 = i15 + (i14 - i15 - i12) / 2 - i32 / 2;
    int i34 = i32 + i33;
    if (i33 >= i27)
      if (i34 > i11)
        i27 = i33 - (i34 - i11);
      else
        i27 = i33;
    int i35 = this.mTempViews.size();
    while (i22 < i35)
    {
      i27 = layoutChildLeft((View)this.mTempViews.get(i22), i27, arrayOfInt, i29);
      i22++;
    }
    this.mTempViews.clear();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = this.mTempMargins;
    int i;
    int j;
    if (ak.a(this))
    {
      i = 1;
      j = 0;
    }
    else
    {
      i = 0;
      j = 1;
    }
    int k;
    int m;
    int n;
    if (shouldLayout(this.mNavButtonView))
    {
      measureChildConstrained(this.mNavButtonView, paramInt1, 0, paramInt2, 0, this.mMaxButtonHeight);
      k = this.mNavButtonView.getMeasuredWidth() + getHorizontalMargins(this.mNavButtonView);
      int i29 = Math.max(0, this.mNavButtonView.getMeasuredHeight() + getVerticalMargins(this.mNavButtonView));
      int i30 = View.combineMeasuredStates(0, this.mNavButtonView.getMeasuredState());
      m = i29;
      n = i30;
    }
    else
    {
      k = 0;
      m = 0;
      n = 0;
    }
    if (shouldLayout(this.mCollapseButtonView))
    {
      measureChildConstrained(this.mCollapseButtonView, paramInt1, 0, paramInt2, 0, this.mMaxButtonHeight);
      k = this.mCollapseButtonView.getMeasuredWidth() + getHorizontalMargins(this.mCollapseButtonView);
      m = Math.max(m, this.mCollapseButtonView.getMeasuredHeight() + getVerticalMargins(this.mCollapseButtonView));
      n = View.combineMeasuredStates(n, this.mCollapseButtonView.getMeasuredState());
    }
    int i1 = getCurrentContentInsetStart();
    int i2 = 0 + Math.max(i1, k);
    arrayOfInt[i] = Math.max(0, i1 - k);
    int i3;
    if (shouldLayout(this.mMenuView))
    {
      measureChildConstrained(this.mMenuView, paramInt1, i2, paramInt2, 0, this.mMaxButtonHeight);
      i3 = this.mMenuView.getMeasuredWidth() + getHorizontalMargins(this.mMenuView);
      m = Math.max(m, this.mMenuView.getMeasuredHeight() + getVerticalMargins(this.mMenuView));
      n = View.combineMeasuredStates(n, this.mMenuView.getMeasuredState());
    }
    else
    {
      i3 = 0;
    }
    int i4 = getCurrentContentInsetEnd();
    int i5 = i2 + Math.max(i4, i3);
    arrayOfInt[j] = Math.max(0, i4 - i3);
    if (shouldLayout(this.mExpandedActionView))
    {
      i5 += measureChildCollapseMargins(this.mExpandedActionView, paramInt1, i5, paramInt2, 0, arrayOfInt);
      m = Math.max(m, this.mExpandedActionView.getMeasuredHeight() + getVerticalMargins(this.mExpandedActionView));
      n = View.combineMeasuredStates(n, this.mExpandedActionView.getMeasuredState());
    }
    if (shouldLayout(this.mLogoView))
    {
      i5 += measureChildCollapseMargins(this.mLogoView, paramInt1, i5, paramInt2, 0, arrayOfInt);
      m = Math.max(m, this.mLogoView.getMeasuredHeight() + getVerticalMargins(this.mLogoView));
      n = View.combineMeasuredStates(n, this.mLogoView.getMeasuredState());
    }
    int i6 = getChildCount();
    int i7 = m;
    int i8 = i5;
    for (int i9 = 0; i9 < i6; i9++)
    {
      View localView = getChildAt(i9);
      if ((((LayoutParams)localView.getLayoutParams()).b == 0) && (shouldLayout(localView)))
      {
        i8 += measureChildCollapseMargins(localView, paramInt1, i8, paramInt2, 0, arrayOfInt);
        int i27 = Math.max(i7, localView.getMeasuredHeight() + getVerticalMargins(localView));
        int i28 = View.combineMeasuredStates(n, localView.getMeasuredState());
        i7 = i27;
        n = i28;
      }
    }
    int i10 = this.mTitleMarginTop + this.mTitleMarginBottom;
    int i11 = this.mTitleMarginStart + this.mTitleMarginEnd;
    int i14;
    int i12;
    int i13;
    if (shouldLayout(this.mTitleTextView))
    {
      measureChildCollapseMargins(this.mTitleTextView, paramInt1, i8 + i11, paramInt2, i10, arrayOfInt);
      int i24 = this.mTitleTextView.getMeasuredWidth() + getHorizontalMargins(this.mTitleTextView);
      int i25 = this.mTitleTextView.getMeasuredHeight() + getVerticalMargins(this.mTitleTextView);
      int i26 = View.combineMeasuredStates(n, this.mTitleTextView.getMeasuredState());
      i14 = i25;
      i12 = i26;
      i13 = i24;
    }
    else
    {
      i12 = n;
      i13 = 0;
      i14 = 0;
    }
    if (shouldLayout(this.mSubtitleTextView))
    {
      TextView localTextView = this.mSubtitleTextView;
      int i21 = i8 + i11;
      int i22 = i14 + i10;
      int i23 = i12;
      i13 = Math.max(i13, measureChildCollapseMargins(localTextView, paramInt1, i21, paramInt2, i22, arrayOfInt));
      i14 += this.mSubtitleTextView.getMeasuredHeight() + getVerticalMargins(this.mSubtitleTextView);
      i12 = View.combineMeasuredStates(i23, this.mSubtitleTextView.getMeasuredState());
    }
    int i15 = i8 + i13;
    int i16 = Math.max(i7, i14);
    int i17 = i15 + (getPaddingLeft() + getPaddingRight());
    int i18 = i16 + (getPaddingTop() + getPaddingBottom());
    int i19 = View.resolveSizeAndState(Math.max(i17, getSuggestedMinimumWidth()), paramInt1, 0xFF000000 & i12);
    int i20 = View.resolveSizeAndState(Math.max(i18, getSuggestedMinimumHeight()), paramInt2, i12 << 16);
    if (shouldCollapse())
      i20 = 0;
    setMeasuredDimension(i19, i20);
  }

  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.d);
    ActionMenuView localActionMenuView = this.mMenuView;
    h localh;
    if (localActionMenuView != null)
      localh = localActionMenuView.a;
    else
      localh = null;
    if ((localSavedState.a != 0) && (this.mExpandedMenuPresenter != null) && (localh != null))
    {
      MenuItem localMenuItem = localh.findItem(localSavedState.a);
      if (localMenuItem != null)
        localMenuItem.expandActionView();
    }
    if (localSavedState.b)
      postShowOverflowMenu();
  }

  public void onRtlPropertiesChanged(int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 17)
      super.onRtlPropertiesChanged(paramInt);
    ensureContentInsets();
    x localx = this.mContentInsets;
    int i = 1;
    if (paramInt != i)
      i = 0;
    if (i != localx.g)
    {
      localx.g = i;
      if (localx.h)
      {
        if (i != 0)
        {
          int m;
          if (localx.d != -2147483648)
            m = localx.d;
          else
            m = localx.e;
          localx.a = m;
          int n;
          if (localx.c != -2147483648)
            n = localx.c;
          else
            n = localx.f;
          localx.b = n;
          return;
        }
        int j;
        if (localx.c != -2147483648)
          j = localx.c;
        else
          j = localx.e;
        localx.a = j;
        int k;
        if (localx.d != -2147483648)
          k = localx.d;
        else
          k = localx.f;
        localx.b = k;
        return;
      }
      localx.a = localx.e;
      localx.b = localx.f;
    }
  }

  public Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    a locala = this.mExpandedMenuPresenter;
    if ((locala != null) && (locala.b != null))
      localSavedState.a = this.mExpandedMenuPresenter.b.getItemId();
    localSavedState.b = isOverflowMenuShowing();
    return localSavedState;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.mEatingTouch = false;
    if (!this.mEatingTouch)
    {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if ((i == 0) && (!bool))
        this.mEatingTouch = true;
    }
    if ((i == 1) || (i == 3))
      this.mEatingTouch = false;
    return true;
  }

  void removeChildrenForExpandedActionView()
  {
    for (int i = -1 + getChildCount(); i >= 0; i--)
    {
      View localView = getChildAt(i);
      if ((((LayoutParams)localView.getLayoutParams()).b != 2) && (localView != this.mMenuView))
      {
        removeViewAt(i);
        this.mHiddenViews.add(localView);
      }
    }
  }

  public void setCollapsible(boolean paramBoolean)
  {
    this.mCollapsible = paramBoolean;
    requestLayout();
  }

  public void setContentInsetEndWithActions(int paramInt)
  {
    if (paramInt < 0)
      paramInt = -2147483648;
    if (paramInt != this.mContentInsetEndWithActions)
    {
      this.mContentInsetEndWithActions = paramInt;
      if (getNavigationIcon() != null)
        requestLayout();
    }
  }

  public void setContentInsetStartWithNavigation(int paramInt)
  {
    if (paramInt < 0)
      paramInt = -2147483648;
    if (paramInt != this.mContentInsetStartWithNavigation)
    {
      this.mContentInsetStartWithNavigation = paramInt;
      if (getNavigationIcon() != null)
        requestLayout();
    }
  }

  public void setContentInsetsAbsolute(int paramInt1, int paramInt2)
  {
    ensureContentInsets();
    this.mContentInsets.b(paramInt1, paramInt2);
  }

  public void setContentInsetsRelative(int paramInt1, int paramInt2)
  {
    ensureContentInsets();
    this.mContentInsets.a(paramInt1, paramInt2);
  }

  public void setLogo(int paramInt)
  {
    setLogo(a.b(getContext(), paramInt));
  }

  public void setLogo(Drawable paramDrawable)
  {
    if (paramDrawable != null)
    {
      ensureLogoView();
      if (!isChildOrHidden(this.mLogoView))
        addSystemView(this.mLogoView, true);
    }
    else
    {
      ImageView localImageView1 = this.mLogoView;
      if ((localImageView1 != null) && (isChildOrHidden(localImageView1)))
      {
        removeView(this.mLogoView);
        this.mHiddenViews.remove(this.mLogoView);
      }
    }
    ImageView localImageView2 = this.mLogoView;
    if (localImageView2 != null)
      localImageView2.setImageDrawable(paramDrawable);
  }

  public void setLogoDescription(int paramInt)
  {
    setLogoDescription(getContext().getText(paramInt));
  }

  public void setLogoDescription(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
      ensureLogoView();
    ImageView localImageView = this.mLogoView;
    if (localImageView != null)
      localImageView.setContentDescription(paramCharSequence);
  }

  public void setMenu(h paramh, ActionMenuPresenter paramActionMenuPresenter)
  {
    if ((paramh == null) && (this.mMenuView == null))
      return;
    ensureMenuView();
    h localh = this.mMenuView.a;
    if (localh == paramh)
      return;
    if (localh != null)
    {
      localh.b(this.mOuterActionMenuPresenter);
      localh.b(this.mExpandedMenuPresenter);
    }
    if (this.mExpandedMenuPresenter == null)
      this.mExpandedMenuPresenter = new a();
    paramActionMenuPresenter.m = true;
    if (paramh != null)
    {
      paramh.a(paramActionMenuPresenter, this.mPopupContext);
      paramh.a(this.mExpandedMenuPresenter, this.mPopupContext);
    }
    else
    {
      paramActionMenuPresenter.a(this.mPopupContext, null);
      this.mExpandedMenuPresenter.a(this.mPopupContext, null);
      paramActionMenuPresenter.a(true);
      this.mExpandedMenuPresenter.a(true);
    }
    this.mMenuView.setPopupTheme(this.mPopupTheme);
    this.mMenuView.setPresenter(paramActionMenuPresenter);
    this.mOuterActionMenuPresenter = paramActionMenuPresenter;
  }

  public void setMenuCallbacks(o.a parama, h.a parama1)
  {
    this.mActionMenuPresenterCallback = parama;
    this.mMenuBuilderCallback = parama1;
    ActionMenuView localActionMenuView = this.mMenuView;
    if (localActionMenuView != null)
      localActionMenuView.a(parama, parama1);
  }

  public void setNavigationContentDescription(int paramInt)
  {
    CharSequence localCharSequence;
    if (paramInt != 0)
      localCharSequence = getContext().getText(paramInt);
    else
      localCharSequence = null;
    setNavigationContentDescription(localCharSequence);
  }

  public void setNavigationContentDescription(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
      ensureNavButtonView();
    ImageButton localImageButton = this.mNavButtonView;
    if (localImageButton != null)
      localImageButton.setContentDescription(paramCharSequence);
  }

  public void setNavigationIcon(int paramInt)
  {
    setNavigationIcon(a.b(getContext(), paramInt));
  }

  public void setNavigationIcon(Drawable paramDrawable)
  {
    if (paramDrawable != null)
    {
      ensureNavButtonView();
      if (!isChildOrHidden(this.mNavButtonView))
        addSystemView(this.mNavButtonView, true);
    }
    else
    {
      ImageButton localImageButton1 = this.mNavButtonView;
      if ((localImageButton1 != null) && (isChildOrHidden(localImageButton1)))
      {
        removeView(this.mNavButtonView);
        this.mHiddenViews.remove(this.mNavButtonView);
      }
    }
    ImageButton localImageButton2 = this.mNavButtonView;
    if (localImageButton2 != null)
      localImageButton2.setImageDrawable(paramDrawable);
  }

  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener)
  {
    ensureNavButtonView();
    this.mNavButtonView.setOnClickListener(paramOnClickListener);
  }

  public void setOnMenuItemClickListener(b paramb)
  {
    this.mOnMenuItemClickListener = paramb;
  }

  public void setOverflowIcon(Drawable paramDrawable)
  {
    ensureMenu();
    this.mMenuView.setOverflowIcon(paramDrawable);
  }

  public void setPopupTheme(int paramInt)
  {
    if (this.mPopupTheme != paramInt)
    {
      this.mPopupTheme = paramInt;
      if (paramInt == 0)
      {
        this.mPopupContext = getContext();
        return;
      }
      this.mPopupContext = new ContextThemeWrapper(getContext(), paramInt);
    }
  }

  public void setSubtitle(int paramInt)
  {
    setSubtitle(getContext().getText(paramInt));
  }

  public void setSubtitle(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
    {
      if (this.mSubtitleTextView == null)
      {
        Context localContext = getContext();
        this.mSubtitleTextView = new AppCompatTextView(localContext);
        this.mSubtitleTextView.setSingleLine();
        this.mSubtitleTextView.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.mSubtitleTextAppearance;
        if (i != 0)
          this.mSubtitleTextView.setTextAppearance(localContext, i);
        int j = this.mSubtitleTextColor;
        if (j != 0)
          this.mSubtitleTextView.setTextColor(j);
      }
      if (!isChildOrHidden(this.mSubtitleTextView))
        addSystemView(this.mSubtitleTextView, true);
    }
    else
    {
      TextView localTextView1 = this.mSubtitleTextView;
      if ((localTextView1 != null) && (isChildOrHidden(localTextView1)))
      {
        removeView(this.mSubtitleTextView);
        this.mHiddenViews.remove(this.mSubtitleTextView);
      }
    }
    TextView localTextView2 = this.mSubtitleTextView;
    if (localTextView2 != null)
      localTextView2.setText(paramCharSequence);
    this.mSubtitleText = paramCharSequence;
  }

  public void setSubtitleTextAppearance(Context paramContext, int paramInt)
  {
    this.mSubtitleTextAppearance = paramInt;
    TextView localTextView = this.mSubtitleTextView;
    if (localTextView != null)
      localTextView.setTextAppearance(paramContext, paramInt);
  }

  public void setSubtitleTextColor(int paramInt)
  {
    this.mSubtitleTextColor = paramInt;
    TextView localTextView = this.mSubtitleTextView;
    if (localTextView != null)
      localTextView.setTextColor(paramInt);
  }

  public void setTitle(int paramInt)
  {
    setTitle(getContext().getText(paramInt));
  }

  public void setTitle(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
    {
      if (this.mTitleTextView == null)
      {
        Context localContext = getContext();
        this.mTitleTextView = new AppCompatTextView(localContext);
        this.mTitleTextView.setSingleLine();
        this.mTitleTextView.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.mTitleTextAppearance;
        if (i != 0)
          this.mTitleTextView.setTextAppearance(localContext, i);
        int j = this.mTitleTextColor;
        if (j != 0)
          this.mTitleTextView.setTextColor(j);
      }
      if (!isChildOrHidden(this.mTitleTextView))
        addSystemView(this.mTitleTextView, true);
    }
    else
    {
      TextView localTextView1 = this.mTitleTextView;
      if ((localTextView1 != null) && (isChildOrHidden(localTextView1)))
      {
        removeView(this.mTitleTextView);
        this.mHiddenViews.remove(this.mTitleTextView);
      }
    }
    TextView localTextView2 = this.mTitleTextView;
    if (localTextView2 != null)
      localTextView2.setText(paramCharSequence);
    this.mTitleText = paramCharSequence;
  }

  public void setTitleMargin(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.mTitleMarginStart = paramInt1;
    this.mTitleMarginTop = paramInt2;
    this.mTitleMarginEnd = paramInt3;
    this.mTitleMarginBottom = paramInt4;
    requestLayout();
  }

  public void setTitleMarginBottom(int paramInt)
  {
    this.mTitleMarginBottom = paramInt;
    requestLayout();
  }

  public void setTitleMarginEnd(int paramInt)
  {
    this.mTitleMarginEnd = paramInt;
    requestLayout();
  }

  public void setTitleMarginStart(int paramInt)
  {
    this.mTitleMarginStart = paramInt;
    requestLayout();
  }

  public void setTitleMarginTop(int paramInt)
  {
    this.mTitleMarginTop = paramInt;
    requestLayout();
  }

  public void setTitleTextAppearance(Context paramContext, int paramInt)
  {
    this.mTitleTextAppearance = paramInt;
    TextView localTextView = this.mTitleTextView;
    if (localTextView != null)
      localTextView.setTextAppearance(paramContext, paramInt);
  }

  public void setTitleTextColor(int paramInt)
  {
    this.mTitleTextColor = paramInt;
    TextView localTextView = this.mTitleTextView;
    if (localTextView != null)
      localTextView.setTextColor(paramInt);
  }

  public boolean showOverflowMenu()
  {
    ActionMenuView localActionMenuView = this.mMenuView;
    if (localActionMenuView != null)
    {
      int i;
      if ((localActionMenuView.c != null) && (localActionMenuView.c.c()))
        i = 1;
      else
        i = 0;
      if (i != 0)
        return true;
    }
    return false;
  }

  public static class LayoutParams extends ActionBar.LayoutParams
  {
    int b;

    static
    {
      CoverageLogger.Log(12122112);
    }

    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
      this.a = 8388627;
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
      this.leftMargin = paramMarginLayoutParams.leftMargin;
      this.topMargin = paramMarginLayoutParams.topMargin;
      this.rightMargin = paramMarginLayoutParams.rightMargin;
      this.bottomMargin = paramMarginLayoutParams.bottomMargin;
    }

    public LayoutParams(ActionBar.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(LayoutParams paramLayoutParams)
    {
      super();
      this.b = paramLayoutParams.b;
    }
  }

  public static class SavedState extends AbsSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.ClassLoaderCreator()
    {
      static
      {
        CoverageLogger.Log(12134400);
      }
    };
    int a;
    boolean b;

    static
    {
      CoverageLogger.Log(12146688);
    }

    public SavedState(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      super(paramClassLoader);
      this.a = paramParcel.readInt();
      boolean bool;
      if (paramParcel.readInt() != 0)
        bool = true;
      else
        bool = false;
      this.b = bool;
    }

    public SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(this.a);
      paramParcel.writeInt(this.b);
    }
  }

  final class a
    implements androidx.appcompat.view.menu.o
  {
    h a;
    j b;

    static
    {
      CoverageLogger.Log(12118016);
    }

    a()
    {
    }

    public final void a(Context paramContext, h paramh)
    {
      h localh = this.a;
      if (localh != null)
      {
        j localj = this.b;
        if (localj != null)
          localh.d(localj);
      }
      this.a = paramh;
    }

    public final void a(Parcelable paramParcelable)
    {
    }

    public final void a(h paramh, boolean paramBoolean)
    {
    }

    public final void a(o.a parama)
    {
    }

    public final void a(boolean paramBoolean)
    {
      if (this.b != null)
      {
        h localh = this.a;
        int i = 0;
        if (localh != null)
        {
          int j = localh.size();
          for (int k = 0; ; k++)
          {
            i = 0;
            if (k >= j)
              break;
            if (this.a.getItem(k) == this.b)
            {
              i = 1;
              break;
            }
          }
        }
        if (i == 0)
          b(this.a, this.b);
      }
    }

    public final boolean a()
    {
      return false;
    }

    public final boolean a(h paramh, j paramj)
    {
      Toolbar.this.ensureCollapseButtonView();
      ViewParent localViewParent1 = Toolbar.this.mCollapseButtonView.getParent();
      Toolbar localToolbar1 = Toolbar.this;
      if (localViewParent1 != localToolbar1)
      {
        if ((localViewParent1 instanceof ViewGroup))
          ((ViewGroup)localViewParent1).removeView(localToolbar1.mCollapseButtonView);
        Toolbar localToolbar4 = Toolbar.this;
        localToolbar4.addView(localToolbar4.mCollapseButtonView);
      }
      Toolbar.this.mExpandedActionView = paramj.getActionView();
      this.b = paramj;
      ViewParent localViewParent2 = Toolbar.this.mExpandedActionView.getParent();
      Toolbar localToolbar2 = Toolbar.this;
      if (localViewParent2 != localToolbar2)
      {
        if ((localViewParent2 instanceof ViewGroup))
          ((ViewGroup)localViewParent2).removeView(localToolbar2.mExpandedActionView);
        Toolbar.LayoutParams localLayoutParams = Toolbar.this.generateDefaultLayoutParams();
        localLayoutParams.a = (0x800003 | 0x70 & Toolbar.this.mButtonGravity);
        localLayoutParams.b = 2;
        Toolbar.this.mExpandedActionView.setLayoutParams(localLayoutParams);
        Toolbar localToolbar3 = Toolbar.this;
        localToolbar3.addView(localToolbar3.mExpandedActionView);
      }
      Toolbar.this.removeChildrenForExpandedActionView();
      Toolbar.this.requestLayout();
      paramj.e(true);
      if ((Toolbar.this.mExpandedActionView instanceof c))
        ((c)Toolbar.this.mExpandedActionView).a();
      return true;
    }

    public final boolean a(u paramu)
    {
      return false;
    }

    public final int b()
    {
      return 0;
    }

    public final boolean b(h paramh, j paramj)
    {
      if ((Toolbar.this.mExpandedActionView instanceof c))
        ((c)Toolbar.this.mExpandedActionView).b();
      Toolbar localToolbar1 = Toolbar.this;
      localToolbar1.removeView(localToolbar1.mExpandedActionView);
      Toolbar localToolbar2 = Toolbar.this;
      localToolbar2.removeView(localToolbar2.mCollapseButtonView);
      Toolbar localToolbar3 = Toolbar.this;
      localToolbar3.mExpandedActionView = null;
      localToolbar3.addChildrenForExpandedActionView();
      this.b = null;
      Toolbar.this.requestLayout();
      paramj.e(false);
      return true;
    }

    public final Parcelable f()
    {
      return null;
    }
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(12132352);
    }

    public abstract boolean onMenuItemClick(MenuItem paramMenuItem);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.Toolbar
 * JD-Core Version:    0.6.2
 */