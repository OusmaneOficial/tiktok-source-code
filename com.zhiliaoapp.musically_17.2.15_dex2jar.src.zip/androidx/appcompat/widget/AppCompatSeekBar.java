package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class AppCompatSeekBar extends SeekBar
{
  private final k a = new k(this);

  static
  {
    CoverageLogger.Log(12253184);
  }

  public AppCompatSeekBar(Context paramContext)
  {
    this(paramContext, null);
  }

  public AppCompatSeekBar(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 2130969699);
  }

  public AppCompatSeekBar(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.a.a(paramAttributeSet, paramInt);
  }

  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    k localk = this.a;
    Drawable localDrawable = localk.c;
    if ((localDrawable != null) && (localDrawable.isStateful()) && (localDrawable.setState(localk.b.getDrawableState())))
      localk.b.invalidateDrawable(localDrawable);
  }

  public void jumpDrawablesToCurrentState()
  {
    super.jumpDrawablesToCurrentState();
    k localk = this.a;
    if (localk.c != null)
      localk.c.jumpToCurrentState();
  }

  public void onDraw(Canvas paramCanvas)
  {
    try
    {
      super.onDraw(paramCanvas);
      k localk = this.a;
      if (localk.c != null)
      {
        int i = localk.b.getMax();
        int j = 1;
        if (i > j)
        {
          int k = localk.c.getIntrinsicWidth();
          int m = localk.c.getIntrinsicHeight();
          if (k < 0)
            break label207;
          n = k / 2;
          if (m >= 0)
            j = m / 2;
          localk.c.setBounds(-n, -j, n, j);
          float f = (localk.b.getWidth() - localk.b.getPaddingLeft() - localk.b.getPaddingRight()) / i;
          int i1 = paramCanvas.save();
          paramCanvas.translate(localk.b.getPaddingLeft(), localk.b.getHeight() / 2);
          for (int i2 = 0; i2 <= i; i2++)
          {
            localk.c.draw(paramCanvas);
            paramCanvas.translate(f, 0.0F);
          }
          paramCanvas.restoreToCount(i1);
        }
      }
      return;
    }
    finally
    {
      while (true)
      {
        while (true)
          throw localObject;
        label207: int n = 1;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.AppCompatSeekBar
 * JD-Core Version:    0.6.2
 */