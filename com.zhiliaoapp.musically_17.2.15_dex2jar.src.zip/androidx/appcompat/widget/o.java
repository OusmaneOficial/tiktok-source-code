package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window.Callback;
import androidx.appcompat.view.menu.h.a;
import androidx.appcompat.view.menu.o.a;
import androidx.core.h.x;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface o
{
  static
  {
    CoverageLogger.Log(12298240);
  }

  public abstract ViewGroup a();

  public abstract x a(int paramInt, long paramLong);

  public abstract void a(int paramInt);

  public abstract void a(Drawable paramDrawable);

  public abstract void a(Menu paramMenu, o.a parama);

  public abstract void a(Window.Callback paramCallback);

  public abstract void a(o.a parama, h.a parama1);

  public abstract void a(y paramy);

  public abstract void a(CharSequence paramCharSequence);

  public abstract void a(boolean paramBoolean);

  public abstract Context b();

  public abstract void b(int paramInt);

  public abstract void c(int paramInt);

  public abstract boolean c();

  public abstract void d();

  public abstract void d(int paramInt);

  public abstract CharSequence e();

  public abstract void e(int paramInt);

  public abstract boolean f();

  public abstract boolean g();

  public abstract boolean h();

  public abstract boolean i();

  public abstract boolean j();

  public abstract void k();

  public abstract void l();

  public abstract int m();

  public abstract int n();

  public abstract Menu o();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.o
 * JD-Core Version:    0.6.2
 */