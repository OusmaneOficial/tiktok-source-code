package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class d
{
  private final View a;
  private final f b;
  private int c = -1;
  private ac d;
  private ac e;
  private ac f;

  static
  {
    CoverageLogger.Log(12261376);
  }

  d(View paramView)
  {
    this.a = paramView;
    this.b = f.a();
  }

  private void b(ColorStateList paramColorStateList)
  {
    if (paramColorStateList != null)
    {
      if (this.d == null)
        this.d = new ac();
      ac localac = this.d;
      localac.a = paramColorStateList;
      localac.d = true;
    }
    else
    {
      this.d = null;
    }
    c();
  }

  private boolean b(Drawable paramDrawable)
  {
    if (this.f == null)
      this.f = new ac();
    ac localac = this.f;
    localac.a();
    ColorStateList localColorStateList = t.v(this.a);
    if (localColorStateList != null)
    {
      localac.d = true;
      localac.a = localColorStateList;
    }
    PorterDuff.Mode localMode = t.w(this.a);
    if (localMode != null)
    {
      localac.c = true;
      localac.b = localMode;
    }
    if ((!localac.d) && (!localac.c))
      return false;
    f.a(paramDrawable, localac, this.a.getDrawableState());
    return true;
  }

  private boolean d()
  {
    int i = Build.VERSION.SDK_INT;
    if (i > 21)
      return this.d != null;
    return i == 21;
  }

  final ColorStateList a()
  {
    ac localac = this.e;
    if (localac != null)
      return localac.a;
    return null;
  }

  final void a(int paramInt)
  {
    this.c = paramInt;
    f localf = this.b;
    ColorStateList localColorStateList;
    if (localf != null)
      localColorStateList = localf.b(this.a.getContext(), paramInt);
    else
      localColorStateList = null;
    b(localColorStateList);
    c();
  }

  final void a(ColorStateList paramColorStateList)
  {
    if (this.e == null)
      this.e = new ac();
    ac localac = this.e;
    localac.a = paramColorStateList;
    localac.d = true;
    c();
  }

  final void a(PorterDuff.Mode paramMode)
  {
    if (this.e == null)
      this.e = new ac();
    ac localac = this.e;
    localac.b = paramMode;
    localac.c = true;
    c();
  }

  final void a(Drawable paramDrawable)
  {
    this.c = -1;
    b(null);
    c();
  }

  final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    ae localae = ae.a(this.a.getContext(), paramAttributeSet, new int[] { 16842964, 2130968696, 2130968697 }, paramInt, 0);
    try
    {
      if (localae.f(0))
      {
        this.c = localae.g(0, -1);
        ColorStateList localColorStateList = this.b.b(this.a.getContext(), this.c);
        if (localColorStateList != null)
          b(localColorStateList);
      }
      if (localae.f(1))
        t.a(this.a, localae.e(1));
      if (localae.f(2))
        t.a(this.a, p.a(localae.a(2, -1), null));
      return;
    }
    finally
    {
      localae.a();
    }
  }

  final PorterDuff.Mode b()
  {
    ac localac = this.e;
    if (localac != null)
      return localac.b;
    return null;
  }

  final void c()
  {
    Drawable localDrawable = this.a.getBackground();
    if (localDrawable != null)
    {
      if ((d()) && (b(localDrawable)))
        return;
      ac localac1 = this.e;
      if (localac1 != null)
      {
        f.a(localDrawable, localac1, this.a.getDrawableState());
        return;
      }
      ac localac2 = this.d;
      if (localac2 != null)
        f.a(localDrawable, localac2, this.a.getDrawableState());
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.d
 * JD-Core Version:    0.6.2
 */