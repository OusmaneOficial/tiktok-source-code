package androidx.appcompat.widget;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class s
  implements View.OnAttachStateChangeListener, View.OnTouchListener
{
  private final float a;
  private final int b;
  final View c;
  private final int d;
  private Runnable e;
  private Runnable f;
  private boolean g;
  private int h;
  private final int[] i = new int[2];

  static
  {
    CoverageLogger.Log(12314624);
  }

  public s(View paramView)
  {
    this.c = paramView;
    paramView.setLongClickable(true);
    paramView.addOnAttachStateChangeListener(this);
    this.a = ViewConfiguration.get(paramView.getContext()).getScaledTouchSlop();
    this.b = ViewConfiguration.getTapTimeout();
    this.d = ((this.b + ViewConfiguration.getLongPressTimeout()) / 2);
  }

  private void e()
  {
    Runnable localRunnable1 = this.f;
    if (localRunnable1 != null)
      this.c.removeCallbacks(localRunnable1);
    Runnable localRunnable2 = this.e;
    if (localRunnable2 != null)
      this.c.removeCallbacks(localRunnable2);
  }

  public abstract androidx.appcompat.view.menu.s a();

  protected boolean b()
  {
    androidx.appcompat.view.menu.s locals = a();
    if ((locals != null) && (!locals.e()))
      locals.c();
    return true;
  }

  protected boolean c()
  {
    androidx.appcompat.view.menu.s locals = a();
    if ((locals != null) && (locals.e()))
      locals.d();
    return true;
  }

  final void d()
  {
    e();
    View localView = this.c;
    if (localView.isEnabled())
    {
      if (localView.isLongClickable())
        return;
      if (!b())
        return;
      localView.getParent().requestDisallowInterceptTouchEvent(true);
      long l = SystemClock.uptimeMillis();
      MotionEvent localMotionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      localView.onTouchEvent(localMotionEvent);
      localMotionEvent.recycle();
      this.g = true;
    }
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    boolean bool1 = this.g;
    label195: boolean bool2;
    if (bool1)
    {
      View localView2 = this.c;
      androidx.appcompat.view.menu.s locals = a();
      if ((locals != null) && (locals.e()))
      {
        q localq = (q)locals.g();
        if ((localq != null) && (localq.isShown()))
        {
          MotionEvent localMotionEvent2 = MotionEvent.obtainNoHistory(paramMotionEvent);
          int[] arrayOfInt1 = this.i;
          localView2.getLocationOnScreen(arrayOfInt1);
          localMotionEvent2.offsetLocation(arrayOfInt1[0], arrayOfInt1[1]);
          int[] arrayOfInt2 = this.i;
          localq.getLocationOnScreen(arrayOfInt2);
          localMotionEvent2.offsetLocation(-arrayOfInt2[0], -arrayOfInt2[1]);
          boolean bool3 = localq.a(localMotionEvent2, this.h);
          localMotionEvent2.recycle();
          int i2 = paramMotionEvent.getActionMasked();
          int i3;
          if ((i2 != 1) && (i2 != 3))
            i3 = 1;
          else
            i3 = 0;
          if ((bool3) && (i3 != 0))
          {
            i1 = 1;
            break label195;
          }
        }
      }
      int i1 = 0;
      if ((i1 == 0) && (c()))
        bool2 = false;
      else
        bool2 = true;
    }
    else
    {
      View localView1 = this.c;
      if (localView1.isEnabled())
      {
        int k = paramMotionEvent.getActionMasked();
        if (k != 0)
        {
          if (k != 1)
            if (k != 2)
            {
              if (k != 3)
                break label487;
            }
            else
            {
              int m = paramMotionEvent.findPointerIndex(this.h);
              if (m < 0)
                break label487;
              float f1 = paramMotionEvent.getX(m);
              float f2 = paramMotionEvent.getY(m);
              float f3 = this.a;
              float f4 = -f3;
              int n;
              if ((f1 >= f4) && (f2 >= f4) && (f1 < f3 + (localView1.getRight() - localView1.getLeft())) && (f2 < f3 + (localView1.getBottom() - localView1.getTop())))
                n = 1;
              else
                n = 0;
              if (n != 0)
                break label487;
              e();
              localView1.getParent().requestDisallowInterceptTouchEvent(true);
              j = 1;
              break label490;
            }
          e();
        }
        else
        {
          this.h = paramMotionEvent.getPointerId(0);
          if (this.e == null)
            this.e = new a();
          localView1.postDelayed(this.e, this.b);
          if (this.f == null)
            this.f = new b();
          localView1.postDelayed(this.f, this.d);
        }
      }
      label487: int j = 0;
      label490: if ((j != 0) && (b()))
        bool2 = true;
      else
        bool2 = false;
      if (bool2)
      {
        long l = SystemClock.uptimeMillis();
        MotionEvent localMotionEvent1 = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        this.c.onTouchEvent(localMotionEvent1);
        localMotionEvent1.recycle();
      }
    }
    this.g = bool2;
    if (!bool2)
      return bool1;
    return true;
  }

  public void onViewAttachedToWindow(View paramView)
  {
  }

  public void onViewDetachedFromWindow(View paramView)
  {
    this.g = false;
    this.h = -1;
    Runnable localRunnable = this.e;
    if (localRunnable != null)
      this.c.removeCallbacks(localRunnable);
  }

  final class a
    implements Runnable
  {
    static
    {
      CoverageLogger.Log(12152832);
    }

    a()
    {
    }

    public final void run()
    {
      ViewParent localViewParent = s.this.c.getParent();
      if (localViewParent != null)
        localViewParent.requestDisallowInterceptTouchEvent(true);
    }
  }

  final class b
    implements Runnable
  {
    static
    {
      CoverageLogger.Log(12318720);
    }

    b()
    {
    }

    public final void run()
    {
      s.this.d();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.s
 * JD-Core Version:    0.6.2
 */