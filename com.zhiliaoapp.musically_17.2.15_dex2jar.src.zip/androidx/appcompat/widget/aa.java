package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources.Theme;
import android.graphics.Color;
import android.util.TypedValue;
import androidx.core.graphics.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class aa
{
  static final int[] a = { -16842910 };
  static final int[] b = { 16842908 };
  static final int[] c = { 16843518 };
  static final int[] d = { 16842919 };
  static final int[] e = { 16842912 };
  static final int[] f = { 16842913 };
  static final int[] g = { -16842919, -16842908 };
  static final int[] h = new int[0];
  private static final ThreadLocal<TypedValue> i;
  private static final int[] j = new int[1];

  static
  {
    CoverageLogger.Log(12099584);
    i = new ThreadLocal();
  }

  public static int a(Context paramContext, int paramInt)
  {
    int[] arrayOfInt = j;
    arrayOfInt[0] = paramInt;
    ae localae = ae.a(paramContext, null, arrayOfInt);
    try
    {
      int k = localae.b(0, 0);
      return k;
    }
    finally
    {
      localae.a();
    }
  }

  private static int a(Context paramContext, int paramInt, float paramFloat)
  {
    int k = a(paramContext, paramInt);
    return a.b(k, Math.round(paramFloat * Color.alpha(k)));
  }

  private static TypedValue a()
  {
    TypedValue localTypedValue = (TypedValue)i.get();
    if (localTypedValue == null)
    {
      localTypedValue = new TypedValue();
      i.set(localTypedValue);
    }
    return localTypedValue;
  }

  public static ColorStateList b(Context paramContext, int paramInt)
  {
    int[] arrayOfInt = j;
    arrayOfInt[0] = paramInt;
    ae localae = ae.a(paramContext, null, arrayOfInt);
    try
    {
      ColorStateList localColorStateList = localae.e(0);
      return localColorStateList;
    }
    finally
    {
      localae.a();
    }
  }

  public static int c(Context paramContext, int paramInt)
  {
    ColorStateList localColorStateList = b(paramContext, paramInt);
    if ((localColorStateList != null) && (localColorStateList.isStateful()))
      return localColorStateList.getColorForState(a, localColorStateList.getDefaultColor());
    TypedValue localTypedValue = a();
    paramContext.getTheme().resolveAttribute(16842803, localTypedValue, true);
    return a(paramContext, paramInt, localTypedValue.getFloat());
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.aa
 * JD-Core Version:    0.6.2
 */