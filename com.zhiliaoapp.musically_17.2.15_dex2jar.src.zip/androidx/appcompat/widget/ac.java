package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class ac
{
  public ColorStateList a;
  public PorterDuff.Mode b;
  public boolean c;
  public boolean d;

  static
  {
    CoverageLogger.Log(12103680);
  }

  final void a()
  {
    this.a = null;
    this.d = false;
    this.b = null;
    this.c = false;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.ac
 * JD-Core Version:    0.6.2
 */