package androidx.appcompat.widget;

import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.DrawableContainer.DrawableContainerState;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ScaleDrawable;
import android.os.Build.VERSION;
import androidx.appcompat.b.a.c;
import androidx.core.graphics.drawable.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class p
{
  public static final Rect a;
  private static Class<?> b;

  static
  {
    CoverageLogger.Log(12292096);
    a = new Rect();
    if (Build.VERSION.SDK_INT >= 18);
    try
    {
      b = Class.forName("android.graphics.Insets");
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
    }
  }

  public static PorterDuff.Mode a(int paramInt, PorterDuff.Mode paramMode)
  {
    if (paramInt != 3)
    {
      if (paramInt != 5)
      {
        if (paramInt != 9)
        {
          switch (paramInt)
          {
          default:
            return paramMode;
          case 16:
            return PorterDuff.Mode.ADD;
          case 15:
            return PorterDuff.Mode.SCREEN;
          case 14:
          }
          return PorterDuff.Mode.MULTIPLY;
        }
        return PorterDuff.Mode.SRC_ATOP;
      }
      return PorterDuff.Mode.SRC_IN;
    }
    return PorterDuff.Mode.SRC_OVER;
  }

  // ERROR //
  public static Rect a(Drawable paramDrawable)
  {
    // Byte code:
    //   0: getstatic 43	androidx/appcompat/widget/p:b	Ljava/lang/Class;
    //   3: ifnull +258 -> 261
    //   6: aload_0
    //   7: instanceof 70
    //   10: ifeq +13 -> 23
    //   13: aload_0
    //   14: checkcast 70	androidx/core/graphics/drawable/f
    //   17: invokeinterface 73 1 0
    //   22: astore_0
    //   23: aload_0
    //   24: invokevirtual 77	java/lang/Object:getClass	()Ljava/lang/Class;
    //   27: ldc 79
    //   29: iconst_0
    //   30: anewarray 37	java/lang/Class
    //   33: invokevirtual 83	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   36: aload_0
    //   37: iconst_0
    //   38: anewarray 4	java/lang/Object
    //   41: invokevirtual 89	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   44: astore_1
    //   45: aload_1
    //   46: ifnull +215 -> 261
    //   49: new 22	android/graphics/Rect
    //   52: dup
    //   53: invokespecial 25	android/graphics/Rect:<init>	()V
    //   56: astore_2
    //   57: getstatic 43	androidx/appcompat/widget/p:b	Ljava/lang/Class;
    //   60: invokevirtual 93	java/lang/Class:getFields	()[Ljava/lang/reflect/Field;
    //   63: astore_3
    //   64: aload_3
    //   65: arraylength
    //   66: istore 4
    //   68: iconst_0
    //   69: istore 5
    //   71: iload 5
    //   73: iload 4
    //   75: if_icmpge +184 -> 259
    //   78: aload_3
    //   79: iload 5
    //   81: aaload
    //   82: astore 6
    //   84: aload 6
    //   86: invokevirtual 99	java/lang/reflect/Field:getName	()Ljava/lang/String;
    //   89: astore 7
    //   91: iconst_m1
    //   92: istore 8
    //   94: aload 7
    //   96: invokevirtual 105	java/lang/String:hashCode	()I
    //   99: lookupswitch	default:+166->265, -1383228885:+89->188, 115029:+73->172, 3317767:+57->156, 108511772:+41->140
    //   141: iconst_4
    //   142: ldc 107
    //   144: invokevirtual 111	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   147: ifeq +118 -> 265
    //   150: iconst_2
    //   151: istore 8
    //   153: goto +112 -> 265
    //   156: aload 7
    //   158: ldc 113
    //   160: invokevirtual 111	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   163: ifeq +102 -> 265
    //   166: iconst_0
    //   167: istore 8
    //   169: goto +96 -> 265
    //   172: aload 7
    //   174: ldc 115
    //   176: invokevirtual 111	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   179: ifeq +86 -> 265
    //   182: iconst_1
    //   183: istore 8
    //   185: goto +80 -> 265
    //   188: aload 7
    //   190: ldc 117
    //   192: invokevirtual 111	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   195: ifeq +70 -> 265
    //   198: iconst_3
    //   199: istore 8
    //   201: goto +64 -> 265
    //   204: aload_2
    //   205: aload 6
    //   207: aload_1
    //   208: invokevirtual 121	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
    //   211: putfield 123	android/graphics/Rect:bottom	I
    //   214: goto +39 -> 253
    //   217: aload_2
    //   218: aload 6
    //   220: aload_1
    //   221: invokevirtual 121	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
    //   224: putfield 125	android/graphics/Rect:right	I
    //   227: goto +26 -> 253
    //   230: aload_2
    //   231: aload 6
    //   233: aload_1
    //   234: invokevirtual 121	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
    //   237: putfield 127	android/graphics/Rect:top	I
    //   240: goto +13 -> 253
    //   243: aload_2
    //   244: aload 6
    //   246: aload_1
    //   247: invokevirtual 121	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
    //   250: putfield 129	android/graphics/Rect:left	I
    //   253: iinc 5 1
    //   256: goto -185 -> 71
    //   259: aload_2
    //   260: areturn
    //   261: getstatic 27	androidx/appcompat/widget/p:a	Landroid/graphics/Rect;
    //   264: areturn
    //   265: iload 8
    //   267: ifeq -24 -> 243
    //   270: iload 8
    //   272: iconst_1
    //   273: if_icmpeq -43 -> 230
    //   276: iload 8
    //   278: iconst_2
    //   279: if_icmpeq -62 -> 217
    //   282: iload 8
    //   284: iconst_3
    //   285: if_icmpeq -81 -> 204
    //   288: goto -35 -> 253
    //
    // Exception table:
    //   from	to	target	type
    //   6	23	261	java/lang/Exception
    //   23	45	261	java/lang/Exception
    //   49	68	261	java/lang/Exception
    //   78	91	261	java/lang/Exception
    //   94	140	261	java/lang/Exception
    //   140	150	261	java/lang/Exception
    //   156	166	261	java/lang/Exception
    //   172	182	261	java/lang/Exception
    //   188	198	261	java/lang/Exception
    //   204	214	261	java/lang/Exception
    //   217	227	261	java/lang/Exception
    //   230	240	261	java/lang/Exception
    //   243	253	261	java/lang/Exception
  }

  static void b(Drawable paramDrawable)
  {
    if ((Build.VERSION.SDK_INT == 21) && ("android.graphics.drawable.VectorDrawable".equals(paramDrawable.getClass().getName())))
      d(paramDrawable);
  }

  public static boolean c(Drawable paramDrawable)
  {
    while (true)
    {
      if ((Build.VERSION.SDK_INT < 15) && ((paramDrawable instanceof InsetDrawable)))
        return false;
      if ((Build.VERSION.SDK_INT < 15) && ((paramDrawable instanceof GradientDrawable)))
        return false;
      if ((Build.VERSION.SDK_INT < 17) && ((paramDrawable instanceof LayerDrawable)))
        return false;
      if ((paramDrawable instanceof DrawableContainer))
      {
        Drawable.ConstantState localConstantState = paramDrawable.getConstantState();
        if (!(localConstantState instanceof DrawableContainer.DrawableContainerState))
          break;
        Drawable[] arrayOfDrawable = ((DrawableContainer.DrawableContainerState)localConstantState).getChildren();
        int i = arrayOfDrawable.length;
        for (int j = 0; j < i; j++)
          if (!c(arrayOfDrawable[j]))
            return false;
      }
      if ((paramDrawable instanceof f))
      {
        paramDrawable = ((f)paramDrawable).a();
      }
      else if ((paramDrawable instanceof c))
      {
        paramDrawable = ((c)paramDrawable).a;
      }
      else
      {
        if (!(paramDrawable instanceof ScaleDrawable))
          break;
        paramDrawable = ((ScaleDrawable)paramDrawable).getDrawable();
      }
    }
    return true;
  }

  private static void d(Drawable paramDrawable)
  {
    int[] arrayOfInt = paramDrawable.getState();
    if ((arrayOfInt != null) && (arrayOfInt.length != 0))
      paramDrawable.setState(aa.h);
    else
      paramDrawable.setState(aa.e);
    paramDrawable.setState(arrayOfInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.widget.p
 * JD-Core Version:    0.6.2
 */