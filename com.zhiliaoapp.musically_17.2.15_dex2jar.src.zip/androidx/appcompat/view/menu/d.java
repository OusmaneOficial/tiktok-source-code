package androidx.appcompat.view.menu;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class d<T>
{
  public final T b;

  static
  {
    CoverageLogger.Log(12697600);
  }

  d(T paramT)
  {
    if (paramT != null)
    {
      this.b = paramT;
      return;
    }
    throw new IllegalArgumentException("Wrapped Object can not be null.");
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.d
 * JD-Core Version:    0.6.2
 */