package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Build.VERSION;
import android.view.Menu;
import android.view.MenuItem;
import androidx.core.a.a.a;
import androidx.core.a.a.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class q
{
  static
  {
    CoverageLogger.Log(12431360);
  }

  public static Menu a(Context paramContext, a parama)
  {
    return new r(paramContext, parama);
  }

  public static MenuItem a(Context paramContext, b paramb)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new l(paramContext, paramb);
    return new k(paramContext, paramb);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.q
 * JD-Core Version:    0.6.2
 */