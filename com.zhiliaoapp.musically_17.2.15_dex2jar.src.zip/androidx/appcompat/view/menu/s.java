package androidx.appcompat.view.menu;

import android.widget.ListView;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface s
{
  static
  {
    CoverageLogger.Log(12353536);
  }

  public abstract void c();

  public abstract void d();

  public abstract boolean e();

  public abstract ListView g();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.s
 * JD-Core Version:    0.6.2
 */