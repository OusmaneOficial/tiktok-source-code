package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Parcelable;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface o
{
  static
  {
    CoverageLogger.Log(12363776);
  }

  public abstract void a(Context paramContext, h paramh);

  public abstract void a(Parcelable paramParcelable);

  public abstract void a(h paramh, boolean paramBoolean);

  public abstract void a(a parama);

  public abstract void a(boolean paramBoolean);

  public abstract boolean a();

  public abstract boolean a(h paramh, j paramj);

  public abstract boolean a(u paramu);

  public abstract int b();

  public abstract boolean b(h paramh, j paramj);

  public abstract Parcelable f();

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(12412928);
    }

    public abstract void a(h paramh, boolean paramBoolean);

    public abstract boolean a(h paramh);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.o
 * JD-Core Version:    0.6.2
 */