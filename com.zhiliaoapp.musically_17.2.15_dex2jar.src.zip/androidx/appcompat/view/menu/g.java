package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class g extends BaseAdapter
{
  public h a;
  public boolean b;
  private int c = -1;
  private final boolean d;
  private final LayoutInflater e;
  private final int f;

  static
  {
    CoverageLogger.Log(12400640);
  }

  public g(h paramh, LayoutInflater paramLayoutInflater, boolean paramBoolean, int paramInt)
  {
    this.d = paramBoolean;
    this.e = paramLayoutInflater;
    this.a = paramh;
    this.f = paramInt;
    a();
  }

  private void a()
  {
    j localj = this.a.k;
    if (localj != null)
    {
      ArrayList localArrayList = this.a.i();
      int i = localArrayList.size();
      for (int j = 0; j < i; j++)
        if ((j)localArrayList.get(j) == localj)
        {
          this.c = j;
          return;
        }
    }
    this.c = -1;
  }

  public final j a(int paramInt)
  {
    ArrayList localArrayList;
    if (this.d)
      localArrayList = this.a.i();
    else
      localArrayList = this.a.g();
    int i = this.c;
    if ((i >= 0) && (paramInt >= i))
      paramInt++;
    return (j)localArrayList.get(paramInt);
  }

  public final int getCount()
  {
    ArrayList localArrayList;
    if (this.d)
      localArrayList = this.a.i();
    else
      localArrayList = this.a.g();
    if (this.c < 0)
      return localArrayList.size();
    return -1 + localArrayList.size();
  }

  public final long getItemId(int paramInt)
  {
    return paramInt;
  }

  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    if (paramView == null)
      paramView = this.e.inflate(this.f, paramViewGroup, false);
    int i = a(paramInt).getGroupId();
    int j = paramInt - 1;
    int k;
    if (j >= 0)
      k = a(j).getGroupId();
    else
      k = i;
    ListMenuItemView localListMenuItemView = (ListMenuItemView)paramView;
    boolean bool;
    if ((this.a.b()) && (i != k))
      bool = true;
    else
      bool = false;
    localListMenuItemView.setGroupDividerEnabled(bool);
    p.a locala = (p.a)paramView;
    if (this.b)
      localListMenuItemView.setForceShowIcon(true);
    locala.a(a(paramInt), 0);
    return paramView;
  }

  public final void notifyDataSetChanged()
  {
    a();
    super.notifyDataSetChanged();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.g
 * JD-Core Version:    0.6.2
 */