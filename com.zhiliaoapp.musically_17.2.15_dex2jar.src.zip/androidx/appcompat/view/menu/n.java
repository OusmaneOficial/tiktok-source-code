package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow.OnDismissListener;
import androidx.core.h.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class n
{
  public View a;
  public int b = 8388611;
  public PopupWindow.OnDismissListener c;
  private final Context d;
  private final h e;
  private final boolean f;
  private final int g;
  private final int h;
  private boolean i;
  private o.a j;
  private m k;
  private final PopupWindow.OnDismissListener l = new PopupWindow.OnDismissListener()
  {
    static
    {
      CoverageLogger.Log(12410880);
    }

    public final void onDismiss()
    {
      n.this.d();
    }
  };

  static
  {
    CoverageLogger.Log(12408832);
  }

  public n(Context paramContext, h paramh, View paramView, boolean paramBoolean, int paramInt)
  {
    this(paramContext, paramh, paramView, paramBoolean, 2130968615, 0);
  }

  public n(Context paramContext, h paramh, View paramView, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    this.d = paramContext;
    this.e = paramh;
    this.a = paramView;
    this.f = paramBoolean;
    this.g = paramInt1;
    this.h = paramInt2;
  }

  public final m a()
  {
    if (this.k == null)
    {
      Display localDisplay = ((WindowManager)this.d.getSystemService("window")).getDefaultDisplay();
      Point localPoint = new Point();
      if (Build.VERSION.SDK_INT >= 17)
        localDisplay.getRealSize(localPoint);
      else
        localDisplay.getSize(localPoint);
      int m;
      if (Math.min(localPoint.x, localPoint.y) >= this.d.getResources().getDimensionPixelSize(2131165209))
        m = 1;
      else
        m = 0;
      Object localObject;
      if (m != 0)
      {
        Context localContext2 = this.d;
        View localView2 = this.a;
        int i2 = this.g;
        int i3 = this.h;
        boolean bool2 = this.f;
        localObject = new e(localContext2, localView2, i2, i3, bool2);
      }
      else
      {
        Context localContext1 = this.d;
        h localh = this.e;
        View localView1 = this.a;
        int n = this.g;
        int i1 = this.h;
        boolean bool1 = this.f;
        localObject = new t(localContext1, localh, localView1, n, i1, bool1);
      }
      ((m)localObject).a(this.e);
      ((m)localObject).a(this.l);
      ((m)localObject).a(this.a);
      ((m)localObject).a(this.j);
      ((m)localObject).b(this.i);
      ((m)localObject).a(this.b);
      this.k = ((m)localObject);
    }
    return this.k;
  }

  void a(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2)
  {
    m localm = a();
    localm.c(paramBoolean2);
    if (paramBoolean1)
    {
      if ((0x7 & d.a(this.b, androidx.core.h.t.f(this.a))) == 5)
        paramInt1 -= this.a.getWidth();
      localm.b(paramInt1);
      localm.c(paramInt2);
      int m = (int)(48.0F * this.d.getResources().getDisplayMetrics().density / 2.0F);
      localm.g = new Rect(paramInt1 - m, paramInt2 - m, paramInt1 + m, paramInt2 + m);
    }
    localm.c();
  }

  public final void a(o.a parama)
  {
    this.j = parama;
    m localm = this.k;
    if (localm != null)
      localm.a(parama);
  }

  public final void a(boolean paramBoolean)
  {
    this.i = paramBoolean;
    m localm = this.k;
    if (localm != null)
      localm.b(paramBoolean);
  }

  public final boolean b()
  {
    if (e())
      return true;
    if (this.a == null)
      return false;
    a(0, 0, false, false);
    return true;
  }

  public final void c()
  {
    if (e())
      this.k.d();
  }

  public void d()
  {
    this.k = null;
    PopupWindow.OnDismissListener localOnDismissListener = this.c;
    if (localOnDismissListener != null)
      localOnDismissListener.onDismiss();
  }

  public final boolean e()
  {
    m localm = this.k;
    return (localm != null) && (localm.e());
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.n
 * JD-Core Version:    0.6.2
 */