package androidx.appcompat.view.menu;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface p
{
  static
  {
    CoverageLogger.Log(12433408);
  }

  public abstract void a(h paramh);

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(12423168);
    }

    public abstract void a(j paramj, int paramInt);

    public abstract boolean a();

    public abstract j getItemData();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.menu.p
 * JD-Core Version:    0.6.2
 */