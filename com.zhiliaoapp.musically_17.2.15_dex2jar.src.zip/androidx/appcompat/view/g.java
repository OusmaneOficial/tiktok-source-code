package androidx.appcompat.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.SubMenu;
import androidx.appcompat.widget.p;
import androidx.core.h.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.IOException;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class g extends MenuInflater
{
  static final Class<?>[] a = arrayOfClass;
  static final Class<?>[] b = arrayOfClass;
  final Object[] c;
  final Object[] d;
  Context e;
  Object f;

  static
  {
    CoverageLogger.Log(12673024);
    Class[] arrayOfClass = { Context.class };
  }

  public g(Context paramContext)
  {
    super(paramContext);
    this.e = paramContext;
    this.c = new Object[] { paramContext };
    this.d = this.c;
  }

  private void a(XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Menu paramMenu)
    throws XmlPullParserException, IOException
  {
    b localb = new b(paramMenu);
    int i = paramXmlPullParser.getEventType();
    do
    {
      if (i == 2)
      {
        String str3 = paramXmlPullParser.getName();
        if (str3.equals("menu"))
        {
          i = paramXmlPullParser.next();
          break;
        }
        StringBuilder localStringBuilder = new StringBuilder("Expecting menu, got ");
        localStringBuilder.append(str3);
        throw new RuntimeException(localStringBuilder.toString());
      }
      i = paramXmlPullParser.next();
    }
    while (i != 1);
    int j = i;
    Object localObject = null;
    int k = 0;
    int m = 0;
    while (k == 0)
      if (j != 1)
      {
        if (j != 2)
        {
          if (j == 3)
          {
            String str2 = paramXmlPullParser.getName();
            if ((m != 0) && (str2.equals(localObject)))
            {
              m = 0;
              localObject = null;
            }
            else if (str2.equals("group"))
            {
              localb.a();
            }
            else if (str2.equals("item"))
            {
              if (!localb.a)
                if ((localb.b != null) && (localb.b.c()))
                  localb.c();
                else
                  localb.b();
            }
            else if (str2.equals("menu"))
            {
              k = 1;
            }
          }
        }
        else if (m == 0)
        {
          String str1 = paramXmlPullParser.getName();
          if (str1.equals("group"))
          {
            localb.a(paramAttributeSet);
          }
          else if (str1.equals("item"))
          {
            localb.b(paramAttributeSet);
          }
          else if (str1.equals("menu"))
          {
            a(paramXmlPullParser, paramAttributeSet, localb.c());
          }
          else
          {
            localObject = str1;
            m = 1;
          }
        }
        j = paramXmlPullParser.next();
      }
      else
      {
        throw new RuntimeException("Unexpected end of document");
      }
  }

  Object a(Object paramObject)
  {
    while (true)
    {
      if ((paramObject instanceof Activity))
        return paramObject;
      if (!(paramObject instanceof ContextWrapper))
        break;
      paramObject = ((ContextWrapper)paramObject).getBaseContext();
    }
    return paramObject;
  }

  // ERROR //
  public final void inflate(int paramInt, Menu paramMenu)
  {
    // Byte code:
    //   0: aload_2
    //   1: instanceof 136
    //   4: ifne +10 -> 14
    //   7: aload_0
    //   8: iload_1
    //   9: aload_2
    //   10: invokespecial 138	android/view/MenuInflater:inflate	(ILandroid/view/Menu;)V
    //   13: return
    //   14: aconst_null
    //   15: astore_3
    //   16: aload_0
    //   17: getfield 38	androidx/appcompat/view/g:e	Landroid/content/Context;
    //   20: invokevirtual 142	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   23: iload_1
    //   24: invokevirtual 148	android/content/res/Resources:getLayout	(I)Landroid/content/res/XmlResourceParser;
    //   27: astore_3
    //   28: aload_0
    //   29: aload_3
    //   30: aload_3
    //   31: invokestatic 154	android/util/Xml:asAttributeSet	(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    //   34: aload_2
    //   35: invokespecial 121	androidx/appcompat/view/g:a	(Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/view/Menu;)V
    //   38: aload_3
    //   39: ifnull +9 -> 48
    //   42: aload_3
    //   43: invokeinterface 159 1 0
    //   48: return
    //   49: astore 5
    //   51: goto +31 -> 82
    //   54: astore 6
    //   56: new 161	android/view/InflateException
    //   59: dup
    //   60: ldc 163
    //   62: aload 6
    //   64: invokespecial 166	android/view/InflateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   67: athrow
    //   68: astore 4
    //   70: new 161	android/view/InflateException
    //   73: dup
    //   74: ldc 163
    //   76: aload 4
    //   78: invokespecial 166	android/view/InflateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   81: athrow
    //   82: aload_3
    //   83: ifnull +9 -> 92
    //   86: aload_3
    //   87: invokeinterface 159 1 0
    //   92: aload 5
    //   94: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   16	38	49	finally
    //   56	68	49	finally
    //   70	82	49	finally
    //   16	38	54	java/io/IOException
    //   16	38	68	org/xmlpull/v1/XmlPullParserException
  }

  static final class a
    implements MenuItem.OnMenuItemClickListener
  {
    private static final Class<?>[] a = { MenuItem.class };
    private Object b;
    private Method c;

    static
    {
      CoverageLogger.Log(12447744);
    }

    public a(Object paramObject, String paramString)
    {
      this.b = paramObject;
      Class localClass = paramObject.getClass();
      try
      {
        this.c = localClass.getMethod(paramString, a);
        return;
      }
      catch (Exception localException)
      {
        StringBuilder localStringBuilder = new StringBuilder("Couldn't resolve menu item onClick handler ");
        localStringBuilder.append(paramString);
        localStringBuilder.append(" in class ");
        localStringBuilder.append(localClass.getName());
        InflateException localInflateException = new InflateException(localStringBuilder.toString());
        localInflateException.initCause(localException);
        throw localInflateException;
      }
    }

    public final boolean onMenuItemClick(MenuItem paramMenuItem)
    {
      try
      {
        if (this.c.getReturnType() == Boolean.TYPE)
          return ((Boolean)this.c.invoke(this.b, new Object[] { paramMenuItem })).booleanValue();
        this.c.invoke(this.b, new Object[] { paramMenuItem });
        return true;
      }
      catch (Exception localException)
      {
        throw new RuntimeException(localException);
      }
    }
  }

  final class b
  {
    private String A;
    private String B;
    private CharSequence C;
    private CharSequence D;
    private ColorStateList E;
    private PorterDuff.Mode F;
    public boolean a;
    b b;
    private Menu d;
    private int e;
    private int f;
    private int g;
    private int h;
    private boolean i;
    private boolean j;
    private int k;
    private int l;
    private CharSequence m;
    private CharSequence n;
    private int o;
    private char p;
    private int q;
    private char r;
    private int s;
    private int t;
    private boolean u;
    private boolean v;
    private boolean w;
    private int x;
    private int y;
    private String z;

    static
    {
      CoverageLogger.Log(12453888);
    }

    public b(Menu arg2)
    {
      Object localObject;
      this.d = localObject;
      a();
    }

    private static char a(String paramString)
    {
      if (paramString == null)
        return '\000';
      return paramString.charAt(0);
    }

    // ERROR //
    private <T> T a(String paramString, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 58	androidx/appcompat/view/g$b:c	Landroidx/appcompat/view/g;
      //   4: getfield 79	androidx/appcompat/view/g:e	Landroid/content/Context;
      //   7: invokevirtual 85	android/content/Context:getClassLoader	()Ljava/lang/ClassLoader;
      //   10: aload_1
      //   11: invokevirtual 91	java/lang/ClassLoader:loadClass	(Ljava/lang/String;)Ljava/lang/Class;
      //   14: aload_2
      //   15: invokevirtual 97	java/lang/Class:getConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
      //   18: astore 4
      //   20: aload 4
      //   22: iconst_1
      //   23: invokevirtual 103	java/lang/reflect/Constructor:setAccessible	(Z)V
      //   26: aload 4
      //   28: aload_3
      //   29: invokevirtual 107	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
      //   32: astore 5
      //   34: aload 5
      //   36: areturn
      //   37: aconst_null
      //   38: areturn
      //
      // Exception table:
      //   from	to	target	type
      //   0	34	37	java/lang/Exception
    }

    // ERROR //
    private void a(MenuItem paramMenuItem)
    {
      // Byte code:
      //   0: aload_1
      //   1: aload_0
      //   2: getfield 110	androidx/appcompat/view/g$b:u	Z
      //   5: invokeinterface 116 2 0
      //   10: aload_0
      //   11: getfield 118	androidx/appcompat/view/g$b:v	Z
      //   14: invokeinterface 121 2 0
      //   19: aload_0
      //   20: getfield 123	androidx/appcompat/view/g$b:w	Z
      //   23: invokeinterface 126 2 0
      //   28: astore_2
      //   29: aload_0
      //   30: getfield 128	androidx/appcompat/view/g$b:t	I
      //   33: ifle +8 -> 41
      //   36: iconst_1
      //   37: istore_3
      //   38: goto +5 -> 43
      //   41: iconst_0
      //   42: istore_3
      //   43: aload_2
      //   44: iload_3
      //   45: invokeinterface 131 2 0
      //   50: aload_0
      //   51: getfield 133	androidx/appcompat/view/g$b:n	Ljava/lang/CharSequence;
      //   54: invokeinterface 137 2 0
      //   59: aload_0
      //   60: getfield 139	androidx/appcompat/view/g$b:o	I
      //   63: invokeinterface 143 2 0
      //   68: pop
      //   69: aload_0
      //   70: getfield 145	androidx/appcompat/view/g$b:x	I
      //   73: istore 5
      //   75: iload 5
      //   77: iflt +11 -> 88
      //   80: aload_1
      //   81: iload 5
      //   83: invokeinterface 148 2 0
      //   88: aload_0
      //   89: getfield 150	androidx/appcompat/view/g$b:B	Ljava/lang/String;
      //   92: ifnull +81 -> 173
      //   95: aload_0
      //   96: getfield 58	androidx/appcompat/view/g$b:c	Landroidx/appcompat/view/g;
      //   99: getfield 79	androidx/appcompat/view/g:e	Landroid/content/Context;
      //   102: invokevirtual 154	android/content/Context:isRestricted	()Z
      //   105: ifne +58 -> 163
      //   108: aload_0
      //   109: getfield 58	androidx/appcompat/view/g$b:c	Landroidx/appcompat/view/g;
      //   112: astore 41
      //   114: aload 41
      //   116: getfield 157	androidx/appcompat/view/g:f	Ljava/lang/Object;
      //   119: ifnonnull +18 -> 137
      //   122: aload 41
      //   124: aload 41
      //   126: aload 41
      //   128: getfield 79	androidx/appcompat/view/g:e	Landroid/content/Context;
      //   131: invokevirtual 160	androidx/appcompat/view/g:a	(Ljava/lang/Object;)Ljava/lang/Object;
      //   134: putfield 157	androidx/appcompat/view/g:f	Ljava/lang/Object;
      //   137: aload_1
      //   138: new 162	androidx/appcompat/view/g$a
      //   141: dup
      //   142: aload 41
      //   144: getfield 157	androidx/appcompat/view/g:f	Ljava/lang/Object;
      //   147: aload_0
      //   148: getfield 150	androidx/appcompat/view/g$b:B	Ljava/lang/String;
      //   151: invokespecial 165	androidx/appcompat/view/g$a:<init>	(Ljava/lang/Object;Ljava/lang/String;)V
      //   154: invokeinterface 169 2 0
      //   159: pop
      //   160: goto +13 -> 173
      //   163: new 171	java/lang/IllegalStateException
      //   166: dup
      //   167: ldc 173
      //   169: invokespecial 176	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
      //   172: athrow
      //   173: aload_0
      //   174: getfield 128	androidx/appcompat/view/g$b:t	I
      //   177: iconst_2
      //   178: if_icmplt +123 -> 301
      //   181: aload_1
      //   182: instanceof 178
      //   185: ifeq +14 -> 199
      //   188: aload_1
      //   189: checkcast 178	androidx/appcompat/view/menu/j
      //   192: iconst_1
      //   193: invokevirtual 180	androidx/appcompat/view/menu/j:a	(Z)V
      //   196: goto +105 -> 301
      //   199: aload_1
      //   200: instanceof 182
      //   203: ifeq +98 -> 301
      //   206: aload_1
      //   207: checkcast 182	androidx/appcompat/view/menu/k
      //   210: astore 34
      //   212: aload 34
      //   214: getfield 185	androidx/appcompat/view/menu/k:c	Ljava/lang/reflect/Method;
      //   217: ifnonnull +43 -> 260
      //   220: aload 34
      //   222: getfield 187	androidx/appcompat/view/menu/k:b	Ljava/lang/Object;
      //   225: checkcast 189	androidx/core/a/a/b
      //   228: invokevirtual 193	java/lang/Object:getClass	()Ljava/lang/Class;
      //   231: astore 39
      //   233: iconst_1
      //   234: anewarray 93	java/lang/Class
      //   237: astore 40
      //   239: aload 40
      //   241: iconst_0
      //   242: getstatic 199	java/lang/Boolean:TYPE	Ljava/lang/Class;
      //   245: aastore
      //   246: aload 34
      //   248: aload 39
      //   250: ldc 201
      //   252: aload 40
      //   254: invokevirtual 205	java/lang/Class:getDeclaredMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   257: putfield 185	androidx/appcompat/view/menu/k:c	Ljava/lang/reflect/Method;
      //   260: aload 34
      //   262: getfield 185	androidx/appcompat/view/menu/k:c	Ljava/lang/reflect/Method;
      //   265: astore 35
      //   267: aload 34
      //   269: getfield 187	androidx/appcompat/view/menu/k:b	Ljava/lang/Object;
      //   272: astore 36
      //   274: iconst_1
      //   275: anewarray 4	java/lang/Object
      //   278: astore 37
      //   280: aload 37
      //   282: iconst_0
      //   283: iconst_1
      //   284: invokestatic 209	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
      //   287: aastore
      //   288: aload 35
      //   290: aload 36
      //   292: aload 37
      //   294: invokevirtual 215	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   297: pop
      //   298: goto +3 -> 301
      //   301: aload_0
      //   302: getfield 217	androidx/appcompat/view/g$b:z	Ljava/lang/String;
      //   305: astore 6
      //   307: iconst_0
      //   308: istore 7
      //   310: aload 6
      //   312: ifnull +32 -> 344
      //   315: aload_1
      //   316: aload_0
      //   317: aload 6
      //   319: getstatic 220	androidx/appcompat/view/g:a	[Ljava/lang/Class;
      //   322: aload_0
      //   323: getfield 58	androidx/appcompat/view/g$b:c	Landroidx/appcompat/view/g;
      //   326: getfield 223	androidx/appcompat/view/g:c	[Ljava/lang/Object;
      //   329: invokespecial 225	androidx/appcompat/view/g$b:a	(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
      //   332: checkcast 227	android/view/View
      //   335: invokeinterface 231 2 0
      //   340: pop
      //   341: iconst_1
      //   342: istore 7
      //   344: aload_0
      //   345: getfield 233	androidx/appcompat/view/g$b:y	I
      //   348: istore 8
      //   350: iload 8
      //   352: ifle +17 -> 369
      //   355: iload 7
      //   357: ifne +12 -> 369
      //   360: aload_1
      //   361: iload 8
      //   363: invokeinterface 235 2 0
      //   368: pop
      //   369: aload_0
      //   370: getfield 237	androidx/appcompat/view/g$b:b	Landroidx/core/h/b;
      //   373: astore 9
      //   375: aload 9
      //   377: ifnull +22 -> 399
      //   380: aload_1
      //   381: instanceof 189
      //   384: ifeq +15 -> 399
      //   387: aload_1
      //   388: checkcast 189	androidx/core/a/a/b
      //   391: aload 9
      //   393: invokeinterface 240 2 0
      //   398: pop
      //   399: aload_0
      //   400: getfield 242	androidx/appcompat/view/g$b:C	Ljava/lang/CharSequence;
      //   403: astore 10
      //   405: aload_1
      //   406: instanceof 189
      //   409: istore 11
      //   411: iload 11
      //   413: ifeq +18 -> 431
      //   416: aload_1
      //   417: checkcast 189	androidx/core/a/a/b
      //   420: aload 10
      //   422: invokeinterface 245 2 0
      //   427: pop
      //   428: goto +20 -> 448
      //   431: getstatic 250	android/os/Build$VERSION:SDK_INT	I
      //   434: bipush 26
      //   436: if_icmplt +12 -> 448
      //   439: aload_1
      //   440: aload 10
      //   442: invokeinterface 253 2 0
      //   447: pop
      //   448: aload_0
      //   449: getfield 255	androidx/appcompat/view/g$b:D	Ljava/lang/CharSequence;
      //   452: astore 12
      //   454: iload 11
      //   456: ifeq +18 -> 474
      //   459: aload_1
      //   460: checkcast 189	androidx/core/a/a/b
      //   463: aload 12
      //   465: invokeinterface 257 2 0
      //   470: pop
      //   471: goto +20 -> 491
      //   474: getstatic 250	android/os/Build$VERSION:SDK_INT	I
      //   477: bipush 26
      //   479: if_icmplt +12 -> 491
      //   482: aload_1
      //   483: aload 12
      //   485: invokeinterface 260 2 0
      //   490: pop
      //   491: aload_0
      //   492: getfield 262	androidx/appcompat/view/g$b:p	C
      //   495: istore 13
      //   497: aload_0
      //   498: getfield 264	androidx/appcompat/view/g$b:q	I
      //   501: istore 14
      //   503: iload 11
      //   505: ifeq +20 -> 525
      //   508: aload_1
      //   509: checkcast 189	androidx/core/a/a/b
      //   512: iload 13
      //   514: iload 14
      //   516: invokeinterface 268 3 0
      //   521: pop
      //   522: goto +22 -> 544
      //   525: getstatic 250	android/os/Build$VERSION:SDK_INT	I
      //   528: bipush 26
      //   530: if_icmplt +14 -> 544
      //   533: aload_1
      //   534: iload 13
      //   536: iload 14
      //   538: invokeinterface 269 3 0
      //   543: pop
      //   544: aload_0
      //   545: getfield 271	androidx/appcompat/view/g$b:r	C
      //   548: istore 15
      //   550: aload_0
      //   551: getfield 273	androidx/appcompat/view/g$b:s	I
      //   554: istore 16
      //   556: iload 11
      //   558: ifeq +20 -> 578
      //   561: aload_1
      //   562: checkcast 189	androidx/core/a/a/b
      //   565: iload 15
      //   567: iload 16
      //   569: invokeinterface 276 3 0
      //   574: pop
      //   575: goto +22 -> 597
      //   578: getstatic 250	android/os/Build$VERSION:SDK_INT	I
      //   581: bipush 26
      //   583: if_icmplt +14 -> 597
      //   586: aload_1
      //   587: iload 15
      //   589: iload 16
      //   591: invokeinterface 277 3 0
      //   596: pop
      //   597: aload_0
      //   598: getfield 279	androidx/appcompat/view/g$b:F	Landroid/graphics/PorterDuff$Mode;
      //   601: astore 17
      //   603: aload 17
      //   605: ifnull +40 -> 645
      //   608: iload 11
      //   610: ifeq +18 -> 628
      //   613: aload_1
      //   614: checkcast 189	androidx/core/a/a/b
      //   617: aload 17
      //   619: invokeinterface 283 2 0
      //   624: pop
      //   625: goto +20 -> 645
      //   628: getstatic 250	android/os/Build$VERSION:SDK_INT	I
      //   631: bipush 26
      //   633: if_icmplt +12 -> 645
      //   636: aload_1
      //   637: aload 17
      //   639: invokeinterface 284 2 0
      //   644: pop
      //   645: aload_0
      //   646: getfield 286	androidx/appcompat/view/g$b:E	Landroid/content/res/ColorStateList;
      //   649: astore 18
      //   651: aload 18
      //   653: ifnull +38 -> 691
      //   656: iload 11
      //   658: ifeq +16 -> 674
      //   661: aload_1
      //   662: checkcast 189	androidx/core/a/a/b
      //   665: aload 18
      //   667: invokeinterface 290 2 0
      //   672: pop
      //   673: return
      //   674: getstatic 250	android/os/Build$VERSION:SDK_INT	I
      //   677: bipush 26
      //   679: if_icmplt +12 -> 691
      //   682: aload_1
      //   683: aload 18
      //   685: invokeinterface 291 2 0
      //   690: pop
      //   691: return
      //
      // Exception table:
      //   from	to	target	type
      //   212	260	301	java/lang/Exception
      //   260	298	301	java/lang/Exception
    }

    public final void a()
    {
      this.e = 0;
      this.f = 0;
      this.g = 0;
      this.h = 0;
      this.i = true;
      this.j = true;
    }

    public final void a(AttributeSet paramAttributeSet)
    {
      TypedArray localTypedArray = g.this.e.obtainStyledAttributes(paramAttributeSet, new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 });
      this.e = localTypedArray.getResourceId(1, 0);
      this.f = localTypedArray.getInt(3, 0);
      this.g = localTypedArray.getInt(4, 0);
      this.h = localTypedArray.getInt(5, 0);
      this.i = localTypedArray.getBoolean(2, true);
      this.j = localTypedArray.getBoolean(0, true);
      localTypedArray.recycle();
    }

    public final void b()
    {
      this.a = true;
      a(this.d.add(this.e, this.k, this.l, this.m));
    }

    public final void b(AttributeSet paramAttributeSet)
    {
      TypedArray localTypedArray = g.this.e.obtainStyledAttributes(paramAttributeSet, new int[] { 16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 16843236, 16843237, 16843375, 2130968598, 2130968616, 2130968617, 2130968641, 2130968958, 2130969177, 2130969178, 2130969486, 2130969721, 2130969951 });
      this.k = localTypedArray.getResourceId(2, 0);
      int i1 = localTypedArray.getInt(5, this.f);
      int i2 = localTypedArray.getInt(6, this.g);
      this.l = (i1 & 0xFFFF0000 | i2 & 0xFFFF);
      this.m = localTypedArray.getText(7);
      this.n = localTypedArray.getText(8);
      this.o = localTypedArray.getResourceId(0, 0);
      this.p = a(localTypedArray.getString(9));
      this.q = localTypedArray.getInt(16, 4096);
      this.r = a(localTypedArray.getString(10));
      this.s = localTypedArray.getInt(20, 4096);
      if (localTypedArray.hasValue(11))
        this.t = localTypedArray.getBoolean(11, false);
      else
        this.t = this.h;
      this.u = localTypedArray.getBoolean(3, false);
      this.v = localTypedArray.getBoolean(4, this.i);
      boolean bool = this.j;
      int i3 = 1;
      this.w = localTypedArray.getBoolean(i3, bool);
      this.x = localTypedArray.getInt(21, -1);
      this.B = localTypedArray.getString(12);
      this.y = localTypedArray.getResourceId(13, 0);
      this.z = localTypedArray.getString(15);
      this.A = localTypedArray.getString(14);
      if (this.A == null)
        i3 = 0;
      if ((i3 != 0) && (this.y == 0) && (this.z == null))
        this.b = ((b)a(this.A, g.b, g.this.d));
      else
        this.b = null;
      this.C = localTypedArray.getText(17);
      this.D = localTypedArray.getText(22);
      if (localTypedArray.hasValue(19))
        this.F = p.a(localTypedArray.getInt(19, -1), this.F);
      else
        this.F = null;
      if (localTypedArray.hasValue(18))
        this.E = localTypedArray.getColorStateList(18);
      else
        this.E = null;
      localTypedArray.recycle();
      this.a = false;
    }

    public final SubMenu c()
    {
      this.a = true;
      SubMenu localSubMenu = this.d.addSubMenu(this.e, this.k, this.l, this.m);
      a(localSubMenu.getItem());
      return localSubMenu;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.g
 * JD-Core Version:    0.6.2
 */