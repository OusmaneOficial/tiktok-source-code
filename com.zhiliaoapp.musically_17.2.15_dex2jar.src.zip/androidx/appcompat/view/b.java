package androidx.appcompat.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class b
{
  public Object b;
  public boolean c;

  static
  {
    CoverageLogger.Log(12652544);
  }

  public abstract MenuInflater a();

  public abstract void a(int paramInt);

  public abstract void a(View paramView);

  public abstract void a(CharSequence paramCharSequence);

  public void a(boolean paramBoolean)
  {
    this.c = paramBoolean;
  }

  public abstract Menu b();

  public abstract void b(int paramInt);

  public abstract void b(CharSequence paramCharSequence);

  public abstract void c();

  public abstract void d();

  public abstract CharSequence f();

  public abstract CharSequence g();

  public boolean h()
  {
    return false;
  }

  public abstract View i();

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(12648448);
    }

    public abstract void a(b paramb);

    public abstract boolean a(b paramb, Menu paramMenu);

    public abstract boolean a(b paramb, MenuItem paramMenuItem);

    public abstract boolean b(b paramb, Menu paramMenu);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.b
 * JD-Core Version:    0.6.2
 */