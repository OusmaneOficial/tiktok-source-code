package androidx.appcompat.view;

import android.content.Context;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.q;
import androidx.c.g;
import androidx.core.a.a.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class f extends ActionMode
{
  final Context a;
  final b b;

  static
  {
    CoverageLogger.Log(12449792);
  }

  public f(Context paramContext, b paramb)
  {
    this.a = paramContext;
    this.b = paramb;
  }

  public final void finish()
  {
    this.b.c();
  }

  public final View getCustomView()
  {
    return this.b.i();
  }

  public final Menu getMenu()
  {
    return q.a(this.a, (a)this.b.b());
  }

  public final MenuInflater getMenuInflater()
  {
    return this.b.a();
  }

  public final CharSequence getSubtitle()
  {
    return this.b.g();
  }

  public final Object getTag()
  {
    return this.b.b;
  }

  public final CharSequence getTitle()
  {
    return this.b.f();
  }

  public final boolean getTitleOptionalHint()
  {
    return this.b.c;
  }

  public final void invalidate()
  {
    this.b.d();
  }

  public final boolean isTitleOptional()
  {
    return this.b.h();
  }

  public final void setCustomView(View paramView)
  {
    this.b.a(paramView);
  }

  public final void setSubtitle(int paramInt)
  {
    this.b.b(paramInt);
  }

  public final void setSubtitle(CharSequence paramCharSequence)
  {
    this.b.a(paramCharSequence);
  }

  public final void setTag(Object paramObject)
  {
    this.b.b = paramObject;
  }

  public final void setTitle(int paramInt)
  {
    this.b.a(paramInt);
  }

  public final void setTitle(CharSequence paramCharSequence)
  {
    this.b.b(paramCharSequence);
  }

  public final void setTitleOptionalHint(boolean paramBoolean)
  {
    this.b.a(paramBoolean);
  }

  public static final class a
    implements b.a
  {
    final ActionMode.Callback a;
    final Context b;
    final ArrayList<f> c;
    final g<Menu, Menu> d;

    static
    {
      CoverageLogger.Log(12670976);
    }

    public a(Context paramContext, ActionMode.Callback paramCallback)
    {
      this.b = paramContext;
      this.a = paramCallback;
      this.c = new ArrayList();
      this.d = new g();
    }

    private Menu a(Menu paramMenu)
    {
      Menu localMenu = (Menu)this.d.get(paramMenu);
      if (localMenu == null)
      {
        localMenu = q.a(this.b, (a)paramMenu);
        this.d.put(paramMenu, localMenu);
      }
      return localMenu;
    }

    public final void a(b paramb)
    {
      this.a.onDestroyActionMode(b(paramb));
    }

    public final boolean a(b paramb, Menu paramMenu)
    {
      return this.a.onCreateActionMode(b(paramb), a(paramMenu));
    }

    public final boolean a(b paramb, MenuItem paramMenuItem)
    {
      return this.a.onActionItemClicked(b(paramb), q.a(this.b, (androidx.core.a.a.b)paramMenuItem));
    }

    public final ActionMode b(b paramb)
    {
      int i = this.c.size();
      for (int j = 0; j < i; j++)
      {
        f localf2 = (f)this.c.get(j);
        if ((localf2 != null) && (localf2.b == paramb))
          return localf2;
      }
      f localf1 = new f(this.b, paramb);
      this.c.add(localf1);
      return localf1;
    }

    public final boolean b(b paramb, Menu paramMenu)
    {
      return this.a.onPrepareActionMode(b(paramb), a(paramMenu));
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.f
 * JD-Core Version:    0.6.2
 */