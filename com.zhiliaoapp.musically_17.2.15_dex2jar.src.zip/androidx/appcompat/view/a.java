package androidx.appcompat.view;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  public Context a;

  static
  {
    CoverageLogger.Log(12644352);
  }

  private a(Context paramContext)
  {
    this.a = paramContext;
  }

  public static a a(Context paramContext)
  {
    return new a(paramContext);
  }

  public final int a()
  {
    Configuration localConfiguration = this.a.getResources().getConfiguration();
    int i = localConfiguration.screenWidthDp;
    int j = localConfiguration.screenHeightDp;
    if ((localConfiguration.smallestScreenWidthDp <= 600) && (i <= 600) && ((i <= 960) || (j <= 720)) && ((i <= 720) || (j <= 960)))
    {
      if ((i < 500) && ((i <= 640) || (j <= 480)) && ((i <= 480) || (j <= 640)))
      {
        if (i >= 360)
          return 3;
        return 2;
      }
      return 4;
    }
    return 5;
  }

  public final boolean b()
  {
    return this.a.getResources().getBoolean(2131034112);
  }

  public final boolean c()
  {
    return this.a.getApplicationInfo().targetSdkVersion < 14;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.a
 * JD-Core Version:    0.6.2
 */