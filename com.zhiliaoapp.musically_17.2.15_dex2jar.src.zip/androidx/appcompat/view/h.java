package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.h.x;
import androidx.core.h.y;
import androidx.core.h.z;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.Iterator;

public final class h
{
  final ArrayList<x> a = new ArrayList();
  y b;
  boolean c;
  private long d = -1L;
  private Interpolator e;
  private final z f = new z()
  {
    private boolean b;
    private int c;

    static
    {
      CoverageLogger.Log(12681216);
    }

    public final void a(View paramAnonymousView)
    {
      if (this.b)
        return;
      this.b = true;
      if (h.this.b != null)
        h.this.b.a(null);
    }

    public final void b(View paramAnonymousView)
    {
      int i = 1 + this.c;
      this.c = i;
      if (i == h.this.a.size())
      {
        if (h.this.b != null)
          h.this.b.b(null);
        this.c = 0;
        this.b = false;
        h.this.c = false;
      }
    }
  };

  static
  {
    CoverageLogger.Log(12441600);
  }

  public final h a(long paramLong)
  {
    if (!this.c)
      this.d = 250L;
    return this;
  }

  public final h a(Interpolator paramInterpolator)
  {
    if (!this.c)
      this.e = paramInterpolator;
    return this;
  }

  public final h a(x paramx)
  {
    if (!this.c)
      this.a.add(paramx);
    return this;
  }

  public final h a(x paramx1, x paramx2)
  {
    this.a.add(paramx1);
    paramx2.b(paramx1.a());
    this.a.add(paramx2);
    return this;
  }

  public final h a(y paramy)
  {
    if (!this.c)
      this.b = paramy;
    return this;
  }

  public final void a()
  {
    if (this.c)
      return;
    Iterator localIterator = this.a.iterator();
    while (localIterator.hasNext())
    {
      x localx = (x)localIterator.next();
      long l = this.d;
      if (l >= 0L)
        localx.a(l);
      Interpolator localInterpolator = this.e;
      if (localInterpolator != null)
        localx.a(localInterpolator);
      if (this.b != null)
        localx.a(this.f);
      localx.c();
    }
    this.c = true;
  }

  public final void b()
  {
    if (!this.c)
      return;
    Iterator localIterator = this.a.iterator();
    while (localIterator.hasNext())
      ((x)localIterator.next()).b();
    this.c = false;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.h
 * JD-Core Version:    0.6.2
 */