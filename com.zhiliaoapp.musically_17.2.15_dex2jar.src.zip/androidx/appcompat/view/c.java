package androidx.appcompat.view;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface c
{
  static
  {
    CoverageLogger.Log(12658688);
  }

  public abstract void a();

  public abstract void b();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.view.c
 * JD-Core Version:    0.6.2
 */