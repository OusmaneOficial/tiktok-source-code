package androidx.appcompat.b.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import androidx.core.graphics.drawable.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

class b extends Drawable
  implements Drawable.Callback
{
  public int a = -1;
  private b b;
  private Rect c;
  private Drawable d;
  private Drawable e;
  private int f = 255;
  private boolean g;
  private int h = -1;
  private boolean i;
  private Runnable j;
  private long k;
  private long l;
  private a m;

  static
  {
    CoverageLogger.Log(12627968);
  }

  static int a(Resources paramResources, int paramInt)
  {
    if (paramResources != null)
      paramInt = paramResources.getDisplayMetrics().densityDpi;
    if (paramInt == 0)
      return 160;
    return paramInt;
  }

  private void a(Drawable paramDrawable)
  {
    if (this.m == null)
      this.m = new a();
    paramDrawable.setCallback(this.m.a(paramDrawable.getCallback()));
    try
    {
      if ((this.b.C <= 0) && (this.g))
        paramDrawable.setAlpha(this.f);
      if (this.b.G)
      {
        paramDrawable.setColorFilter(this.b.F);
      }
      else
      {
        if (this.b.J)
          a.a(paramDrawable, this.b.H);
        if (this.b.K)
          a.a(paramDrawable, this.b.I);
      }
      paramDrawable.setVisible(isVisible(), true);
      paramDrawable.setDither(this.b.z);
      paramDrawable.setState(getState());
      paramDrawable.setLevel(getLevel());
      paramDrawable.setBounds(getBounds());
      if (Build.VERSION.SDK_INT >= 23)
        paramDrawable.setLayoutDirection(getLayoutDirection());
      if (Build.VERSION.SDK_INT >= 19)
        paramDrawable.setAutoMirrored(this.b.E);
      Rect localRect = this.c;
      if ((Build.VERSION.SDK_INT >= 21) && (localRect != null))
        paramDrawable.setHotspotBounds(localRect.left, localRect.top, localRect.right, localRect.bottom);
      return;
    }
    finally
    {
      paramDrawable.setCallback(this.m.a());
    }
  }

  final void a(Resources paramResources)
  {
    this.b.a(paramResources);
  }

  protected void a(b paramb)
  {
    this.b = paramb;
    int n = this.a;
    if (n >= 0)
    {
      this.d = paramb.b(n);
      Drawable localDrawable = this.d;
      if (localDrawable != null)
        a(localDrawable);
    }
    this.h = -1;
    this.e = null;
  }

  final void a(boolean paramBoolean)
  {
    boolean bool1 = true;
    this.g = bool1;
    long l1 = SystemClock.uptimeMillis();
    Drawable localDrawable1 = this.d;
    if (localDrawable1 != null)
    {
      long l3 = this.k;
      if (l3 == 0L)
        break label106;
      if (l3 <= l1)
      {
        localDrawable1.setAlpha(this.f);
      }
      else
      {
        int i1 = (int)(255L * (l3 - l1)) / this.b.C;
        this.d.setAlpha((255 - i1) * this.f / 255);
        bool2 = true;
        break label109;
      }
    }
    this.k = 0L;
    label106: boolean bool2 = false;
    label109: Drawable localDrawable2 = this.e;
    if (localDrawable2 != null)
    {
      long l2 = this.l;
      if (l2 == 0L)
        break label206;
      if (l2 <= l1)
      {
        localDrawable2.setVisible(false, false);
        this.e = null;
        this.h = -1;
      }
      else
      {
        int n = (int)(255L * (l2 - l1)) / this.b.D;
        this.e.setAlpha(n * this.f / 255);
        break label209;
      }
    }
    this.l = 0L;
    label206: bool1 = bool2;
    label209: if ((paramBoolean) && (bool1))
      scheduleSelf(this.j, l1 + 16L);
  }

  final boolean a(int paramInt)
  {
    if (paramInt == this.a)
      return false;
    long l1 = SystemClock.uptimeMillis();
    if (this.b.D > 0)
    {
      Drawable localDrawable3 = this.e;
      if (localDrawable3 != null)
        localDrawable3.setVisible(false, false);
      Drawable localDrawable4 = this.d;
      if (localDrawable4 != null)
      {
        this.e = localDrawable4;
        this.h = this.a;
        this.l = (l1 + this.b.D);
      }
      else
      {
        this.e = null;
        this.h = -1;
        this.l = 0L;
      }
    }
    else
    {
      Drawable localDrawable1 = this.d;
      if (localDrawable1 != null)
        localDrawable1.setVisible(false, false);
    }
    if ((paramInt >= 0) && (paramInt < this.b.j))
    {
      Drawable localDrawable2 = this.b.b(paramInt);
      this.d = localDrawable2;
      this.a = paramInt;
      if (localDrawable2 != null)
      {
        if (this.b.C > 0)
          this.k = (l1 + this.b.C);
        a(localDrawable2);
      }
    }
    else
    {
      this.d = null;
      this.a = -1;
    }
    if ((this.k != 0L) || (this.l != 0L))
    {
      Runnable localRunnable = this.j;
      if (localRunnable == null)
        this.j = new Runnable()
        {
          static
          {
            CoverageLogger.Log(12621824);
          }

          public final void run()
          {
            b.this.a(true);
            b.this.invalidateSelf();
          }
        };
      else
        unscheduleSelf(localRunnable);
      a(true);
    }
    invalidateSelf();
    return true;
  }

  public void applyTheme(Resources.Theme paramTheme)
  {
    b localb = this.b;
    if (paramTheme != null)
    {
      localb.c();
      int n = localb.j;
      Drawable[] arrayOfDrawable = localb.i;
      for (int i1 = 0; i1 < n; i1++)
        if ((arrayOfDrawable[i1] != null) && (arrayOfDrawable[i1].canApplyTheme()))
        {
          arrayOfDrawable[i1].applyTheme(paramTheme);
          localb.g |= arrayOfDrawable[i1].getChangingConfigurations();
        }
      localb.a(paramTheme.getResources());
    }
  }

  b b()
  {
    return this.b;
  }

  public boolean canApplyTheme()
  {
    return this.b.canApplyTheme();
  }

  public void draw(Canvas paramCanvas)
  {
    Drawable localDrawable1 = this.d;
    if (localDrawable1 != null)
      localDrawable1.draw(paramCanvas);
    Drawable localDrawable2 = this.e;
    if (localDrawable2 != null)
      localDrawable2.draw(paramCanvas);
  }

  public int getAlpha()
  {
    return this.f;
  }

  public int getChangingConfigurations()
  {
    return super.getChangingConfigurations() | this.b.getChangingConfigurations();
  }

  public final Drawable.ConstantState getConstantState()
  {
    if (this.b.h())
    {
      this.b.f = getChangingConfigurations();
      return this.b;
    }
    return null;
  }

  public Drawable getCurrent()
  {
    return this.d;
  }

  public void getHotspotBounds(Rect paramRect)
  {
    Rect localRect = this.c;
    if (localRect != null)
    {
      paramRect.set(localRect);
      return;
    }
    super.getHotspotBounds(paramRect);
  }

  public int getIntrinsicHeight()
  {
    if (this.b.n)
      return this.b.e();
    Drawable localDrawable = this.d;
    if (localDrawable != null)
      return localDrawable.getIntrinsicHeight();
    return -1;
  }

  public int getIntrinsicWidth()
  {
    if (this.b.n)
      return this.b.d();
    Drawable localDrawable = this.d;
    if (localDrawable != null)
      return localDrawable.getIntrinsicWidth();
    return -1;
  }

  public int getMinimumHeight()
  {
    if (this.b.n)
      return this.b.g();
    Drawable localDrawable = this.d;
    if (localDrawable != null)
      return localDrawable.getMinimumHeight();
    return 0;
  }

  public int getMinimumWidth()
  {
    if (this.b.n)
      return this.b.f();
    Drawable localDrawable = this.d;
    if (localDrawable != null)
      return localDrawable.getMinimumWidth();
    return 0;
  }

  public int getOpacity()
  {
    Drawable localDrawable = this.d;
    int n = -2;
    if (localDrawable != null)
    {
      if (!localDrawable.isVisible())
        return n;
      b localb = this.b;
      if (localb.t)
        return localb.u;
      localb.c();
      int i1 = localb.j;
      Drawable[] arrayOfDrawable = localb.i;
      if (i1 > 0)
        n = arrayOfDrawable[0].getOpacity();
      int i2 = n;
      for (int i3 = 1; i3 < i1; i3++)
        i2 = Drawable.resolveOpacity(i2, arrayOfDrawable[i3].getOpacity());
      localb.u = i2;
      localb.t = true;
      return i2;
    }
    return n;
  }

  public void getOutline(Outline paramOutline)
  {
    Drawable localDrawable = this.d;
    if (localDrawable != null)
      localDrawable.getOutline(paramOutline);
  }

  public boolean getPadding(Rect paramRect)
  {
    b localb = this.b;
    boolean bool1 = localb.k;
    int n = 1;
    Object localObject;
    if (bool1)
    {
      localObject = null;
    }
    else if ((localb.m == null) && (!localb.l))
    {
      localb.c();
      Rect localRect1 = new Rect();
      int i2 = localb.j;
      Drawable[] arrayOfDrawable = localb.i;
      Rect localRect2 = null;
      for (int i3 = 0; i3 < i2; i3++)
        if (arrayOfDrawable[i3].getPadding(localRect1))
        {
          if (localRect2 == null)
            localRect2 = new Rect(0, 0, 0, 0);
          if (localRect1.left > localRect2.left)
            localRect2.left = localRect1.left;
          if (localRect1.top > localRect2.top)
            localRect2.top = localRect1.top;
          if (localRect1.right > localRect2.right)
            localRect2.right = localRect1.right;
          if (localRect1.bottom > localRect2.bottom)
            localRect2.bottom = localRect1.bottom;
        }
      localb.l = n;
      localb.m = localRect2;
      localObject = localRect2;
    }
    else
    {
      localObject = localb.m;
    }
    boolean bool2;
    if (localObject != null)
    {
      paramRect.set((Rect)localObject);
      if ((((Rect)localObject).left | ((Rect)localObject).top | ((Rect)localObject).bottom | ((Rect)localObject).right) != 0)
        bool2 = true;
      else
        bool2 = false;
    }
    else
    {
      Drawable localDrawable = this.d;
      if (localDrawable != null)
        bool2 = localDrawable.getPadding(paramRect);
      else
        bool2 = super.getPadding(paramRect);
    }
    if ((!isAutoMirrored()) || (getLayoutDirection() != n))
      n = 0;
    if (n != 0)
    {
      int i1 = paramRect.left;
      paramRect.left = paramRect.right;
      paramRect.right = i1;
    }
    return bool2;
  }

  public void invalidateDrawable(Drawable paramDrawable)
  {
    b localb = this.b;
    if (localb != null)
      localb.b();
    if ((paramDrawable == this.d) && (getCallback() != null))
      getCallback().invalidateDrawable(this);
  }

  public boolean isAutoMirrored()
  {
    return this.b.E;
  }

  public boolean isStateful()
  {
    b localb = this.b;
    if (localb.v)
      return localb.w;
    localb.c();
    int n = localb.j;
    Drawable[] arrayOfDrawable = localb.i;
    boolean bool;
    for (int i1 = 0; ; i1++)
    {
      bool = false;
      if (i1 >= n)
        break;
      if (arrayOfDrawable[i1].isStateful())
      {
        bool = true;
        break;
      }
    }
    localb.w = bool;
    localb.v = true;
    return bool;
  }

  public void jumpToCurrentState()
  {
    Drawable localDrawable1 = this.e;
    int n;
    if (localDrawable1 != null)
    {
      localDrawable1.jumpToCurrentState();
      this.e = null;
      this.h = -1;
      n = 1;
    }
    else
    {
      n = 0;
    }
    Drawable localDrawable2 = this.d;
    if (localDrawable2 != null)
    {
      localDrawable2.jumpToCurrentState();
      if (this.g)
        this.d.setAlpha(this.f);
    }
    if (this.l != 0L)
    {
      this.l = 0L;
      n = 1;
    }
    if (this.k != 0L)
    {
      this.k = 0L;
      n = 1;
    }
    if (n != 0)
      invalidateSelf();
  }

  public Drawable mutate()
  {
    if ((!this.i) && (super.mutate() == this))
    {
      b localb = b();
      localb.a();
      a(localb);
      this.i = true;
    }
    return this;
  }

  protected void onBoundsChange(Rect paramRect)
  {
    Drawable localDrawable1 = this.e;
    if (localDrawable1 != null)
      localDrawable1.setBounds(paramRect);
    Drawable localDrawable2 = this.d;
    if (localDrawable2 != null)
      localDrawable2.setBounds(paramRect);
  }

  public boolean onLayoutDirectionChanged(int paramInt)
  {
    b localb = this.b;
    int n = this.a;
    int i1 = localb.j;
    Drawable[] arrayOfDrawable = localb.i;
    int i2 = 0;
    boolean bool1 = false;
    while (i2 < i1)
    {
      if (arrayOfDrawable[i2] != null)
      {
        boolean bool2;
        if (Build.VERSION.SDK_INT >= 23)
          bool2 = arrayOfDrawable[i2].setLayoutDirection(paramInt);
        else
          bool2 = false;
        if (i2 == n)
          bool1 = bool2;
      }
      i2++;
    }
    localb.B = paramInt;
    return bool1;
  }

  protected boolean onLevelChange(int paramInt)
  {
    Drawable localDrawable1 = this.e;
    if (localDrawable1 != null)
      return localDrawable1.setLevel(paramInt);
    Drawable localDrawable2 = this.d;
    if (localDrawable2 != null)
      return localDrawable2.setLevel(paramInt);
    return false;
  }

  protected boolean onStateChange(int[] paramArrayOfInt)
  {
    Drawable localDrawable1 = this.e;
    if (localDrawable1 != null)
      return localDrawable1.setState(paramArrayOfInt);
    Drawable localDrawable2 = this.d;
    if (localDrawable2 != null)
      return localDrawable2.setState(paramArrayOfInt);
    return false;
  }

  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong)
  {
    if ((paramDrawable == this.d) && (getCallback() != null))
      getCallback().scheduleDrawable(this, paramRunnable, paramLong);
  }

  public void setAlpha(int paramInt)
  {
    if ((!this.g) || (this.f != paramInt))
    {
      this.g = true;
      this.f = paramInt;
      Drawable localDrawable = this.d;
      if (localDrawable != null)
      {
        if (this.k == 0L)
        {
          localDrawable.setAlpha(paramInt);
          return;
        }
        a(false);
      }
    }
  }

  public void setAutoMirrored(boolean paramBoolean)
  {
    if (this.b.E != paramBoolean)
    {
      b localb = this.b;
      localb.E = paramBoolean;
      Drawable localDrawable = this.d;
      if (localDrawable != null)
        a.a(localDrawable, localb.E);
    }
  }

  public void setColorFilter(ColorFilter paramColorFilter)
  {
    b localb = this.b;
    localb.G = true;
    if (localb.F != paramColorFilter)
    {
      this.b.F = paramColorFilter;
      Drawable localDrawable = this.d;
      if (localDrawable != null)
        localDrawable.setColorFilter(paramColorFilter);
    }
  }

  public void setDither(boolean paramBoolean)
  {
    if (this.b.z != paramBoolean)
    {
      b localb = this.b;
      localb.z = paramBoolean;
      Drawable localDrawable = this.d;
      if (localDrawable != null)
        localDrawable.setDither(localb.z);
    }
  }

  public void setHotspot(float paramFloat1, float paramFloat2)
  {
    Drawable localDrawable = this.d;
    if (localDrawable != null)
      a.a(localDrawable, paramFloat1, paramFloat2);
  }

  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Rect localRect = this.c;
    if (localRect == null)
      this.c = new Rect(paramInt1, paramInt2, paramInt3, paramInt4);
    else
      localRect.set(paramInt1, paramInt2, paramInt3, paramInt4);
    Drawable localDrawable = this.d;
    if (localDrawable != null)
      a.a(localDrawable, paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public void setTintList(ColorStateList paramColorStateList)
  {
    b localb = this.b;
    localb.J = true;
    if (localb.H != paramColorStateList)
    {
      this.b.H = paramColorStateList;
      a.a(this.d, paramColorStateList);
    }
  }

  public void setTintMode(PorterDuff.Mode paramMode)
  {
    b localb = this.b;
    localb.K = true;
    if (localb.I != paramMode)
    {
      this.b.I = paramMode;
      a.a(this.d, paramMode);
    }
  }

  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = super.setVisible(paramBoolean1, paramBoolean2);
    Drawable localDrawable1 = this.e;
    if (localDrawable1 != null)
      localDrawable1.setVisible(paramBoolean1, paramBoolean2);
    Drawable localDrawable2 = this.d;
    if (localDrawable2 != null)
      localDrawable2.setVisible(paramBoolean1, paramBoolean2);
    return bool;
  }

  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable)
  {
    if ((paramDrawable == this.d) && (getCallback() != null))
      getCallback().unscheduleDrawable(this, paramRunnable);
  }

  static final class a
    implements Drawable.Callback
  {
    private Drawable.Callback a;

    static
    {
      CoverageLogger.Log(12630016);
    }

    public final Drawable.Callback a()
    {
      Drawable.Callback localCallback = this.a;
      this.a = null;
      return localCallback;
    }

    public final a a(Drawable.Callback paramCallback)
    {
      this.a = paramCallback;
      return this;
    }

    public final void invalidateDrawable(Drawable paramDrawable)
    {
    }

    public final void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong)
    {
      Drawable.Callback localCallback = this.a;
      if (localCallback != null)
        localCallback.scheduleDrawable(paramDrawable, paramRunnable, paramLong);
    }

    public final void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable)
    {
      Drawable.Callback localCallback = this.a;
      if (localCallback != null)
        localCallback.unscheduleDrawable(paramDrawable, paramRunnable);
    }
  }

  static abstract class b extends Drawable.ConstantState
  {
    boolean A;
    int B;
    public int C;
    public int D;
    boolean E;
    ColorFilter F;
    boolean G;
    ColorStateList H;
    PorterDuff.Mode I;
    boolean J;
    boolean K;
    final b c;
    Resources d;
    int e = 160;
    int f;
    int g;
    SparseArray<Drawable.ConstantState> h;
    Drawable[] i;
    public int j;
    public boolean k;
    boolean l;
    Rect m;
    public boolean n;
    boolean o;
    int p;
    int q;
    int r;
    int s;
    boolean t;
    int u;
    boolean v;
    boolean w;
    boolean x;
    boolean y;
    boolean z = true;

    static
    {
      CoverageLogger.Log(12476416);
    }

    b(b paramb, b paramb1, Resources paramResources)
    {
      this.c = paramb1;
      Resources localResources;
      if (paramResources != null)
        localResources = paramResources;
      else if (paramb != null)
        localResources = paramb.d;
      else
        localResources = null;
      this.d = localResources;
      int i1 = 0;
      int i2;
      if (paramb != null)
        i2 = paramb.e;
      else
        i2 = 0;
      this.e = b.a(paramResources, i2);
      if (paramb != null)
      {
        this.f = paramb.f;
        this.g = paramb.g;
        this.x = true;
        this.y = true;
        this.k = paramb.k;
        this.n = paramb.n;
        this.z = paramb.z;
        this.A = paramb.A;
        this.B = paramb.B;
        this.C = paramb.C;
        this.D = paramb.D;
        this.E = paramb.E;
        this.F = paramb.F;
        this.G = paramb.G;
        this.H = paramb.H;
        this.I = paramb.I;
        this.J = paramb.J;
        this.K = paramb.K;
        if (paramb.e == this.e)
        {
          if (paramb.l)
          {
            this.m = new Rect(paramb.m);
            this.l = true;
          }
          if (paramb.o)
          {
            this.p = paramb.p;
            this.q = paramb.q;
            this.r = paramb.r;
            this.s = paramb.s;
            this.o = true;
          }
        }
        if (paramb.t)
        {
          this.u = paramb.u;
          this.t = true;
        }
        if (paramb.v)
        {
          this.w = paramb.w;
          this.v = true;
        }
        Drawable[] arrayOfDrawable = paramb.i;
        this.i = new Drawable[arrayOfDrawable.length];
        this.j = paramb.j;
        SparseArray localSparseArray = paramb.h;
        if (localSparseArray != null)
          this.h = localSparseArray.clone();
        else
          this.h = new SparseArray(this.j);
        int i3 = this.j;
        while (i1 < i3)
        {
          if (arrayOfDrawable[i1] != null)
          {
            Drawable.ConstantState localConstantState = arrayOfDrawable[i1].getConstantState();
            if (localConstantState != null)
              this.h.put(i1, localConstantState);
            else
              this.i[i1] = arrayOfDrawable[i1];
          }
          i1++;
        }
        return;
      }
      this.i = new Drawable[10];
      this.j = 0;
    }

    private Drawable b(Drawable paramDrawable)
    {
      if (Build.VERSION.SDK_INT >= 23)
        paramDrawable.setLayoutDirection(this.B);
      Drawable localDrawable = paramDrawable.mutate();
      localDrawable.setCallback(this.c);
      return localDrawable;
    }

    private void i()
    {
      this.o = true;
      c();
      int i1 = this.j;
      Drawable[] arrayOfDrawable = this.i;
      this.q = -1;
      this.p = -1;
      int i2 = 0;
      this.s = 0;
      this.r = 0;
      while (i2 < i1)
      {
        Drawable localDrawable = arrayOfDrawable[i2];
        int i3 = localDrawable.getIntrinsicWidth();
        if (i3 > this.p)
          this.p = i3;
        int i4 = localDrawable.getIntrinsicHeight();
        if (i4 > this.q)
          this.q = i4;
        int i5 = localDrawable.getMinimumWidth();
        if (i5 > this.r)
          this.r = i5;
        int i6 = localDrawable.getMinimumHeight();
        if (i6 > this.s)
          this.s = i6;
        i2++;
      }
    }

    public final int a(Drawable paramDrawable)
    {
      int i1 = this.j;
      if (i1 >= this.i.length)
        b(i1, i1 + 10);
      paramDrawable.mutate();
      paramDrawable.setVisible(false, true);
      paramDrawable.setCallback(this.c);
      this.i[i1] = paramDrawable;
      this.j = (1 + this.j);
      this.g |= paramDrawable.getChangingConfigurations();
      b();
      this.m = null;
      this.l = false;
      this.o = false;
      this.x = false;
      return i1;
    }

    void a()
    {
      int i1 = this.j;
      Drawable[] arrayOfDrawable = this.i;
      for (int i2 = 0; i2 < i1; i2++)
        if (arrayOfDrawable[i2] != null)
          arrayOfDrawable[i2].mutate();
      this.A = true;
    }

    final void a(Resources paramResources)
    {
      if (paramResources != null)
      {
        this.d = paramResources;
        int i1 = b.a(paramResources, this.e);
        int i2 = this.e;
        this.e = i1;
        if (i2 != i1)
        {
          this.o = false;
          this.l = false;
        }
      }
    }

    public final Drawable b(int paramInt)
    {
      Drawable localDrawable1 = this.i[paramInt];
      if (localDrawable1 != null)
        return localDrawable1;
      SparseArray localSparseArray = this.h;
      if (localSparseArray != null)
      {
        int i1 = localSparseArray.indexOfKey(paramInt);
        if (i1 >= 0)
        {
          Drawable localDrawable2 = b(((Drawable.ConstantState)this.h.valueAt(i1)).newDrawable(this.d));
          this.i[paramInt] = localDrawable2;
          this.h.removeAt(i1);
          if (this.h.size() == 0)
            this.h = null;
          return localDrawable2;
        }
      }
      return null;
    }

    final void b()
    {
      this.t = false;
      this.v = false;
    }

    public void b(int paramInt1, int paramInt2)
    {
      Drawable[] arrayOfDrawable = new Drawable[paramInt2];
      System.arraycopy(this.i, 0, arrayOfDrawable, 0, paramInt1);
      this.i = arrayOfDrawable;
    }

    void c()
    {
      SparseArray localSparseArray = this.h;
      if (localSparseArray != null)
      {
        int i1 = localSparseArray.size();
        for (int i2 = 0; i2 < i1; i2++)
        {
          int i3 = this.h.keyAt(i2);
          Drawable.ConstantState localConstantState = (Drawable.ConstantState)this.h.valueAt(i2);
          this.i[i3] = b(localConstantState.newDrawable(this.d));
        }
        this.h = null;
      }
    }

    public boolean canApplyTheme()
    {
      int i1 = this.j;
      Drawable[] arrayOfDrawable = this.i;
      for (int i2 = 0; i2 < i1; i2++)
      {
        Drawable localDrawable = arrayOfDrawable[i2];
        if (localDrawable != null)
        {
          if (localDrawable.canApplyTheme())
            return true;
        }
        else
        {
          Drawable.ConstantState localConstantState = (Drawable.ConstantState)this.h.get(i2);
          if ((localConstantState != null) && (localConstantState.canApplyTheme()))
            return true;
        }
      }
      return false;
    }

    public final int d()
    {
      if (!this.o)
        i();
      return this.p;
    }

    public final int e()
    {
      if (!this.o)
        i();
      return this.q;
    }

    public final int f()
    {
      if (!this.o)
        i();
      return this.r;
    }

    public final int g()
    {
      if (!this.o)
        i();
      return this.s;
    }

    public int getChangingConfigurations()
    {
      return this.f | this.g;
    }

    public final boolean h()
    {
      try
      {
        if (this.x)
        {
          boolean bool = this.y;
          return bool;
        }
        c();
        this.x = true;
        int i1 = this.j;
        Drawable[] arrayOfDrawable = this.i;
        for (int i2 = 0; i2 < i1; i2++)
          if (arrayOfDrawable[i2].getConstantState() == null)
          {
            this.y = false;
            return false;
          }
        this.y = true;
        return true;
      }
      finally
      {
      }
      while (true)
        throw localObject;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.b.a.b
 * JD-Core Version:    0.6.2
 */