package androidx.appcompat.b.a;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import androidx.core.graphics.drawable.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d extends Drawable
{
  private static final float i = (float)Math.toRadians(45.0D);
  public final Paint a;
  public float b;
  public float c;
  public float d;
  public float e;
  public boolean f;
  public float g;
  public int h;
  private final Path j;
  private final int k;
  private boolean l;
  private float m;

  static
  {
    CoverageLogger.Log(12632064);
  }

  private static float a(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return paramFloat1 + paramFloat3 * (paramFloat2 - paramFloat1);
  }

  public final void a(float paramFloat)
  {
    if (this.g != paramFloat)
    {
      this.g = paramFloat;
      invalidateSelf();
    }
  }

  public final void a(boolean paramBoolean)
  {
    if (this.l != paramBoolean)
    {
      this.l = paramBoolean;
      invalidateSelf();
    }
  }

  public final void draw(Canvas paramCanvas)
  {
    Rect localRect = getBounds();
    int n = this.h;
    int i1 = 0;
    if (n != 0)
    {
      if (n != 1)
        if (n != 3)
        {
          int i5 = a.g(this);
          i1 = 0;
          if (i5 != 1)
            break label62;
        }
        else
        {
          int i4 = a.g(this);
          i1 = 0;
          if (i4 != 0)
            break label62;
        }
      i1 = 1;
    }
    label62: float f1 = this.b;
    float f2 = (float)Math.sqrt(2.0F * (f1 * f1));
    float f3 = a(this.c, f2, this.g);
    float f4 = a(this.c, this.d, this.g);
    float f5 = Math.round(a(0.0F, this.m, this.g));
    float f6 = a(0.0F, i, this.g);
    float f7;
    if (i1 != 0)
      f7 = 0.0F;
    else
      f7 = -180.0F;
    float f8;
    if (i1 != 0)
      f8 = 180.0F;
    else
      f8 = 0.0F;
    float f9 = a(f7, f8, this.g);
    double d1 = f3;
    double d2 = f6;
    double d3 = Math.cos(d2);
    Double.isNaN(d1);
    double d4 = d3 * d1;
    int i2 = i1;
    float f10 = (float)Math.round(d4);
    double d5 = Math.sin(d2);
    Double.isNaN(d1);
    float f11 = (float)Math.round(d1 * d5);
    this.j.rewind();
    float f12 = a(this.e + this.a.getStrokeWidth(), -this.m, this.g);
    float f13 = -f4 / 2.0F;
    this.j.moveTo(f13 + f5, 0.0F);
    this.j.rLineTo(f4 - f5 * 2.0F, 0.0F);
    this.j.moveTo(f13, f12);
    this.j.rLineTo(f10, f11);
    this.j.moveTo(f13, -f12);
    this.j.rLineTo(f10, -f11);
    this.j.close();
    paramCanvas.save();
    float f14 = this.a.getStrokeWidth();
    float f15 = localRect.height() - 3.0F * f14;
    float f16 = this.e;
    float f17 = 2 * ((int)(f15 - 2.0F * f16) / 4) + (f16 + f14 * 1.5F);
    paramCanvas.translate(localRect.centerX(), f17);
    if (this.f)
    {
      int i3;
      if ((i2 ^ this.l) != 0)
        i3 = -1;
      else
        i3 = 1;
      paramCanvas.rotate(f9 * i3);
    }
    else if (i2 != 0)
    {
      paramCanvas.rotate(180.0F);
    }
    paramCanvas.drawPath(this.j, this.a);
    paramCanvas.restore();
  }

  public final int getIntrinsicHeight()
  {
    return this.k;
  }

  public final int getIntrinsicWidth()
  {
    return this.k;
  }

  public final int getOpacity()
  {
    return -3;
  }

  public final void setAlpha(int paramInt)
  {
    if (paramInt != this.a.getAlpha())
    {
      this.a.setAlpha(paramInt);
      invalidateSelf();
    }
  }

  public final void setColorFilter(ColorFilter paramColorFilter)
  {
    this.a.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.b.a.d
 * JD-Core Version:    0.6.2
 */