package androidx.appcompat.app;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class h
{
  private static h d;
  public long a;
  public long b;
  public int c;

  static
  {
    CoverageLogger.Log(12582912);
  }

  static h a()
  {
    if (d == null)
      d = new h();
    return d;
  }

  public final void a(long paramLong, double paramDouble1, double paramDouble2)
  {
    float f1 = (float)(paramLong - 946728000000L) / 86400000.0F;
    float f2 = 6.24006F + 0.01720197F * f1;
    double d1 = f2;
    double d2 = 0.03341960161924362D * Math.sin(d1);
    Double.isNaN(d1);
    double d3 = 3.141592653589793D + (1.796593063D + (d2 + d1 + 0.0003490659873933D * Math.sin(2.0F * f2) + 5.236000106378924E-006D * Math.sin(f2 * 3.0F)));
    double d4 = -paramDouble2 / 360.0D;
    double d5 = f1 - 0.0009F;
    Double.isNaN(d5);
    double d6 = 0.0009F + (float)Math.round(d5 - d4);
    Double.isNaN(d6);
    double d7 = d6 + d4 + 0.0053D * Math.sin(d1) + -0.0069D * Math.sin(2.0D * d3);
    double d8 = Math.asin(Math.sin(d3) * Math.sin(0.4092797040939331D));
    double d9 = 0.0174532923847437D * paramDouble1;
    double d10 = (Math.sin(-0.1047197580337524D) - Math.sin(d9) * Math.sin(d8)) / (Math.cos(d9) * Math.cos(d8));
    if (d10 >= 1.0D)
    {
      this.c = 1;
      this.a = -1L;
      this.b = -1L;
      return;
    }
    if (d10 <= -1.0D)
    {
      this.c = 0;
      this.a = -1L;
      this.b = -1L;
      return;
    }
    double d11 = (float)(Math.acos(d10) / 6.283185307179586D);
    Double.isNaN(d11);
    this.a = (946728000000L + Math.round(86400000.0D * (d7 + d11)));
    Double.isNaN(d11);
    this.b = (946728000000L + Math.round(86400000.0D * (d7 - d11)));
    if ((this.b < paramLong) && (this.a > paramLong))
    {
      this.c = 0;
      return;
    }
    this.c = 1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.h
 * JD-Core Version:    0.6.2
 */