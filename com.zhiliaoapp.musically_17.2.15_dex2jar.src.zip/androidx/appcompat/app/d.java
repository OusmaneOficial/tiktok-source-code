package androidx.appcompat.app;

import android.app.Dialog;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import androidx.appcompat.view.b;
import androidx.appcompat.view.b.a;
import androidx.appcompat.widget.Toolbar;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class d
{
  public static int a = -1;

  static
  {
    CoverageLogger.Log(12824576);
  }

  public static d a(Dialog paramDialog, c paramc)
  {
    return new AppCompatDelegateImpl(paramDialog.getContext(), paramDialog.getWindow(), paramc);
  }

  public static int k()
  {
    return a;
  }

  public abstract <T extends View> T a(int paramInt);

  public abstract ActionBar a();

  public abstract b a(b.a parama);

  public abstract void a(Configuration paramConfiguration);

  public abstract void a(Bundle paramBundle);

  public abstract void a(View paramView);

  public abstract void a(View paramView, ViewGroup.LayoutParams paramLayoutParams);

  public abstract void a(Toolbar paramToolbar);

  public abstract void a(CharSequence paramCharSequence);

  public abstract MenuInflater b();

  public abstract void b(int paramInt);

  public abstract void b(Bundle paramBundle);

  public abstract void b(View paramView, ViewGroup.LayoutParams paramLayoutParams);

  public abstract void c();

  public abstract void c(Bundle paramBundle);

  public abstract boolean c(int paramInt);

  public abstract void d();

  public abstract void e();

  public abstract void f();

  public abstract void g();

  public abstract a.a h();

  public abstract void i();

  public abstract boolean j();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.d
 * JD-Core Version:    0.6.2
 */