package androidx.appcompat.app;

import androidx.appcompat.view.b;
import androidx.appcompat.view.b.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface c
{
  static
  {
    CoverageLogger.Log(12591104);
  }

  public abstract void onSupportActionModeFinished(b paramb);

  public abstract void onSupportActionModeStarted(b paramb);

  public abstract b onWindowStartingSupportActionMode(b.a parama);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.c
 * JD-Core Version:    0.6.2
 */