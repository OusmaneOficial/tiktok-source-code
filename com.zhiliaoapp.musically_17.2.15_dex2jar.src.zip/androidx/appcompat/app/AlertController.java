package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import androidx.core.widget.NestedScrollView.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;

public final class AlertController
{
  NestedScrollView A;
  int B;
  Drawable C;
  ImageView D;
  TextView E;
  TextView F;
  public View G;
  ListAdapter H;
  int I = -1;
  int J;
  int K;
  int L;
  int M;
  int N;
  int O;
  boolean P;
  public int Q;
  Handler R;
  final View.OnClickListener S = new View.OnClickListener()
  {
    static
    {
      CoverageLogger.Log(12636160);
    }

    public final void onClick(View paramAnonymousView)
    {
      Message localMessage;
      if ((paramAnonymousView == AlertController.this.o) && (AlertController.this.q != null))
        localMessage = Message.obtain(AlertController.this.q);
      else if ((paramAnonymousView == AlertController.this.s) && (AlertController.this.u != null))
        localMessage = Message.obtain(AlertController.this.u);
      else if ((paramAnonymousView == AlertController.this.w) && (AlertController.this.y != null))
        localMessage = Message.obtain(AlertController.this.y);
      else
        localMessage = null;
      if (localMessage != null)
        localMessage.sendToTarget();
      AlertController.this.R.obtainMessage(1, AlertController.this.b).sendToTarget();
    }
  };
  final Context a;
  final e b;
  final Window c;
  final int d;
  CharSequence e;
  CharSequence f;
  public ListView g;
  View h;
  int i;
  int j;
  int k;
  int l;
  int m;
  boolean n;
  public Button o;
  CharSequence p;
  Message q;
  Drawable r;
  public Button s;
  CharSequence t;
  Message u;
  Drawable v;
  public Button w;
  CharSequence x;
  Message y;
  Drawable z;

  static
  {
    CoverageLogger.Log(12810240);
  }

  public AlertController(Context paramContext, e parame, Window paramWindow)
  {
    this.a = paramContext;
    this.b = parame;
    this.c = paramWindow;
    this.R = new b(parame);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(null, new int[] { 16842994, 2130968837, 2130968838, 2130969398, 2130969399, 2130969468, 2130969734, 2130969742 }, 2130968635, 0);
    this.J = localTypedArray.getResourceId(0, 0);
    this.K = localTypedArray.getResourceId(2, 0);
    this.L = localTypedArray.getResourceId(4, 0);
    this.M = localTypedArray.getResourceId(5, 0);
    this.N = localTypedArray.getResourceId(7, 0);
    this.O = localTypedArray.getResourceId(3, 0);
    this.P = localTypedArray.getBoolean(6, true);
    this.d = localTypedArray.getDimensionPixelSize(1, 0);
    localTypedArray.recycle();
    parame.f_(1);
  }

  static ViewGroup a(View paramView1, View paramView2)
  {
    if (paramView1 == null)
    {
      if ((paramView2 instanceof ViewStub))
        paramView2 = ((ViewStub)paramView2).inflate();
      return (ViewGroup)paramView2;
    }
    if (paramView2 != null)
    {
      ViewParent localViewParent = paramView2.getParent();
      if ((localViewParent instanceof ViewGroup))
        ((ViewGroup)localViewParent).removeView(paramView2);
    }
    if ((paramView1 instanceof ViewStub))
      paramView1 = ((ViewStub)paramView1).inflate();
    return (ViewGroup)paramView1;
  }

  static void a(View paramView1, View paramView2, View paramView3)
  {
    if (paramView2 != null)
    {
      int i2;
      if (paramView1.canScrollVertically(-1))
        i2 = 0;
      else
        i2 = 4;
      paramView2.setVisibility(i2);
    }
    if (paramView3 != null)
    {
      int i1;
      if (paramView1.canScrollVertically(1))
        i1 = 0;
      else
        i1 = 4;
      paramView3.setVisibility(i1);
    }
  }

  static void a(Button paramButton)
  {
    LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    localLayoutParams.gravity = 1;
    localLayoutParams.weight = 0.5F;
    paramButton.setLayoutParams(localLayoutParams);
  }

  static boolean a(View paramView)
  {
    if (paramView.onCheckIsTextEditor())
      return true;
    if (!(paramView instanceof ViewGroup))
      return false;
    ViewGroup localViewGroup = (ViewGroup)paramView;
    int i1 = localViewGroup.getChildCount();
    while (i1 > 0)
    {
      i1--;
      if (a(localViewGroup.getChildAt(i1)))
        return true;
    }
    return false;
  }

  public final void a(int paramInt)
  {
    this.C = null;
    this.B = paramInt;
    ImageView localImageView = this.D;
    if (localImageView != null)
    {
      if (paramInt != 0)
      {
        localImageView.setVisibility(0);
        this.D.setImageResource(this.B);
        return;
      }
      localImageView.setVisibility(8);
    }
  }

  public final void a(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage, Drawable paramDrawable)
  {
    if (paramOnClickListener != null)
      paramMessage = this.R.obtainMessage(paramInt, paramOnClickListener);
    if (paramInt != -3)
    {
      if (paramInt != -2)
      {
        if (paramInt == -1)
        {
          this.p = paramCharSequence;
          this.q = paramMessage;
          this.r = paramDrawable;
          return;
        }
        throw new IllegalArgumentException("Button does not exist");
      }
      this.t = paramCharSequence;
      this.u = paramMessage;
      this.v = paramDrawable;
      return;
    }
    this.x = paramCharSequence;
    this.y = paramMessage;
    this.z = paramDrawable;
  }

  public final void a(CharSequence paramCharSequence)
  {
    this.e = paramCharSequence;
    TextView localTextView = this.E;
    if (localTextView != null)
      localTextView.setText(paramCharSequence);
  }

  public static class RecycleListView extends ListView
  {
    final int a;
    final int b;

    static
    {
      CoverageLogger.Log(12812288);
    }

    public RecycleListView(Context paramContext)
    {
      this(paramContext, null);
    }

    public RecycleListView(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 2130969495, 2130969498 });
      this.b = localTypedArray.getDimensionPixelOffset(0, -1);
      this.a = localTypedArray.getDimensionPixelOffset(1, -1);
    }
  }

  public static final class a
  {
    public int A;
    public int B;
    public int C;
    public int D;
    public boolean E;
    public boolean[] F;
    public boolean G;
    public boolean H;
    public int I = -1;
    public DialogInterface.OnMultiChoiceClickListener J;
    public Cursor K;
    public String L;
    public String M;
    public AdapterView.OnItemSelectedListener N;
    public boolean O = true;
    public final Context a;
    public final LayoutInflater b;
    public int c;
    public Drawable d;
    public int e;
    public CharSequence f;
    public View g;
    public CharSequence h;
    public CharSequence i;
    public Drawable j;
    public DialogInterface.OnClickListener k;
    public CharSequence l;
    public Drawable m;
    public DialogInterface.OnClickListener n;
    public CharSequence o;
    public Drawable p;
    public DialogInterface.OnClickListener q;
    public boolean r;
    public DialogInterface.OnCancelListener s;
    public DialogInterface.OnDismissListener t;
    public DialogInterface.OnKeyListener u;
    public CharSequence[] v;
    public ListAdapter w;
    public DialogInterface.OnClickListener x;
    public int y;
    public View z;

    static
    {
      CoverageLogger.Log(12808192);
    }

    public a(Context paramContext)
    {
      this.a = paramContext;
      this.r = true;
      this.b = ((LayoutInflater)paramContext.getSystemService("layout_inflater"));
    }
  }

  static final class b extends Handler
  {
    private WeakReference<DialogInterface> a;

    static
    {
      CoverageLogger.Log(12615680);
    }

    public b(DialogInterface paramDialogInterface)
    {
      this.a = new WeakReference(paramDialogInterface);
    }

    public final void handleMessage(Message paramMessage)
    {
      int i = paramMessage.what;
      if ((i != -3) && (i != -2) && (i != -1))
      {
        if (i != 1)
          return;
        ((DialogInterface)paramMessage.obj).dismiss();
        return;
      }
      ((DialogInterface.OnClickListener)paramMessage.obj).onClick((DialogInterface)this.a.get(), paramMessage.what);
    }
  }

  static final class c extends ArrayAdapter<CharSequence>
  {
    static
    {
      CoverageLogger.Log(12611584);
    }

    public c(Context paramContext, int paramInt1, int paramInt2, CharSequence[] paramArrayOfCharSequence)
    {
      super(paramInt1, 16908308, paramArrayOfCharSequence);
    }

    public final long getItemId(int paramInt)
    {
      return paramInt;
    }

    public final boolean hasStableIds()
    {
      return true;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.AlertController
 * JD-Core Version:    0.6.2
 */