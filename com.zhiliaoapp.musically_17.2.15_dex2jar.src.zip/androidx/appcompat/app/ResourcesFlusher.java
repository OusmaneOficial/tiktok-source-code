package androidx.appcompat.app;

import android.content.res.Resources;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Field;

public class ResourcesFlusher
{
  private static Field sDrawableCacheField;
  private static boolean sDrawableCacheFieldFetched;
  private static Field sResourcesImplField;
  private static boolean sResourcesImplFieldFetched;
  private static Class sThemedResourceCacheClazz;
  private static boolean sThemedResourceCacheClazzFetched;
  private static Field sThemedResourceCache_mUnthemedEntriesField;
  private static boolean sThemedResourceCache_mUnthemedEntriesFieldFetched;

  static
  {
    CoverageLogger.Log(12564480);
  }

  static void flush(Resources paramResources)
  {
    if (Build.VERSION.SDK_INT >= 28)
      return;
    if (Build.VERSION.SDK_INT >= 24)
    {
      flushNougats(paramResources);
      return;
    }
    if (Build.VERSION.SDK_INT >= 23)
    {
      flushMarshmallows(paramResources);
      return;
    }
    if (Build.VERSION.SDK_INT >= 21)
      flushLollipops(paramResources);
  }

  // ERROR //
  private static void flushLollipops(Resources paramResources)
  {
    // Byte code:
    //   0: getstatic 50	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheFieldFetched	Z
    //   3: ifne +31 -> 34
    //   6: ldc 52
    //   8: ldc 54
    //   10: invokevirtual 60	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   13: astore 4
    //   15: aload 4
    //   17: putstatic 62	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheField	Ljava/lang/reflect/Field;
    //   20: aload 4
    //   22: iconst_1
    //   23: invokevirtual 68	java/lang/reflect/Field:setAccessible	(Z)V
    //   26: goto +4 -> 30
    //   29: pop
    //   30: iconst_1
    //   31: putstatic 50	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheFieldFetched	Z
    //   34: getstatic 62	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheField	Ljava/lang/reflect/Field;
    //   37: astore_1
    //   38: aload_1
    //   39: ifnull +27 -> 66
    //   42: aload_1
    //   43: aload_0
    //   44: invokevirtual 72	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   47: checkcast 74	java/util/Map
    //   50: astore_2
    //   51: goto +5 -> 56
    //   54: aconst_null
    //   55: astore_2
    //   56: aload_2
    //   57: ifnull +9 -> 66
    //   60: aload_2
    //   61: invokeinterface 77 1 0
    //   66: return
    //
    // Exception table:
    //   from	to	target	type
    //   6	26	29	java/lang/NoSuchFieldException
    //   42	51	54	java/lang/IllegalAccessException
  }

  // ERROR //
  private static void flushMarshmallows(Resources paramResources)
  {
    // Byte code:
    //   0: getstatic 50	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheFieldFetched	Z
    //   3: ifne +31 -> 34
    //   6: ldc 52
    //   8: ldc 54
    //   10: invokevirtual 60	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   13: astore 4
    //   15: aload 4
    //   17: putstatic 62	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheField	Ljava/lang/reflect/Field;
    //   20: aload 4
    //   22: iconst_1
    //   23: invokevirtual 68	java/lang/reflect/Field:setAccessible	(Z)V
    //   26: goto +4 -> 30
    //   29: pop
    //   30: iconst_1
    //   31: putstatic 50	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheFieldFetched	Z
    //   34: getstatic 62	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheField	Ljava/lang/reflect/Field;
    //   37: astore_1
    //   38: aconst_null
    //   39: astore_2
    //   40: aload_1
    //   41: ifnull +12 -> 53
    //   44: aload_1
    //   45: aload_0
    //   46: invokevirtual 72	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   49: astore_2
    //   50: goto +3 -> 53
    //   53: aload_2
    //   54: ifnonnull +4 -> 58
    //   57: return
    //   58: aload_2
    //   59: invokestatic 81	androidx/appcompat/app/ResourcesFlusher:flushThemedResourcesCache	(Ljava/lang/Object;)V
    //   62: return
    //
    // Exception table:
    //   from	to	target	type
    //   6	26	29	java/lang/NoSuchFieldException
    //   44	50	53	java/lang/IllegalAccessException
  }

  // ERROR //
  private static void flushNougats(Resources paramResources)
  {
    // Byte code:
    //   0: getstatic 83	androidx/appcompat/app/ResourcesFlusher:sResourcesImplFieldFetched	Z
    //   3: ifne +31 -> 34
    //   6: ldc 52
    //   8: ldc 85
    //   10: invokevirtual 60	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   13: astore 8
    //   15: aload 8
    //   17: putstatic 87	androidx/appcompat/app/ResourcesFlusher:sResourcesImplField	Ljava/lang/reflect/Field;
    //   20: aload 8
    //   22: iconst_1
    //   23: invokevirtual 68	java/lang/reflect/Field:setAccessible	(Z)V
    //   26: goto +4 -> 30
    //   29: pop
    //   30: iconst_1
    //   31: putstatic 83	androidx/appcompat/app/ResourcesFlusher:sResourcesImplFieldFetched	Z
    //   34: getstatic 87	androidx/appcompat/app/ResourcesFlusher:sResourcesImplField	Ljava/lang/reflect/Field;
    //   37: astore_1
    //   38: aload_1
    //   39: ifnonnull +4 -> 43
    //   42: return
    //   43: aload_1
    //   44: aload_0
    //   45: invokevirtual 72	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   48: astore_2
    //   49: goto +5 -> 54
    //   52: aconst_null
    //   53: astore_2
    //   54: aload_2
    //   55: ifnonnull +4 -> 59
    //   58: return
    //   59: getstatic 50	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheFieldFetched	Z
    //   62: ifne +33 -> 95
    //   65: aload_2
    //   66: invokevirtual 91	java/lang/Object:getClass	()Ljava/lang/Class;
    //   69: ldc 54
    //   71: invokevirtual 60	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   74: astore 6
    //   76: aload 6
    //   78: putstatic 62	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheField	Ljava/lang/reflect/Field;
    //   81: aload 6
    //   83: iconst_1
    //   84: invokevirtual 68	java/lang/reflect/Field:setAccessible	(Z)V
    //   87: goto +4 -> 91
    //   90: pop
    //   91: iconst_1
    //   92: putstatic 50	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheFieldFetched	Z
    //   95: getstatic 62	androidx/appcompat/app/ResourcesFlusher:sDrawableCacheField	Ljava/lang/reflect/Field;
    //   98: astore_3
    //   99: aconst_null
    //   100: astore 4
    //   102: aload_3
    //   103: ifnull +13 -> 116
    //   106: aload_3
    //   107: aload_2
    //   108: invokevirtual 72	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   111: astore 4
    //   113: goto +3 -> 116
    //   116: aload 4
    //   118: ifnull +8 -> 126
    //   121: aload 4
    //   123: invokestatic 81	androidx/appcompat/app/ResourcesFlusher:flushThemedResourcesCache	(Ljava/lang/Object;)V
    //   126: return
    //
    // Exception table:
    //   from	to	target	type
    //   6	26	29	java/lang/NoSuchFieldException
    //   43	49	52	java/lang/IllegalAccessException
    //   65	87	90	java/lang/NoSuchFieldException
    //   106	113	116	java/lang/IllegalAccessException
  }

  // ERROR //
  private static void flushThemedResourcesCache(Object paramObject)
  {
    // Byte code:
    //   0: getstatic 95	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCacheClazzFetched	Z
    //   3: ifne +19 -> 22
    //   6: ldc 97
    //   8: invokestatic 101	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   11: putstatic 103	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCacheClazz	Ljava/lang/Class;
    //   14: goto +4 -> 18
    //   17: pop
    //   18: iconst_1
    //   19: putstatic 95	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCacheClazzFetched	Z
    //   22: getstatic 103	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCacheClazz	Ljava/lang/Class;
    //   25: astore_1
    //   26: aload_1
    //   27: ifnonnull +4 -> 31
    //   30: return
    //   31: getstatic 105	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCache_mUnthemedEntriesFieldFetched	Z
    //   34: ifne +30 -> 64
    //   37: aload_1
    //   38: ldc 107
    //   40: invokevirtual 60	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   43: astore 5
    //   45: aload 5
    //   47: putstatic 109	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCache_mUnthemedEntriesField	Ljava/lang/reflect/Field;
    //   50: aload 5
    //   52: iconst_1
    //   53: invokevirtual 68	java/lang/reflect/Field:setAccessible	(Z)V
    //   56: goto +4 -> 60
    //   59: pop
    //   60: iconst_1
    //   61: putstatic 105	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCache_mUnthemedEntriesFieldFetched	Z
    //   64: getstatic 109	androidx/appcompat/app/ResourcesFlusher:sThemedResourceCache_mUnthemedEntriesField	Ljava/lang/reflect/Field;
    //   67: astore_2
    //   68: aload_2
    //   69: ifnonnull +4 -> 73
    //   72: return
    //   73: aload_2
    //   74: aload_0
    //   75: invokevirtual 72	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   78: checkcast 111	android/util/LongSparseArray
    //   81: astore_3
    //   82: goto +5 -> 87
    //   85: aconst_null
    //   86: astore_3
    //   87: aload_3
    //   88: ifnull +7 -> 95
    //   91: aload_3
    //   92: invokevirtual 112	android/util/LongSparseArray:clear	()V
    //   95: return
    //
    // Exception table:
    //   from	to	target	type
    //   6	14	17	java/lang/ClassNotFoundException
    //   37	56	59	java/lang/NoSuchFieldException
    //   73	82	85	java/lang/IllegalAccessException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.ResourcesFlusher
 * JD-Core Version:    0.6.2
 */