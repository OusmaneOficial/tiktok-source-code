package androidx.appcompat.app;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import androidx.core.content.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Calendar;

final class i
{
  private static i a;
  private final Context b;
  private final LocationManager c;
  private final a d = new a();

  static
  {
    CoverageLogger.Log(12523520);
  }

  private i(Context paramContext, LocationManager paramLocationManager)
  {
    this.b = paramContext;
    this.c = paramLocationManager;
  }

  // ERROR //
  private Location a(java.lang.String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 34	androidx/appcompat/app/i:c	Landroid/location/LocationManager;
    //   4: aload_1
    //   5: invokevirtual 43	android/location/LocationManager:isProviderEnabled	(Ljava/lang/String;)Z
    //   8: ifeq +34 -> 42
    //   11: aload_0
    //   12: getfield 34	androidx/appcompat/app/i:c	Landroid/location/LocationManager;
    //   15: astore_2
    //   16: aload_2
    //   17: aload_1
    //   18: invokevirtual 46	android/location/LocationManager:getLastKnownLocation	(Ljava/lang/String;)Landroid/location/Location;
    //   21: astore_3
    //   22: aload_3
    //   23: aload_2
    //   24: iconst_1
    //   25: anewarray 4	java/lang/Object
    //   28: dup
    //   29: iconst_0
    //   30: aload_1
    //   31: aastore
    //   32: iconst_0
    //   33: ldc 47
    //   35: ldc 49
    //   37: invokestatic 54	com/bytedance/ugc/security/detection/privacy_detection_dynamic/b:a	(Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;ZILjava/lang/String;)V
    //   40: aload_3
    //   41: areturn
    //   42: aconst_null
    //   43: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	40	42	java/lang/Exception
  }

  static i a(Context paramContext)
  {
    if (a == null)
    {
      Context localContext = paramContext.getApplicationContext();
      a = new i(localContext, (LocationManager)localContext.getSystemService("location"));
    }
    return a;
  }

  private void a(Location paramLocation)
  {
    a locala = this.d;
    long l1 = System.currentTimeMillis();
    h localh = h.a();
    localh.a(l1 - 86400000L, paramLocation.getLatitude(), paramLocation.getLongitude());
    long l2 = localh.a;
    localh.a(l1, paramLocation.getLatitude(), paramLocation.getLongitude());
    boolean bool1;
    if (localh.c == 1)
      bool1 = true;
    else
      bool1 = false;
    long l3 = localh.b;
    long l4 = localh.a;
    long l5 = 86400000L + l1;
    double d1 = paramLocation.getLatitude();
    double d2 = paramLocation.getLongitude();
    boolean bool2 = bool1;
    localh.a(l5, d1, d2);
    long l6 = localh.b;
    long l7;
    if ((l3 != -1L) && (l4 != -1L))
    {
      long l8;
      if (l1 > l4)
        l8 = 0L + l6;
      else if (l1 > l3)
        l8 = 0L + l4;
      else
        l8 = 0L + l3;
      l7 = l8 + 60000L;
    }
    else
    {
      l7 = 43200000L + l1;
    }
    locala.a = bool2;
    locala.b = l2;
    locala.c = l3;
    locala.d = l4;
    locala.e = l6;
    locala.f = l7;
  }

  private Location b()
  {
    Location localLocation1;
    if (d.a(this.b, "android.permission.ACCESS_COARSE_LOCATION") == 0)
      localLocation1 = a("network");
    else
      localLocation1 = null;
    int i = d.a(this.b, "android.permission.ACCESS_FINE_LOCATION");
    Location localLocation2 = null;
    if (i == 0)
      localLocation2 = a("gps");
    if ((localLocation2 != null) && (localLocation1 != null))
    {
      if (localLocation2.getTime() > localLocation1.getTime())
        return localLocation2;
      return localLocation1;
    }
    if (localLocation2 != null)
      return localLocation2;
    return localLocation1;
  }

  private boolean c()
  {
    return this.d.f > System.currentTimeMillis();
  }

  final boolean a()
  {
    a locala = this.d;
    if (c())
      return locala.a;
    Location localLocation = b();
    if (localLocation != null)
    {
      a(localLocation);
      return locala.a;
    }
    int i = Calendar.getInstance().get(11);
    return (i < 6) || (i >= 22);
  }

  static final class a
  {
    boolean a;
    long b;
    long c;
    long d;
    long e;
    long f;

    static
    {
      CoverageLogger.Log(12587008);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.i
 * JD-Core Version:    0.6.2
 */