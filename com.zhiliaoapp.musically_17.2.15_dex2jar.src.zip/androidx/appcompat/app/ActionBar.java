package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import androidx.appcompat.view.b;
import androidx.appcompat.view.b.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class ActionBar
{
  static
  {
    CoverageLogger.Log(12640256);
  }

  public abstract int a();

  public b a(b.a parama)
  {
    return null;
  }

  public void a(float paramFloat)
  {
    if (paramFloat == 0.0F)
      return;
    throw new UnsupportedOperationException("Setting a non-zero elevation is not supported in this action bar configuration.");
  }

  public void a(int paramInt)
  {
  }

  public void a(Configuration paramConfiguration)
  {
  }

  public void a(CharSequence paramCharSequence)
  {
  }

  public abstract void a(boolean paramBoolean);

  public boolean a(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }

  public boolean a(KeyEvent paramKeyEvent)
  {
    return false;
  }

  public abstract void b();

  public abstract void b(boolean paramBoolean);

  public Context c()
  {
    return null;
  }

  public void c(boolean paramBoolean)
  {
    throw new UnsupportedOperationException("Hide on content scroll is not supported in this action bar configuration.");
  }

  public void d(boolean paramBoolean)
  {
  }

  public boolean d()
  {
    return false;
  }

  public void e(boolean paramBoolean)
  {
  }

  public boolean e()
  {
    return false;
  }

  public void f(boolean paramBoolean)
  {
  }

  public boolean f()
  {
    return false;
  }

  public boolean g()
  {
    return false;
  }

  void h()
  {
  }

  public static class LayoutParams extends ViewGroup.MarginLayoutParams
  {
    public int a;

    static
    {
      CoverageLogger.Log(12787712);
    }

    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
      this.a = 8388627;
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16842931 });
      this.a = localTypedArray.getInt(0, 0);
      localTypedArray.recycle();
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(LayoutParams paramLayoutParams)
    {
      super();
      this.a = paramLayoutParams.a;
    }
  }

  public static abstract class a
  {
    static
    {
      CoverageLogger.Log(12642304);
    }

    public abstract Drawable a();

    public abstract CharSequence b();

    public abstract View c();

    public abstract CharSequence d();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.appcompat.app.ActionBar
 * JD-Core Version:    0.6.2
 */