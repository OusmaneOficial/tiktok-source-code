package androidx.customview.view;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class AbsSavedState
  implements Parcelable
{
  public static final Parcelable.Creator<AbsSavedState> CREATOR = new Parcelable.ClassLoaderCreator()
  {
    static
    {
      CoverageLogger.Log(129515520);
    }

    private static AbsSavedState a(Parcel paramAnonymousParcel, ClassLoader paramAnonymousClassLoader)
    {
      if (paramAnonymousParcel.readParcelable(paramAnonymousClassLoader) == null)
        return AbsSavedState.c;
      throw new IllegalStateException("superState must be null");
    }
  };
  public static final AbsSavedState c;
  public final Parcelable d;

  static
  {
    // Byte code:
    //   0: ldc 16
    //   2: invokestatic 22	com/ss/android/ugc/bytex/coverage_lib/CoverageLogger:Log	(I)V
    //   5: new 24	androidx/customview/view/AbsSavedState$1
    //   8: dup
    //   9: invokespecial 27	androidx/customview/view/AbsSavedState$1:<init>	()V
    //   12: putstatic 29	androidx/customview/view/AbsSavedState:c	Landroidx/customview/view/AbsSavedState;
    //   15: new 31	androidx/customview/view/AbsSavedState$2
    //   18: dup
    //   19: invokespecial 32	androidx/customview/view/AbsSavedState$2:<init>	()V
    //   22: putstatic 34	androidx/customview/view/AbsSavedState:CREATOR	Landroid/os/Parcelable$Creator;
    //   25: return
  }

  private AbsSavedState()
  {
  }

  public AbsSavedState(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    Object localObject = paramParcel.readParcelable(paramClassLoader);
    if (localObject == null)
      localObject = c;
    this.d = ((Parcelable)localObject);
  }

  public AbsSavedState(Parcelable paramParcelable)
  {
    if (paramParcelable != null)
    {
      if (paramParcelable == c)
        paramParcelable = null;
      this.d = paramParcelable;
      return;
    }
    throw new IllegalArgumentException("superState must not be null");
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeParcelable(this.d, paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.customview.view.AbsSavedState
 * JD-Core Version:    0.6.2
 */