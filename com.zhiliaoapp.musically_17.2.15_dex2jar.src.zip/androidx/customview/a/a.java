package androidx.customview.a;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Arrays;

public final class a
{
  private static final Interpolator v = new Interpolator()
  {
    static
    {
      CoverageLogger.Log(129624064);
    }

    public final float getInterpolation(float paramAnonymousFloat)
    {
      float f = paramAnonymousFloat - 1.0F;
      return 1.0F + f * (f * (f * (f * f)));
    }
  };
  public int a;
  public int b;
  public int c = -1;
  public float[] d;
  public float[] e;
  public float[] f;
  public float[] g;
  public float h;
  public int i;
  public int j;
  public View k;
  private int[] l;
  private int[] m;
  private int[] n;
  private int o;
  private VelocityTracker p;
  private float q;
  private OverScroller r;
  private final a s;
  private boolean t;
  private final ViewGroup u;
  private final Runnable w = new Runnable()
  {
    static
    {
      CoverageLogger.Log(129505280);
    }

    public final void run()
    {
      a.this.b(0);
    }
  };

  static
  {
    CoverageLogger.Log(129519616);
  }

  private a(Context paramContext, ViewGroup paramViewGroup, a parama)
  {
    if (paramViewGroup != null)
    {
      if (parama != null)
      {
        this.u = paramViewGroup;
        this.s = parama;
        ViewConfiguration localViewConfiguration = ViewConfiguration.get(paramContext);
        this.i = ((int)(0.5F + 20.0F * paramContext.getResources().getDisplayMetrics().density));
        this.b = localViewConfiguration.getScaledTouchSlop();
        this.q = localViewConfiguration.getScaledMaximumFlingVelocity();
        this.h = localViewConfiguration.getScaledMinimumFlingVelocity();
        this.r = new OverScroller(paramContext, v);
        return;
      }
      throw new IllegalArgumentException("Callback may not be null");
    }
    throw new IllegalArgumentException("Parent view may not be null");
  }

  private static float a(float paramFloat)
  {
    return (float)Math.sin(0.4712389F * (paramFloat - 0.5F));
  }

  private static float a(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    float f1 = Math.abs(paramFloat1);
    if (f1 < paramFloat2)
      return 0.0F;
    if (f1 > paramFloat3)
    {
      if (paramFloat1 > 0.0F)
        return paramFloat3;
      paramFloat1 = -paramFloat3;
    }
    return paramFloat1;
  }

  private int a(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 == 0)
      return 0;
    int i1 = this.u.getWidth();
    int i2 = i1 / 2;
    float f1 = Math.min(1.0F, Math.abs(paramInt1) / i1);
    float f2 = i2;
    float f3 = f2 + f2 * a(f1);
    int i3 = Math.abs(paramInt2);
    int i4;
    if (i3 > 0)
      i4 = 4 * Math.round(1000.0F * Math.abs(f3 / i3));
    else
      i4 = (int)(256.0F * (1.0F + Math.abs(paramInt1) / paramInt3));
    return Math.min(i4, 600);
  }

  private int a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i1 = b(paramInt3, (int)this.h, (int)this.q);
    int i2 = b(paramInt4, (int)this.h, (int)this.q);
    int i3 = Math.abs(paramInt1);
    int i4 = Math.abs(paramInt2);
    int i5 = Math.abs(i1);
    int i6 = Math.abs(i2);
    int i7 = i5 + i6;
    int i8 = i3 + i4;
    float f1;
    float f2;
    if (i1 != 0)
    {
      f1 = i5;
      f2 = i7;
    }
    else
    {
      f1 = i3;
      f2 = i8;
    }
    float f3 = f1 / f2;
    float f4;
    float f5;
    if (i2 != 0)
    {
      f4 = i6;
      f5 = i7;
    }
    else
    {
      f4 = i4;
      f5 = i8;
    }
    float f6 = f4 / f5;
    int i9 = a(paramInt1, i1, this.s.a(paramView));
    int i10 = a(paramInt2, i2, this.s.b(paramView));
    return (int)(f3 * i9 + f6 * i10);
  }

  public static a a(ViewGroup paramViewGroup, float paramFloat, a parama)
  {
    a locala = a(paramViewGroup, parama);
    locala.b = ((int)(locala.b * (1.0F / paramFloat)));
    return locala;
  }

  public static a a(ViewGroup paramViewGroup, a parama)
  {
    return new a(paramViewGroup.getContext(), paramViewGroup, parama);
  }

  private void a(float paramFloat1, float paramFloat2)
  {
    this.t = true;
    this.s.a(this.k, paramFloat1, paramFloat2);
    this.t = false;
    if (this.a == 1)
      b(0);
  }

  private void a(float paramFloat1, float paramFloat2, int paramInt)
  {
    float[] arrayOfFloat1 = this.d;
    if ((arrayOfFloat1 == null) || (arrayOfFloat1.length <= paramInt))
    {
      int i1 = paramInt + 1;
      float[] arrayOfFloat2 = new float[i1];
      float[] arrayOfFloat3 = new float[i1];
      float[] arrayOfFloat4 = new float[i1];
      float[] arrayOfFloat5 = new float[i1];
      int[] arrayOfInt1 = new int[i1];
      int[] arrayOfInt2 = new int[i1];
      int[] arrayOfInt3 = new int[i1];
      float[] arrayOfFloat6 = this.d;
      if (arrayOfFloat6 != null)
      {
        System.arraycopy(arrayOfFloat6, 0, arrayOfFloat2, 0, arrayOfFloat6.length);
        float[] arrayOfFloat9 = this.e;
        System.arraycopy(arrayOfFloat9, 0, arrayOfFloat3, 0, arrayOfFloat9.length);
        float[] arrayOfFloat10 = this.f;
        System.arraycopy(arrayOfFloat10, 0, arrayOfFloat4, 0, arrayOfFloat10.length);
        float[] arrayOfFloat11 = this.g;
        System.arraycopy(arrayOfFloat11, 0, arrayOfFloat5, 0, arrayOfFloat11.length);
        int[] arrayOfInt5 = this.l;
        System.arraycopy(arrayOfInt5, 0, arrayOfInt1, 0, arrayOfInt5.length);
        int[] arrayOfInt6 = this.m;
        System.arraycopy(arrayOfInt6, 0, arrayOfInt2, 0, arrayOfInt6.length);
        int[] arrayOfInt7 = this.n;
        System.arraycopy(arrayOfInt7, 0, arrayOfInt3, 0, arrayOfInt7.length);
      }
      this.d = arrayOfFloat2;
      this.e = arrayOfFloat3;
      this.f = arrayOfFloat4;
      this.g = arrayOfFloat5;
      this.l = arrayOfInt1;
      this.m = arrayOfInt2;
      this.n = arrayOfInt3;
    }
    float[] arrayOfFloat7 = this.d;
    this.f[paramInt] = paramFloat1;
    arrayOfFloat7[paramInt] = paramFloat1;
    float[] arrayOfFloat8 = this.e;
    this.g[paramInt] = paramFloat2;
    arrayOfFloat8[paramInt] = paramFloat2;
    int[] arrayOfInt4 = this.l;
    int i2 = (int)paramFloat1;
    int i3 = (int)paramFloat2;
    int i4 = this.u.getLeft() + this.i;
    int i5 = 0;
    if (i2 < i4)
      i5 = 1;
    if (i3 < this.u.getTop() + this.i)
      i5 |= 4;
    if (i2 > this.u.getRight() - this.i)
      i5 |= 2;
    if (i3 > this.u.getBottom() - this.i)
      i5 |= 8;
    arrayOfInt4[paramInt] = i5;
    this.o |= 1 << paramInt;
  }

  private boolean a(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
  {
    float f1 = Math.abs(paramFloat1);
    float f2 = Math.abs(paramFloat2);
    if (((paramInt2 & this.l[paramInt1]) == paramInt2) && ((paramInt2 & this.j) != 0) && ((paramInt2 & this.n[paramInt1]) != paramInt2) && ((paramInt2 & this.m[paramInt1]) != paramInt2))
    {
      int i1 = this.b;
      if ((f1 <= i1) && (f2 <= i1))
        return false;
      if (((paramInt2 & this.m[paramInt1]) == 0) && (f1 > this.b))
        return true;
    }
    return false;
  }

  private boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i1 = this.k.getLeft();
    int i2 = this.k.getTop();
    int i3 = paramInt1 - i1;
    int i4 = paramInt2 - i2;
    if ((i3 == 0) && (i4 == 0))
    {
      this.r.abortAnimation();
      b(0);
      return false;
    }
    int i5 = a(this.k, i3, i4, paramInt3, paramInt4);
    this.r.startScroll(i1, i2, i3, i4, i5);
    b(2);
    return true;
  }

  private boolean a(View paramView, float paramFloat1, float paramFloat2)
  {
    if (paramView == null)
      return false;
    int i1;
    if (this.s.a(paramView) > 0)
      i1 = 1;
    else
      i1 = 0;
    int i2;
    if (this.s.b(paramView) > 0)
      i2 = 1;
    else
      i2 = 0;
    if ((i1 != 0) && (i2 != 0))
    {
      float f1 = paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2;
      int i3 = this.b;
      return f1 > i3 * i3;
    }
    if (i1 != 0)
      return Math.abs(paramFloat1) > this.b;
    return (i2 != 0) && (Math.abs(paramFloat2) > this.b);
  }

  private static int b(int paramInt1, int paramInt2, int paramInt3)
  {
    int i1 = Math.abs(paramInt1);
    if (i1 < paramInt2)
      return 0;
    if (i1 > paramInt3)
    {
      if (paramInt1 > 0)
        return paramInt3;
      paramInt1 = -paramInt3;
    }
    return paramInt1;
  }

  private void b(float paramFloat1, float paramFloat2, int paramInt)
  {
    boolean bool = a(paramFloat1, paramFloat2, paramInt, 1);
    int i1;
    if (a(paramFloat2, paramFloat1, paramInt, 4))
      bool |= true;
    if (a(paramFloat1, paramFloat2, paramInt, 2))
      i1 |= 2;
    if (a(paramFloat2, paramFloat1, paramInt, 8))
      i1 |= 8;
    if (i1 != 0)
    {
      int[] arrayOfInt = this.m;
      arrayOfInt[paramInt] = (i1 | arrayOfInt[paramInt]);
      this.s.b(i1, paramInt);
    }
  }

  private boolean b(View paramView, int paramInt)
  {
    if ((paramView == this.k) && (this.c == paramInt))
      return true;
    if ((paramView != null) && (this.s.b(paramView, paramInt)))
    {
      this.c = paramInt;
      a(paramView, paramInt);
      return true;
    }
    return false;
  }

  public static boolean b(View paramView, int paramInt1, int paramInt2)
  {
    if (paramView == null)
      return false;
    return (paramInt1 >= paramView.getLeft()) && (paramInt1 < paramView.getRight()) && (paramInt2 >= paramView.getTop()) && (paramInt2 < paramView.getBottom());
  }

  private void c()
  {
    this.p.computeCurrentVelocity(1000, this.q);
    a(a(this.p.getXVelocity(this.c), this.h, this.q), a(this.p.getYVelocity(this.c), this.h, this.q));
  }

  private void c(int paramInt)
  {
    if (this.d != null)
    {
      if (!a(paramInt))
        return;
      this.d[paramInt] = 0.0F;
      this.e[paramInt] = 0.0F;
      this.f[paramInt] = 0.0F;
      this.g[paramInt] = 0.0F;
      this.l[paramInt] = 0;
      this.m[paramInt] = 0;
      this.n[paramInt] = 0;
      this.o &= (0xFFFFFFFF ^ 1 << paramInt);
    }
  }

  private void c(MotionEvent paramMotionEvent)
  {
    int i1 = paramMotionEvent.getPointerCount();
    for (int i2 = 0; i2 < i1; i2++)
    {
      int i3 = paramMotionEvent.getPointerId(i2);
      if (d(i3))
      {
        float f1 = paramMotionEvent.getX(i2);
        float f2 = paramMotionEvent.getY(i2);
        this.f[i3] = f1;
        this.g[i3] = f2;
      }
    }
  }

  private boolean d(int paramInt)
  {
    return a(paramInt);
  }

  public final void a()
  {
    this.c = -1;
    float[] arrayOfFloat = this.d;
    if (arrayOfFloat != null)
    {
      Arrays.fill(arrayOfFloat, 0.0F);
      Arrays.fill(this.e, 0.0F);
      Arrays.fill(this.f, 0.0F);
      Arrays.fill(this.g, 0.0F);
      Arrays.fill(this.l, 0);
      Arrays.fill(this.m, 0);
      Arrays.fill(this.n, 0);
      this.o = 0;
    }
    VelocityTracker localVelocityTracker = this.p;
    if (localVelocityTracker != null)
    {
      localVelocityTracker.recycle();
      this.p = null;
    }
  }

  public final void a(View paramView, int paramInt)
  {
    if (paramView.getParent() == this.u)
    {
      this.k = paramView;
      this.c = paramInt;
      this.s.a(paramView, paramInt);
      b(1);
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (");
    localStringBuilder.append(this.u);
    localStringBuilder.append(")");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public final boolean a(int paramInt)
  {
    return (this.o & 1 << paramInt) != 0;
  }

  public final boolean a(int paramInt1, int paramInt2)
  {
    if (this.t)
      return a(paramInt1, paramInt2, (int)this.p.getXVelocity(this.c), (int)this.p.getYVelocity(this.c));
    throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
  }

  public final boolean a(MotionEvent paramMotionEvent)
  {
    int i1 = paramMotionEvent.getActionMasked();
    int i2 = paramMotionEvent.getActionIndex();
    if (i1 == 0)
      a();
    if (this.p == null)
      this.p = VelocityTracker.obtain();
    this.p.addMovement(paramMotionEvent);
    if (i1 != 0)
    {
      if (i1 != 1)
        if (i1 != 2)
        {
          if (i1 != 3)
          {
            if (i1 != 5)
            {
              if (i1 != 6)
                break label620;
              c(paramMotionEvent.getPointerId(i2));
              break label620;
            }
            int i20 = paramMotionEvent.getPointerId(i2);
            float f7 = paramMotionEvent.getX(i2);
            float f8 = paramMotionEvent.getY(i2);
            a(f7, f8, i20);
            int i21 = this.a;
            if (i21 == 0)
            {
              int i22 = this.l[i20];
              int i23 = this.j;
              if ((i22 & i23) == 0)
                break label620;
              this.s.a(i22 & i23, i20);
              break label620;
            }
            if (i21 != 2)
              break label620;
            View localView3 = b((int)f7, (int)f8);
            if (localView3 != this.k)
              break label620;
            b(localView3, i20);
            break label620;
          }
        }
        else
        {
          if ((this.d == null) || (this.e == null))
            break label620;
          int i6 = paramMotionEvent.getPointerCount();
          for (int i7 = 0; i7 < i6; i7++)
          {
            int i8 = paramMotionEvent.getPointerId(i7);
            if (d(i8))
            {
              float f3 = paramMotionEvent.getX(i7);
              float f4 = paramMotionEvent.getY(i7);
              float f5 = f3 - this.d[i8];
              float f6 = f4 - this.e[i8];
              View localView2 = b((int)f3, (int)f4);
              int i9;
              if ((localView2 != null) && (a(localView2, f5, f6)))
                i9 = 1;
              else
                i9 = 0;
              if (i9 != 0)
              {
                int i10 = localView2.getLeft();
                int i11 = (int)f5;
                int i12 = i10 + i11;
                int i13 = this.s.a(localView2, i12, i11);
                int i14 = localView2.getTop();
                int i15 = (int)f6;
                int i16 = i14 + i15;
                int i17 = this.s.b(localView2, i16, i15);
                int i18 = this.s.a(localView2);
                int i19 = this.s.b(localView2);
                if (((i18 == 0) || ((i18 > 0) && (i13 == i10))) && ((i19 == 0) || ((i19 > 0) && (i17 == i14))))
                  break;
              }
              b(f5, f6, i8);
              if ((this.a == 1) || ((i9 != 0) && (b(localView2, i8))))
                break;
            }
          }
          c(paramMotionEvent);
          break label620;
        }
      a();
    }
    else
    {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      int i3 = paramMotionEvent.getPointerId(0);
      a(f1, f2, i3);
      View localView1 = b((int)f1, (int)f2);
      if ((localView1 == this.k) && (this.a == 2))
        b(localView1, i3);
      int i4 = this.l[i3];
      int i5 = this.j;
      if ((i4 & i5) != 0)
        this.s.a(i4 & i5, i3);
    }
    label620: return this.a == 1;
  }

  public final boolean a(View paramView, int paramInt1, int paramInt2)
  {
    this.k = paramView;
    this.c = -1;
    boolean bool = a(paramInt1, paramInt2, 0, 0);
    if ((!bool) && (this.a == 0) && (this.k != null))
      this.k = null;
    return bool;
  }

  public final boolean a(boolean paramBoolean)
  {
    if (this.a == 2)
    {
      boolean bool = this.r.computeScrollOffset();
      int i1 = this.r.getCurrX();
      int i2 = this.r.getCurrY();
      int i3 = i1 - this.k.getLeft();
      int i4 = i2 - this.k.getTop();
      if (i3 != 0)
        t.h(this.k, i3);
      if (i4 != 0)
        t.g(this.k, i4);
      if ((i3 != 0) || (i4 != 0))
        this.s.a(this.k, i1, i2, i3, i4);
      if ((bool) && (i1 == this.r.getFinalX()) && (i2 == this.r.getFinalY()))
      {
        this.r.abortAnimation();
        bool = false;
      }
      if (!bool)
        this.u.post(this.w);
    }
    return this.a == 2;
  }

  public final View b(int paramInt1, int paramInt2)
  {
    for (int i1 = -1 + this.u.getChildCount(); i1 >= 0; i1--)
    {
      View localView = this.u.getChildAt(a.b(i1));
      if ((paramInt1 >= localView.getLeft()) && (paramInt1 < localView.getRight()) && (paramInt2 >= localView.getTop()) && (paramInt2 < localView.getBottom()))
        return localView;
    }
    return null;
  }

  public final void b()
  {
    a();
    if (this.a == 2)
    {
      int i1 = this.r.getCurrX();
      int i2 = this.r.getCurrY();
      this.r.abortAnimation();
      int i3 = this.r.getCurrX();
      int i4 = this.r.getCurrY();
      this.s.a(this.k, i3, i4, i3 - i1, i4 - i2);
    }
    b(0);
  }

  final void b(int paramInt)
  {
    this.u.removeCallbacks(this.w);
    if (this.a != paramInt)
    {
      this.a = paramInt;
      this.s.a(paramInt);
      if (this.a == 0)
        this.k = null;
    }
  }

  public final void b(MotionEvent paramMotionEvent)
  {
    int i1 = paramMotionEvent.getActionMasked();
    int i2 = paramMotionEvent.getActionIndex();
    if (i1 == 0)
      a();
    if (this.p == null)
      this.p = VelocityTracker.obtain();
    this.p.addMovement(paramMotionEvent);
    int i3 = 0;
    if (i1 != 0)
    {
      if (i1 != 1)
      {
        if (i1 != 2)
        {
          if (i1 != 3)
          {
            if (i1 != 5)
            {
              if (i1 != 6)
                return;
              int i26 = paramMotionEvent.getPointerId(i2);
              if ((this.a == 1) && (i26 == this.c))
              {
                int i27 = paramMotionEvent.getPointerCount();
                while (i3 < i27)
                {
                  int i29 = paramMotionEvent.getPointerId(i3);
                  if (i29 != this.c)
                  {
                    float f11 = paramMotionEvent.getX(i3);
                    float f12 = paramMotionEvent.getY(i3);
                    View localView3 = b((int)f11, (int)f12);
                    View localView4 = this.k;
                    if ((localView3 == localView4) && (b(localView4, i29)))
                    {
                      i28 = this.c;
                      break label198;
                    }
                  }
                  i3++;
                }
                int i28 = -1;
                label198: if (i28 == -1)
                  c();
              }
              c(i26);
              return;
            }
            int i21 = paramMotionEvent.getPointerId(i2);
            float f9 = paramMotionEvent.getX(i2);
            float f10 = paramMotionEvent.getY(i2);
            a(f9, f10, i21);
            if (this.a == 0)
            {
              b(b((int)f9, (int)f10), i21);
              int i24 = this.l[i21];
              int i25 = this.j;
              if ((i24 & i25) != 0)
                this.s.a(i24 & i25, i21);
              return;
            }
            int i22 = (int)f9;
            int i23 = (int)f10;
            if (b(this.k, i22, i23))
              b(this.k, i21);
          }
          else
          {
            if (this.a == 1)
              a(0.0F, 0.0F);
            a();
          }
        }
        else if (this.a == 1)
        {
          if (d(this.c))
          {
            int i9 = paramMotionEvent.findPointerIndex(this.c);
            float f7 = paramMotionEvent.getX(i9);
            float f8 = paramMotionEvent.getY(i9);
            float[] arrayOfFloat = this.f;
            int i10 = this.c;
            int i11 = (int)(f7 - arrayOfFloat[i10]);
            int i12 = (int)(f8 - this.g[i10]);
            int i13 = i11 + this.k.getLeft();
            int i14 = i12 + this.k.getTop();
            int i15 = this.k.getLeft();
            int i16 = this.k.getTop();
            if (i11 != 0)
            {
              i13 = this.s.a(this.k, i13, i11);
              t.h(this.k, i13 - i15);
            }
            int i17 = i13;
            if (i12 != 0)
            {
              i14 = this.s.b(this.k, i14, i12);
              t.g(this.k, i14 - i16);
            }
            int i18 = i14;
            if ((i11 != 0) || (i12 != 0))
            {
              int i19 = i17 - i15;
              int i20 = i18 - i16;
              this.s.a(this.k, i17, i18, i19, i20);
            }
            c(paramMotionEvent);
          }
        }
        else
        {
          int i7 = paramMotionEvent.getPointerCount();
          while (i3 < i7)
          {
            int i8 = paramMotionEvent.getPointerId(i3);
            if (d(i8))
            {
              float f3 = paramMotionEvent.getX(i3);
              float f4 = paramMotionEvent.getY(i3);
              float f5 = f3 - this.d[i8];
              float f6 = f4 - this.e[i8];
              b(f5, f6, i8);
              if (this.a == 1)
                break;
              View localView2 = b((int)f3, (int)f4);
              if ((a(localView2, f5, f6)) && (b(localView2, i8)))
                break;
            }
            i3++;
          }
          c(paramMotionEvent);
        }
      }
      else
      {
        if (this.a == 1)
          c();
        a();
      }
    }
    else
    {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      int i4 = paramMotionEvent.getPointerId(0);
      View localView1 = b((int)f1, (int)f2);
      a(f1, f2, i4);
      b(localView1, i4);
      int i5 = this.l[i4];
      int i6 = this.j;
      if ((i5 & i6) != 0)
        this.s.a(i5 & i6, i4);
    }
  }

  public static abstract class a
  {
    static
    {
      CoverageLogger.Log(129503232);
    }

    public static int b(int paramInt)
    {
      return paramInt;
    }

    public int a(View paramView)
    {
      return 0;
    }

    public int a(View paramView, int paramInt1, int paramInt2)
    {
      return 0;
    }

    public void a(int paramInt)
    {
    }

    public void a(int paramInt1, int paramInt2)
    {
    }

    public void a(View paramView, float paramFloat1, float paramFloat2)
    {
    }

    public void a(View paramView, int paramInt)
    {
    }

    public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
    }

    public int b(View paramView)
    {
      return 0;
    }

    public int b(View paramView, int paramInt1, int paramInt2)
    {
      return 0;
    }

    public void b(int paramInt1, int paramInt2)
    {
    }

    public abstract boolean b(View paramView, int paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.customview.a.a
 * JD-Core Version:    0.6.2
 */