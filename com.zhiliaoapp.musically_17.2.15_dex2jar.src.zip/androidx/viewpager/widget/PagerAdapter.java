package androidx.viewpager.widget;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class PagerAdapter
{
  private final DataSetObservable mObservable = new DataSetObservable();
  public DataSetObserver mViewPagerObserver;

  static
  {
    CoverageLogger.Log(28418048);
  }

  public void destroyItem(View paramView, int paramInt, Object paramObject)
  {
    throw new UnsupportedOperationException("Required method destroyItem was not overridden");
  }

  public void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    destroyItem(paramViewGroup, paramInt, paramObject);
  }

  public void finishUpdate(View paramView)
  {
  }

  public void finishUpdate(ViewGroup paramViewGroup)
  {
    finishUpdate(paramViewGroup);
  }

  public abstract int getCount();

  public int getItemPosition(Object paramObject)
  {
    return -1;
  }

  public CharSequence getPageTitle(int paramInt)
  {
    return null;
  }

  public float getPageWidth(int paramInt)
  {
    return 1.0F;
  }

  public Object instantiateItem(View paramView, int paramInt)
  {
    throw new UnsupportedOperationException("Required method instantiateItem was not overridden");
  }

  public Object instantiateItem(ViewGroup paramViewGroup, int paramInt)
  {
    return instantiateItem(paramViewGroup, paramInt);
  }

  public abstract boolean isViewFromObject(View paramView, Object paramObject);

  public void notifyDataSetChanged()
  {
    try
    {
      if (this.mViewPagerObserver != null)
        this.mViewPagerObserver.onChanged();
      this.mObservable.notifyChanged();
      return;
    }
    finally
    {
    }
  }

  public void registerDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    this.mObservable.registerObserver(paramDataSetObserver);
  }

  public void restoreState(Parcelable paramParcelable, ClassLoader paramClassLoader)
  {
  }

  public Parcelable saveState()
  {
    return null;
  }

  public void setPrimaryItem(View paramView, int paramInt, Object paramObject)
  {
  }

  public void setPrimaryItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    setPrimaryItem(paramViewGroup, paramInt, paramObject);
  }

  public void setViewPagerObserver(DataSetObserver paramDataSetObserver)
  {
    try
    {
      this.mViewPagerObserver = paramDataSetObserver;
      return;
    }
    finally
    {
    }
  }

  public void startUpdate(View paramView)
  {
  }

  public void startUpdate(ViewGroup paramViewGroup)
  {
    startUpdate(paramViewGroup);
  }

  public void unregisterDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    this.mObservable.unregisterObserver(paramDataSetObserver);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.viewpager.widget.PagerAdapter
 * JD-Core Version:    0.6.2
 */