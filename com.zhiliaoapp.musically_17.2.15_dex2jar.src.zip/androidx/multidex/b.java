package androidx.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;
import com.ss.android.ugc.aweme.keva.e;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

final class b
  implements Closeable
{
  private final File a;
  private final long b;
  private final File c;
  private final RandomAccessFile d;
  private final FileChannel e;
  private final FileLock f;

  static
  {
    CoverageLogger.Log(88563712);
  }

  b(File paramFile1, File paramFile2)
    throws IOException
  {
    this.a = paramFile1;
    this.c = paramFile2;
    this.b = b(paramFile1);
    this.d = new RandomAccessFile(new File(paramFile2, "MultiDex.lock"), "rw");
    try
    {
      this.e = this.d.getChannel();
      try
      {
        this.f = this.e.lock();
        return;
      }
      catch (Error localError2)
      {
      }
      catch (RuntimeException localRuntimeException2)
      {
      }
      catch (IOException localIOException2)
      {
      }
      a(this.e);
      throw localIOException2;
    }
    catch (Error localError1)
    {
    }
    catch (RuntimeException localRuntimeException1)
    {
    }
    catch (IOException localIOException1)
    {
    }
    a(this.d);
    throw localIOException1;
  }

  private static long a(File paramFile)
  {
    long l = paramFile.lastModified();
    if (l == -1L)
      l -= 1L;
    return l;
  }

  private static SharedPreferences a(Context paramContext)
  {
    int i;
    if (Build.VERSION.SDK_INT < 11)
      i = 0;
    else
      i = 4;
    return e.a(paramContext, "multidex.version", i);
  }

  private List<a> a()
    throws IOException
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    localStringBuilder1.append(this.a.getName());
    localStringBuilder1.append(".classes");
    String str1 = localStringBuilder1.toString();
    b();
    ArrayList localArrayList = new ArrayList();
    ZipFile localZipFile = new ZipFile(this.a);
    try
    {
      StringBuilder localStringBuilder2 = new StringBuilder("classes");
      int i = 2;
      localStringBuilder2.append(i);
      localStringBuilder2.append(".dex");
      ZipEntry localZipEntry = localZipFile.getEntry(localStringBuilder2.toString());
      while (localZipEntry != null)
      {
        StringBuilder localStringBuilder3 = new StringBuilder();
        localStringBuilder3.append(str1);
        localStringBuilder3.append(i);
        localStringBuilder3.append(".zip");
        String str2 = localStringBuilder3.toString();
        a locala = new a(this.c, str2);
        localArrayList.add(locala);
        int j = 0;
        int k = 0;
        while ((j < 3) && (k == 0))
        {
          j++;
          a(localZipFile, localZipEntry, locala, str1);
          try
          {
            locala.a = b(locala);
            k = 1;
          }
          catch (IOException localIOException1)
          {
            k = 0;
            localStringBuilder6 = new StringBuilder("Extraction ");
            if (k == 0)
              break label470;
            str3 = "succeeded";
            tmpTernaryOp = localIOException1;
          }
          StringBuilder localStringBuilder6;
          localStringBuilder6.append(str3);
          localStringBuilder6.append(" '");
          localStringBuilder6.append(locala.getAbsolutePath());
          localStringBuilder6.append("': length ");
          localStringBuilder6.append(locala.length());
          localStringBuilder6.append(" - crc: ");
          localStringBuilder6.append(locala.a);
          if (k == 0)
          {
            locala.delete();
            locala.exists();
          }
        }
        if (k != 0)
        {
          i++;
          StringBuilder localStringBuilder5 = new StringBuilder("classes");
          localStringBuilder5.append(i);
          localStringBuilder5.append(".dex");
          localZipEntry = localZipFile.getEntry(localStringBuilder5.toString());
        }
        else
        {
          StringBuilder localStringBuilder4 = new StringBuilder("Could not create zip file ");
          localStringBuilder4.append(locala.getAbsolutePath());
          localStringBuilder4.append(" for secondary dex (");
          localStringBuilder4.append(i);
          localStringBuilder4.append(")");
          throw new IOException(localStringBuilder4.toString());
        }
      }
      try
      {
        localZipFile.close();
      }
      catch (IOException localIOException2)
      {
      }
      return localArrayList;
    }
    finally
    {
      while (true)
      {
        try
        {
          localZipFile.close();
        }
        catch (IOException localIOException3)
        {
        }
        while (true)
          throw localObject;
        label470: String str3 = "failed";
      }
    }
  }

  private List<a> a(Context paramContext, String paramString)
    throws IOException
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    localStringBuilder1.append(this.a.getName());
    localStringBuilder1.append(".classes");
    Object localObject1 = localStringBuilder1.toString();
    Object localObject2 = a(paramContext);
    StringBuilder localStringBuilder2 = new StringBuilder();
    localStringBuilder2.append(paramString);
    localStringBuilder2.append("dex.number");
    int i = ((SharedPreferences)localObject2).getInt(localStringBuilder2.toString(), 1);
    ArrayList localArrayList = new ArrayList(i - 1);
    int j = 2;
    while (j <= i)
    {
      StringBuilder localStringBuilder3 = new StringBuilder();
      localStringBuilder3.append((String)localObject1);
      localStringBuilder3.append(j);
      localStringBuilder3.append(".zip");
      String str = localStringBuilder3.toString();
      a locala = new a(this.c, str);
      if (locala.isFile())
      {
        locala.a = b(locala);
        StringBuilder localStringBuilder5 = new StringBuilder();
        localStringBuilder5.append(paramString);
        localStringBuilder5.append("dex.crc.");
        localStringBuilder5.append(j);
        long l1 = ((SharedPreferences)localObject2).getLong(localStringBuilder5.toString(), -1L);
        StringBuilder localStringBuilder6 = new StringBuilder();
        localStringBuilder6.append(paramString);
        localStringBuilder6.append("dex.time.");
        localStringBuilder6.append(j);
        long l2 = ((SharedPreferences)localObject2).getLong(localStringBuilder6.toString(), -1L);
        long l3 = locala.lastModified();
        if (l2 == l3)
        {
          Object localObject3 = localObject1;
          Object localObject4 = localObject2;
          if (l1 == locala.a)
          {
            localArrayList.add(locala);
            j++;
            localObject2 = localObject4;
            localObject1 = localObject3;
          }
        }
        else
        {
          StringBuilder localStringBuilder7 = new StringBuilder("Invalid extracted dex: ");
          localStringBuilder7.append(locala);
          localStringBuilder7.append(" (key \"");
          localStringBuilder7.append(paramString);
          localStringBuilder7.append("\"), expected modification time: ");
          localStringBuilder7.append(l2);
          localStringBuilder7.append(", modification time: ");
          localStringBuilder7.append(l3);
          localStringBuilder7.append(", expected crc: ");
          localStringBuilder7.append(l1);
          localStringBuilder7.append(", file crc: ");
          localStringBuilder7.append(locala.a);
          throw new IOException(localStringBuilder7.toString());
        }
      }
      else
      {
        StringBuilder localStringBuilder4 = new StringBuilder("Missing extracted secondary dex file '");
        localStringBuilder4.append(locala.getPath());
        localStringBuilder4.append("'");
        throw new IOException(localStringBuilder4.toString());
      }
    }
    return localArrayList;
  }

  private static void a(Context paramContext, String paramString, long paramLong1, long paramLong2, List<a> paramList)
  {
    SharedPreferences.Editor localEditor = a(paramContext).edit();
    StringBuilder localStringBuilder1 = new StringBuilder();
    localStringBuilder1.append(paramString);
    localStringBuilder1.append("timestamp");
    localEditor.putLong(localStringBuilder1.toString(), paramLong1);
    StringBuilder localStringBuilder2 = new StringBuilder();
    localStringBuilder2.append(paramString);
    localStringBuilder2.append("crc");
    localEditor.putLong(localStringBuilder2.toString(), paramLong2);
    StringBuilder localStringBuilder3 = new StringBuilder();
    localStringBuilder3.append(paramString);
    localStringBuilder3.append("dex.number");
    localEditor.putInt(localStringBuilder3.toString(), 1 + paramList.size());
    Iterator localIterator = paramList.iterator();
    for (int i = 2; localIterator.hasNext(); i++)
    {
      a locala = (a)localIterator.next();
      StringBuilder localStringBuilder4 = new StringBuilder();
      localStringBuilder4.append(paramString);
      localStringBuilder4.append("dex.crc.");
      localStringBuilder4.append(i);
      localEditor.putLong(localStringBuilder4.toString(), locala.a);
      StringBuilder localStringBuilder5 = new StringBuilder();
      localStringBuilder5.append(paramString);
      localStringBuilder5.append("dex.time.");
      localStringBuilder5.append(i);
      localEditor.putLong(localStringBuilder5.toString(), locala.lastModified());
    }
    localEditor.commit();
  }

  private static void a(Closeable paramCloseable)
  {
    try
    {
      paramCloseable.close();
    }
    catch (IOException localIOException)
    {
    }
  }

  private static void a(ZipFile paramZipFile, ZipEntry paramZipEntry, File paramFile, String paramString)
    throws IOException, FileNotFoundException
  {
    InputStream localInputStream = paramZipFile.getInputStream(paramZipEntry);
    StringBuilder localStringBuilder1 = new StringBuilder("tmp-");
    localStringBuilder1.append(paramString);
    File localFile = File.createTempFile(localStringBuilder1.toString(), ".zip", paramFile.getParentFile());
    try
    {
      ZipOutputStream localZipOutputStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(localFile)));
      try
      {
        ZipEntry localZipEntry = new ZipEntry("classes.dex");
        localZipEntry.setTime(paramZipEntry.getTime());
        localZipOutputStream.putNextEntry(localZipEntry);
        byte[] arrayOfByte = new byte[16384];
        for (int i = localInputStream.read(arrayOfByte); i != -1; i = localInputStream.read(arrayOfByte))
          localZipOutputStream.write(arrayOfByte, 0, i);
        localZipOutputStream.closeEntry();
        localZipOutputStream.close();
        if (localFile.setReadOnly())
        {
          boolean bool = localFile.renameTo(paramFile);
          if (bool)
          {
            a(localInputStream);
            localFile.delete();
            return;
          }
          StringBuilder localStringBuilder3 = new StringBuilder("Failed to rename \"");
          localStringBuilder3.append(localFile.getAbsolutePath());
          localStringBuilder3.append("\" to \"");
          localStringBuilder3.append(paramFile.getAbsolutePath());
          localStringBuilder3.append("\"");
          throw new IOException(localStringBuilder3.toString());
        }
        StringBuilder localStringBuilder2 = new StringBuilder("Failed to mark readonly \"");
        localStringBuilder2.append(localFile.getAbsolutePath());
        localStringBuilder2.append("\" (tmp of \"");
        localStringBuilder2.append(paramFile.getAbsolutePath());
        localStringBuilder2.append("\")");
        throw new IOException(localStringBuilder2.toString());
      }
      finally
      {
        localZipOutputStream.close();
      }
    }
    finally
    {
      a(localInputStream);
      localFile.delete();
    }
    while (true)
      throw localObject2;
  }

  private static long b(File paramFile)
    throws IOException
  {
    long l = c.a(paramFile);
    if (l == -1L)
      l -= 1L;
    return l;
  }

  private void b()
  {
    File[] arrayOfFile = this.c.listFiles(new FileFilter()
    {
      static
      {
        CoverageLogger.Log(88557568);
      }

      public final boolean accept(File paramAnonymousFile)
      {
        return !paramAnonymousFile.getName().equals("MultiDex.lock");
      }
    });
    if (arrayOfFile == null)
      return;
    int i = arrayOfFile.length;
    for (int j = 0; j < i; j++)
      arrayOfFile[j].delete();
  }

  // ERROR //
  final List<? extends File> a(Context paramContext, String paramString, boolean paramBoolean)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 73	androidx/multidex/b:f	Ljava/nio/channels/FileLock;
    //   4: invokevirtual 375	java/nio/channels/FileLock:isValid	()Z
    //   7: ifeq +173 -> 180
    //   10: iload_3
    //   11: ifne +142 -> 153
    //   14: aload_0
    //   15: getfield 38	androidx/multidex/b:a	Ljava/io/File;
    //   18: astore 5
    //   20: aload_0
    //   21: getfield 45	androidx/multidex/b:b	J
    //   24: lstore 6
    //   26: aload_1
    //   27: invokestatic 194	androidx/multidex/b:a	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   30: astore 8
    //   32: new 99	java/lang/StringBuilder
    //   35: dup
    //   36: invokespecial 100	java/lang/StringBuilder:<init>	()V
    //   39: astore 9
    //   41: aload 9
    //   43: aload_2
    //   44: invokevirtual 108	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: pop
    //   48: aload 9
    //   50: ldc 245
    //   52: invokevirtual 108	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: pop
    //   56: aload 8
    //   58: aload 9
    //   60: invokevirtual 113	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   63: ldc2_w 81
    //   66: invokeinterface 213 4 0
    //   71: aload 5
    //   73: invokestatic 376	androidx/multidex/b:a	(Ljava/io/File;)J
    //   76: lcmp
    //   77: ifne +57 -> 134
    //   80: new 99	java/lang/StringBuilder
    //   83: dup
    //   84: invokespecial 100	java/lang/StringBuilder:<init>	()V
    //   87: astore 12
    //   89: aload 12
    //   91: aload_2
    //   92: invokevirtual 108	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: pop
    //   96: aload 12
    //   98: ldc 253
    //   100: invokevirtual 108	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload 8
    //   106: aload 12
    //   108: invokevirtual 113	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   111: ldc2_w 81
    //   114: invokeinterface 213 4 0
    //   119: lload 6
    //   121: lcmp
    //   122: ifeq +6 -> 128
    //   125: goto +9 -> 134
    //   128: iconst_0
    //   129: istore 15
    //   131: goto +6 -> 137
    //   134: iconst_1
    //   135: istore 15
    //   137: iload 15
    //   139: ifne +14 -> 153
    //   142: aload_0
    //   143: aload_1
    //   144: aload_2
    //   145: invokespecial 378	androidx/multidex/b:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/util/List;
    //   148: astore 16
    //   150: aload 16
    //   152: areturn
    //   153: aload_0
    //   154: invokespecial 380	androidx/multidex/b:a	()Ljava/util/List;
    //   157: astore 4
    //   159: aload_1
    //   160: aload_2
    //   161: aload_0
    //   162: getfield 38	androidx/multidex/b:a	Ljava/io/File;
    //   165: invokestatic 376	androidx/multidex/b:a	(Ljava/io/File;)J
    //   168: aload_0
    //   169: getfield 45	androidx/multidex/b:b	J
    //   172: aload 4
    //   174: invokestatic 382	androidx/multidex/b:a	(Landroid/content/Context;Ljava/lang/String;JJLjava/util/List;)V
    //   177: aload 4
    //   179: areturn
    //   180: new 384	java/lang/IllegalStateException
    //   183: dup
    //   184: ldc_w 386
    //   187: invokespecial 387	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   190: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   142	150	153	java/io/IOException
  }

  public final void close()
    throws IOException
  {
    this.f.release();
    this.e.close();
    this.d.close();
  }

  static final class a extends File
  {
    public long a = -1L;

    static
    {
      CoverageLogger.Log(88793088);
    }

    public a(File paramFile, String paramString)
    {
      super(paramString);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.multidex.b
 * JD-Core Version:    0.6.2
 */