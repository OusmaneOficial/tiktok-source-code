package androidx.multidex;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.zip.CRC32;
import java.util.zip.ZipException;

final class c
{
  static
  {
    CoverageLogger.Log(88795136);
  }

  static long a(File paramFile)
    throws IOException
  {
    RandomAccessFile localRandomAccessFile = new RandomAccessFile(paramFile, "r");
    try
    {
      long l = a(localRandomAccessFile, a(localRandomAccessFile));
      return l;
    }
    finally
    {
      localRandomAccessFile.close();
    }
  }

  private static long a(RandomAccessFile paramRandomAccessFile, a parama)
    throws IOException
  {
    CRC32 localCRC32 = new CRC32();
    long l = parama.b;
    paramRandomAccessFile.seek(parama.a);
    int i = (int)Math.min(16384L, l);
    byte[] arrayOfByte = new byte[16384];
    for (int j = paramRandomAccessFile.read(arrayOfByte, 0, i); j != -1; j = paramRandomAccessFile.read(arrayOfByte, 0, (int)Math.min(16384L, l)))
    {
      localCRC32.update(arrayOfByte, 0, j);
      l -= j;
      if (l == 0L)
        break;
    }
    return localCRC32.getValue();
  }

  private static a a(RandomAccessFile paramRandomAccessFile)
    throws IOException, ZipException
  {
    long l1 = paramRandomAccessFile.length() - 22L;
    long l2 = 0L;
    if (l1 >= l2)
    {
      long l3 = l1 - 65536L;
      if (l3 >= l2)
        l2 = l3;
      int i = Integer.reverseBytes(101010256);
      do
      {
        paramRandomAccessFile.seek(l1);
        if (paramRandomAccessFile.readInt() == i)
          break;
        l1 -= 1L;
      }
      while (l1 >= l2);
      throw new ZipException("End Of Central Directory signature not found");
      paramRandomAccessFile.skipBytes(2);
      paramRandomAccessFile.skipBytes(2);
      paramRandomAccessFile.skipBytes(2);
      paramRandomAccessFile.skipBytes(2);
      a locala = new a();
      locala.b = (0xFFFFFFFF & Integer.reverseBytes(paramRandomAccessFile.readInt()));
      locala.a = (0xFFFFFFFF & Integer.reverseBytes(paramRandomAccessFile.readInt()));
      return locala;
    }
    StringBuilder localStringBuilder = new StringBuilder("File too short to be a zip file: ");
    localStringBuilder.append(paramRandomAccessFile.length());
    ZipException localZipException = new ZipException(localStringBuilder.toString());
    while (true)
      throw localZipException;
  }

  static final class a
  {
    long a;
    long b;

    static
    {
      CoverageLogger.Log(88797184);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.multidex.c
 * JD-Core Version:    0.6.2
 */