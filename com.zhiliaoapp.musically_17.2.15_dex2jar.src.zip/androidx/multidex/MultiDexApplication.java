package androidx.multidex;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.File;

public class MultiDexApplication extends Application
{
  static
  {
    CoverageLogger.Log(88788992);
  }

  protected void attachBaseContext(Context paramContext)
  {
    super.attachBaseContext(paramContext);
    if (!a.a)
    {
      if (Build.VERSION.SDK_INT >= 4)
        try
        {
          ApplicationInfo localApplicationInfo = a.a(this);
          if (localApplicationInfo == null)
            return;
          a.a(this, new File(localApplicationInfo.sourceDir), new File(localApplicationInfo.dataDir), "secondary-dexes", "", true);
          return;
        }
        catch (Exception localException)
        {
          StringBuilder localStringBuilder2 = new StringBuilder("MultiDex installation failed (");
          localStringBuilder2.append(localException.getMessage());
          localStringBuilder2.append(").");
          throw new RuntimeException(localStringBuilder2.toString());
        }
      StringBuilder localStringBuilder1 = new StringBuilder("MultiDex installation failed. SDK ");
      localStringBuilder1.append(Build.VERSION.SDK_INT);
      localStringBuilder1.append(" is unsupported. Min SDK version is 4");
      localStringBuilder1.append(".");
      throw new RuntimeException(localStringBuilder1.toString());
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.multidex.MultiDexApplication
 * JD-Core Version:    0.6.2
 */