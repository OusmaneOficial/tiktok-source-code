package androidx.coordinatorlayout.widget;

import androidx.c.g;
import androidx.core.g.f.a;
import androidx.core.g.f.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public final class a<T>
{
  final f.a<ArrayList<T>> a = new f.b(10);
  final g<T, ArrayList<T>> b = new g();
  private final ArrayList<T> c = new ArrayList();
  private final HashSet<T> d = new HashSet();

  static
  {
    CoverageLogger.Log(55894016);
  }

  private void a(T paramT, ArrayList<T> paramArrayList, HashSet<T> paramHashSet)
  {
    if (paramArrayList.contains(paramT))
      return;
    if (!paramHashSet.contains(paramT))
    {
      paramHashSet.add(paramT);
      ArrayList localArrayList = (ArrayList)this.b.get(paramT);
      if (localArrayList != null)
      {
        int i = 0;
        int j = localArrayList.size();
        while (i < j)
        {
          a(localArrayList.get(i), paramArrayList, paramHashSet);
          i++;
        }
      }
      paramHashSet.remove(paramT);
      paramArrayList.add(paramT);
      return;
    }
    RuntimeException localRuntimeException = new RuntimeException("This graph contains cyclic dependencies");
    while (true)
      throw localRuntimeException;
  }

  public final ArrayList<T> a()
  {
    this.c.clear();
    this.d.clear();
    int i = this.b.size();
    for (int j = 0; j < i; j++)
      a(this.b.b(j), this.c, this.d);
    return this.c;
  }

  public final void a(T paramT)
  {
    if (!this.b.containsKey(paramT))
      this.b.put(paramT, null);
  }

  public final List b(T paramT)
  {
    return (List)this.b.get(paramT);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.coordinatorlayout.widget.a
 * JD-Core Version:    0.6.2
 */