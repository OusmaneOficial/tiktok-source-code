package androidx.h;

import androidx.recyclerview.widget.RecyclerView.a;
import androidx.recyclerview.widget.b;
import androidx.recyclerview.widget.c;
import androidx.recyclerview.widget.c.a;
import androidx.recyclerview.widget.h.b;
import androidx.recyclerview.widget.s;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

public final class a<T>
{
  public final s a;
  public final c<T> b;
  Executor c = androidx.a.a.a.a.b();
  a<T> d;
  public boolean e;
  public h<T> f;
  public h<T> g;
  public int h;
  public h.c i = new h.c()
  {
    static
    {
      CoverageLogger.Log(78968832);
    }

    public final void a(int paramAnonymousInt1, int paramAnonymousInt2)
    {
      a.this.a.a(paramAnonymousInt1, paramAnonymousInt2);
    }

    public final void b(int paramAnonymousInt1, int paramAnonymousInt2)
    {
      a.this.a.a(paramAnonymousInt1, paramAnonymousInt2, null);
    }
  };

  static
  {
    CoverageLogger.Log(78962688);
  }

  public a(RecyclerView.a parama, androidx.recyclerview.widget.h.c<T> paramc)
  {
    this.a = new b(parama);
    this.b = new c.a(paramc).a();
  }

  public final int a()
  {
    h localh1 = this.f;
    if (localh1 != null)
      return localh1.size();
    h localh2 = this.g;
    if (localh2 == null)
      return 0;
    return localh2.size();
  }

  static abstract interface a<T>
  {
    static
    {
      CoverageLogger.Log(78964736);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.h.a
 * JD-Core Version:    0.6.2
 */