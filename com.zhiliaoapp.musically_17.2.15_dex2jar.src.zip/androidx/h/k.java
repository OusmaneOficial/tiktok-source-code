package androidx.h;

import androidx.recyclerview.widget.h.a;
import androidx.recyclerview.widget.h.b;
import androidx.recyclerview.widget.h.c;
import androidx.recyclerview.widget.s;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class k
{
  static
  {
    CoverageLogger.Log(79104000);
  }

  static int a(h.b paramb, j paramj1, j paramj2, int paramInt)
  {
    int i = paramj1.b();
    int j = paramInt - i;
    int k = paramj1.size() - i - paramj1.c();
    if ((j >= 0) && (j < k))
      for (int m = 0; m < 30; m++)
      {
        int n = m / 2;
        int i1;
        if (m % 2 == 1)
          i1 = -1;
        else
          i1 = 1;
        int i2 = j + n * i1;
        if ((i2 >= 0) && (i2 < paramj1.f))
          if ((i2 >= 0) && (i2 < paramb.b.length))
          {
            int i3 = paramb.b[i2];
            int i4;
            if ((i3 & 0x1F) == 0)
              i4 = -1;
            else
              i4 = i3 >> 5;
            if (i4 != -1)
              return i4 + paramj2.b;
          }
          else
          {
            StringBuilder localStringBuilder = new StringBuilder("Index out of bounds - passed position = ");
            localStringBuilder.append(i2);
            localStringBuilder.append(", old list size = ");
            localStringBuilder.append(paramb.b.length);
            throw new IndexOutOfBoundsException(localStringBuilder.toString());
          }
      }
    return Math.max(0, Math.min(paramInt, paramj2.size() - 1));
  }

  static final class a
    implements s
  {
    private final int a;
    private final s b;

    static
    {
      CoverageLogger.Log(78946304);
    }

    a(int paramInt, s params)
    {
      this.a = paramInt;
      this.b = params;
    }

    public final void a(int paramInt1, int paramInt2)
    {
      this.b.a(paramInt1 + this.a, paramInt2);
    }

    public final void a(int paramInt1, int paramInt2, Object paramObject)
    {
      this.b.a(paramInt1 + this.a, paramInt2, paramObject);
    }

    public final void b(int paramInt1, int paramInt2)
    {
      this.b.b(paramInt1 + this.a, paramInt2);
    }

    public final void c(int paramInt1, int paramInt2)
    {
      s locals = this.b;
      int i = this.a;
      locals.c(paramInt1 + i, paramInt2 + i);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.h.k
 * JD-Core Version:    0.6.2
 */