package androidx.h;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class d<Key, Value>
{
  private AtomicBoolean a = new AtomicBoolean(false);
  private CopyOnWriteArrayList<b> b = new CopyOnWriteArrayList();

  static
  {
    CoverageLogger.Log(81195008);
  }

  public void a(b paramb)
  {
    this.b.add(paramb);
  }

  abstract boolean a();

  public void b()
  {
    if (this.a.compareAndSet(false, true))
    {
      Iterator localIterator = this.b.iterator();
      while (localIterator.hasNext())
        ((b)localIterator.next()).c_();
    }
  }

  public void b(b paramb)
  {
    this.b.remove(paramb);
  }

  public boolean c()
  {
    return this.a.get();
  }

  public static abstract class a<Key, Value>
  {
    static
    {
      CoverageLogger.Log(81180672);
    }

    public abstract d<Key, Value> a();
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(81182720);
    }

    public abstract void c_();
  }

  static final class c<T>
  {
    final int a;
    public final g.a<T> b;
    private final d c;
    private final Object d = new Object();
    private Executor e = null;
    private boolean f = false;

    static
    {
      CoverageLogger.Log(81190912);
    }

    c(d paramd, int paramInt, Executor paramExecutor, g.a<T> parama)
    {
      this.c = paramd;
      this.a = paramInt;
      this.e = paramExecutor;
      this.b = parama;
    }

    final void a(final g<T> paramg)
    {
      synchronized (this.d)
      {
        if (!this.f)
        {
          this.f = true;
          Executor localExecutor = this.e;
          if (localExecutor != null)
          {
            localExecutor.execute(new Runnable()
            {
              static
              {
                CoverageLogger.Log(81186816);
              }

              public final void run()
              {
                d.c.this.b.a(d.c.this.a, paramg);
              }
            });
            return;
          }
          this.b.a(this.a, paramg);
          return;
        }
        throw new IllegalStateException("callback.onResult already called, cannot call again.");
      }
    }

    final void a(Executor paramExecutor)
    {
      synchronized (this.d)
      {
        this.e = paramExecutor;
        return;
      }
    }

    final boolean a()
    {
      if (this.c.c())
      {
        a(g.a);
        return true;
      }
      return false;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.h.d
 * JD-Core Version:    0.6.2
 */