package androidx.h;

import androidx.a.a.a.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

public final class e<Key, Value>
{
  public Key a;
  public h.d b;
  public d.a<Key, Value> c;
  public h.a d;
  public Executor e = a.c();

  static
  {
    CoverageLogger.Log(79097856);
  }

  public e(d.a<Key, Value> parama, h.d paramd)
  {
    if (paramd != null)
    {
      this.c = parama;
      this.b = paramd;
      return;
    }
    throw new IllegalArgumentException("PagedList.Config must be provided");
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.h.e
 * JD-Core Version:    0.6.2
 */