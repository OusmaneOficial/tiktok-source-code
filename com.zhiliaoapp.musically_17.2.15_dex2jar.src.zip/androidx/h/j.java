package androidx.h;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

final class j<T> extends AbstractList<T>
{
  static final List a = new ArrayList();
  public int b;
  final ArrayList<List<T>> c;
  public int d;
  public int e;
  public int f;
  int g;
  public int h;
  public int i;

  static
  {
    CoverageLogger.Log(80922624);
  }

  j()
  {
    this.c = new ArrayList();
    this.d = 0;
    this.e = 0;
    this.f = 0;
    this.g = 1;
    this.h = 0;
    this.i = 0;
  }

  j(j<T> paramj)
  {
    this.b = paramj.b;
    this.c = new ArrayList(paramj.c);
    this.d = paramj.d;
    this.e = paramj.e;
    this.f = paramj.f;
    this.g = paramj.g;
    this.h = paramj.h;
    this.i = paramj.i;
  }

  final int a()
  {
    return this.c.size();
  }

  void a(int paramInt1, int paramInt2)
  {
    int j = this.b / this.g;
    if (paramInt1 < j)
    {
      int i1;
      for (int n = 0; ; n++)
      {
        i1 = j - paramInt1;
        if (n >= i1)
          break;
        this.c.add(0, null);
      }
      int i2 = i1 * this.g;
      this.f = (i2 + this.f);
      this.b -= i2;
    }
    else
    {
      paramInt1 = j;
    }
    if (paramInt2 >= paramInt1 + this.c.size())
    {
      int k = Math.min(this.d, (paramInt2 + 1 - (paramInt1 + this.c.size())) * this.g);
      for (int m = this.c.size(); m <= paramInt2 - paramInt1; m++)
      {
        ArrayList localArrayList = this.c;
        localArrayList.add(localArrayList.size(), null);
      }
      this.f = (k + this.f);
      this.d -= k;
    }
  }

  void a(int paramInt1, List<T> paramList, int paramInt2, int paramInt3)
  {
    this.b = paramInt1;
    this.c.clear();
    this.c.add(paramList);
    this.d = paramInt2;
    this.e = paramInt3;
    this.f = paramList.size();
    this.g = paramList.size();
    this.h = 0;
    this.i = 0;
  }

  final void a(int paramInt1, List<T> paramList, int paramInt2, int paramInt3, int paramInt4, a parama)
  {
    int j = (paramList.size() + (paramInt4 - 1)) / paramInt4;
    int i1;
    for (int k = 0; k < j; k = i1)
    {
      int m = k * paramInt4;
      int n = paramList.size();
      i1 = k + 1;
      List localList = paramList.subList(m, Math.min(n, i1 * paramInt4));
      if (k == 0)
        a(paramInt1, localList, paramInt2 + paramList.size() - localList.size(), paramInt3);
      else
        a(m + paramInt1, localList, null);
    }
    parama.b(size());
  }

  public final void a(int paramInt, List<T> paramList, a parama)
  {
    int j = paramList.size();
    if (j != this.g)
    {
      int n = size();
      int i1 = this.g;
      int i2;
      if ((paramInt == n - n % i1) && (j < i1))
        i2 = 1;
      else
        i2 = 0;
      int i3 = this.d;
      int i4 = 0;
      if (i3 == 0)
      {
        int i5 = this.c.size();
        i4 = 0;
        if (i5 == 1)
        {
          int i6 = this.g;
          i4 = 0;
          if (j > i6)
            i4 = 1;
        }
      }
      if ((i4 == 0) && (i2 == 0))
        throw new IllegalArgumentException("page introduces incorrect tiling");
      if (i4 != 0)
        this.g = j;
    }
    int k = paramInt / this.g;
    a(k, k);
    int m = k - this.b / this.g;
    List localList = (List)this.c.get(m);
    if ((localList != null) && (localList != a))
    {
      StringBuilder localStringBuilder = new StringBuilder("Invalid position ");
      localStringBuilder.append(paramInt);
      localStringBuilder.append(": data already loaded");
      throw new IllegalArgumentException(localStringBuilder.toString());
    }
    this.c.set(m, paramList);
    if (parama != null)
      parama.a(paramInt, paramList.size());
  }

  final int b()
  {
    int j = this.b;
    int k = this.c.size();
    for (int m = 0; m < k; m++)
    {
      List localList = (List)this.c.get(m);
      if ((localList != null) && (localList != a))
        break;
      j += this.g;
    }
    return j;
  }

  public final boolean b(int paramInt1, int paramInt2)
  {
    int j = this.b / paramInt1;
    boolean bool = false;
    if (paramInt2 >= j)
    {
      if (paramInt2 >= j + this.c.size())
        return false;
      List localList1 = (List)this.c.get(paramInt2 - j);
      bool = false;
      if (localList1 != null)
      {
        List localList2 = a;
        bool = false;
        if (localList1 != localList2)
          bool = true;
      }
    }
    return bool;
  }

  final int c()
  {
    int j = this.d;
    for (int k = -1 + this.c.size(); k >= 0; k--)
    {
      List localList = (List)this.c.get(k);
      if ((localList != null) && (localList != a))
        break;
      j += this.g;
    }
    return j;
  }

  final T d()
  {
    return ((List)this.c.get(0)).get(0);
  }

  final T e()
  {
    ArrayList localArrayList = this.c;
    List localList = (List)localArrayList.get(-1 + localArrayList.size());
    return localList.get(-1 + localList.size());
  }

  public final T get(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < size()))
    {
      int j = paramInt - this.b;
      if (j >= 0)
      {
        if (j >= this.f)
          return null;
        int k = this.g;
        int m = 0;
        int n;
        if (k > 0)
          n = 1;
        else
          n = 0;
        if (n != 0)
        {
          int i3 = this.g;
          m = j / i3;
          j %= i3;
        }
        else
        {
          int i1 = this.c.size();
          while (m < i1)
          {
            int i2 = ((List)this.c.get(m)).size();
            if (i2 > j)
              break;
            j -= i2;
            m++;
          }
        }
        List localList = (List)this.c.get(m);
        if (localList != null)
        {
          if (localList.size() == 0)
            return null;
          return localList.get(j);
        }
      }
      return null;
    }
    StringBuilder localStringBuilder = new StringBuilder("Index: ");
    localStringBuilder.append(paramInt);
    localStringBuilder.append(", Size: ");
    localStringBuilder.append(size());
    IndexOutOfBoundsException localIndexOutOfBoundsException = new IndexOutOfBoundsException(localStringBuilder.toString());
    while (true)
      throw localIndexOutOfBoundsException;
  }

  public final int size()
  {
    return this.b + this.f + this.d;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder("leading ");
    localStringBuilder1.append(this.b);
    localStringBuilder1.append(", storage ");
    localStringBuilder1.append(this.f);
    localStringBuilder1.append(", trailing ");
    localStringBuilder1.append(this.d);
    StringBuilder localStringBuilder2 = new StringBuilder(localStringBuilder1.toString());
    for (int j = 0; j < this.c.size(); j++)
    {
      localStringBuilder2.append(" ");
      localStringBuilder2.append(this.c.get(j));
    }
    return localStringBuilder2.toString();
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(80924672);
    }

    public abstract void a(int paramInt1, int paramInt2);

    public abstract void a(int paramInt1, int paramInt2, int paramInt3);

    public abstract void b(int paramInt);

    public abstract void b(int paramInt1, int paramInt2, int paramInt3);

    public abstract void c(int paramInt);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.h.j
 * JD-Core Version:    0.6.2
 */