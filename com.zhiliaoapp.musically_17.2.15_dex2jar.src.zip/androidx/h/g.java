package androidx.h;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Collections;
import java.util.List;

final class g<T>
{
  static final g a = new g(Collections.emptyList(), 0);
  private static final g f;
  public final List<T> b;
  public final int c;
  public final int d;
  public final int e;

  static
  {
    CoverageLogger.Log(80910336);
    f = new g(Collections.emptyList(), 0);
  }

  private g(List<T> paramList, int paramInt)
  {
    this.b = paramList;
    this.e = 0;
  }

  g(List<T> paramList, int paramInt1, int paramInt2, int paramInt3)
  {
    this.b = paramList;
    this.c = 0;
    this.d = 0;
    this.e = paramInt3;
  }

  static <T> g<T> a()
  {
    return f;
  }

  public final boolean b()
  {
    return this == a;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("Result ");
    localStringBuilder.append(this.c);
    localStringBuilder.append(", ");
    localStringBuilder.append(this.b);
    localStringBuilder.append(", ");
    localStringBuilder.append(this.d);
    localStringBuilder.append(", offset ");
    localStringBuilder.append(this.e);
    return localStringBuilder.toString();
  }

  static abstract class a<T>
  {
    static
    {
      CoverageLogger.Log(80904192);
    }

    public abstract void a(int paramInt, g<T> paramg);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.h.g
 * JD-Core Version:    0.6.2
 */