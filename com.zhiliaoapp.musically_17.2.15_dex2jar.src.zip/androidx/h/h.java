package androidx.h;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class h<T> extends AbstractList<T>
{
  private int a = 2147483647;
  private int b = -2147483648;
  final Executor c;
  final Executor d;
  final a<T> e;
  public final d f;
  final j<T> g;
  int h;
  T i;
  public boolean j;
  public boolean k;
  private final AtomicBoolean l = new AtomicBoolean(false);
  private final ArrayList<WeakReference<c>> m = new ArrayList();

  static
  {
    CoverageLogger.Log(80893952);
  }

  h(j<T> paramj, Executor paramExecutor1, Executor paramExecutor2, a<T> parama, d paramd)
  {
    this.g = paramj;
    this.c = paramExecutor1;
    this.d = paramExecutor2;
    this.e = parama;
    this.f = paramd;
  }

  private int h()
  {
    return this.g.e;
  }

  abstract void a(int paramInt);

  public final void a(c paramc)
  {
    for (int n = -1 + this.m.size(); n >= 0; n--)
    {
      c localc = (c)((WeakReference)this.m.get(n)).get();
      if ((localc == null) || (localc == paramc))
        this.m.remove(n);
    }
  }

  abstract void a(h<T> paramh, c paramc);

  public final void a(List<T> paramList, c paramc)
  {
    if ((paramList != null) && (paramList != this))
      if (paramList.isEmpty())
      {
        if (!this.g.isEmpty())
          paramc.a(0, this.g.size());
      }
      else
        a((h)paramList, paramc);
    for (int n = -1 + this.m.size(); n >= 0; n--)
      if ((c)((WeakReference)this.m.get(n)).get() == null)
        this.m.remove(n);
    this.m.add(new WeakReference(paramc));
  }

  public final void a(boolean paramBoolean)
  {
    boolean bool1 = this.j;
    final int n = 1;
    final boolean bool2;
    if ((bool1) && (this.a <= this.f.b))
      bool2 = true;
    else
      bool2 = false;
    if ((!this.k) || (this.b < size() - n - this.f.b))
      n = 0;
    if ((!bool2) && (n == 0))
      return;
    if (bool2)
      this.j = false;
    if (n != 0)
      this.k = false;
    if (paramBoolean)
    {
      this.c.execute(new Runnable()
      {
        static
        {
          CoverageLogger.Log(80914432);
        }

        public final void run()
        {
          h.this.a(bool2, n);
        }
      });
      return;
    }
    a(bool2, n);
  }

  public final void a(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramBoolean1)
      this.g.d();
    if (paramBoolean2)
      this.e.a(this.g.e());
  }

  final void a(final boolean paramBoolean1, final boolean paramBoolean2, final boolean paramBoolean3)
  {
    if (this.e != null)
    {
      if (this.a == 2147483647)
        this.a = this.g.size();
      if (this.b == -2147483648)
        this.b = 0;
      if ((paramBoolean1) || (paramBoolean2) || (paramBoolean3))
        this.c.execute(new Runnable()
        {
          static
          {
            CoverageLogger.Log(80912384);
          }

          public final void run()
          {
            if (paramBoolean1)
              h.this.e.a();
            if (paramBoolean2)
              h.this.j = true;
            if (paramBoolean3)
              h.this.k = true;
            h.this.a(false);
          }
        });
      return;
    }
    throw new IllegalStateException("Can't defer BoundaryCallback, no instance");
  }

  public abstract boolean a();

  public abstract d<?, T> b();

  final void b(int paramInt1, int paramInt2)
  {
    if (paramInt2 != 0)
      for (int n = -1 + this.m.size(); n >= 0; n--)
      {
        c localc = (c)((WeakReference)this.m.get(n)).get();
        if (localc != null)
          localc.a(paramInt1, paramInt2);
      }
  }

  public abstract Object c();

  final void c(int paramInt1, int paramInt2)
  {
    if (paramInt2 != 0)
      for (int n = -1 + this.m.size(); n >= 0; n--)
      {
        c localc = (c)((WeakReference)this.m.get(n)).get();
        if (localc != null)
          localc.b(paramInt1, paramInt2);
      }
  }

  public final void d(int paramInt)
  {
    this.h = (paramInt + h());
    a(paramInt);
    this.a = Math.min(this.a, paramInt);
    this.b = Math.max(this.b, paramInt);
    a(true);
  }

  public boolean d()
  {
    return f();
  }

  public final List<T> e()
  {
    if (d())
      return this;
    return new m(this);
  }

  final void e(int paramInt)
  {
    this.h = (paramInt + this.h);
    this.a = (paramInt + this.a);
    this.b = (paramInt + this.b);
  }

  public boolean f()
  {
    return this.l.get();
  }

  public final void g()
  {
    this.l.set(true);
  }

  public T get(int paramInt)
  {
    Object localObject = this.g.get(paramInt);
    if (localObject != null)
      this.i = localObject;
    return localObject;
  }

  public int size()
  {
    return this.g.size();
  }

  public static abstract class a<T>
  {
    static
    {
      CoverageLogger.Log(80896000);
    }

    public void a()
    {
    }

    public void a(T paramT)
    {
    }
  }

  public static final class b<Key, Value>
  {
    final d<Key, Value> a;
    final h.d b;
    Executor c;
    Executor d;
    h.a e;
    Key f;

    static
    {
      CoverageLogger.Log(80918528);
    }

    public b(d<Key, Value> paramd, h.d paramd1)
    {
      if (paramd != null)
      {
        if (paramd1 != null)
        {
          this.a = paramd;
          this.b = paramd1;
          return;
        }
        throw new IllegalArgumentException("Config may not be null");
      }
      throw new IllegalArgumentException("DataSource may not be null");
    }
  }

  public static abstract class c
  {
    static
    {
      CoverageLogger.Log(80891904);
    }

    public abstract void a(int paramInt1, int paramInt2);

    public abstract void b(int paramInt1, int paramInt2);
  }

  public static final class d
  {
    public final int a;
    public final int b;
    public final boolean c;
    public final int d;

    static
    {
      CoverageLogger.Log(80887808);
    }

    private d(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
    {
      this.a = paramInt1;
      this.b = paramInt2;
      this.c = paramBoolean;
      this.d = paramInt3;
    }

    public static final class a
    {
      public int a = -1;
      private int b = -1;
      private int c = -1;
      private boolean d = true;

      static
      {
        CoverageLogger.Log(80920576);
      }

      public final a a(int paramInt)
      {
        this.b = paramInt;
        return this;
      }

      public final a a(boolean paramBoolean)
      {
        this.d = false;
        return this;
      }

      public final h.d a()
      {
        int i = this.b;
        if (i > 0)
        {
          if (this.c < 0)
            this.c = i;
          if (this.a < 0)
            this.a = (3 * this.b);
          if ((!this.d) && (this.c == 0))
            throw new IllegalArgumentException("Placeholders and prefetch are the only ways to trigger loading of more data in the PagedList, so either placeholders must be enabled, or prefetch distance must be > 0.");
          h.d locald = new h.d(this.b, this.c, this.d, this.a, null);
          return locald;
        }
        throw new IllegalArgumentException("Page size must be a positive number");
      }

      public final a b(int paramInt)
      {
        this.c = paramInt;
        return this;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.h.h
 * JD-Core Version:    0.6.2
 */