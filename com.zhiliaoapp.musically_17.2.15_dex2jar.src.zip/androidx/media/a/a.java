package androidx.media.a;

import android.app.Notification.Builder;
import android.app.Notification.MediaStyle;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.media.session.MediaSession.Token;
import android.os.Build.VERSION;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.widget.RemoteViews;
import androidx.core.app.f;
import androidx.core.app.g.a;
import androidx.core.app.g.d;
import androidx.core.app.g.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class a
{
  static
  {
    CoverageLogger.Log(58642432);
  }

  public static final class a extends g.g
  {
    int[] a;
    public MediaSessionCompat.Token b;
    boolean c;
    PendingIntent h;

    static
    {
      CoverageLogger.Log(58370048);
    }

    private RemoteViews a(g.a parama)
    {
      int i;
      if (parama.i == null)
        i = 1;
      else
        i = 0;
      RemoteViews localRemoteViews = new RemoteViews(this.d.a.getPackageName(), 2131494479);
      localRemoteViews.setImageViewResource(2131296277, parama.g);
      if (i == 0)
        localRemoteViews.setOnClickPendingIntent(2131296277, parama.i);
      if (Build.VERSION.SDK_INT >= 15)
        localRemoteViews.setContentDescription(2131296277, parama.h);
      return localRemoteViews;
    }

    public final void a(f paramf)
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        Notification.Builder localBuilder = paramf.a();
        Notification.MediaStyle localMediaStyle = new Notification.MediaStyle();
        int[] arrayOfInt = this.a;
        if (arrayOfInt != null)
          localMediaStyle.setShowActionsInCompactView(arrayOfInt);
        MediaSessionCompat.Token localToken = this.b;
        if (localToken != null)
          localMediaStyle.setMediaSession((MediaSession.Token)localToken.a);
        localBuilder.setStyle(localMediaStyle);
        return;
      }
      if (this.c)
        paramf.a().setOngoing(true);
    }

    public final RemoteViews b(f paramf)
    {
      if (Build.VERSION.SDK_INT >= 21)
        return null;
      RemoteViews localRemoteViews = a(false, 2131494489, true);
      int i = this.d.b.size();
      int[] arrayOfInt = this.a;
      int j;
      if (arrayOfInt == null)
        j = 0;
      else
        j = Math.min(arrayOfInt.length, 3);
      localRemoteViews.removeAllViews(2131300008);
      if (j > 0)
      {
        int k = 0;
        while (k < j)
          if (k < i)
          {
            localRemoteViews.addView(2131300008, a((g.a)this.d.b.get(this.a[k])));
            k++;
          }
          else
          {
            Object[] arrayOfObject = new Object[2];
            arrayOfObject[0] = Integer.valueOf(k);
            arrayOfObject[1] = Integer.valueOf(i - 1);
            throw new IllegalArgumentException(com.a.a("setShowActionsInCompactView: action %d out of bounds (max %d)", arrayOfObject));
          }
      }
      if (this.c)
      {
        localRemoteViews.setViewVisibility(2131297921, 8);
        localRemoteViews.setViewVisibility(2131297045, 0);
        localRemoteViews.setOnClickPendingIntent(2131297045, this.h);
        localRemoteViews.setInt(2131297045, "setAlpha", this.d.a.getResources().getInteger(2131361809));
        return localRemoteViews;
      }
      localRemoteViews.setViewVisibility(2131297921, 0);
      localRemoteViews.setViewVisibility(2131297045, 8);
      return localRemoteViews;
    }

    public final RemoteViews c(f paramf)
    {
      if (Build.VERSION.SDK_INT >= 21)
        return null;
      int i = Math.min(this.d.b.size(), 5);
      int j;
      if (i <= 3)
        j = 2131494484;
      else
        j = 2131494482;
      RemoteViews localRemoteViews = a(false, j, false);
      localRemoteViews.removeAllViews(2131300008);
      if (i > 0)
        for (int k = 0; k < i; k++)
          localRemoteViews.addView(2131300008, a((g.a)this.d.b.get(k)));
      if (this.c)
      {
        localRemoteViews.setViewVisibility(2131297045, 0);
        localRemoteViews.setInt(2131297045, "setAlpha", this.d.a.getResources().getInteger(2131361809));
        localRemoteViews.setOnClickPendingIntent(2131297045, this.h);
        return localRemoteViews;
      }
      localRemoteViews.setViewVisibility(2131297045, 8);
      return localRemoteViews;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.a.a
 * JD-Core Version:    0.6.2
 */