package androidx.media;

import android.media.AudioAttributes;
import androidx.versionedparcelable.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class AudioAttributesImplApi21Parcelizer
{
  static
  {
    CoverageLogger.Log(58544128);
  }

  public static b read(a parama)
  {
    b localb = new b();
    localb.a = ((AudioAttributes)parama.b(localb.a, 1));
    localb.b = parama.b(localb.b, 2);
    return localb;
  }

  public static void write(b paramb, a parama)
  {
    parama.a(paramb.a, 1);
    parama.a(paramb.b, 2);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.AudioAttributesImplApi21Parcelizer
 * JD-Core Version:    0.6.2
 */