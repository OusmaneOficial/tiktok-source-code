package androidx.media;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class i
{
  public final int a;
  public final int b;
  public int c;

  static
  {
    CoverageLogger.Log(58640384);
  }

  public static abstract class a
  {
    static
    {
      CoverageLogger.Log(58636288);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.i
 * JD-Core Version:    0.6.2
 */