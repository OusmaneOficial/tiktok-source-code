package androidx.media.session;

import android.content.BroadcastReceiver;
import android.content.BroadcastReceiver.PendingResult;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build.VERSION;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaBrowserCompat.b;
import android.support.v4.media.MediaBrowserCompat.d;
import com.ss.android.ugc.aweme.push.downgrade.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public class MediaButtonReceiver extends BroadcastReceiver
{
  static
  {
    CoverageLogger.Log(58363904);
  }

  private static ComponentName a(Context paramContext, String paramString)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    Intent localIntent = new Intent(paramString);
    localIntent.setPackage(paramContext.getPackageName());
    List localList = localPackageManager.queryIntentServices(localIntent, 0);
    if (localList.size() == 1)
    {
      ResolveInfo localResolveInfo = (ResolveInfo)localList.get(0);
      return new ComponentName(localResolveInfo.serviceInfo.packageName, localResolveInfo.serviceInfo.name);
    }
    if (localList.isEmpty())
      return null;
    StringBuilder localStringBuilder = new StringBuilder("Expected 1 service that handles ");
    localStringBuilder.append(paramString);
    localStringBuilder.append(", found ");
    localStringBuilder.append(localList.size());
    throw new IllegalStateException(localStringBuilder.toString());
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if ((paramIntent != null) && ("android.intent.action.MEDIA_BUTTON".equals(paramIntent.getAction())))
    {
      if (!paramIntent.hasExtra("android.intent.extra.KEY_EVENT"))
        return;
      ComponentName localComponentName1 = a(paramContext, "android.intent.action.MEDIA_BUTTON");
      if (localComponentName1 != null)
      {
        paramIntent.setComponent(localComponentName1);
        if (Build.VERSION.SDK_INT >= 26)
        {
          paramContext.startForegroundService(paramIntent);
          return;
        }
        if ((paramContext != null) && ((paramContext instanceof Context)) && (d.a((Context)paramContext, paramIntent)))
          return;
        paramContext.startService(paramIntent);
        return;
      }
      ComponentName localComponentName2 = a(paramContext, "android.media.browse.MediaBrowserService");
      if (localComponentName2 != null)
      {
        BroadcastReceiver.PendingResult localPendingResult = goAsync();
        Context localContext = paramContext.getApplicationContext();
        a locala = new a(localContext, paramIntent, localPendingResult);
        MediaBrowserCompat localMediaBrowserCompat = new MediaBrowserCompat(localContext, localComponentName2, locala, null);
        locala.c = localMediaBrowserCompat;
        localMediaBrowserCompat.b.c();
        return;
      }
      throw new IllegalStateException("Could not find any Service that handles android.intent.action.MEDIA_BUTTON or implements a media browser service.");
    }
  }

  static final class a extends MediaBrowserCompat.b
  {
    public MediaBrowserCompat c;
    private final Context d;
    private final Intent e;
    private final BroadcastReceiver.PendingResult f;

    static
    {
      CoverageLogger.Log(58644480);
    }

    a(Context paramContext, Intent paramIntent, BroadcastReceiver.PendingResult paramPendingResult)
    {
      this.d = paramContext;
      this.e = paramIntent;
      this.f = paramPendingResult;
    }

    private void d()
    {
      this.c.a();
      this.f.finish();
    }

    // ERROR //
    public final void a()
    {
      // Byte code:
      //   0: new 47	android/support/v4/media/session/MediaControllerCompat
      //   3: dup
      //   4: aload_0
      //   5: getfield 27	androidx/media/session/MediaButtonReceiver$a:d	Landroid/content/Context;
      //   8: aload_0
      //   9: getfield 33	androidx/media/session/MediaButtonReceiver$a:c	Landroid/support/v4/media/MediaBrowserCompat;
      //   12: getfield 51	android/support/v4/media/MediaBrowserCompat:b	Landroid/support/v4/media/MediaBrowserCompat$d;
      //   15: invokeinterface 56 1 0
      //   20: invokespecial 59	android/support/v4/media/session/MediaControllerCompat:<init>	(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V
      //   23: astore_1
      //   24: aload_0
      //   25: getfield 29	androidx/media/session/MediaButtonReceiver$a:e	Landroid/content/Intent;
      //   28: ldc 61
      //   30: invokevirtual 67	android/content/Intent:getParcelableExtra	(Ljava/lang/String;)Landroid/os/Parcelable;
      //   33: checkcast 69	android/view/KeyEvent
      //   36: astore_2
      //   37: aload_2
      //   38: ifnull +17 -> 55
      //   41: aload_1
      //   42: getfield 72	android/support/v4/media/session/MediaControllerCompat:a	Landroid/support/v4/media/session/MediaControllerCompat$b;
      //   45: aload_2
      //   46: invokeinterface 77 2 0
      //   51: pop
      //   52: goto +13 -> 65
      //   55: new 79	java/lang/IllegalArgumentException
      //   58: dup
      //   59: ldc 81
      //   61: invokespecial 84	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
      //   64: athrow
      //   65: aload_0
      //   66: invokespecial 86	androidx/media/session/MediaButtonReceiver$a:d	()V
      //   69: return
      //
      // Exception table:
      //   from	to	target	type
      //   0	37	65	android/os/RemoteException
      //   41	52	65	android/os/RemoteException
      //   55	65	65	android/os/RemoteException
    }

    public final void b()
    {
      d();
    }

    public final void c()
    {
      d();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.session.MediaButtonReceiver
 * JD-Core Version:    0.6.2
 */