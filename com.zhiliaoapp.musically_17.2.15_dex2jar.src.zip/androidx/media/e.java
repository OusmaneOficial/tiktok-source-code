package androidx.media;

import android.media.session.MediaSessionManager.RemoteUserInfo;
import android.os.Build.VERSION;
import android.util.Log;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
{
  static final boolean a = Log.isLoggable("MediaSessionManager", 3);
  private static final Object b = new Object();

  static
  {
    CoverageLogger.Log(58624000);
  }

  public static final class a
  {
    e.b a;

    static
    {
      CoverageLogger.Log(58611712);
    }

    public a(MediaSessionManager.RemoteUserInfo paramRemoteUserInfo)
    {
      this.a = new g.a(paramRemoteUserInfo);
    }

    public a(String paramString, int paramInt1, int paramInt2)
    {
      if (Build.VERSION.SDK_INT >= 28)
      {
        this.a = new g.a(paramString, paramInt1, paramInt2);
        return;
      }
      this.a = new h.a(paramString, paramInt1, paramInt2);
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (!(paramObject instanceof a))
        return false;
      return this.a.equals(((a)paramObject).a);
    }

    public final int hashCode()
    {
      return this.a.hashCode();
    }
  }

  static abstract interface b
  {
    static
    {
      CoverageLogger.Log(58615808);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.e
 * JD-Core Version:    0.6.2
 */