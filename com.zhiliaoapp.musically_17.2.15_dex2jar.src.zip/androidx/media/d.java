package androidx.media;

import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
{
  static
  {
    CoverageLogger.Log(58550272);
  }

  public static boolean a(Bundle paramBundle1, Bundle paramBundle2)
  {
    if (paramBundle1 == paramBundle2)
      return true;
    if (paramBundle1 == null)
      return (paramBundle2.getInt("android.media.browse.extra.PAGE", -1) == -1) && (paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1);
    if (paramBundle2 == null)
      return (paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == -1) && (paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1);
    return (paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE", -1)) && (paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1));
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.d
 * JD-Core Version:    0.6.2
 */