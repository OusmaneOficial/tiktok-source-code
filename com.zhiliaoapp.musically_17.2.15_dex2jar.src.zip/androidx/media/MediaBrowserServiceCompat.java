package androidx.media;

import android.app.Service;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.MediaBrowserCompat.MediaItem;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.support.v4.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;
import androidx.c.a;
import androidx.core.g.e;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public abstract class MediaBrowserServiceCompat extends Service
{
  static final boolean a = Log.isLoggable("MBServiceCompat", 3);
  final a<IBinder, b> b = new a();
  b c;
  final g d = new g();
  public MediaSessionCompat.Token e;

  static
  {
    CoverageLogger.Log(58603520);
  }

  public abstract a a(String paramString, int paramInt, Bundle paramBundle);

  final boolean a(String paramString, b paramb, IBinder paramIBinder)
  {
    boolean bool1 = true;
    if (paramIBinder == null);
    try
    {
      Object localObject2 = paramb.g.remove(paramString);
      if (localObject2 == null)
        bool1 = false;
      this.c = paramb;
      this.c = null;
      return bool1;
      List localList = (List)paramb.g.get(paramString);
      boolean bool2 = false;
      if (localList != null)
      {
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
          if (paramIBinder == ((e)localIterator.next()).a)
          {
            localIterator.remove();
            bool2 = true;
          }
        if (localList.size() == 0)
          paramb.g.remove(paramString);
      }
      this.c = paramb;
      this.c = null;
      return bool2;
    }
    finally
    {
      this.c = paramb;
      this.c = null;
    }
    while (true)
      throw localObject1;
  }

  public static final class a
  {
    public final String a;
    public final Bundle b;

    static
    {
      CoverageLogger.Log(58566656);
    }
  }

  final class b
    implements IBinder.DeathRecipient
  {
    public final String a;
    public final int b;
    public final int c;
    public final e.a d;
    public final Bundle e;
    public final MediaBrowserServiceCompat.e f;
    public final HashMap<String, List<e<IBinder, Bundle>>> g = new HashMap();
    public MediaBrowserServiceCompat.a h;

    static
    {
      CoverageLogger.Log(58574848);
    }

    b(String paramInt1, int paramInt2, int paramBundle, Bundle parame, MediaBrowserServiceCompat.e arg6)
    {
      this.a = paramInt1;
      this.b = paramInt2;
      this.c = paramBundle;
      this.d = new e.a(paramInt1, paramInt2, paramBundle);
      this.e = parame;
      Object localObject;
      this.f = localObject;
    }

    public final void binderDied()
    {
      MediaBrowserServiceCompat.this.d.post(new Runnable()
      {
        static
        {
          CoverageLogger.Log(58572800);
        }

        public final void run()
        {
          MediaBrowserServiceCompat.this.b.remove(MediaBrowserServiceCompat.b.this.f.a());
        }
      });
    }
  }

  public static class c<T>
  {
    private boolean a;
    final Object f;
    boolean g;
    boolean h;
    public int i;

    static
    {
      CoverageLogger.Log(58576896);
    }

    c(Object paramObject)
    {
      this.f = paramObject;
    }

    void a(Bundle paramBundle)
    {
      StringBuilder localStringBuilder = new StringBuilder("It is not supported to send an error for ");
      localStringBuilder.append(this.f);
      throw new UnsupportedOperationException(localStringBuilder.toString());
    }

    void a(T paramT)
    {
    }

    final boolean a()
    {
      return (this.a) || (this.g) || (this.h);
    }

    public final void b(T paramT)
    {
      if ((!this.g) && (!this.h))
      {
        this.g = true;
        a(null);
        return;
      }
      StringBuilder localStringBuilder = new StringBuilder("sendResult() called when either sendResult() or sendError() had already been called for: ");
      localStringBuilder.append(this.f);
      throw new IllegalStateException(localStringBuilder.toString());
    }
  }

  final class d
  {
    static
    {
      CoverageLogger.Log(58591232);
    }

    d()
    {
    }
  }

  static abstract interface e
  {
    static
    {
      CoverageLogger.Log(58394624);
    }

    public abstract IBinder a();

    public abstract void a(String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
      throws RemoteException;

    public abstract void a(String paramString, List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle1, Bundle paramBundle2)
      throws RemoteException;

    public abstract void b()
      throws RemoteException;
  }

  static final class f
    implements MediaBrowserServiceCompat.e
  {
    final Messenger a;

    static
    {
      CoverageLogger.Log(58597376);
    }

    f(Messenger paramMessenger)
    {
      this.a = paramMessenger;
    }

    private void a(int paramInt, Bundle paramBundle)
      throws RemoteException
    {
      Message localMessage = Message.obtain();
      localMessage.what = paramInt;
      localMessage.arg1 = 2;
      localMessage.setData(paramBundle);
      this.a.send(localMessage);
    }

    public final IBinder a()
    {
      return this.a.getBinder();
    }

    public final void a(String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
      throws RemoteException
    {
      if (paramBundle == null)
        paramBundle = new Bundle();
      paramBundle.putInt("extra_service_version", 2);
      Bundle localBundle = new Bundle();
      localBundle.putString("data_media_item_id", paramString);
      localBundle.putParcelable("data_media_session_token", paramToken);
      localBundle.putBundle("data_root_hints", paramBundle);
      a(1, localBundle);
    }

    public final void a(String paramString, List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle1, Bundle paramBundle2)
      throws RemoteException
    {
      Bundle localBundle = new Bundle();
      localBundle.putString("data_media_item_id", paramString);
      localBundle.putBundle("data_options", paramBundle1);
      localBundle.putBundle("data_notify_children_changed_options", paramBundle2);
      if (paramList != null)
      {
        ArrayList localArrayList;
        if ((paramList instanceof ArrayList))
          localArrayList = (ArrayList)paramList;
        else
          localArrayList = new ArrayList(paramList);
        localBundle.putParcelableArrayList("data_media_item_list", localArrayList);
      }
      a(3, localBundle);
    }

    public final void b()
      throws RemoteException
    {
      a(2, null);
    }
  }

  final class g extends Handler
  {
    private final MediaBrowserServiceCompat.d b = new MediaBrowserServiceCompat.d(MediaBrowserServiceCompat.this);

    static
    {
      CoverageLogger.Log(58593280);
    }

    g()
    {
    }

    public final void a(Runnable paramRunnable)
    {
      if (Thread.currentThread() == getLooper().getThread())
      {
        paramRunnable.run();
        return;
      }
      post(paramRunnable);
    }

    public final void handleMessage(Message paramMessage)
    {
      Bundle localBundle1 = paramMessage.getData();
      switch (paramMessage.what)
      {
      default:
      case 9:
        Bundle localBundle6 = localBundle1.getBundle("data_custom_action_extras");
        MediaSessionCompat.a(localBundle6);
        MediaBrowserServiceCompat.d locald9 = this.b;
        String str7 = localBundle1.getString("data_custom_action");
        ResultReceiver localResultReceiver3 = (ResultReceiver)localBundle1.getParcelable("data_result_receiver");
        MediaBrowserServiceCompat.f localf9 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        if (!TextUtils.isEmpty(str7))
        {
          if (localResultReceiver3 == null)
            return;
          g localg5 = locald9.a.d;
          MediaBrowserServiceCompat.d.9 local9 = new MediaBrowserServiceCompat.d.9(locald9, localf9, str7, localBundle6, localResultReceiver3);
          localg5.a(local9);
          return;
        }
        return;
      case 8:
        Bundle localBundle5 = localBundle1.getBundle("data_search_extras");
        MediaSessionCompat.a(localBundle5);
        MediaBrowserServiceCompat.d locald8 = this.b;
        String str6 = localBundle1.getString("data_search_query");
        ResultReceiver localResultReceiver2 = (ResultReceiver)localBundle1.getParcelable("data_result_receiver");
        MediaBrowserServiceCompat.f localf8 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        if (!TextUtils.isEmpty(str6))
        {
          if (localResultReceiver2 == null)
            return;
          g localg4 = locald8.a.d;
          MediaBrowserServiceCompat.d.8 local8 = new MediaBrowserServiceCompat.d.8(locald8, localf8, str6, localBundle5, localResultReceiver2);
          localg4.a(local8);
          return;
        }
        break;
      case 7:
        MediaBrowserServiceCompat.d locald7 = this.b;
        MediaBrowserServiceCompat.f localf7 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        locald7.a.d.a(new MediaBrowserServiceCompat.d.7(locald7, localf7));
        return;
      case 6:
        Bundle localBundle4 = localBundle1.getBundle("data_root_hints");
        MediaSessionCompat.a(localBundle4);
        MediaBrowserServiceCompat.d locald6 = this.b;
        MediaBrowserServiceCompat.f localf6 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        String str5 = localBundle1.getString("data_package_name");
        int i1 = localBundle1.getInt("data_calling_pid");
        int i2 = localBundle1.getInt("data_calling_uid");
        g localg3 = locald6.a.d;
        MediaBrowserServiceCompat.d.6 local6 = new MediaBrowserServiceCompat.d.6(locald6, localf6, str5, i1, i2, localBundle4);
        localg3.a(local6);
        return;
      case 5:
        MediaBrowserServiceCompat.d locald5 = this.b;
        String str4 = localBundle1.getString("data_media_item_id");
        ResultReceiver localResultReceiver1 = (ResultReceiver)localBundle1.getParcelable("data_result_receiver");
        MediaBrowserServiceCompat.f localf5 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        if (!TextUtils.isEmpty(str4))
        {
          if (localResultReceiver1 == null)
            return;
          locald5.a.d.a(new MediaBrowserServiceCompat.d.5(locald5, localf5, str4, localResultReceiver1));
          return;
        }
        break;
      case 4:
        MediaBrowserServiceCompat.d locald4 = this.b;
        String str3 = localBundle1.getString("data_media_item_id");
        IBinder localIBinder2 = androidx.core.app.d.a(localBundle1, "data_callback_token");
        MediaBrowserServiceCompat.f localf4 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        locald4.a.d.a(new MediaBrowserServiceCompat.d.4(locald4, localf4, str3, localIBinder2));
        return;
      case 3:
        Bundle localBundle3 = localBundle1.getBundle("data_options");
        MediaSessionCompat.a(localBundle3);
        MediaBrowserServiceCompat.d locald3 = this.b;
        String str2 = localBundle1.getString("data_media_item_id");
        IBinder localIBinder1 = androidx.core.app.d.a(localBundle1, "data_callback_token");
        MediaBrowserServiceCompat.f localf3 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        g localg2 = locald3.a.d;
        MediaBrowserServiceCompat.d.3 local3 = new MediaBrowserServiceCompat.d.3(locald3, localf3, str2, localIBinder1, localBundle3);
        localg2.a(local3);
        return;
      case 2:
        MediaBrowserServiceCompat.d locald2 = this.b;
        MediaBrowserServiceCompat.f localf2 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        locald2.a.d.a(new MediaBrowserServiceCompat.d.2(locald2, localf2));
        return;
      case 1:
        Bundle localBundle2 = localBundle1.getBundle("data_root_hints");
        MediaSessionCompat.a(localBundle2);
        MediaBrowserServiceCompat.d locald1 = this.b;
        String str1 = localBundle1.getString("data_package_name");
        int i = localBundle1.getInt("data_calling_pid");
        int j = localBundle1.getInt("data_calling_uid");
        MediaBrowserServiceCompat.f localf1 = new MediaBrowserServiceCompat.f(paramMessage.replyTo);
        MediaBrowserServiceCompat localMediaBrowserServiceCompat = locald1.a;
        int k = 0;
        if (str1 != null)
        {
          String[] arrayOfString = localMediaBrowserServiceCompat.getPackageManager().getPackagesForUid(j);
          int m = arrayOfString.length;
          for (int n = 0; ; n++)
          {
            k = 0;
            if (n >= m)
              break;
            if (arrayOfString[n].equals(str1))
            {
              k = 1;
              break;
            }
          }
        }
        if (k != 0)
        {
          g localg1 = locald1.a.d;
          MediaBrowserServiceCompat.d.1 local1 = new MediaBrowserServiceCompat.d.1(locald1, localf1, str1, i, j, localBundle2);
          localg1.a(local1);
          return;
        }
        StringBuilder localStringBuilder = new StringBuilder("Package/uid mismatch: uid=");
        localStringBuilder.append(j);
        localStringBuilder.append(" package=");
        localStringBuilder.append(str1);
        throw new IllegalArgumentException(localStringBuilder.toString());
      }
    }

    public final boolean sendMessageAtTime(Message paramMessage, long paramLong)
    {
      Bundle localBundle = paramMessage.getData();
      localBundle.setClassLoader(MediaBrowserCompat.class.getClassLoader());
      localBundle.putInt("data_calling_uid", Binder.getCallingUid());
      localBundle.putInt("data_calling_pid", Binder.getCallingPid());
      return super.sendMessageAtTime(paramMessage, paramLong);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.MediaBrowserServiceCompat
 * JD-Core Version:    0.6.2
 */