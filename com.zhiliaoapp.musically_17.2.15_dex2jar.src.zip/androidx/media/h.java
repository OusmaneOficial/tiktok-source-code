package androidx.media;

import android.text.TextUtils;
import androidx.core.g.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

class h
{
  private static final boolean a = e.a;

  static
  {
    CoverageLogger.Log(58634240);
  }

  static final class a
    implements e.b
  {
    private String a;
    private int b;
    private int c;

    static
    {
      CoverageLogger.Log(58378240);
    }

    a(String paramString, int paramInt1, int paramInt2)
    {
      this.a = paramString;
      this.b = paramInt1;
      this.c = paramInt2;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (!(paramObject instanceof a))
        return false;
      a locala = (a)paramObject;
      return (TextUtils.equals(this.a, locala.a)) && (this.b == locala.b) && (this.c == locala.c);
    }

    public final int hashCode()
    {
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = this.a;
      arrayOfObject[1] = Integer.valueOf(this.b);
      arrayOfObject[2] = Integer.valueOf(this.c);
      return d.a(arrayOfObject);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.h
 * JD-Core Version:    0.6.2
 */