package androidx.media;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class AudioAttributesCompatParcelizer
{
  static
  {
    CoverageLogger.Log(58529792);
  }

  public static AudioAttributesCompat read(androidx.versionedparcelable.a parama)
  {
    AudioAttributesCompat localAudioAttributesCompat = new AudioAttributesCompat();
    localAudioAttributesCompat.a = ((a)parama.b(localAudioAttributesCompat.a, 1));
    return localAudioAttributesCompat;
  }

  public static void write(AudioAttributesCompat paramAudioAttributesCompat, androidx.versionedparcelable.a parama)
  {
    parama.a(paramAudioAttributesCompat.a, 1);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.AudioAttributesCompatParcelizer
 * JD-Core Version:    0.6.2
 */