package androidx.media;

import androidx.versionedparcelable.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class AudioAttributesImplBaseParcelizer
{
  static
  {
    CoverageLogger.Log(58548224);
  }

  public static c read(a parama)
  {
    c localc = new c();
    localc.a = parama.b(localc.a, 1);
    localc.b = parama.b(localc.b, 2);
    localc.c = parama.b(localc.c, 3);
    localc.d = parama.b(localc.d, 4);
    return localc;
  }

  public static void write(c paramc, a parama)
  {
    parama.a(paramc.a, 1);
    parama.a(paramc.b, 2);
    parama.a(paramc.c, 3);
    parama.a(paramc.d, 4);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.media.AudioAttributesImplBaseParcelizer
 * JD-Core Version:    0.6.2
 */