package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface f
{
  static
  {
    CoverageLogger.Log(2435072);
  }

  public abstract void a(l paraml, i.a parama, boolean paramBoolean, q paramq);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.f
 * JD-Core Version:    0.6.2
 */