package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.atomic.AtomicBoolean;

final class j
{
  static AtomicBoolean a = new AtomicBoolean(false);

  static
  {
    CoverageLogger.Log(19767296);
  }

  static final class a extends d
  {
    static
    {
      CoverageLogger.Log(20101120);
    }

    public final void onActivityCreated(Activity paramActivity, Bundle paramBundle)
    {
      v.a(paramActivity);
    }

    public final void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle)
    {
    }

    public final void onActivityStopped(Activity paramActivity)
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.j
 * JD-Core Version:    0.6.2
 */