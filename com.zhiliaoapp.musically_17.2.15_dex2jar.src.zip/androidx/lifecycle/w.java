package androidx.lifecycle;

import android.os.Handler;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class w
{
  public final m a;
  private final Handler b;
  private a c;

  static
  {
    CoverageLogger.Log(19410944);
  }

  public w(l paraml)
  {
    this.a = new m(paraml);
    this.b = new Handler();
  }

  void a(i.a parama)
  {
    a locala = this.c;
    if (locala != null)
      locala.run();
    this.c = new a(this.a, parama);
    this.b.postAtFrontOfQueue(this.c);
  }

  static final class a
    implements Runnable
  {
    final i.a a;
    private final m b;
    private boolean c;

    static
    {
      CoverageLogger.Log(19431424);
    }

    a(m paramm, i.a parama)
    {
      this.b = paramm;
      this.a = parama;
    }

    public final void run()
    {
      if (!this.c)
      {
        this.b.a(this.a);
        this.c = true;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.w
 * JD-Core Version:    0.6.2
 */