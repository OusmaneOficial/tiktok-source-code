package androidx.lifecycle;

import android.app.Application;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public final class y
{
  private final b a;
  private final aa b;

  static
  {
    CoverageLogger.Log(14938112);
  }

  public y(aa paramaa, b paramb)
  {
    this.a = paramb;
    this.b = paramaa;
  }

  public final <T extends x> T a(Class<T> paramClass)
  {
    String str = paramClass.getCanonicalName();
    if (str != null)
    {
      StringBuilder localStringBuilder = new StringBuilder("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      localStringBuilder.append(str);
      return a(localStringBuilder.toString(), paramClass);
    }
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }

  public final <T extends x> T a(String paramString, Class<T> paramClass)
  {
    x localx1 = this.b.a(paramString);
    if (paramClass.isInstance(localx1))
      return localx1;
    x localx2 = this.a.a(paramClass);
    this.b.a(paramString, localx2);
    return localx2;
  }

  public static final class a extends y.c
  {
    private static a a;
    private Application b;

    static
    {
      CoverageLogger.Log(14577664);
    }

    private a(Application paramApplication)
    {
      this.b = paramApplication;
    }

    public static a a(Application paramApplication)
    {
      if (a == null)
        a = new a(paramApplication);
      return a;
    }

    public final <T extends x> T a(Class<T> paramClass)
    {
      if (a.class.isAssignableFrom(paramClass))
        try
        {
          Constructor localConstructor = paramClass.getConstructor(new Class[] { Application.class });
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = this.b;
          x localx = (x)localConstructor.newInstance(arrayOfObject);
          return localx;
        }
        catch (InvocationTargetException localInvocationTargetException)
        {
          StringBuilder localStringBuilder4 = new StringBuilder("Cannot create an instance of ");
          localStringBuilder4.append(paramClass);
          throw new RuntimeException(localStringBuilder4.toString(), localInvocationTargetException);
        }
        catch (InstantiationException localInstantiationException)
        {
          StringBuilder localStringBuilder3 = new StringBuilder("Cannot create an instance of ");
          localStringBuilder3.append(paramClass);
          throw new RuntimeException(localStringBuilder3.toString(), localInstantiationException);
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          StringBuilder localStringBuilder2 = new StringBuilder("Cannot create an instance of ");
          localStringBuilder2.append(paramClass);
          throw new RuntimeException(localStringBuilder2.toString(), localIllegalAccessException);
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
          StringBuilder localStringBuilder1 = new StringBuilder("Cannot create an instance of ");
          localStringBuilder1.append(paramClass);
          throw new RuntimeException(localStringBuilder1.toString(), localNoSuchMethodException);
        }
      return super.a(paramClass);
    }
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(14573568);
    }

    public abstract <T extends x> T a(Class<T> paramClass);
  }

  public static class c
    implements y.b
  {
    static
    {
      CoverageLogger.Log(14571520);
    }

    public <T extends x> T a(Class<T> paramClass)
    {
      try
      {
        x localx = (x)paramClass.newInstance();
        return localx;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        StringBuilder localStringBuilder2 = new StringBuilder("Cannot create an instance of ");
        localStringBuilder2.append(paramClass);
        throw new RuntimeException(localStringBuilder2.toString(), localIllegalAccessException);
      }
      catch (InstantiationException localInstantiationException)
      {
        StringBuilder localStringBuilder1 = new StringBuilder("Cannot create an instance of ");
        localStringBuilder1.append(paramClass);
        throw new RuntimeException(localStringBuilder1.toString(), localInstantiationException);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.y
 * JD-Core Version:    0.6.2
 */