package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface s<T>
{
  static
  {
    CoverageLogger.Log(23750656);
  }

  public abstract void onChanged(T paramT);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.s
 * JD-Core Version:    0.6.2
 */