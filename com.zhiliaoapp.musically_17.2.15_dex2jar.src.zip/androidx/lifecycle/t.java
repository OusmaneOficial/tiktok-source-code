package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.METHOD})
public @interface t
{
  static
  {
    CoverageLogger.Log(2469888);
  }

  public abstract i.a a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.t
 * JD-Core Version:    0.6.2
 */