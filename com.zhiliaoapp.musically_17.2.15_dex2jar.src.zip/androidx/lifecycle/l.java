package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface l
{
  static
  {
    CoverageLogger.Log(2461696);
  }

  public abstract i getLifecycle();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.l
 * JD-Core Version:    0.6.2
 */