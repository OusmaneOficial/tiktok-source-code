package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface ab
{
  static
  {
    CoverageLogger.Log(14575616);
  }

  public abstract aa getViewModelStore();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.ab
 * JD-Core Version:    0.6.2
 */