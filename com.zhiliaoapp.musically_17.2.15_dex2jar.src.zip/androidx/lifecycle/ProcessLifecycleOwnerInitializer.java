package androidx.lifecycle;

import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.atomic.AtomicBoolean;

public class ProcessLifecycleOwnerInitializer extends ContentProvider
{
  static
  {
    CoverageLogger.Log(19769344);
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    return 0;
  }

  public String getType(Uri paramUri)
  {
    return null;
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    return null;
  }

  public boolean onCreate()
  {
    Context localContext1 = getContext();
    if (!j.a.getAndSet(true))
      ((Application)localContext1.getApplicationContext()).registerActivityLifecycleCallbacks(new j.a());
    Context localContext2 = getContext();
    u localu = u.i;
    localu.e = new Handler();
    localu.f.a(i.a.ON_CREATE);
    ((Application)localContext2.getApplicationContext()).registerActivityLifecycleCallbacks(new u.3(localu));
    return true;
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    return null;
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    return 0;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.ProcessLifecycleOwnerInitializer
 * JD-Core Version:    0.6.2
 */