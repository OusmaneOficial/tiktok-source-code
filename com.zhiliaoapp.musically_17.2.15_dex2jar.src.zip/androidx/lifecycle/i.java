package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class i
{
  static
  {
    CoverageLogger.Log(2449408);
  }

  public abstract b a();

  public abstract void a(k paramk);

  public abstract void b(k paramk);

  public static enum a
  {
    static
    {
      CoverageLogger.Log(2445312);
      ON_CREATE = new a("ON_CREATE", 0);
      ON_START = new a("ON_START", 1);
      ON_RESUME = new a("ON_RESUME", 2);
      ON_PAUSE = new a("ON_PAUSE", 3);
      ON_STOP = new a("ON_STOP", 4);
      ON_DESTROY = new a("ON_DESTROY", 5);
      ON_ANY = new a("ON_ANY", 6);
      a[] arrayOfa = new a[7];
      arrayOfa[0] = ON_CREATE;
      arrayOfa[1] = ON_START;
      arrayOfa[2] = ON_RESUME;
      arrayOfa[3] = ON_PAUSE;
      arrayOfa[4] = ON_STOP;
      arrayOfa[5] = ON_DESTROY;
      arrayOfa[6] = ON_ANY;
    }
  }

  public static enum b
  {
    static
    {
      CoverageLogger.Log(2447360);
      DESTROYED = new b("DESTROYED", 0);
      INITIALIZED = new b("INITIALIZED", 1);
      CREATED = new b("CREATED", 2);
      STARTED = new b("STARTED", 3);
      RESUMED = new b("RESUMED", 4);
      b[] arrayOfb = new b[5];
      arrayOfb[0] = DESTROYED;
      arrayOfb[1] = INITIALIZED;
      arrayOfb[2] = CREATED;
      arrayOfb[3] = STARTED;
      arrayOfb[4] = RESUMED;
    }

    public final boolean isAtLeast(b paramb)
    {
      return compareTo(paramb) >= 0;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.i
 * JD-Core Version:    0.6.2
 */