package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.HashMap;
import java.util.Map;

public final class q
{
  private Map<String, Integer> a = new HashMap();

  static
  {
    CoverageLogger.Log(2467840);
  }

  public final boolean a(String paramString, int paramInt)
  {
    Integer localInteger = (Integer)this.a.get(paramString);
    int i;
    if (localInteger != null)
      i = localInteger.intValue();
    else
      i = 0;
    int j;
    if ((i & paramInt) != 0)
      j = 1;
    else
      j = 0;
    this.a.put(paramString, Integer.valueOf(paramInt | i));
    return j == 0;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.q
 * JD-Core Version:    0.6.2
 */