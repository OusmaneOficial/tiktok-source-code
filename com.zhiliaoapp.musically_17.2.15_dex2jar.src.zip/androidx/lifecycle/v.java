package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class v extends Fragment
{
  public a a;

  static
  {
    CoverageLogger.Log(123566080);
  }

  public static void a(Activity paramActivity)
  {
    FragmentManager localFragmentManager = paramActivity.getFragmentManager();
    if (localFragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null)
    {
      localFragmentManager.beginTransaction().add(new v(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
      localFragmentManager.executePendingTransactions();
    }
  }

  private void a(i.a parama)
  {
    Activity localActivity = getActivity();
    if ((localActivity instanceof n))
    {
      ((n)localActivity).a().a(parama);
      return;
    }
    if ((localActivity instanceof l))
    {
      i locali = ((l)localActivity).getLifecycle();
      if ((locali instanceof m))
        ((m)locali).a(parama);
    }
  }

  public final void onActivityCreated(Bundle paramBundle)
  {
    super.onActivityCreated(paramBundle);
    a(i.a.ON_CREATE);
  }

  public final void onDestroy()
  {
    super.onDestroy();
    a(i.a.ON_DESTROY);
    this.a = null;
  }

  public final void onPause()
  {
    super.onPause();
    a(i.a.ON_PAUSE);
  }

  public final void onResume()
  {
    super.onResume();
    a locala = this.a;
    if (locala != null)
      locala.b();
    a(i.a.ON_RESUME);
  }

  public final void onStart()
  {
    super.onStart();
    a locala = this.a;
    if (locala != null)
      locala.a();
    a(i.a.ON_START);
  }

  public final void onStop()
  {
    super.onStop();
    a(i.a.ON_STOP);
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(123807744);
    }

    public abstract void a();

    public abstract void b();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.v
 * JD-Core Version:    0.6.2
 */