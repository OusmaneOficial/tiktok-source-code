package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class z
{
  static
  {
    CoverageLogger.Log(63320064);
  }

  private static Application a(Activity paramActivity)
  {
    Application localApplication = paramActivity.getApplication();
    if (localApplication != null)
      return localApplication;
    throw new IllegalStateException("Your activity/fragment is not yet attached to Application. You can't request ViewModel before onCreate call.");
  }

  public static y a(Fragment paramFragment)
  {
    return a(paramFragment, null);
  }

  public static y a(Fragment paramFragment, y.b paramb)
  {
    Application localApplication = a(b(paramFragment));
    if (paramb == null)
      paramb = y.a.a(localApplication);
    return new y(paramFragment.getViewModelStore(), paramb);
  }

  public static y a(FragmentActivity paramFragmentActivity)
  {
    return a(paramFragmentActivity, null);
  }

  public static y a(FragmentActivity paramFragmentActivity, y.b paramb)
  {
    Application localApplication = a(paramFragmentActivity);
    if (paramb == null)
      paramb = y.a.a(localApplication);
    return new y(paramFragmentActivity.getViewModelStore(), paramb);
  }

  private static Activity b(Fragment paramFragment)
  {
    FragmentActivity localFragmentActivity = paramFragment.getActivity();
    if (localFragmentActivity != null)
      return localFragmentActivity;
    throw new IllegalStateException("Can't create ViewModelProvider for detached fragment");
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.z
 * JD-Core Version:    0.6.2
 */