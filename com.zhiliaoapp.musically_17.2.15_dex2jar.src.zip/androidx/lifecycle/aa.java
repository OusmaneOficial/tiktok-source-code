package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public class aa
{
  public final HashMap<String, x> a = new HashMap();

  static
  {
    CoverageLogger.Log(14567424);
  }

  public final x a(String paramString)
  {
    return (x)this.a.get(paramString);
  }

  public final void a()
  {
    Iterator localIterator = this.a.values().iterator();
    while (localIterator.hasNext())
      ((x)localIterator.next()).onCleared();
    this.a.clear();
  }

  public final void a(String paramString, x paramx)
  {
    x localx = (x)this.a.put(paramString, paramx);
    if (localx != null)
      localx.onCleared();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.aa
 * JD-Core Version:    0.6.2
 */