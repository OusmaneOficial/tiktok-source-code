package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f;
import e.f.a.a;
import e.f.b.l;
import e.f.b.m;
import e.f.b.z;
import e.g;
import e.k.i;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public final class h
{
  private final f b = g.a((a)a.a);

  static
  {
    CoverageLogger.Log(24340480);
    i[] arrayOfi = new i[1];
    arrayOfi[0] = ((i)z.a(new e.f.b.x(z.a(h.class), "viewModels", "getViewModels()Ljava/util/HashMap;")));
  }

  public final HashMap<String, x> a()
  {
    return (HashMap)this.b.getValue();
  }

  public final void a(String paramString, x paramx)
  {
    l.b(paramString, "key");
    l.b(paramx, "viewModel");
    x localx = (x)a().put(paramString, paramx);
    if (localx != null)
      localx.onCleared();
  }

  public final void b()
  {
    Collection localCollection = a().values();
    l.a(localCollection, "viewModels.values");
    Iterator localIterator = ((Iterable)localCollection).iterator();
    while (localIterator.hasNext())
      ((x)localIterator.next()).onCleared();
    a().clear();
  }

  static final class a extends m
    implements a<HashMap<String, x>>
  {
    public static final a a = new a();

    static
    {
      CoverageLogger.Log(24336384);
    }

    a()
    {
      super();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.h
 * JD-Core Version:    0.6.2
 */