package androidx.lifecycle;

import androidx.a.a.a.a;
import androidx.a.a.b.b;
import androidx.a.a.b.b.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Iterator;
import java.util.Map.Entry;

public abstract class LiveData<T>
{
  static final Object NOT_SET = new Object();
  int mActiveCount = 0;
  private volatile Object mData;
  final Object mDataLock = new Object();
  private boolean mDispatchInvalidated;
  private boolean mDispatchingValue;
  private b<s<? super T>, LiveData<T>.b> mObservers = new b();
  volatile Object mPendingData;
  private final Runnable mPostValueRunnable;
  public int mVersion;

  static
  {
    CoverageLogger.Log(23744512);
  }

  public LiveData()
  {
    Object localObject = NOT_SET;
    this.mData = localObject;
    this.mPendingData = localObject;
    this.mVersion = -1;
    this.mPostValueRunnable = new Runnable()
    {
      static
      {
        CoverageLogger.Log(23738368);
      }

      public final void run()
      {
        synchronized (LiveData.this.mDataLock)
        {
          Object localObject3 = LiveData.this.mPendingData;
          LiveData.this.mPendingData = LiveData.NOT_SET;
          LiveData.this.setValue(localObject3);
          return;
        }
      }
    };
  }

  private static void assertMainThread(String paramString)
  {
    if (a.a().d())
      return;
    StringBuilder localStringBuilder = new StringBuilder("Cannot invoke ");
    localStringBuilder.append(paramString);
    localStringBuilder.append(" on a background thread");
    throw new IllegalStateException(localStringBuilder.toString());
  }

  private void considerNotify(LiveData<T>.b paramLiveData)
  {
    if (!paramLiveData.d)
      return;
    if (!paramLiveData.a())
    {
      paramLiveData.a(false);
      return;
    }
    int i = paramLiveData.e;
    int j = this.mVersion;
    if (i >= j)
      return;
    paramLiveData.e = j;
    paramLiveData.c.onChanged(this.mData);
  }

  void dispatchingValue(LiveData<T>.b paramLiveData)
  {
    if (this.mDispatchingValue)
    {
      this.mDispatchInvalidated = true;
      return;
    }
    this.mDispatchingValue = true;
    do
    {
      this.mDispatchInvalidated = false;
      if (paramLiveData != null)
      {
        considerNotify(paramLiveData);
        paramLiveData = null;
      }
      else
      {
        b.d locald = this.mObservers.a();
        do
        {
          if (!locald.hasNext())
            break;
          considerNotify((b)((Map.Entry)locald.next()).getValue());
        }
        while (!this.mDispatchInvalidated);
      }
    }
    while (this.mDispatchInvalidated);
    this.mDispatchingValue = false;
  }

  public T getValue()
  {
    Object localObject = this.mData;
    if (localObject != NOT_SET)
      return localObject;
    return null;
  }

  public boolean hasActiveObservers()
  {
    return this.mActiveCount > 0;
  }

  public boolean hasObservers()
  {
    return this.mObservers.e > 0;
  }

  public void observe(l paraml, s<? super T> params)
  {
    assertMainThread("observe");
    if (paraml.getLifecycle().a() == i.b.DESTROYED)
      return;
    LifecycleBoundObserver localLifecycleBoundObserver = new LifecycleBoundObserver(paraml, params);
    b localb = (b)this.mObservers.a(params, localLifecycleBoundObserver);
    if ((localb != null) && (!localb.a(paraml)))
      throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
    if (localb != null)
      return;
    paraml.getLifecycle().a(localLifecycleBoundObserver);
  }

  public void observeForever(s<? super T> params)
  {
    assertMainThread("observeForever");
    a locala = new a(params);
    b localb = (b)this.mObservers.a(params, locala);
    if ((localb != null) && ((localb instanceof LifecycleBoundObserver)))
      throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
    if (localb != null)
      return;
    locala.a(true);
  }

  protected void onActive()
  {
  }

  protected void onInactive()
  {
  }

  protected void postValue(T paramT)
  {
    while (true)
    {
      synchronized (this.mDataLock)
      {
        if (this.mPendingData == NOT_SET)
        {
          i = 1;
          this.mPendingData = paramT;
          if (i == 0)
            return;
          a.a().b(this.mPostValueRunnable);
          return;
        }
      }
      int i = 0;
    }
  }

  public void removeObserver(s<? super T> params)
  {
    assertMainThread("removeObserver");
    b localb = (b)this.mObservers.b(params);
    if (localb == null)
      return;
    localb.b();
    localb.a(false);
  }

  public void removeObservers(l paraml)
  {
    assertMainThread("removeObservers");
    Iterator localIterator = this.mObservers.iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (((b)localEntry.getValue()).a(paraml))
        removeObserver((s)localEntry.getKey());
    }
  }

  protected void setValue(T paramT)
  {
    assertMainThread("setValue");
    this.mVersion = (1 + this.mVersion);
    this.mData = paramT;
    dispatchingValue(null);
  }

  class LifecycleBoundObserver extends LiveData<T>.b
    implements g
  {
    final l a;

    static
    {
      CoverageLogger.Log(23506944);
    }

    LifecycleBoundObserver(s<? super T> arg2)
    {
      super(locals);
      Object localObject;
      this.a = localObject;
    }

    public final void a(l paraml, i.a parama)
    {
      if (this.a.getLifecycle().a() == i.b.DESTROYED)
      {
        LiveData.this.removeObserver(this.c);
        return;
      }
      a(a());
    }

    final boolean a()
    {
      return this.a.getLifecycle().a().isAtLeast(i.b.STARTED);
    }

    final boolean a(l paraml)
    {
      return this.a == paraml;
    }

    final void b()
    {
      this.a.getLifecycle().b(this);
    }
  }

  final class a extends LiveData<T>.b
  {
    static
    {
      CoverageLogger.Log(23508992);
    }

    a()
    {
      super(locals);
    }

    final boolean a()
    {
      return true;
    }
  }

  abstract class b
  {
    final s<? super T> c;
    boolean d;
    int e = -1;

    static
    {
      CoverageLogger.Log(23746560);
    }

    b()
    {
      Object localObject;
      this.c = localObject;
    }

    final void a(boolean paramBoolean)
    {
      if (paramBoolean == this.d)
        return;
      this.d = paramBoolean;
      int i = LiveData.this.mActiveCount;
      int j = 1;
      int k;
      if (i == 0)
        k = 1;
      else
        k = 0;
      LiveData localLiveData = LiveData.this;
      int m = localLiveData.mActiveCount;
      if (!this.d)
        j = -1;
      localLiveData.mActiveCount = (m + j);
      if ((k != 0) && (this.d))
        LiveData.this.onActive();
      if ((LiveData.this.mActiveCount == 0) && (!this.d))
        LiveData.this.onInactive();
      if (this.d)
        LiveData.this.dispatchingValue(this);
    }

    abstract boolean a();

    boolean a(l paraml)
    {
      return false;
    }

    void b()
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.LiveData
 * JD-Core Version:    0.6.2
 */