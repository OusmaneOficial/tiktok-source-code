package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class c<T>
{
  final Executor a;
  public final LiveData<T> b;
  final AtomicBoolean c = new AtomicBoolean(true);
  final AtomicBoolean d = new AtomicBoolean(false);
  final Runnable e = new Runnable()
  {
    static
    {
      CoverageLogger.Log(81694720);
    }

    public final void run()
    {
      int i;
      do
      {
        if (c.this.d.compareAndSet(false, true))
        {
          Object localObject1 = null;
          i = 0;
          try
          {
            while (c.this.c.compareAndSet(true, false))
            {
              localObject1 = c.this.a();
              i = 1;
            }
            if (i != 0)
              c.this.b.postValue(localObject1);
          }
          finally
          {
            c.this.d.set(false);
          }
        }
        i = 0;
      }
      while ((i != 0) && (c.this.c.get()));
    }
  };
  public final Runnable f = new Runnable()
  {
    static
    {
      CoverageLogger.Log(81438720);
    }

    public final void run()
    {
      boolean bool = c.this.b.hasActiveObservers();
      if ((c.this.c.compareAndSet(false, true)) && (bool))
        c.this.a.execute(c.this.e);
    }
  };

  static
  {
    CoverageLogger.Log(81436672);
  }

  public c(Executor paramExecutor)
  {
    this.a = paramExecutor;
    this.b = new LiveData()
    {
      static
      {
        CoverageLogger.Log(81692672);
      }

      protected final void onActive()
      {
        c.this.a.execute(c.this.e);
      }
    };
  }

  protected abstract T a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.c
 * JD-Core Version:    0.6.2
 */