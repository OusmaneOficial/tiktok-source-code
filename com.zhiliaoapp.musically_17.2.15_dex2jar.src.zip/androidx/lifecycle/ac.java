package androidx.lifecycle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class ac
{
  static
  {
    CoverageLogger.Log(63328256);
  }

  public static aa a(Fragment paramFragment)
  {
    return paramFragment.getViewModelStore();
  }

  public static aa a(FragmentActivity paramFragmentActivity)
  {
    return paramFragmentActivity.getViewModelStore();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.ac
 * JD-Core Version:    0.6.2
 */