package androidx.lifecycle;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

final class b
{
  static b a = new b();
  private final Map<Class, a> b = new HashMap();
  private final Map<Class, Boolean> c = new HashMap();

  static
  {
    CoverageLogger.Log(2742272);
  }

  private a a(Class paramClass, Method[] paramArrayOfMethod)
  {
    Class localClass = paramClass.getSuperclass();
    HashMap localHashMap = new HashMap();
    if (localClass != null)
    {
      a locala2 = b(localClass);
      if (locala2 != null)
        localHashMap.putAll(locala2.b);
    }
    Class[] arrayOfClass1 = paramClass.getInterfaces();
    int i = arrayOfClass1.length;
    for (int j = 0; j < i; j++)
    {
      Iterator localIterator = b(arrayOfClass1[j]).b.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        a(localHashMap, (b)localEntry.getKey(), (i.a)localEntry.getValue(), paramClass);
      }
    }
    if (paramArrayOfMethod == null)
      paramArrayOfMethod = c(paramClass);
    int k = paramArrayOfMethod.length;
    int m = 0;
    boolean bool = false;
    while (m < k)
    {
      Method localMethod = paramArrayOfMethod[m];
      t localt = (t)localMethod.getAnnotation(t.class);
      if (localt != null)
      {
        Class[] arrayOfClass2 = localMethod.getParameterTypes();
        int n;
        if (arrayOfClass2.length > 0)
        {
          if (arrayOfClass2[0].isAssignableFrom(l.class))
            n = 1;
          else
            throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
        }
        else
          n = 0;
        i.a locala = localt.a();
        if (arrayOfClass2.length > 1)
          if (arrayOfClass2[1].isAssignableFrom(i.a.class))
          {
            if (locala == i.a.ON_ANY)
              n = 2;
            else
              throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
          }
          else
            throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
        if (arrayOfClass2.length <= 2)
        {
          a(localHashMap, new b(n, localMethod), locala, paramClass);
          bool = true;
        }
        else
        {
          throw new IllegalArgumentException("cannot have more than 2 params");
        }
      }
      m++;
    }
    a locala1 = new a(localHashMap);
    this.b.put(paramClass, locala1);
    this.c.put(paramClass, Boolean.valueOf(bool));
    return locala1;
  }

  private static void a(Map<b, i.a> paramMap, b paramb, i.a parama, Class paramClass)
  {
    i.a locala = (i.a)paramMap.get(paramb);
    if ((locala != null) && (parama != locala))
    {
      Method localMethod = paramb.b;
      StringBuilder localStringBuilder = new StringBuilder("Method ");
      localStringBuilder.append(localMethod.getName());
      localStringBuilder.append(" in ");
      localStringBuilder.append(paramClass.getName());
      localStringBuilder.append(" already declared with different @OnLifecycleEvent value: previous value ");
      localStringBuilder.append(locala);
      localStringBuilder.append(", new value ");
      localStringBuilder.append(parama);
      throw new IllegalArgumentException(localStringBuilder.toString());
    }
    if (locala == null)
      paramMap.put(paramb, parama);
  }

  private static Method[] c(Class paramClass)
  {
    try
    {
      Method[] arrayOfMethod = paramClass.getDeclaredMethods();
      return arrayOfMethod;
    }
    catch (NoClassDefFoundError localNoClassDefFoundError)
    {
      throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", localNoClassDefFoundError);
    }
  }

  final boolean a(Class paramClass)
  {
    if (this.c.containsKey(paramClass))
      return ((Boolean)this.c.get(paramClass)).booleanValue();
    Method[] arrayOfMethod = c(paramClass);
    int i = arrayOfMethod.length;
    for (int j = 0; j < i; j++)
      if ((t)arrayOfMethod[j].getAnnotation(t.class) != null)
      {
        a(paramClass, arrayOfMethod);
        return true;
      }
    this.c.put(paramClass, Boolean.valueOf(false));
    return false;
  }

  final a b(Class paramClass)
  {
    a locala = (a)this.b.get(paramClass);
    if (locala != null)
      return locala;
    return a(paramClass, null);
  }

  static final class a
  {
    final Map<i.a, List<b.b>> a;
    final Map<b.b, i.a> b;

    static
    {
      CoverageLogger.Log(2451456);
    }

    a(Map<b.b, i.a> paramMap)
    {
      this.b = paramMap;
      this.a = new HashMap();
      Iterator localIterator = paramMap.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        i.a locala = (i.a)localEntry.getValue();
        Object localObject = (List)this.a.get(locala);
        if (localObject == null)
        {
          localObject = new ArrayList();
          this.a.put(locala, localObject);
        }
        ((List)localObject).add(localEntry.getKey());
      }
    }

    static void a(List<b.b> paramList, l paraml, i.a parama, Object paramObject)
    {
      if (paramList != null)
        for (int i = -1 + paramList.size(); i >= 0; i--)
          ((b.b)paramList.get(i)).a(paraml, parama, paramObject);
    }
  }

  static final class b
  {
    final int a;
    final Method b;

    static
    {
      CoverageLogger.Log(2744320);
    }

    b(int paramInt, Method paramMethod)
    {
      this.a = paramInt;
      this.b = paramMethod;
      this.b.setAccessible(true);
    }

    final void a(l paraml, i.a parama, Object paramObject)
    {
      try
      {
        int i = this.a;
        if (i != 0)
        {
          if (i != 1)
          {
            if (i != 2)
              return;
            this.b.invoke(paramObject, new Object[] { paraml, parama });
            return;
          }
          this.b.invoke(paramObject, new Object[] { paraml });
          return;
        }
        this.b.invoke(paramObject, new Object[0]);
        return;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new RuntimeException(localIllegalAccessException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new RuntimeException("Failed to call observer method", localInvocationTargetException.getCause());
      }
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject != null)
      {
        if (getClass() != paramObject.getClass())
          return false;
        b localb = (b)paramObject;
        if ((this.a == localb.a) && (this.b.getName().equals(localb.b.getName())))
          return true;
      }
      return false;
    }

    public final int hashCode()
    {
      return 31 * this.a + this.b.getName().hashCode();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.lifecycle.b
 * JD-Core Version:    0.6.2
 */