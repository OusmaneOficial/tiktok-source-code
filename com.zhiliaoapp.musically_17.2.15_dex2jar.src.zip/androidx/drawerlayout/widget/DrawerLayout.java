package androidx.drawerlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.ClassLoaderCreator;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import androidx.core.content.b;
import androidx.core.h.a.c;
import androidx.core.h.a.c.a;
import androidx.core.h.d;
import androidx.core.h.t;
import androidx.customview.a.a.a;
import androidx.customview.view.AbsSavedState;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.List;

public class DrawerLayout extends ViewGroup
{
  static final boolean CAN_HIDE_DESCENDANTS;
  static final int[] LAYOUT_ATTRS;
  private static final boolean SET_DRAWER_SHADOW_FROM_ELEVATION = bool1;
  private static final int[] THEME_ATTRS;
  private final b mChildAccessibilityDelegate = new b();
  private Rect mChildHitRect;
  private Matrix mChildInvertedMatrix;
  private boolean mChildrenCanceledTouch;
  private boolean mDisallowInterceptRequested;
  private boolean mDrawStatusBarBackground;
  private float mDrawerElevation;
  private int mDrawerState;
  private boolean mFirstLayout = true;
  private boolean mInLayout;
  private float mInitialMotionX;
  private float mInitialMotionY;
  private Object mLastInsets;
  private final e mLeftCallback;
  private final androidx.customview.a.a mLeftDragger;
  private c mListener;
  private List<c> mListeners;
  private int mLockModeEnd = 3;
  private int mLockModeLeft = 3;
  private int mLockModeRight = 3;
  private int mLockModeStart = 3;
  private int mMinDrawerMargin;
  private final ArrayList<View> mNonDrawerViews;
  private final e mRightCallback;
  private final androidx.customview.a.a mRightDragger;
  private int mScrimColor = -1728053248;
  private float mScrimOpacity;
  private Paint mScrimPaint = new Paint();
  private Drawable mShadowEnd = null;
  private Drawable mShadowLeft = null;
  private Drawable mShadowLeftResolved;
  private Drawable mShadowRight = null;
  private Drawable mShadowRightResolved;
  private Drawable mShadowStart = null;
  private Drawable mStatusBarBackground;
  private CharSequence mTitleLeft;
  private CharSequence mTitleRight;

  static
  {
    CoverageLogger.Log(68124672);
    boolean bool1 = true;
    int[] arrayOfInt1 = new int[bool1];
    arrayOfInt1[0] = 16843828;
    THEME_ATTRS = arrayOfInt1;
    int[] arrayOfInt2 = new int[bool1];
    arrayOfInt2[0] = 16842931;
    LAYOUT_ATTRS = arrayOfInt2;
    boolean bool2;
    if (Build.VERSION.SDK_INT >= 19)
      bool2 = true;
    else
      bool2 = false;
    CAN_HIDE_DESCENDANTS = bool2;
    if (Build.VERSION.SDK_INT < 21)
      bool1 = false;
  }

  public DrawerLayout(Context paramContext)
  {
    this(paramContext, null);
  }

  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    setDescendantFocusability(262144);
    float f1 = getResources().getDisplayMetrics().density;
    this.mMinDrawerMargin = ((int)(0.5F + 64.0F * f1));
    float f2 = 400.0F * f1;
    this.mLeftCallback = new e(3);
    this.mRightCallback = new e(5);
    this.mLeftDragger = androidx.customview.a.a.a(this, 1.0F, this.mLeftCallback);
    androidx.customview.a.a locala1 = this.mLeftDragger;
    locala1.j = 1;
    locala1.h = f2;
    this.mLeftCallback.b = locala1;
    this.mRightDragger = androidx.customview.a.a.a(this, 1.0F, this.mRightCallback);
    androidx.customview.a.a locala2 = this.mRightDragger;
    locala2.j = 2;
    locala2.h = f2;
    this.mRightCallback.b = locala2;
    setFocusableInTouchMode(true);
    t.b(this, 1);
    t.a(this, new a());
    setMotionEventSplittingEnabled(false);
    if (t.s(this))
    {
      TypedArray localTypedArray;
      if (Build.VERSION.SDK_INT >= 21)
      {
        setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener()
        {
          static
          {
            CoverageLogger.Log(68220928);
          }

          public final WindowInsets onApplyWindowInsets(View paramAnonymousView, WindowInsets paramAnonymousWindowInsets)
          {
            DrawerLayout localDrawerLayout = (DrawerLayout)paramAnonymousView;
            boolean bool;
            if (paramAnonymousWindowInsets.getSystemWindowInsetTop() > 0)
              bool = true;
            else
              bool = false;
            localDrawerLayout.setChildInsets(paramAnonymousWindowInsets, bool);
            return paramAnonymousWindowInsets.consumeSystemWindowInsets();
          }
        });
        setSystemUiVisibility(1280);
        localTypedArray = paramContext.obtainStyledAttributes(THEME_ATTRS);
      }
      try
      {
        this.mStatusBarBackground = localTypedArray.getDrawable(0);
        localTypedArray.recycle();
      }
      finally
      {
        localTypedArray.recycle();
      }
    }
    this.mDrawerElevation = (f1 * 10.0F);
    this.mNonDrawerViews = new ArrayList();
  }

  private boolean dispatchTransformedGenericPointerEvent(MotionEvent paramMotionEvent, View paramView)
  {
    if (!paramView.getMatrix().isIdentity())
    {
      MotionEvent localMotionEvent = getTransformedMotionEvent(paramMotionEvent, paramView);
      boolean bool2 = paramView.dispatchGenericMotionEvent(localMotionEvent);
      localMotionEvent.recycle();
      return bool2;
    }
    float f1 = getScrollX() - paramView.getLeft();
    float f2 = getScrollY() - paramView.getTop();
    paramMotionEvent.offsetLocation(f1, f2);
    boolean bool1 = paramView.dispatchGenericMotionEvent(paramMotionEvent);
    paramMotionEvent.offsetLocation(-f1, -f2);
    return bool1;
  }

  private MotionEvent getTransformedMotionEvent(MotionEvent paramMotionEvent, View paramView)
  {
    float f1 = getScrollX() - paramView.getLeft();
    float f2 = getScrollY() - paramView.getTop();
    MotionEvent localMotionEvent = MotionEvent.obtain(paramMotionEvent);
    localMotionEvent.offsetLocation(f1, f2);
    Matrix localMatrix = paramView.getMatrix();
    if (!localMatrix.isIdentity())
    {
      if (this.mChildInvertedMatrix == null)
        this.mChildInvertedMatrix = new Matrix();
      localMatrix.invert(this.mChildInvertedMatrix);
      localMotionEvent.transform(this.mChildInvertedMatrix);
    }
    return localMotionEvent;
  }

  static String gravityToString(int paramInt)
  {
    if ((paramInt & 0x3) == 3)
      return "LEFT";
    if ((paramInt & 0x5) == 5)
      return "RIGHT";
    return Integer.toHexString(paramInt);
  }

  private static boolean hasOpaqueBackground(View paramView)
  {
    Drawable localDrawable = paramView.getBackground();
    return (localDrawable != null) && (localDrawable.getOpacity() == -1);
  }

  private boolean hasPeekingDrawer()
  {
    int i = getChildCount();
    for (int j = 0; j < i; j++)
      if (((LayoutParams)getChildAt(j).getLayoutParams()).c)
        return true;
    return false;
  }

  private boolean hasVisibleDrawer()
  {
    return findVisibleDrawer() != null;
  }

  static boolean includeChildForAccessibility(View paramView)
  {
    return (t.e(paramView) != 4) && (t.e(paramView) != 2);
  }

  private boolean isInBoundsOfChild(float paramFloat1, float paramFloat2, View paramView)
  {
    if (this.mChildHitRect == null)
      this.mChildHitRect = new Rect();
    paramView.getHitRect(this.mChildHitRect);
    return this.mChildHitRect.contains((int)paramFloat1, (int)paramFloat2);
  }

  private boolean mirror(Drawable paramDrawable, int paramInt)
  {
    if ((paramDrawable != null) && (androidx.core.graphics.drawable.a.b(paramDrawable)))
    {
      androidx.core.graphics.drawable.a.b(paramDrawable, paramInt);
      return true;
    }
    return false;
  }

  private Drawable resolveLeftShadow()
  {
    int i = t.f(this);
    if (i == 0)
    {
      Drawable localDrawable2 = this.mShadowStart;
      if (localDrawable2 != null)
      {
        mirror(localDrawable2, i);
        return this.mShadowStart;
      }
    }
    else
    {
      Drawable localDrawable1 = this.mShadowEnd;
      if (localDrawable1 != null)
      {
        mirror(localDrawable1, i);
        return this.mShadowEnd;
      }
    }
    return this.mShadowLeft;
  }

  private Drawable resolveRightShadow()
  {
    int i = t.f(this);
    if (i == 0)
    {
      Drawable localDrawable2 = this.mShadowEnd;
      if (localDrawable2 != null)
      {
        mirror(localDrawable2, i);
        return this.mShadowEnd;
      }
    }
    else
    {
      Drawable localDrawable1 = this.mShadowStart;
      if (localDrawable1 != null)
      {
        mirror(localDrawable1, i);
        return this.mShadowStart;
      }
    }
    return this.mShadowRight;
  }

  private void resolveShadowDrawables()
  {
    if (SET_DRAWER_SHADOW_FROM_ELEVATION)
      return;
    this.mShadowLeftResolved = resolveLeftShadow();
    this.mShadowRightResolved = resolveRightShadow();
  }

  private void updateChildrenImportantForAccessibility(View paramView, boolean paramBoolean)
  {
    int i = getChildCount();
    for (int j = 0; j < i; j++)
    {
      View localView = getChildAt(j);
      if (((!paramBoolean) && (!isDrawerView(localView))) || ((paramBoolean) && (localView == paramView)))
        t.b(localView, 1);
      else
        t.b(localView, 4);
    }
  }

  public void addDrawerListener(c paramc)
  {
    if (paramc == null)
      return;
    if (this.mListeners == null)
      this.mListeners = new ArrayList();
    this.mListeners.add(paramc);
  }

  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2)
  {
    if (getDescendantFocusability() == 393216)
      return;
    int i = getChildCount();
    int j = 0;
    int k = 0;
    int m = 0;
    while (k < i)
    {
      View localView2 = getChildAt(k);
      if (isDrawerView(localView2))
      {
        if (isDrawerOpen(localView2))
        {
          localView2.addFocusables(paramArrayList, paramInt1, paramInt2);
          m = 1;
        }
      }
      else
        this.mNonDrawerViews.add(localView2);
      k++;
    }
    if (m == 0)
    {
      int n = this.mNonDrawerViews.size();
      while (j < n)
      {
        View localView1 = (View)this.mNonDrawerViews.get(j);
        if (localView1.getVisibility() == 0)
          localView1.addFocusables(paramArrayList, paramInt1, paramInt2);
        j++;
      }
    }
    this.mNonDrawerViews.clear();
  }

  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    super.addView(paramView, paramInt, paramLayoutParams);
    if ((findOpenDrawer() == null) && (!isDrawerView(paramView)))
      t.b(paramView, 1);
    else
      t.b(paramView, 4);
    if (!CAN_HIDE_DESCENDANTS)
      t.a(paramView, this.mChildAccessibilityDelegate);
  }

  void cancelChildViewTouch()
  {
    if (!this.mChildrenCanceledTouch)
    {
      long l = SystemClock.uptimeMillis();
      MotionEvent localMotionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      int i = getChildCount();
      for (int j = 0; j < i; j++)
        getChildAt(j).dispatchTouchEvent(localMotionEvent);
      localMotionEvent.recycle();
      this.mChildrenCanceledTouch = true;
    }
  }

  boolean checkDrawerViewAbsoluteGravity(View paramView, int paramInt)
  {
    return (paramInt & getDrawerViewAbsoluteGravity(paramView)) == paramInt;
  }

  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return ((paramLayoutParams instanceof LayoutParams)) && (super.checkLayoutParams(paramLayoutParams));
  }

  public void closeDrawer(int paramInt)
  {
    closeDrawer(paramInt, true);
  }

  public void closeDrawer(int paramInt, boolean paramBoolean)
  {
    View localView = findDrawerWithGravity(paramInt);
    if (localView != null)
    {
      closeDrawer(localView, paramBoolean);
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("No drawer view found with gravity ");
    localStringBuilder.append(gravityToString(paramInt));
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public void closeDrawer(View paramView)
  {
    closeDrawer(paramView, true);
  }

  public void closeDrawer(View paramView, boolean paramBoolean)
  {
    if (isDrawerView(paramView))
    {
      LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
      if (this.mFirstLayout)
      {
        localLayoutParams.b = 0.0F;
        localLayoutParams.d = 0;
      }
      else if (paramBoolean)
      {
        localLayoutParams.d = (0x4 | localLayoutParams.d);
        if (checkDrawerViewAbsoluteGravity(paramView, 3))
          this.mLeftDragger.a(paramView, -paramView.getWidth(), paramView.getTop());
        else
          this.mRightDragger.a(paramView, getWidth(), paramView.getTop());
      }
      else
      {
        moveDrawerToOffset(paramView, 0.0F);
        updateDrawerState(localLayoutParams.a, 0, paramView);
        paramView.setVisibility(4);
      }
      invalidate();
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("View ");
    localStringBuilder.append(paramView);
    localStringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public void closeDrawers()
  {
    closeDrawers(false);
  }

  void closeDrawers(boolean paramBoolean)
  {
    int i = getChildCount();
    int j = 0;
    boolean bool1 = false;
    while (j < i)
    {
      View localView = getChildAt(j);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      if ((isDrawerView(localView)) && ((!paramBoolean) || (localLayoutParams.c)))
      {
        int k = localView.getWidth();
        boolean bool2;
        if (checkDrawerViewAbsoluteGravity(localView, 3))
          bool2 = this.mLeftDragger.a(localView, -k, localView.getTop());
        else
          bool2 = this.mRightDragger.a(localView, getWidth(), localView.getTop());
        bool1 |= bool2;
        localLayoutParams.c = false;
      }
      j++;
    }
    this.mLeftCallback.a();
    this.mRightCallback.a();
    if (bool1)
      invalidate();
  }

  public void computeScroll()
  {
    int i = getChildCount();
    float f = 0.0F;
    for (int j = 0; j < i; j++)
      f = Math.max(f, ((LayoutParams)getChildAt(j).getLayoutParams()).b);
    this.mScrimOpacity = f;
    boolean bool1 = this.mLeftDragger.a(true);
    boolean bool2 = this.mRightDragger.a(true);
    if ((bool1) || (bool2))
      t.d(this);
  }

  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    if (((0x2 & paramMotionEvent.getSource()) != 0) && (paramMotionEvent.getAction() != 10) && (this.mScrimOpacity > 0.0F))
    {
      int i = getChildCount();
      if (i != 0)
      {
        float f1 = paramMotionEvent.getX();
        float f2 = paramMotionEvent.getY();
        for (int j = i - 1; j >= 0; j--)
        {
          View localView = getChildAt(j);
          if ((isInBoundsOfChild(f1, f2, localView)) && (!isContentView(localView)) && (dispatchTransformedGenericPointerEvent(paramMotionEvent, localView)))
            return true;
        }
      }
      return false;
    }
    return super.dispatchGenericMotionEvent(paramMotionEvent);
  }

  void dispatchOnDrawerClosed(View paramView)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    if ((0x1 & localLayoutParams.d) == 1)
    {
      localLayoutParams.d = 0;
      List localList = this.mListeners;
      if (localList != null)
        for (int i = localList.size() - 1; i >= 0; i--)
          ((c)this.mListeners.get(i)).onDrawerClosed(paramView);
      updateChildrenImportantForAccessibility(paramView, false);
      if (hasWindowFocus())
      {
        View localView = getRootView();
        if (localView != null)
          localView.sendAccessibilityEvent(32);
      }
    }
  }

  void dispatchOnDrawerOpened(View paramView)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    if ((0x1 & localLayoutParams.d) == 0)
    {
      localLayoutParams.d = 1;
      List localList = this.mListeners;
      if (localList != null)
        for (int i = localList.size() - 1; i >= 0; i--)
          ((c)this.mListeners.get(i)).onDrawerOpened(paramView);
      updateChildrenImportantForAccessibility(paramView, true);
      if (hasWindowFocus())
        sendAccessibilityEvent(32);
    }
  }

  void dispatchOnDrawerSlide(View paramView, float paramFloat)
  {
    List localList = this.mListeners;
    if (localList != null)
      for (int i = -1 + localList.size(); i >= 0; i--)
        ((c)this.mListeners.get(i)).onDrawerSlide(paramView, paramFloat);
  }

  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong)
  {
    int i = getHeight();
    boolean bool1 = isContentView(paramView);
    int j = getWidth();
    int k = paramCanvas.save();
    int m = 0;
    int n;
    if (bool1)
    {
      int i10 = getChildCount();
      n = j;
      int i11 = 0;
      int i12 = 0;
      while (i11 < i10)
      {
        View localView = getChildAt(i11);
        if ((localView != paramView) && (localView.getVisibility() == 0) && (hasOpaqueBackground(localView)) && (isDrawerView(localView)) && (localView.getHeight() >= i))
          if (checkDrawerViewAbsoluteGravity(localView, 3))
          {
            int i14 = localView.getRight();
            if (i14 > i12)
              i12 = i14;
          }
          else
          {
            int i13 = localView.getLeft();
            if (i13 < n)
              n = i13;
          }
        i11++;
      }
      paramCanvas.clipRect(i12, 0, n, getHeight());
      m = i12;
    }
    else
    {
      n = j;
    }
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(k);
    float f1 = this.mScrimOpacity;
    if ((f1 > 0.0F) && (bool1))
    {
      int i8 = this.mScrimColor;
      int i9 = (int)(f1 * ((0xFF000000 & i8) >>> 24)) << 24 | i8 & 0xFFFFFF;
      this.mScrimPaint.setColor(i9);
      paramCanvas.drawRect(m, 0.0F, n, getHeight(), this.mScrimPaint);
      return bool2;
    }
    if ((this.mShadowLeftResolved != null) && (checkDrawerViewAbsoluteGravity(paramView, 3)))
    {
      int i5 = this.mShadowLeftResolved.getIntrinsicWidth();
      int i6 = paramView.getRight();
      int i7 = this.mLeftDragger.i;
      float f3 = Math.max(0.0F, Math.min(i6 / i7, 1.0F));
      this.mShadowLeftResolved.setBounds(i6, paramView.getTop(), i5 + i6, paramView.getBottom());
      this.mShadowLeftResolved.setAlpha((int)(f3 * 255.0F));
      this.mShadowLeftResolved.draw(paramCanvas);
      return bool2;
    }
    if ((this.mShadowRightResolved != null) && (checkDrawerViewAbsoluteGravity(paramView, 5)))
    {
      int i1 = this.mShadowRightResolved.getIntrinsicWidth();
      int i2 = paramView.getLeft();
      int i3 = getWidth() - i2;
      int i4 = this.mRightDragger.i;
      float f2 = Math.max(0.0F, Math.min(i3 / i4, 1.0F));
      this.mShadowRightResolved.setBounds(i2 - i1, paramView.getTop(), i2, paramView.getBottom());
      this.mShadowRightResolved.setAlpha((int)(f2 * 255.0F));
      this.mShadowRightResolved.draw(paramCanvas);
    }
    return bool2;
  }

  View findDrawerWithGravity(int paramInt)
  {
    int i = 0x7 & d.a(paramInt, t.f(this));
    int j = getChildCount();
    for (int k = 0; k < j; k++)
    {
      View localView = getChildAt(k);
      if ((0x7 & getDrawerViewAbsoluteGravity(localView)) == i)
        return localView;
    }
    return null;
  }

  View findOpenDrawer()
  {
    int i = getChildCount();
    for (int j = 0; j < i; j++)
    {
      View localView = getChildAt(j);
      if ((0x1 & ((LayoutParams)localView.getLayoutParams()).d) == 1)
        return localView;
    }
    return null;
  }

  View findVisibleDrawer()
  {
    int i = getChildCount();
    for (int j = 0; j < i; j++)
    {
      View localView = getChildAt(j);
      if ((isDrawerView(localView)) && (isDrawerVisible(localView)))
        return localView;
    }
    return null;
  }

  protected ViewGroup.LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams(-1, -1);
  }

  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }

  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof LayoutParams))
      return new LayoutParams((LayoutParams)paramLayoutParams);
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams))
      return new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams);
    return new LayoutParams(paramLayoutParams);
  }

  public float getDrawerElevation()
  {
    if (SET_DRAWER_SHADOW_FROM_ELEVATION)
      return this.mDrawerElevation;
    return 0.0F;
  }

  public int getDrawerLockMode(int paramInt)
  {
    int i = t.f(this);
    if (paramInt != 3)
    {
      if (paramInt != 5)
      {
        if (paramInt != 8388611)
        {
          if (paramInt == 8388613)
          {
            int i3 = this.mLockModeEnd;
            if (i3 != 3)
              return i3;
            int i4;
            if (i == 0)
              i4 = this.mLockModeRight;
            else
              i4 = this.mLockModeLeft;
            if (i4 != 3)
              return i4;
          }
        }
        else
        {
          int i1 = this.mLockModeStart;
          if (i1 != 3)
            return i1;
          int i2;
          if (i == 0)
            i2 = this.mLockModeLeft;
          else
            i2 = this.mLockModeRight;
          if (i2 != 3)
            return i2;
        }
      }
      else
      {
        int m = this.mLockModeRight;
        if (m != 3)
          return m;
        int n;
        if (i == 0)
          n = this.mLockModeEnd;
        else
          n = this.mLockModeStart;
        if (n != 3)
          return n;
      }
    }
    else
    {
      int j = this.mLockModeLeft;
      if (j != 3)
        return j;
      int k;
      if (i == 0)
        k = this.mLockModeStart;
      else
        k = this.mLockModeEnd;
      if (k != 3)
        return k;
    }
    return 0;
  }

  public int getDrawerLockMode(View paramView)
  {
    if (isDrawerView(paramView))
      return getDrawerLockMode(((LayoutParams)paramView.getLayoutParams()).a);
    StringBuilder localStringBuilder = new StringBuilder("View ");
    localStringBuilder.append(paramView);
    localStringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public CharSequence getDrawerTitle(int paramInt)
  {
    int i = d.a(paramInt, t.f(this));
    if (i == 3)
      return this.mTitleLeft;
    if (i == 5)
      return this.mTitleRight;
    return null;
  }

  int getDrawerViewAbsoluteGravity(View paramView)
  {
    return d.a(((LayoutParams)paramView.getLayoutParams()).a, t.f(this));
  }

  float getDrawerViewOffset(View paramView)
  {
    return ((LayoutParams)paramView.getLayoutParams()).b;
  }

  public Drawable getStatusBarBackgroundDrawable()
  {
    return this.mStatusBarBackground;
  }

  boolean isContentView(View paramView)
  {
    return ((LayoutParams)paramView.getLayoutParams()).a == 0;
  }

  public boolean isDrawerOpen(int paramInt)
  {
    View localView = findDrawerWithGravity(paramInt);
    if (localView != null)
      return isDrawerOpen(localView);
    return false;
  }

  public boolean isDrawerOpen(View paramView)
  {
    if (isDrawerView(paramView))
      return (0x1 & ((LayoutParams)paramView.getLayoutParams()).d) == 1;
    StringBuilder localStringBuilder = new StringBuilder("View ");
    localStringBuilder.append(paramView);
    localStringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  boolean isDrawerView(View paramView)
  {
    int i = d.a(((LayoutParams)paramView.getLayoutParams()).a, t.f(paramView));
    if ((i & 0x3) != 0)
      return true;
    return (i & 0x5) != 0;
  }

  public boolean isDrawerVisible(int paramInt)
  {
    View localView = findDrawerWithGravity(paramInt);
    if (localView != null)
      return isDrawerVisible(localView);
    return false;
  }

  public boolean isDrawerVisible(View paramView)
  {
    if (isDrawerView(paramView))
      return ((LayoutParams)paramView.getLayoutParams()).b > 0.0F;
    StringBuilder localStringBuilder = new StringBuilder("View ");
    localStringBuilder.append(paramView);
    localStringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  void moveDrawerToOffset(View paramView, float paramFloat)
  {
    float f1 = getDrawerViewOffset(paramView);
    float f2 = paramView.getWidth();
    int i = (int)(f1 * f2);
    int j = (int)(f2 * paramFloat) - i;
    if (!checkDrawerViewAbsoluteGravity(paramView, 3))
      j = -j;
    paramView.offsetLeftAndRight(j);
    setDrawerViewOffset(paramView, paramFloat);
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.mFirstLayout = true;
  }

  public void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if ((this.mDrawStatusBarBackground) && (this.mStatusBarBackground != null))
    {
      if (Build.VERSION.SDK_INT >= 21)
      {
        Object localObject = this.mLastInsets;
        if (localObject != null)
        {
          i = ((WindowInsets)localObject).getSystemWindowInsetTop();
          break label49;
        }
      }
      int i = 0;
      label49: if (i > 0)
      {
        this.mStatusBarBackground.setBounds(0, 0, getWidth(), i);
        this.mStatusBarBackground.draw(paramCanvas);
      }
    }
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = paramMotionEvent.getActionMasked();
    boolean bool = this.mLeftDragger.a(paramMotionEvent) | this.mRightDragger.a(paramMotionEvent);
    label153: label173: label210: int j;
    if (i != 0)
    {
      if (i != 1)
        if (i != 2)
        {
          if (i != 3)
            break label210;
        }
        else
        {
          androidx.customview.a.a locala = this.mLeftDragger;
          int k = locala.d.length;
          for (int m = 0; m < k; m++)
          {
            if (locala.a(m))
            {
              float f3 = locala.f[m] - locala.d[m];
              float f4 = locala.g[m] - locala.e[m];
              if (f3 * f3 + f4 * f4 > locala.b * locala.b)
              {
                i1 = 1;
                break label153;
              }
            }
            int i1 = 0;
            if (i1 != 0)
            {
              n = 1;
              break label173;
            }
          }
          int n = 0;
          if (n == 0)
            break label210;
          this.mLeftCallback.a();
          this.mRightCallback.a();
          break label210;
        }
      closeDrawers(true);
      this.mDisallowInterceptRequested = false;
      this.mChildrenCanceledTouch = false;
      j = 0;
    }
    else
    {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      this.mInitialMotionX = f1;
      this.mInitialMotionY = f2;
      if (this.mScrimOpacity > 0.0F)
      {
        View localView = this.mLeftDragger.b((int)f1, (int)f2);
        if ((localView != null) && (isContentView(localView)))
        {
          j = 1;
          break label287;
        }
      }
      j = 0;
      label287: this.mDisallowInterceptRequested = false;
      this.mChildrenCanceledTouch = false;
    }
    if ((!bool) && (j == 0) && (!hasPeekingDrawer()))
      return this.mChildrenCanceledTouch;
    return true;
  }

  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (hasVisibleDrawer()))
    {
      paramKeyEvent.startTracking();
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }

  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      View localView = findVisibleDrawer();
      if ((localView != null) && (getDrawerLockMode(localView) == 0))
        closeDrawers();
      return localView != null;
    }
    return super.onKeyUp(paramInt, paramKeyEvent);
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.mInLayout = true;
    int i = paramInt3 - paramInt1;
    int j = getChildCount();
    for (int k = 0; k < j; k++)
    {
      View localView = getChildAt(k);
      if (localView.getVisibility() != 8)
      {
        LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
        if (isContentView(localView))
        {
          localView.layout(localLayoutParams.leftMargin, localLayoutParams.topMargin, localLayoutParams.leftMargin + localView.getMeasuredWidth(), localLayoutParams.topMargin + localView.getMeasuredHeight());
        }
        else
        {
          int m = localView.getMeasuredWidth();
          int n = localView.getMeasuredHeight();
          int i2;
          float f2;
          if (checkDrawerViewAbsoluteGravity(localView, 3))
          {
            int i9 = -m;
            float f3 = m;
            i2 = i9 + (int)(f3 * localLayoutParams.b);
            f2 = (m + i2) / f3;
          }
          else
          {
            float f1 = m;
            int i1 = i - (int)(f1 * localLayoutParams.b);
            f2 = (i - i1) / f1;
            i2 = i1;
          }
          int i3;
          if (f2 != localLayoutParams.b)
            i3 = 1;
          else
            i3 = 0;
          int i4 = 0x70 & localLayoutParams.a;
          if (i4 != 16)
          {
            if (i4 != 80)
            {
              localView.layout(i2, localLayoutParams.topMargin, m + i2, n + localLayoutParams.topMargin);
            }
            else
            {
              int i8 = paramInt4 - paramInt2;
              localView.layout(i2, i8 - localLayoutParams.bottomMargin - localView.getMeasuredHeight(), m + i2, i8 - localLayoutParams.bottomMargin);
            }
          }
          else
          {
            int i5 = paramInt4 - paramInt2;
            int i6 = (i5 - n) / 2;
            if (i6 < localLayoutParams.topMargin)
              i6 = localLayoutParams.topMargin;
            else if (i6 + n > i5 - localLayoutParams.bottomMargin)
              i6 = i5 - localLayoutParams.bottomMargin - n;
            localView.layout(i2, i6, m + i2, n + i6);
          }
          if (i3 != 0)
            setDrawerViewOffset(localView, f2);
          int i7;
          if (localLayoutParams.b > 0.0F)
            i7 = 0;
          else
            i7 = 4;
          if (localView.getVisibility() != i7)
            localView.setVisibility(i7);
        }
      }
    }
    this.mInLayout = false;
    this.mFirstLayout = false;
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    int k = View.MeasureSpec.getSize(paramInt1);
    int m = View.MeasureSpec.getSize(paramInt2);
    if ((i != 1073741824) || (j != 1073741824))
    {
      if (!isInEditMode())
        break label734;
      if ((i != -2147483648) && (i == 0))
        k = 300;
      if ((j != -2147483648) && (j == 0))
        m = 300;
    }
    setMeasuredDimension(k, m);
    int n;
    if ((this.mLastInsets != null) && (t.s(this)))
      n = 1;
    else
      n = 0;
    int i1 = t.f(this);
    int i2 = getChildCount();
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    while (i3 < i2)
    {
      View localView = getChildAt(i3);
      if (localView.getVisibility() != 8)
      {
        LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
        if (n != 0)
        {
          int i8 = d.a(localLayoutParams.a, i1);
          if (t.s(localView))
          {
            if (Build.VERSION.SDK_INT >= 21)
            {
              WindowInsets localWindowInsets2 = (WindowInsets)this.mLastInsets;
              if (i8 == 3)
                localWindowInsets2 = localWindowInsets2.replaceSystemWindowInsets(localWindowInsets2.getSystemWindowInsetLeft(), localWindowInsets2.getSystemWindowInsetTop(), 0, localWindowInsets2.getSystemWindowInsetBottom());
              else if (i8 == 5)
                localWindowInsets2 = localWindowInsets2.replaceSystemWindowInsets(0, localWindowInsets2.getSystemWindowInsetTop(), localWindowInsets2.getSystemWindowInsetRight(), localWindowInsets2.getSystemWindowInsetBottom());
              localView.dispatchApplyWindowInsets(localWindowInsets2);
            }
          }
          else if (Build.VERSION.SDK_INT >= 21)
          {
            WindowInsets localWindowInsets1 = (WindowInsets)this.mLastInsets;
            if (i8 == 3)
              localWindowInsets1 = localWindowInsets1.replaceSystemWindowInsets(localWindowInsets1.getSystemWindowInsetLeft(), localWindowInsets1.getSystemWindowInsetTop(), 0, localWindowInsets1.getSystemWindowInsetBottom());
            else if (i8 == 5)
              localWindowInsets1 = localWindowInsets1.replaceSystemWindowInsets(0, localWindowInsets1.getSystemWindowInsetTop(), localWindowInsets1.getSystemWindowInsetRight(), localWindowInsets1.getSystemWindowInsetBottom());
            localLayoutParams.leftMargin = localWindowInsets1.getSystemWindowInsetLeft();
            localLayoutParams.topMargin = localWindowInsets1.getSystemWindowInsetTop();
            localLayoutParams.rightMargin = localWindowInsets1.getSystemWindowInsetRight();
            localLayoutParams.bottomMargin = localWindowInsets1.getSystemWindowInsetBottom();
          }
        }
        if (isContentView(localView))
        {
          localView.measure(View.MeasureSpec.makeMeasureSpec(k - localLayoutParams.leftMargin - localLayoutParams.rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec(m - localLayoutParams.topMargin - localLayoutParams.bottomMargin, 1073741824));
        }
        else if (isDrawerView(localView))
        {
          if (SET_DRAWER_SHADOW_FROM_ELEVATION)
          {
            float f1 = t.o(localView);
            float f2 = this.mDrawerElevation;
            if (f1 != f2)
              t.c(localView, f2);
          }
          int i6 = 0x7 & getDrawerViewAbsoluteGravity(localView);
          int i7;
          if (i6 == 3)
            i7 = 1;
          else
            i7 = 0;
          if (((i7 != 0) && (i4 != 0)) || ((i7 == 0) && (i5 != 0)))
          {
            StringBuilder localStringBuilder2 = new StringBuilder("Child drawer has absolute gravity ");
            localStringBuilder2.append(gravityToString(i6));
            localStringBuilder2.append(" but this DrawerLayout");
            localStringBuilder2.append(" already has a drawer view along that edge");
            throw new IllegalStateException(localStringBuilder2.toString());
          }
          if (i7 != 0)
            i4 = 1;
          else
            i5 = 1;
          localView.measure(getChildMeasureSpec(paramInt1, this.mMinDrawerMargin + localLayoutParams.leftMargin + localLayoutParams.rightMargin, localLayoutParams.width), getChildMeasureSpec(paramInt2, localLayoutParams.topMargin + localLayoutParams.bottomMargin, localLayoutParams.height));
        }
        else
        {
          StringBuilder localStringBuilder1 = new StringBuilder("Child ");
          localStringBuilder1.append(localView);
          localStringBuilder1.append(" at index ");
          localStringBuilder1.append(i3);
          localStringBuilder1.append(" does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
          throw new IllegalStateException(localStringBuilder1.toString());
        }
      }
      i3++;
    }
    return;
    label734: IllegalArgumentException localIllegalArgumentException = new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
    while (true)
      throw localIllegalArgumentException;
  }

  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.d);
    if (localSavedState.a != 0)
    {
      View localView = findDrawerWithGravity(localSavedState.a);
      if (localView != null)
        openDrawer(localView);
    }
    if (localSavedState.b != 3)
      setDrawerLockMode(localSavedState.b, 3);
    if (localSavedState.e != 3)
      setDrawerLockMode(localSavedState.e, 5);
    if (localSavedState.f != 3)
      setDrawerLockMode(localSavedState.f, 8388611);
    if (localSavedState.g != 3)
      setDrawerLockMode(localSavedState.g, 8388613);
  }

  public void onRtlPropertiesChanged(int paramInt)
  {
    resolveShadowDrawables();
  }

  protected Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    int i = getChildCount();
    int j = 0;
    while (j < i)
    {
      LayoutParams localLayoutParams = (LayoutParams)getChildAt(j).getLayoutParams();
      int k = localLayoutParams.d;
      int m = 1;
      int n;
      if (k == m)
        n = 1;
      else
        n = 0;
      if (localLayoutParams.d != 2)
        m = 0;
      if ((n == 0) && (m == 0))
        j++;
      else
        localSavedState.a = localLayoutParams.a;
    }
    localSavedState.b = this.mLockModeLeft;
    localSavedState.e = this.mLockModeRight;
    localSavedState.f = this.mLockModeStart;
    localSavedState.g = this.mLockModeEnd;
    return localSavedState;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    this.mLeftDragger.b(paramMotionEvent);
    this.mRightDragger.b(paramMotionEvent);
    int i = 0xFF & paramMotionEvent.getAction();
    if (i != 0)
    {
      if (i != 1)
      {
        if (i != 3)
          return true;
        closeDrawers(true);
        this.mDisallowInterceptRequested = false;
        this.mChildrenCanceledTouch = false;
        return true;
      }
      float f3 = paramMotionEvent.getX();
      float f4 = paramMotionEvent.getY();
      View localView1 = this.mLeftDragger.b((int)f3, (int)f4);
      if ((localView1 != null) && (isContentView(localView1)))
      {
        float f5 = f3 - this.mInitialMotionX;
        float f6 = f4 - this.mInitialMotionY;
        int j = this.mLeftDragger.b;
        if (f5 * f5 + f6 * f6 < j * j)
        {
          View localView2 = findOpenDrawer();
          if ((localView2 != null) && (getDrawerLockMode(localView2) != 2))
          {
            bool = false;
            break label180;
          }
        }
      }
      boolean bool = true;
      label180: closeDrawers(bool);
      this.mDisallowInterceptRequested = false;
      return true;
    }
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    this.mInitialMotionX = f1;
    this.mInitialMotionY = f2;
    this.mDisallowInterceptRequested = false;
    this.mChildrenCanceledTouch = false;
    return true;
  }

  public void openDrawer(int paramInt)
  {
    openDrawer(paramInt, true);
  }

  public void openDrawer(int paramInt, boolean paramBoolean)
  {
    View localView = findDrawerWithGravity(paramInt);
    if (localView != null)
    {
      openDrawer(localView, paramBoolean);
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("No drawer view found with gravity ");
    localStringBuilder.append(gravityToString(paramInt));
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public void openDrawer(View paramView)
  {
    openDrawer(paramView, true);
  }

  public void openDrawer(View paramView, boolean paramBoolean)
  {
    if (isDrawerView(paramView))
    {
      LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
      if (this.mFirstLayout)
      {
        localLayoutParams.b = 1.0F;
        localLayoutParams.d = 1;
        updateChildrenImportantForAccessibility(paramView, true);
      }
      else if (paramBoolean)
      {
        localLayoutParams.d = (0x2 | localLayoutParams.d);
        if (checkDrawerViewAbsoluteGravity(paramView, 3))
          this.mLeftDragger.a(paramView, 0, paramView.getTop());
        else
          this.mRightDragger.a(paramView, getWidth() - paramView.getWidth(), paramView.getTop());
      }
      else
      {
        moveDrawerToOffset(paramView, 1.0F);
        updateDrawerState(localLayoutParams.a, 0, paramView);
        paramView.setVisibility(0);
      }
      invalidate();
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("View ");
    localStringBuilder.append(paramView);
    localStringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public void removeDrawerListener(c paramc)
  {
    if (paramc == null)
      return;
    List localList = this.mListeners;
    if (localList == null)
      return;
    localList.remove(paramc);
  }

  public void requestDisallowInterceptTouchEvent(boolean paramBoolean)
  {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    this.mDisallowInterceptRequested = paramBoolean;
    if (paramBoolean)
      closeDrawers(true);
  }

  public void requestLayout()
  {
    if (!this.mInLayout)
      super.requestLayout();
  }

  public void setChildInsets(Object paramObject, boolean paramBoolean)
  {
    this.mLastInsets = paramObject;
    this.mDrawStatusBarBackground = paramBoolean;
    boolean bool;
    if ((!paramBoolean) && (getBackground() == null))
      bool = true;
    else
      bool = false;
    setWillNotDraw(bool);
    requestLayout();
  }

  public void setDrawerElevation(float paramFloat)
  {
    this.mDrawerElevation = paramFloat;
    for (int i = 0; i < getChildCount(); i++)
    {
      View localView = getChildAt(i);
      if (isDrawerView(localView))
        t.c(localView, this.mDrawerElevation);
    }
  }

  public void setDrawerListener(c paramc)
  {
    c localc = this.mListener;
    if (localc != null)
      removeDrawerListener(localc);
    if (paramc != null)
      addDrawerListener(paramc);
    this.mListener = paramc;
  }

  public void setDrawerLockMode(int paramInt)
  {
    setDrawerLockMode(paramInt, 3);
    setDrawerLockMode(paramInt, 5);
  }

  public void setDrawerLockMode(int paramInt1, int paramInt2)
  {
    int i = d.a(paramInt2, t.f(this));
    if (paramInt2 != 3)
    {
      if (paramInt2 != 5)
      {
        if (paramInt2 != 8388611)
        {
          if (paramInt2 == 8388613)
            this.mLockModeEnd = paramInt1;
        }
        else
          this.mLockModeStart = paramInt1;
      }
      else
        this.mLockModeRight = paramInt1;
    }
    else
      this.mLockModeLeft = paramInt1;
    if (paramInt1 != 0)
    {
      androidx.customview.a.a locala;
      if (i == 3)
        locala = this.mLeftDragger;
      else
        locala = this.mRightDragger;
      locala.a();
    }
    if (paramInt1 != 1)
    {
      if (paramInt1 != 2)
        return;
      View localView2 = findDrawerWithGravity(i);
      if (localView2 != null)
        openDrawer(localView2);
    }
    else
    {
      View localView1 = findDrawerWithGravity(i);
      if (localView1 != null)
        closeDrawer(localView1);
    }
  }

  public void setDrawerLockMode(int paramInt, View paramView)
  {
    if (isDrawerView(paramView))
    {
      setDrawerLockMode(paramInt, ((LayoutParams)paramView.getLayoutParams()).a);
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("View ");
    localStringBuilder.append(paramView);
    localStringBuilder.append(" is not a drawer with appropriate layout_gravity");
    throw new IllegalArgumentException(localStringBuilder.toString());
  }

  public void setDrawerShadow(int paramInt1, int paramInt2)
  {
    setDrawerShadow(b.a(getContext(), paramInt1), paramInt2);
  }

  public void setDrawerShadow(Drawable paramDrawable, int paramInt)
  {
    if (SET_DRAWER_SHADOW_FROM_ELEVATION)
      return;
    if ((paramInt & 0x800003) == 8388611)
    {
      this.mShadowStart = paramDrawable;
    }
    else if ((paramInt & 0x800005) == 8388613)
    {
      this.mShadowEnd = paramDrawable;
    }
    else if ((paramInt & 0x3) == 3)
    {
      this.mShadowLeft = paramDrawable;
    }
    else
    {
      if ((paramInt & 0x5) != 5)
        return;
      this.mShadowRight = paramDrawable;
    }
    resolveShadowDrawables();
    invalidate();
  }

  public void setDrawerTitle(int paramInt, CharSequence paramCharSequence)
  {
    int i = d.a(paramInt, t.f(this));
    if (i == 3)
    {
      this.mTitleLeft = paramCharSequence;
      return;
    }
    if (i == 5)
      this.mTitleRight = paramCharSequence;
  }

  void setDrawerViewOffset(View paramView, float paramFloat)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    if (paramFloat == localLayoutParams.b)
      return;
    localLayoutParams.b = paramFloat;
    dispatchOnDrawerSlide(paramView, paramFloat);
  }

  public void setScrimColor(int paramInt)
  {
    this.mScrimColor = paramInt;
    invalidate();
  }

  public void setStatusBarBackground(int paramInt)
  {
    Drawable localDrawable;
    if (paramInt != 0)
      localDrawable = b.a(getContext(), paramInt);
    else
      localDrawable = null;
    this.mStatusBarBackground = localDrawable;
    invalidate();
  }

  public void setStatusBarBackground(Drawable paramDrawable)
  {
    this.mStatusBarBackground = paramDrawable;
    invalidate();
  }

  public void setStatusBarBackgroundColor(int paramInt)
  {
    this.mStatusBarBackground = new ColorDrawable(paramInt);
    invalidate();
  }

  void updateDrawerState(int paramInt1, int paramInt2, View paramView)
  {
    int i = this.mLeftDragger.a;
    int j = this.mRightDragger.a;
    int k = 2;
    if ((i != 1) && (j != 1))
    {
      if ((i != k) && (j != k))
        k = 0;
    }
    else
      k = 1;
    if ((paramView != null) && (paramInt2 == 0))
    {
      LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
      if (localLayoutParams.b == 0.0F)
        dispatchOnDrawerClosed(paramView);
      else if (localLayoutParams.b == 1.0F)
        dispatchOnDrawerOpened(paramView);
    }
    if (k != this.mDrawerState)
    {
      this.mDrawerState = k;
      List localList = this.mListeners;
      if (localList != null)
        for (int m = localList.size() - 1; m >= 0; m--)
          ((c)this.mListeners.get(m)).onDrawerStateChanged(k);
    }
  }

  public static class LayoutParams extends ViewGroup.MarginLayoutParams
  {
    public int a;
    float b;
    boolean c;
    int d;

    static
    {
      CoverageLogger.Log(68098048);
    }

    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(-1);
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, DrawerLayout.LAYOUT_ATTRS);
      this.a = localTypedArray.getInt(0, 0);
      localTypedArray.recycle();
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }

    public LayoutParams(LayoutParams paramLayoutParams)
    {
      super();
      this.a = paramLayoutParams.a;
    }
  }

  protected static class SavedState extends AbsSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.ClassLoaderCreator()
    {
      static
      {
        CoverageLogger.Log(68239360);
      }
    };
    int a;
    int b;
    int e;
    int f;
    int g;

    static
    {
      CoverageLogger.Log(68243456);
    }

    public SavedState(Parcel paramParcel, ClassLoader paramClassLoader)
    {
      super(paramClassLoader);
      this.a = paramParcel.readInt();
      this.b = paramParcel.readInt();
      this.e = paramParcel.readInt();
      this.f = paramParcel.readInt();
      this.g = paramParcel.readInt();
    }

    public SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(this.a);
      paramParcel.writeInt(this.b);
      paramParcel.writeInt(this.e);
      paramParcel.writeInt(this.f);
      paramParcel.writeInt(this.g);
    }
  }

  final class a extends androidx.core.h.a
  {
    private final Rect d = new Rect();

    static
    {
      CoverageLogger.Log(68218880);
    }

    a()
    {
    }

    public final void a(View paramView, c paramc)
    {
      if (DrawerLayout.CAN_HIDE_DESCENDANTS)
      {
        super.a(paramView, paramc);
      }
      else
      {
        c localc = c.a(paramc);
        super.a(paramView, localc);
        paramc.a(paramView);
        ViewParent localViewParent = t.g(paramView);
        if ((localViewParent instanceof View))
          paramc.c((View)localViewParent);
        Rect localRect = this.d;
        localc.a(localRect);
        paramc.b(localRect);
        localc.c(localRect);
        paramc.d(localRect);
        paramc.d(localc.d());
        paramc.a(localc.j());
        paramc.b(localc.k());
        paramc.d(localc.l());
        paramc.i(localc.i());
        paramc.g(localc.g());
        paramc.b(localc.b());
        paramc.c(localc.c());
        paramc.e(localc.e());
        paramc.f(localc.f());
        paramc.h(localc.h());
        paramc.a(localc.a());
        localc.m();
        ViewGroup localViewGroup = (ViewGroup)paramView;
        int i = localViewGroup.getChildCount();
        for (int j = 0; j < i; j++)
        {
          View localView = localViewGroup.getChildAt(j);
          if (DrawerLayout.includeChildForAccessibility(localView))
            paramc.b(localView);
        }
      }
      paramc.b(DrawerLayout.class.getName());
      paramc.b(false);
      paramc.c(false);
      paramc.a(c.a.a);
      paramc.a(c.a.b);
    }

    public final boolean a(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      if (paramAccessibilityEvent.getEventType() == 32)
      {
        List localList = paramAccessibilityEvent.getText();
        View localView = DrawerLayout.this.findVisibleDrawer();
        if (localView != null)
        {
          int i = DrawerLayout.this.getDrawerViewAbsoluteGravity(localView);
          CharSequence localCharSequence = DrawerLayout.this.getDrawerTitle(i);
          if (localCharSequence != null)
            localList.add(localCharSequence);
        }
        return true;
      }
      return super.a(paramView, paramAccessibilityEvent);
    }

    public final boolean a(ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      if ((!DrawerLayout.CAN_HIDE_DESCENDANTS) && (!DrawerLayout.includeChildForAccessibility(paramView)))
        return false;
      return super.a(paramViewGroup, paramView, paramAccessibilityEvent);
    }

    public final void c(View paramView, AccessibilityEvent paramAccessibilityEvent)
    {
      super.c(paramView, paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(DrawerLayout.class.getName());
    }
  }

  static final class b extends androidx.core.h.a
  {
    static
    {
      CoverageLogger.Log(68227072);
    }

    public final void a(View paramView, c paramc)
    {
      super.a(paramView, paramc);
      if (!DrawerLayout.includeChildForAccessibility(paramView))
        paramc.c(null);
    }
  }

  public static abstract interface c
  {
    static
    {
      CoverageLogger.Log(68237312);
    }

    public abstract void onDrawerClosed(View paramView);

    public abstract void onDrawerOpened(View paramView);

    public abstract void onDrawerSlide(View paramView, float paramFloat);

    public abstract void onDrawerStateChanged(int paramInt);
  }

  public static abstract class d
    implements DrawerLayout.c
  {
    static
    {
      CoverageLogger.Log(68091904);
    }

    public void onDrawerClosed(View paramView)
    {
    }

    public void onDrawerOpened(View paramView)
    {
    }

    public void onDrawerSlide(View paramView, float paramFloat)
    {
    }

    public void onDrawerStateChanged(int paramInt)
    {
    }
  }

  final class e extends a.a
  {
    final int a;
    public androidx.customview.a.a b;
    private final Runnable d = new Runnable()
    {
      static
      {
        CoverageLogger.Log(68251648);
      }

      public final void run()
      {
        DrawerLayout.e locale = DrawerLayout.e.this;
        int i = locale.b.i;
        int j;
        if (locale.a == 3)
          j = 1;
        else
          j = 0;
        View localView;
        int k;
        if (j != 0)
        {
          localView = locale.c.findDrawerWithGravity(3);
          int m = 0;
          if (localView != null)
            m = -localView.getWidth();
          k = m + i;
        }
        else
        {
          localView = locale.c.findDrawerWithGravity(5);
          k = locale.c.getWidth() - i;
        }
        if ((localView != null) && (((j != 0) && (localView.getLeft() < k)) || ((j == 0) && (localView.getLeft() > k) && (locale.c.getDrawerLockMode(localView) == 0))))
        {
          DrawerLayout.LayoutParams localLayoutParams = (DrawerLayout.LayoutParams)localView.getLayoutParams();
          locale.b.a(localView, k, localView.getTop());
          localLayoutParams.c = true;
          locale.c.invalidate();
          locale.b();
          locale.c.cancelChildViewTouch();
        }
      }
    };

    static
    {
      CoverageLogger.Log(68245504);
    }

    e(int arg2)
    {
      int i;
      this.a = i;
    }

    public final int a(View paramView)
    {
      if (DrawerLayout.this.isDrawerView(paramView))
        return paramView.getWidth();
      return 0;
    }

    public final int a(View paramView, int paramInt1, int paramInt2)
    {
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(paramView, 3))
        return Math.max(-paramView.getWidth(), Math.min(paramInt1, 0));
      int i = DrawerLayout.this.getWidth();
      return Math.max(i - paramView.getWidth(), Math.min(paramInt1, i));
    }

    public final void a()
    {
      DrawerLayout.this.removeCallbacks(this.d);
    }

    public final void a(int paramInt)
    {
      DrawerLayout.this.updateDrawerState(this.a, paramInt, this.b.k);
    }

    public final void a(int paramInt1, int paramInt2)
    {
      DrawerLayout.this.postDelayed(this.d, 160L);
    }

    public final void a(View paramView, float paramFloat1, float paramFloat2)
    {
      float f = DrawerLayout.this.getDrawerViewOffset(paramView);
      int i = paramView.getWidth();
      int k;
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(paramView, 3))
      {
        if ((paramFloat1 <= 0.0F) && ((paramFloat1 != 0.0F) || (f <= 0.5F)))
          k = -i;
        else
          k = 0;
      }
      else
      {
        int j = DrawerLayout.this.getWidth();
        if ((paramFloat1 < 0.0F) || ((paramFloat1 == 0.0F) && (f > 0.5F)))
          j -= i;
        k = j;
      }
      this.b.a(k, paramView.getTop());
      DrawerLayout.this.invalidate();
    }

    public final void a(View paramView, int paramInt)
    {
      ((DrawerLayout.LayoutParams)paramView.getLayoutParams()).c = false;
      b();
    }

    public final void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      int i = paramView.getWidth();
      float f1;
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(paramView, 3))
        f1 = paramInt1 + i;
      else
        f1 = DrawerLayout.this.getWidth() - paramInt1;
      float f2 = f1 / i;
      DrawerLayout.this.setDrawerViewOffset(paramView, f2);
      int j;
      if (f2 == 0.0F)
        j = 4;
      else
        j = 0;
      paramView.setVisibility(j);
      DrawerLayout.this.invalidate();
    }

    public final int b(View paramView, int paramInt1, int paramInt2)
    {
      return paramView.getTop();
    }

    void b()
    {
      int i = this.a;
      int j = 3;
      if (i == j)
        j = 5;
      View localView = DrawerLayout.this.findDrawerWithGravity(j);
      if (localView != null)
        DrawerLayout.this.closeDrawer(localView);
    }

    public final void b(int paramInt1, int paramInt2)
    {
      View localView;
      if ((paramInt1 & 0x1) == 1)
        localView = DrawerLayout.this.findDrawerWithGravity(3);
      else
        localView = DrawerLayout.this.findDrawerWithGravity(5);
      if ((localView != null) && (DrawerLayout.this.getDrawerLockMode(localView) == 0))
        this.b.a(localView, paramInt2);
    }

    public final boolean b(View paramView, int paramInt)
    {
      return (DrawerLayout.this.isDrawerView(paramView)) && (DrawerLayout.this.checkDrawerViewAbsoluteGravity(paramView, this.a)) && (DrawerLayout.this.getDrawerLockMode(paramView) == 0);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.drawerlayout.widget.DrawerLayout
 * JD-Core Version:    0.6.2
 */