package androidx.d.a;

import android.database.Cursor;
import android.widget.Filter;
import android.widget.Filter.FilterResults;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class b extends Filter
{
  a a;

  static
  {
    CoverageLogger.Log(137185280);
  }

  b(a parama)
  {
    this.a = parama;
  }

  public final CharSequence convertResultToString(Object paramObject)
  {
    return this.a.b((Cursor)paramObject);
  }

  protected final Filter.FilterResults performFiltering(CharSequence paramCharSequence)
  {
    Cursor localCursor = this.a.a(paramCharSequence);
    Filter.FilterResults localFilterResults = new Filter.FilterResults();
    if (localCursor != null)
    {
      localFilterResults.count = localCursor.getCount();
      localFilterResults.values = localCursor;
      return localFilterResults;
    }
    localFilterResults.count = 0;
    localFilterResults.values = null;
    return localFilterResults;
  }

  protected final void publishResults(CharSequence paramCharSequence, Filter.FilterResults paramFilterResults)
  {
    Cursor localCursor = this.a.a();
    if ((paramFilterResults.values != null) && (paramFilterResults.values != localCursor))
      this.a.a((Cursor)paramFilterResults.values);
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(137197568);
    }

    public abstract Cursor a();

    public abstract Cursor a(CharSequence paramCharSequence);

    public abstract void a(Cursor paramCursor);

    public abstract CharSequence b(Cursor paramCursor);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.d.a.b
 * JD-Core Version:    0.6.2
 */