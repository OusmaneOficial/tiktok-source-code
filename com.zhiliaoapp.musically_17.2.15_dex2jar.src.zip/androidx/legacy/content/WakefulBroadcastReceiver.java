package androidx.legacy.content;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.SparseArray;
import com.ss.android.ugc.aweme.push.downgrade.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class WakefulBroadcastReceiver extends BroadcastReceiver
{
  private static final SparseArray<PowerManager.WakeLock> a = new SparseArray();
  private static int b = 1;

  static
  {
    CoverageLogger.Log(79278080);
  }

  public static boolean a(Intent paramIntent)
  {
    int i = paramIntent.getIntExtra("androidx.contentpager.content.wakelockid", 0);
    if (i == 0)
      return false;
    synchronized (a)
    {
      PowerManager.WakeLock localWakeLock = (PowerManager.WakeLock)a.get(i);
      if (localWakeLock != null)
      {
        localWakeLock.release();
        a.remove(i);
        return true;
      }
      return true;
    }
  }

  public static ComponentName a_(Context paramContext, Intent paramIntent)
  {
    synchronized (a)
    {
      int i = b;
      int j = 1 + b;
      b = j;
      if (j <= 0)
        b = 1;
      paramIntent.putExtra("androidx.contentpager.content.wakelockid", i);
      ComponentName localComponentName;
      if ((paramContext != null) && ((paramContext instanceof Context)) && (d.a((Context)paramContext, paramIntent)))
        localComponentName = null;
      else
        localComponentName = paramContext.startService(paramIntent);
      if (localComponentName == null)
        return null;
      PowerManager localPowerManager = (PowerManager)paramContext.getSystemService("power");
      StringBuilder localStringBuilder = new StringBuilder("androidx.core:wake:");
      localStringBuilder.append(localComponentName.flattenToShortString());
      PowerManager.WakeLock localWakeLock = localPowerManager.newWakeLock(1, localStringBuilder.toString());
      localWakeLock.setReferenceCounted(false);
      localWakeLock.acquire(60000L);
      a.put(i, localWakeLock);
      return localComponentName;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.legacy.content.WakefulBroadcastReceiver
 * JD-Core Version:    0.6.2
 */