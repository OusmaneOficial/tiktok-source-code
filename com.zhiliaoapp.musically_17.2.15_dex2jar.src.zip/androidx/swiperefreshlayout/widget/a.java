package androidx.swiperefreshlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import androidx.core.h.t;
import com.ss.android.ugc.aweme.lancet.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class a extends ImageView
{
  int a;
  private Animation.AnimationListener b;

  static
  {
    CoverageLogger.Log(79925248);
  }

  a(Context paramContext, int paramInt)
  {
    super(paramContext);
    float f = getContext().getResources().getDisplayMetrics().density;
    int i = (int)(1.75F * f);
    int j = (int)(0.0F * f);
    this.a = ((int)(3.5F * f));
    Object localObject;
    if (a())
    {
      localObject = new ShapeDrawable(new OvalShape());
      t.c(this, f * 4.0F);
    }
    else
    {
      ShapeDrawable localShapeDrawable = new ShapeDrawable(new a(this.a));
      setLayerType(1, localShapeDrawable.getPaint());
      localShapeDrawable.getPaint().setShadowLayer(this.a, j, i, 503316480);
      int k = this.a;
      setPadding(k, k, k, k);
      localObject = localShapeDrawable;
    }
    ((ShapeDrawable)localObject).getPaint().setColor(-328966);
    t.a(this, (Drawable)localObject);
  }

  private static boolean a()
  {
    return Build.VERSION.SDK_INT >= 21;
  }

  public final void a(Animation.AnimationListener paramAnimationListener)
  {
    this.b = paramAnimationListener;
  }

  public final void onAnimationEnd()
  {
    super.onAnimationEnd();
    Animation.AnimationListener localAnimationListener = this.b;
    if (localAnimationListener != null)
      localAnimationListener.onAnimationEnd(getAnimation());
  }

  public final void onAnimationStart()
  {
    super.onAnimationStart();
    Animation.AnimationListener localAnimationListener = this.b;
    if (localAnimationListener != null)
      localAnimationListener.onAnimationStart(getAnimation());
  }

  protected final void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    g.a(this);
  }

  protected final void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
    if (!a())
      setMeasuredDimension(getMeasuredWidth() + 2 * this.a, getMeasuredHeight() + 2 * this.a);
  }

  public final void setBackgroundColor(int paramInt)
  {
    if ((getBackground() instanceof ShapeDrawable))
      ((ShapeDrawable)getBackground()).getPaint().setColor(paramInt);
  }

  final class a extends OvalShape
  {
    private RadialGradient b;
    private Paint c = new Paint();

    static
    {
      CoverageLogger.Log(79921152);
    }

    a(int arg2)
    {
      int i;
      a.this.a = i;
      a((int)rect().width());
    }

    private void a(int paramInt)
    {
      float f = paramInt / 2;
      RadialGradient localRadialGradient = new RadialGradient(f, f, a.this.a, new int[] { 1023410176, 0 }, null, Shader.TileMode.CLAMP);
      this.b = localRadialGradient;
      this.c.setShader(this.b);
    }

    public final void draw(Canvas paramCanvas, Paint paramPaint)
    {
      int i = a.this.getWidth();
      int j = a.this.getHeight();
      int k = i / 2;
      float f1 = k;
      float f2 = j / 2;
      paramCanvas.drawCircle(f1, f2, f1, this.c);
      paramCanvas.drawCircle(f1, f2, k - a.this.a, paramPaint);
    }

    protected final void onResize(float paramFloat1, float paramFloat2)
    {
      super.onResize(paramFloat1, paramFloat2);
      a((int)paramFloat1);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.swiperefreshlayout.widget.a
 * JD-Core Version:    0.6.2
 */