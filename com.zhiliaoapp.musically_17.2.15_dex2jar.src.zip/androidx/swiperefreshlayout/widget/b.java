package androidx.swiperefreshlayout.widget;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import androidx.core.g.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b extends Drawable
  implements Animatable
{
  private static final Interpolator e = new LinearInterpolator();
  private static final Interpolator f = new androidx.e.a.a.b();
  private static final int[] g = { -16777216 };
  final a a;
  public float b;
  float c;
  boolean d;
  private Resources h;
  private Animator i;

  static
  {
    CoverageLogger.Log(79681536);
  }

  public b(Context paramContext)
  {
    this.h = ((Context)g.a(paramContext)).getResources();
    this.a = new a();
    this.a.a(g);
    this.a.a(2.5F);
    invalidateSelf();
    final a locala = this.a;
    ValueAnimator localValueAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F });
    localValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener()
    {
      static
      {
        CoverageLogger.Log(79933440);
      }

      public final void onAnimationUpdate(ValueAnimator paramAnonymousValueAnimator)
      {
        float f = ((Float)paramAnonymousValueAnimator.getAnimatedValue()).floatValue();
        b.this.a(f, locala);
        b.this.a(f, locala, false);
        b.this.invalidateSelf();
      }
    });
    localValueAnimator.setRepeatCount(-1);
    localValueAnimator.setRepeatMode(1);
    localValueAnimator.setInterpolator(e);
    localValueAnimator.addListener(new Animator.AnimatorListener()
    {
      static
      {
        CoverageLogger.Log(79939584);
      }

      public final void onAnimationCancel(Animator paramAnonymousAnimator)
      {
      }

      public final void onAnimationEnd(Animator paramAnonymousAnimator)
      {
      }

      public final void onAnimationRepeat(Animator paramAnonymousAnimator)
      {
        b.this.a(1.0F, locala, true);
        locala.c();
        b.a locala = locala;
        locala.a(locala.a());
        if (b.this.d)
        {
          b.this.d = false;
          paramAnonymousAnimator.cancel();
          paramAnonymousAnimator.setDuration(1332L);
          paramAnonymousAnimator.start();
          locala.a(false);
          return;
        }
        b localb = b.this;
        localb.c = (1.0F + localb.c);
      }

      public final void onAnimationStart(Animator paramAnonymousAnimator)
      {
        b.this.c = 0.0F;
      }
    });
    this.i = localValueAnimator;
  }

  private void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    a locala = this.a;
    float f1 = this.h.getDisplayMetrics().density;
    locala.a(paramFloat2 * f1);
    locala.q = (paramFloat1 * f1);
    locala.a(0);
    float f2 = paramFloat3 * f1;
    float f3 = paramFloat4 * f1;
    locala.r = ((int)f2);
    locala.s = ((int)f3);
  }

  public final void a(float paramFloat)
  {
    a locala = this.a;
    if (paramFloat != locala.p)
      locala.p = paramFloat;
    invalidateSelf();
  }

  public final void a(float paramFloat1, float paramFloat2)
  {
    a locala = this.a;
    locala.e = 0.0F;
    locala.f = paramFloat2;
    invalidateSelf();
  }

  final void a(float paramFloat, a parama)
  {
    if (paramFloat > 0.75F)
    {
      float f1 = (paramFloat - 0.75F) / 0.25F;
      int j = parama.b();
      int k = parama.i[parama.a()];
      int m = 0xFF & j >> 24;
      int n = 0xFF & j >> 16;
      int i1 = 0xFF & j >> 8;
      int i2 = j & 0xFF;
      int i3 = 0xFF & k >> 24;
      int i4 = 0xFF & k >> 16;
      int i5 = 0xFF & k >> 8;
      int i6 = k & 0xFF;
      parama.u = (m + (int)(f1 * (i3 - m)) << 24 | n + (int)(f1 * (i4 - n)) << 16 | i1 + (int)(f1 * (i5 - i1)) << 8 | i2 + (int)(f1 * (i6 - i2)));
      return;
    }
    parama.u = parama.b();
  }

  final void a(float paramFloat, a parama, boolean paramBoolean)
  {
    if (this.d)
    {
      a(paramFloat, parama);
      float f9 = (float)(1.0D + Math.floor(parama.m / 0.8F));
      parama.e = (parama.k + paramFloat * (parama.l - 0.01F - parama.k));
      parama.f = parama.l;
      parama.g = (parama.m + paramFloat * (f9 - parama.m));
      return;
    }
    if ((paramFloat != 1.0F) || (paramBoolean))
    {
      float f1 = parama.m;
      float f3;
      float f4;
      if (paramFloat < 0.5F)
      {
        float f7 = paramFloat / 0.5F;
        float f8 = parama.k;
        f3 = f8 + (0.01F + 0.79F * f.getInterpolation(f7));
        f4 = f8;
      }
      else
      {
        float f2 = (paramFloat - 0.5F) / 0.5F;
        f3 = 0.79F + parama.k;
        f4 = f3 - (0.01F + 0.79F * (1.0F - f.getInterpolation(f2)));
      }
      float f5 = f1 + 0.21F * paramFloat;
      float f6 = 216.0F * (paramFloat + this.c);
      parama.e = f4;
      parama.f = f3;
      parama.g = f5;
      this.b = f6;
    }
  }

  public final void a(int paramInt)
  {
    if (paramInt == 0)
      a(11.0F, 3.0F, 12.0F, 6.0F);
    else
      a(7.5F, 2.5F, 10.0F, 5.0F);
    invalidateSelf();
  }

  public final void a(boolean paramBoolean)
  {
    this.a.a(paramBoolean);
    invalidateSelf();
  }

  public final void draw(Canvas paramCanvas)
  {
    Rect localRect = getBounds();
    paramCanvas.save();
    paramCanvas.rotate(this.b, localRect.exactCenterX(), localRect.exactCenterY());
    a locala = this.a;
    RectF localRectF = locala.a;
    float f1 = locala.q + locala.h / 2.0F;
    if (locala.q <= 0.0F)
      f1 = Math.min(localRect.width(), localRect.height()) / 2.0F - Math.max(locala.r * locala.p / 2.0F, locala.h / 2.0F);
    localRectF.set(localRect.centerX() - f1, localRect.centerY() - f1, f1 + localRect.centerX(), f1 + localRect.centerY());
    float f2 = 360.0F * (locala.e + locala.g);
    float f3 = 360.0F * (locala.f + locala.g) - f2;
    locala.b.setColor(locala.u);
    locala.b.setAlpha(locala.t);
    float f4 = locala.h / 2.0F;
    localRectF.inset(f4, f4);
    paramCanvas.drawCircle(localRectF.centerX(), localRectF.centerY(), localRectF.width() / 2.0F, locala.d);
    float f5 = -f4;
    localRectF.inset(f5, f5);
    paramCanvas.drawArc(localRectF, f2, f3, false, locala.b);
    if (locala.n)
    {
      if (locala.o == null)
      {
        locala.o = new Path();
        locala.o.setFillType(Path.FillType.EVEN_ODD);
      }
      else
      {
        locala.o.reset();
      }
      float f6 = Math.min(localRectF.width(), localRectF.height()) / 2.0F;
      float f7 = locala.r * locala.p / 2.0F;
      locala.o.moveTo(0.0F, 0.0F);
      locala.o.lineTo(locala.r * locala.p, 0.0F);
      locala.o.lineTo(locala.r * locala.p / 2.0F, locala.s * locala.p);
      locala.o.offset(f6 + localRectF.centerX() - f7, localRectF.centerY() + locala.h / 2.0F);
      locala.o.close();
      locala.c.setColor(locala.u);
      locala.c.setAlpha(locala.t);
      paramCanvas.save();
      paramCanvas.rotate(f2 + f3, localRectF.centerX(), localRectF.centerY());
      paramCanvas.drawPath(locala.o, locala.c);
      paramCanvas.restore();
    }
    paramCanvas.restore();
  }

  public final int getAlpha()
  {
    return this.a.t;
  }

  public final int getOpacity()
  {
    return -3;
  }

  public final boolean isRunning()
  {
    return this.i.isRunning();
  }

  public final void setAlpha(int paramInt)
  {
    this.a.t = paramInt;
    invalidateSelf();
  }

  public final void setColorFilter(ColorFilter paramColorFilter)
  {
    this.a.b.setColorFilter(paramColorFilter);
    invalidateSelf();
  }

  public final void start()
  {
    this.i.cancel();
    this.a.c();
    if (this.a.f != this.a.e)
    {
      this.d = true;
      this.i.setDuration(666L);
      this.i.start();
      return;
    }
    this.a.a(0);
    this.a.d();
    this.i.setDuration(1332L);
    this.i.start();
  }

  public final void stop()
  {
    this.i.cancel();
    this.b = 0.0F;
    this.a.a(false);
    this.a.a(0);
    this.a.d();
    invalidateSelf();
  }

  static final class a
  {
    final RectF a = new RectF();
    final Paint b = new Paint();
    final Paint c = new Paint();
    final Paint d = new Paint();
    public float e = 0.0F;
    public float f = 0.0F;
    public float g = 0.0F;
    public float h = 5.0F;
    public int[] i;
    int j;
    public float k;
    public float l;
    public float m;
    public boolean n;
    Path o;
    public float p = 1.0F;
    public float q;
    int r;
    int s;
    public int t = 255;
    public int u;

    static
    {
      CoverageLogger.Log(79937536);
    }

    a()
    {
      this.b.setStrokeCap(Paint.Cap.SQUARE);
      this.b.setAntiAlias(true);
      this.b.setStyle(Paint.Style.STROKE);
      this.c.setStyle(Paint.Style.FILL);
      this.c.setAntiAlias(true);
      this.d.setColor(0);
    }

    final int a()
    {
      return (1 + this.j) % this.i.length;
    }

    final void a(float paramFloat)
    {
      this.h = paramFloat;
      this.b.setStrokeWidth(paramFloat);
    }

    final void a(int paramInt)
    {
      this.j = paramInt;
      this.u = this.i[this.j];
    }

    final void a(boolean paramBoolean)
    {
      if (this.n != paramBoolean)
        this.n = paramBoolean;
    }

    final void a(int[] paramArrayOfInt)
    {
      this.i = paramArrayOfInt;
      a(0);
    }

    final int b()
    {
      return this.i[this.j];
    }

    final void c()
    {
      this.k = this.e;
      this.l = this.f;
      this.m = this.g;
    }

    final void d()
    {
      this.k = 0.0F;
      this.l = 0.0F;
      this.m = 0.0F;
      this.e = 0.0F;
      this.f = 0.0F;
      this.g = 0.0F;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.swiperefreshlayout.widget.b
 * JD-Core Version:    0.6.2
 */