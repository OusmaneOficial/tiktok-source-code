package androidx.b.a;

import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.g.f.c;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.ArrayBlockingQueue;

public final class a
{
  LayoutInflater a;
  Handler b;
  c c;
  private Handler.Callback d = new Handler.Callback()
  {
    static
    {
      CoverageLogger.Log(78098432);
    }

    public final boolean handleMessage(Message paramAnonymousMessage)
    {
      a.b localb = (a.b)paramAnonymousMessage.obj;
      if (localb.d == null)
        localb.d = a.this.a.inflate(localb.c, localb.b, false);
      localb.e.onInflateFinished(localb.d, localb.c, localb.b);
      a.c localc = a.this.c;
      localb.e = null;
      localb.a = null;
      localb.b = null;
      localb.c = 0;
      localb.d = null;
      localc.c.release(localb);
      return true;
    }
  };

  static
  {
    CoverageLogger.Log(78108672);
  }

  public a(Context paramContext)
  {
    this.a = new a(paramContext);
    this.b = new Handler(this.d);
    this.c = c.a;
  }

  public final void a(int paramInt, ViewGroup paramViewGroup, d paramd)
  {
    b localb = (b)this.c.c.acquire();
    if (localb == null)
      localb = new b();
    localb.a = this;
    localb.c = paramInt;
    localb.b = paramViewGroup;
    localb.e = paramd;
    c localc = this.c;
    try
    {
      localc.b.put(localb);
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      throw new RuntimeException("Failed to enqueue async inflate request", localInterruptedException);
    }
  }

  static final class a extends LayoutInflater
  {
    private static final String[] a = { "android.widget.", "android.webkit.", "android.app." };

    static
    {
      CoverageLogger.Log(78000128);
    }

    a(Context paramContext)
    {
      super();
    }

    public final LayoutInflater cloneInContext(Context paramContext)
    {
      return new a(paramContext);
    }

    protected final View onCreateView(String paramString, AttributeSet paramAttributeSet)
      throws ClassNotFoundException
    {
      String[] arrayOfString = a;
      int i = arrayOfString.length;
      int j = 0;
      while (j < i)
      {
        String str = arrayOfString[j];
        try
        {
          View localView = createView(paramString, str, paramAttributeSet);
          if (localView != null)
            return localView;
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          j++;
          tmpTernaryOp = localClassNotFoundException;
        }
      }
      return super.onCreateView(paramString, paramAttributeSet);
    }
  }

  static final class b
  {
    a a;
    ViewGroup b;
    int c;
    View d;
    a.d e;

    static
    {
      CoverageLogger.Log(78100480);
    }
  }

  static final class c extends Thread
  {
    static final c a;
    ArrayBlockingQueue<a.b> b = new ArrayBlockingQueue(10);
    f.c<a.b> c = new f.c(10);

    static
    {
      CoverageLogger.Log(78102528);
      c localc = new c();
      a = localc;
      localc.start();
    }

    // ERROR //
    public final void run()
    {
      // Byte code:
      //   0: goto +4 -> 4
      //   3: pop
      //   4: aload_0
      //   5: getfield 36	androidx/b/a/a$c:b	Ljava/util/concurrent/ArrayBlockingQueue;
      //   8: invokevirtual 50	java/util/concurrent/ArrayBlockingQueue:take	()Ljava/lang/Object;
      //   11: checkcast 52	androidx/b/a/a$b
      //   14: astore_1
      //   15: aload_1
      //   16: aload_1
      //   17: getfield 55	androidx/b/a/a$b:a	Landroidx/b/a/a;
      //   20: getfield 60	androidx/b/a/a:a	Landroid/view/LayoutInflater;
      //   23: aload_1
      //   24: getfield 63	androidx/b/a/a$b:c	I
      //   27: aload_1
      //   28: getfield 66	androidx/b/a/a$b:b	Landroid/view/ViewGroup;
      //   31: iconst_0
      //   32: invokevirtual 72	android/view/LayoutInflater:inflate	(ILandroid/view/ViewGroup;Z)Landroid/view/View;
      //   35: putfield 76	androidx/b/a/a$b:d	Landroid/view/View;
      //   38: goto +4 -> 42
      //   41: pop
      //   42: aload_1
      //   43: getfield 55	androidx/b/a/a$b:a	Landroidx/b/a/a;
      //   46: getfield 79	androidx/b/a/a:b	Landroid/os/Handler;
      //   49: iconst_0
      //   50: aload_1
      //   51: invokestatic 85	android/os/Message:obtain	(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;
      //   54: invokevirtual 88	android/os/Message:sendToTarget	()V
      //   57: goto -54 -> 3
      //
      // Exception table:
      //   from	to	target	type
      //   3	4	3	java/lang/InterruptedException
      //   4	15	3	java/lang/InterruptedException
      //   15	38	41	java/lang/RuntimeException
    }
  }

  public static abstract interface d
  {
    static
    {
      CoverageLogger.Log(78104576);
    }

    public abstract void onInflateFinished(View paramView, int paramInt, ViewGroup paramViewGroup);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.b.a.a
 * JD-Core Version:    0.6.2
 */