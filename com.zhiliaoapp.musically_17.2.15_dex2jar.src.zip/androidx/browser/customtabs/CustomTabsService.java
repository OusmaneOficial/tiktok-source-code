package androidx.browser.customtabs;

import android.app.Service;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.support.a.b.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;
import java.util.Map;

public abstract class CustomTabsService extends Service
{
  final Map<IBinder, IBinder.DeathRecipient> a = new androidx.c.a();
  private b.a b = new b.a()
  {
    static
    {
      CoverageLogger.Log(115206144);
    }

    public final int a(android.support.a.a paramAnonymousa, String paramAnonymousString, Bundle paramAnonymousBundle)
    {
      return CustomTabsService.this.a(new f(paramAnonymousa), paramAnonymousString, paramAnonymousBundle);
    }

    public final Bundle a(String paramAnonymousString, Bundle paramAnonymousBundle)
    {
      return CustomTabsService.this.a(paramAnonymousString, paramAnonymousBundle);
    }

    public final boolean a(long paramAnonymousLong)
    {
      return CustomTabsService.this.a(paramAnonymousLong);
    }

    // ERROR //
    public final boolean a(android.support.a.a paramAnonymousa)
    {
      // Byte code:
      //   0: new 26	androidx/browser/customtabs/f
      //   3: dup
      //   4: aload_1
      //   5: invokespecial 29	androidx/browser/customtabs/f:<init>	(Landroid/support/a/a;)V
      //   8: astore_2
      //   9: new 43	androidx/browser/customtabs/CustomTabsService$1$1
      //   12: dup
      //   13: aload_0
      //   14: aload_2
      //   15: invokespecial 46	androidx/browser/customtabs/CustomTabsService$1$1:<init>	(Landroidx/browser/customtabs/CustomTabsService$1;Landroidx/browser/customtabs/f;)V
      //   18: astore_3
      //   19: aload_0
      //   20: getfield 21	androidx/browser/customtabs/CustomTabsService$1:a	Landroidx/browser/customtabs/CustomTabsService;
      //   23: getfield 49	androidx/browser/customtabs/CustomTabsService:a	Ljava/util/Map;
      //   26: astore 4
      //   28: aload 4
      //   30: monitorenter
      //   31: aload_1
      //   32: invokeinterface 55 1 0
      //   37: aload_3
      //   38: iconst_0
      //   39: invokeinterface 61 3 0
      //   44: aload_0
      //   45: getfield 21	androidx/browser/customtabs/CustomTabsService$1:a	Landroidx/browser/customtabs/CustomTabsService;
      //   48: getfield 49	androidx/browser/customtabs/CustomTabsService:a	Ljava/util/Map;
      //   51: aload_1
      //   52: invokeinterface 55 1 0
      //   57: aload_3
      //   58: invokeinterface 67 3 0
      //   63: pop
      //   64: aload 4
      //   66: monitorexit
      //   67: aload_0
      //   68: getfield 21	androidx/browser/customtabs/CustomTabsService$1:a	Landroidx/browser/customtabs/CustomTabsService;
      //   71: aload_2
      //   72: invokevirtual 71	androidx/browser/customtabs/CustomTabsService:b	(Landroidx/browser/customtabs/f;)Z
      //   75: istore 7
      //   77: iload 7
      //   79: ireturn
      //   80: astore 5
      //   82: aload 4
      //   84: monitorexit
      //   85: aload 5
      //   87: athrow
      //   88: iconst_0
      //   89: ireturn
      //
      // Exception table:
      //   from	to	target	type
      //   31	67	80	finally
      //   82	85	80	finally
      //   9	31	88	android/os/RemoteException
      //   67	77	88	android/os/RemoteException
      //   85	88	88	android/os/RemoteException
    }

    public final boolean a(android.support.a.a paramAnonymousa, int paramAnonymousInt, Uri paramAnonymousUri, Bundle paramAnonymousBundle)
    {
      return CustomTabsService.this.a(new f(paramAnonymousa), paramAnonymousInt, paramAnonymousUri, paramAnonymousBundle);
    }

    public final boolean a(android.support.a.a paramAnonymousa, Uri paramAnonymousUri)
    {
      return CustomTabsService.this.a(new f(paramAnonymousa), paramAnonymousUri);
    }

    public final boolean a(android.support.a.a paramAnonymousa, Uri paramAnonymousUri, Bundle paramAnonymousBundle, List<Bundle> paramAnonymousList)
    {
      return CustomTabsService.this.a(new f(paramAnonymousa), paramAnonymousUri, paramAnonymousBundle, paramAnonymousList);
    }

    public final boolean a(android.support.a.a paramAnonymousa, Bundle paramAnonymousBundle)
    {
      return CustomTabsService.this.a(new f(paramAnonymousa), paramAnonymousBundle);
    }
  };

  static
  {
    CoverageLogger.Log(115204096);
  }

  protected abstract int a(f paramf, String paramString, Bundle paramBundle);

  protected abstract Bundle a(String paramString, Bundle paramBundle);

  protected abstract boolean a(long paramLong);

  // ERROR //
  protected final boolean a(f paramf)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 26	androidx/browser/customtabs/CustomTabsService:a	Ljava/util/Map;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_1
    //   8: invokevirtual 44	androidx/browser/customtabs/f:a	()Landroid/os/IBinder;
    //   11: astore 4
    //   13: aload 4
    //   15: aload_0
    //   16: getfield 26	androidx/browser/customtabs/CustomTabsService:a	Ljava/util/Map;
    //   19: aload 4
    //   21: invokeinterface 50 2 0
    //   26: checkcast 52	android/os/IBinder$DeathRecipient
    //   29: iconst_0
    //   30: invokeinterface 58 3 0
    //   35: pop
    //   36: aload_0
    //   37: getfield 26	androidx/browser/customtabs/CustomTabsService:a	Ljava/util/Map;
    //   40: aload 4
    //   42: invokeinterface 61 2 0
    //   47: pop
    //   48: aload_2
    //   49: monitorexit
    //   50: iconst_1
    //   51: ireturn
    //   52: astore_3
    //   53: aload_2
    //   54: monitorexit
    //   55: aload_3
    //   56: athrow
    //   57: iconst_0
    //   58: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   7	50	52	finally
    //   53	55	52	finally
    //   0	7	57	java/util/NoSuchElementException
    //   55	57	57	java/util/NoSuchElementException
  }

  protected abstract boolean a(f paramf, int paramInt, Uri paramUri, Bundle paramBundle);

  protected abstract boolean a(f paramf, Uri paramUri);

  protected abstract boolean a(f paramf, Uri paramUri, Bundle paramBundle, List<Bundle> paramList);

  protected abstract boolean a(f paramf, Bundle paramBundle);

  protected abstract boolean b(f paramf);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.CustomTabsService
 * JD-Core Version:    0.6.2
 */