package androidx.browser.customtabs;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.support.a.a;
import androidx.core.app.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class c
{
  public final Intent a;
  public final Bundle b;

  static
  {
    CoverageLogger.Log(115499008);
  }

  c(Intent paramIntent, Bundle paramBundle)
  {
    this.a = paramIntent;
    this.b = paramBundle;
  }

  public static final class a
  {
    public final Intent a = new Intent("android.intent.action.VIEW");
    private ArrayList<Bundle> b = null;
    private Bundle c = null;
    private ArrayList<Bundle> d = null;
    private boolean e = true;

    static
    {
      CoverageLogger.Log(115486720);
    }

    public a()
    {
      this(null);
    }

    public a(e parame)
    {
      if (parame != null)
        this.a.setPackage(parame.b.getPackageName());
      Bundle localBundle = new Bundle();
      IBinder localIBinder;
      if (parame == null)
        localIBinder = null;
      else
        localIBinder = parame.a.asBinder();
      d.a(localBundle, "android.support.customtabs.extra.SESSION", localIBinder);
      this.a.putExtras(localBundle);
    }

    public final c a()
    {
      ArrayList localArrayList1 = this.b;
      if (localArrayList1 != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", localArrayList1);
      ArrayList localArrayList2 = this.d;
      if (localArrayList2 != null)
        this.a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", localArrayList2);
      this.a.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.e);
      return new c(this.a, this.c);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.c
 * JD-Core Version:    0.6.2
 */