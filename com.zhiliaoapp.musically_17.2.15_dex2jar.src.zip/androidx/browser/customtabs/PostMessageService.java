package androidx.browser.customtabs;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.a.a;
import android.support.a.c.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class PostMessageService extends Service
{
  private c.a a = new c.a()
  {
    static
    {
      CoverageLogger.Log(115513344);
    }

    public final void a(a paramAnonymousa, Bundle paramAnonymousBundle)
      throws RemoteException
    {
      paramAnonymousa.a(paramAnonymousBundle);
    }

    public final void a(a paramAnonymousa, String paramAnonymousString, Bundle paramAnonymousBundle)
      throws RemoteException
    {
      paramAnonymousa.b(paramAnonymousString, paramAnonymousBundle);
    }
  };

  static
  {
    CoverageLogger.Log(115185664);
  }

  public IBinder onBind(Intent paramIntent)
  {
    return this.a;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.PostMessageService
 * JD-Core Version:    0.6.2
 */