package androidx.browser.customtabs;

import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class f
{
  final android.support.a.a a;
  public final a b;

  static
  {
    CoverageLogger.Log(115511296);
  }

  f(android.support.a.a parama)
  {
    this.a = parama;
    this.b = new a()
    {
      static
      {
        CoverageLogger.Log(115193856);
      }

      public final void a(int paramAnonymousInt, Uri paramAnonymousUri, boolean paramAnonymousBoolean, Bundle paramAnonymousBundle)
      {
        try
        {
          f.this.a.a(paramAnonymousInt, paramAnonymousUri, paramAnonymousBoolean, paramAnonymousBundle);
        }
        catch (RemoteException localRemoteException)
        {
        }
      }

      public final void a(int paramAnonymousInt, Bundle paramAnonymousBundle)
      {
        try
        {
          f.this.a.a(paramAnonymousInt, paramAnonymousBundle);
        }
        catch (RemoteException localRemoteException)
        {
        }
      }

      public final void a(Bundle paramAnonymousBundle)
      {
        try
        {
          f.this.a.a(paramAnonymousBundle);
        }
        catch (RemoteException localRemoteException)
        {
        }
      }

      public final void a(String paramAnonymousString, Bundle paramAnonymousBundle)
      {
        try
        {
          f.this.a.a(paramAnonymousString, paramAnonymousBundle);
        }
        catch (RemoteException localRemoteException)
        {
        }
      }

      public final void b(String paramAnonymousString, Bundle paramAnonymousBundle)
      {
        try
        {
          f.this.a.b(paramAnonymousString, paramAnonymousBundle);
        }
        catch (RemoteException localRemoteException)
        {
        }
      }
    };
  }

  final IBinder a()
  {
    return this.a.asBinder();
  }

  public final boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof f))
      return false;
    return ((f)paramObject).a().equals(this.a.asBinder());
  }

  public final int hashCode()
  {
    return a().hashCode();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.f
 * JD-Core Version:    0.6.2
 */