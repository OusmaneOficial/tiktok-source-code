package androidx.browser.customtabs;

import android.content.ComponentName;
import android.support.a.a;
import android.support.a.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
{
  final a a;
  public final ComponentName b;
  private final Object c = new Object();
  private final b d;

  static
  {
    CoverageLogger.Log(115195904);
  }

  e(b paramb, a parama, ComponentName paramComponentName)
  {
    this.d = paramb;
    this.a = parama;
    this.b = paramComponentName;
  }

  // ERROR //
  public final boolean a(android.net.Uri paramUri, android.os.Bundle paramBundle, java.util.List<android.os.Bundle> paramList)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 29	androidx/browser/customtabs/e:d	Landroid/support/a/b;
    //   4: aload_0
    //   5: getfield 31	androidx/browser/customtabs/e:a	Landroid/support/a/a;
    //   8: aload_1
    //   9: aconst_null
    //   10: aload_3
    //   11: invokeinterface 41 5 0
    //   16: istore 4
    //   18: iload 4
    //   20: ireturn
    //   21: iconst_0
    //   22: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	18	21	android/os/RemoteException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.e
 * JD-Core Version:    0.6.2
 */