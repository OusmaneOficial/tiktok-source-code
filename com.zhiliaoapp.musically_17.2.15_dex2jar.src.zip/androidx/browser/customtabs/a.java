package androidx.browser.customtabs;

import android.net.Uri;
import android.os.Bundle;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class a
{
  static
  {
    CoverageLogger.Log(115470336);
  }

  public void a(int paramInt, Uri paramUri, boolean paramBoolean, Bundle paramBundle)
  {
  }

  public void a(int paramInt, Bundle paramBundle)
  {
  }

  public void a(Bundle paramBundle)
  {
  }

  public void a(String paramString, Bundle paramBundle)
  {
  }

  public void b(String paramString, Bundle paramBundle)
  {
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.a
 * JD-Core Version:    0.6.2
 */