package androidx.browser.customtabs;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.IInterface;
import android.support.a.b.a.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class d
  implements ServiceConnection
{
  static
  {
    CoverageLogger.Log(115505152);
  }

  public abstract void a(ComponentName paramComponentName, b paramb);

  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    Object localObject;
    if (paramIBinder == null)
    {
      localObject = null;
    }
    else
    {
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.support.customtabs.ICustomTabsService");
      if ((localIInterface != null) && ((localIInterface instanceof android.support.a.b)))
        localObject = (android.support.a.b)localIInterface;
      else
        localObject = new b.a.a(paramIBinder);
    }
    a(paramComponentName, new b((android.support.a.b)localObject, paramComponentName)
    {
      static
      {
        CoverageLogger.Log(115200000);
      }
    });
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.d
 * JD-Core Version:    0.6.2
 */