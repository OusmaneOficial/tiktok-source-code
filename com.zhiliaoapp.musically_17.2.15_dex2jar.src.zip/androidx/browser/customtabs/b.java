package androidx.browser.customtabs;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.support.a.a.a;
import android.text.TextUtils;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class b
{
  private final android.support.a.b a;
  private final ComponentName b;

  static
  {
    CoverageLogger.Log(115214336);
  }

  b(android.support.a.b paramb, ComponentName paramComponentName)
  {
    this.a = paramb;
    this.b = paramComponentName;
  }

  // ERROR //
  public static boolean a(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +5 -> 6
    //   4: iconst_0
    //   5: ireturn
    //   6: aload_0
    //   7: invokevirtual 34	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   10: astore_2
    //   11: new 36	androidx/browser/customtabs/b$1
    //   14: dup
    //   15: aload_2
    //   16: invokespecial 39	androidx/browser/customtabs/b$1:<init>	(Landroid/content/Context;)V
    //   19: astore_3
    //   20: aload_2
    //   21: aload_1
    //   22: aload_3
    //   23: invokestatic 42	androidx/browser/customtabs/b:a	(Landroid/content/Context;Ljava/lang/String;Landroidx/browser/customtabs/d;)Z
    //   26: istore 4
    //   28: iload 4
    //   30: ireturn
    //   31: iconst_0
    //   32: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   20	28	31	java/lang/SecurityException
  }

  public static boolean a(Context paramContext, String paramString, d paramd)
  {
    Intent localIntent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      localIntent.setPackage(paramString);
    if ((paramContext != null) && ((paramContext instanceof Context)))
    {
      if (com.ss.android.ugc.aweme.push.downgrade.d.a((Context)paramContext, localIntent))
        return true;
      return paramContext.bindService(localIntent, paramd, 33);
    }
    return paramContext.bindService(localIntent, paramd, 33);
  }

  public final e a(final a parama)
  {
    a.a local2 = new a.a()
    {
      private Handler c = new Handler(Looper.getMainLooper());

      static
      {
        CoverageLogger.Log(115482624);
      }

      public final void a(final int paramAnonymousInt, final Uri paramAnonymousUri, final boolean paramAnonymousBoolean, final Bundle paramAnonymousBundle)
        throws RemoteException
      {
        if (parama == null)
          return;
        Handler localHandler = this.c;
        Runnable local5 = new Runnable()
        {
          static
          {
            CoverageLogger.Log(115484672);
          }

          public final void run()
          {
            b.2.this.a.a(paramAnonymousInt, paramAnonymousUri, paramAnonymousBoolean, paramAnonymousBundle);
          }
        };
        localHandler.post(local5);
      }

      public final void a(final int paramAnonymousInt, final Bundle paramAnonymousBundle)
      {
        if (parama == null)
          return;
        this.c.post(new Runnable()
        {
          static
          {
            CoverageLogger.Log(115478528);
          }

          public final void run()
          {
            b.2.this.a.a(paramAnonymousInt, paramAnonymousBundle);
          }
        });
      }

      public final void a(final Bundle paramAnonymousBundle)
        throws RemoteException
      {
        if (parama == null)
          return;
        this.c.post(new Runnable()
        {
          static
          {
            CoverageLogger.Log(115220480);
          }

          public final void run()
          {
            b.2.this.a.a(paramAnonymousBundle);
          }
        });
      }

      public final void a(final String paramAnonymousString, final Bundle paramAnonymousBundle)
        throws RemoteException
      {
        if (parama == null)
          return;
        this.c.post(new Runnable()
        {
          static
          {
            CoverageLogger.Log(115480576);
          }

          public final void run()
          {
            b.2.this.a.a(paramAnonymousString, paramAnonymousBundle);
          }
        });
      }

      public final void b(final String paramAnonymousString, final Bundle paramAnonymousBundle)
        throws RemoteException
      {
        if (parama == null)
          return;
        this.c.post(new Runnable()
        {
          static
          {
            CoverageLogger.Log(115218432);
          }

          public final void run()
          {
            b.2.this.a.b(paramAnonymousString, paramAnonymousBundle);
          }
        });
      }
    };
    e locale = null;
    try
    {
      boolean bool = this.a.a(local2);
      if (!bool)
        return null;
      locale = new e(this.a, local2, this.b);
    }
    catch (RemoteException localRemoteException)
    {
    }
    return locale;
  }

  // ERROR //
  public final boolean a(long paramLong)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	androidx/browser/customtabs/b:a	Landroid/support/a/b;
    //   4: lconst_0
    //   5: invokeinterface 89 3 0
    //   10: istore_3
    //   11: iload_3
    //   12: ireturn
    //   13: iconst_0
    //   14: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	11	13	android/os/RemoteException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.browser.customtabs.b
 * JD-Core Version:    0.6.2
 */