package androidx.l.a.a;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import android.view.InflateException;
import androidx.core.content.a.g;
import androidx.core.graphics.b;
import androidx.core.graphics.b.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class e
{
  static
  {
    CoverageLogger.Log(24299520);
  }

  // ERROR //
  public static Animator a(Context paramContext, Resources paramResources, Resources.Theme paramTheme, int paramInt, float paramFloat)
    throws Resources.NotFoundException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 5
    //   3: aload_1
    //   4: iload_3
    //   5: invokevirtual 27	android/content/res/Resources:getAnimation	(I)Landroid/content/res/XmlResourceParser;
    //   8: astore 5
    //   10: aload 5
    //   12: invokestatic 33	android/util/Xml:asAttributeSet	(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    //   15: astore 17
    //   17: aload_0
    //   18: aload_1
    //   19: aload_2
    //   20: aload 5
    //   22: aload 17
    //   24: aconst_null
    //   25: iconst_0
    //   26: fconst_1
    //   27: invokestatic 36	androidx/l/a/a/e:a	(Landroid/content/Context;Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/animation/AnimatorSet;IF)Landroid/animation/Animator;
    //   30: astore 18
    //   32: aload 5
    //   34: ifnull +10 -> 44
    //   37: aload 5
    //   39: invokeinterface 41 1 0
    //   44: aload 18
    //   46: areturn
    //   47: astore 11
    //   49: goto +99 -> 148
    //   52: astore 12
    //   54: new 43	java/lang/StringBuilder
    //   57: dup
    //   58: ldc 45
    //   60: invokespecial 49	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   63: astore 13
    //   65: aload 13
    //   67: iload_3
    //   68: invokestatic 55	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   71: invokevirtual 59	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: pop
    //   75: new 17	android/content/res/Resources$NotFoundException
    //   78: dup
    //   79: aload 13
    //   81: invokevirtual 63	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   84: invokespecial 64	android/content/res/Resources$NotFoundException:<init>	(Ljava/lang/String;)V
    //   87: astore 15
    //   89: aload 15
    //   91: aload 12
    //   93: invokevirtual 68	android/content/res/Resources$NotFoundException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   96: pop
    //   97: aload 15
    //   99: athrow
    //   100: astore 6
    //   102: new 43	java/lang/StringBuilder
    //   105: dup
    //   106: ldc 45
    //   108: invokespecial 49	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   111: astore 7
    //   113: aload 7
    //   115: iload_3
    //   116: invokestatic 55	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   119: invokevirtual 59	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   122: pop
    //   123: new 17	android/content/res/Resources$NotFoundException
    //   126: dup
    //   127: aload 7
    //   129: invokevirtual 63	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   132: invokespecial 64	android/content/res/Resources$NotFoundException:<init>	(Ljava/lang/String;)V
    //   135: astore 9
    //   137: aload 9
    //   139: aload 6
    //   141: invokevirtual 68	android/content/res/Resources$NotFoundException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   144: pop
    //   145: aload 9
    //   147: athrow
    //   148: aload 5
    //   150: ifnull +10 -> 160
    //   153: aload 5
    //   155: invokeinterface 41 1 0
    //   160: aload 11
    //   162: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   3	32	47	finally
    //   54	100	47	finally
    //   102	148	47	finally
    //   3	32	52	java/io/IOException
    //   3	32	100	org/xmlpull/v1/XmlPullParserException
  }

  private static Animator a(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, AnimatorSet paramAnimatorSet, int paramInt, float paramFloat)
    throws XmlPullParserException, IOException
  {
    int i = paramXmlPullParser.getDepth();
    Object localObject = null;
    ArrayList localArrayList = null;
    int k;
    while (true)
    {
      int j = paramXmlPullParser.next();
      k = 0;
      if (((j == 3) && (paramXmlPullParser.getDepth() <= i)) || (j == 1))
        break;
      label284: if (j == 2)
      {
        String str = paramXmlPullParser.getName();
        if (str.equals("objectAnimator"));
        int i1;
        for (localObject = a(paramContext, paramResources, paramTheme, paramAttributeSet, paramFloat, paramXmlPullParser); ; localObject = a(paramContext, paramResources, paramTheme, paramAttributeSet, null, paramFloat, paramXmlPullParser))
        {
          i1 = 0;
          break label249;
          if (!str.equals("animator"))
            break;
        }
        if (str.equals("set"))
        {
          AnimatorSet localAnimatorSet = new AnimatorSet();
          TypedArray localTypedArray = g.a(paramResources, paramTheme, paramAttributeSet, a.h);
          int n = g.a(localTypedArray, paramXmlPullParser, "ordering", 0, 0);
          a(paramContext, paramResources, paramTheme, paramXmlPullParser, paramAttributeSet, (AnimatorSet)localAnimatorSet, n, paramFloat);
          localTypedArray.recycle();
          localObject = localAnimatorSet;
          i1 = 0;
        }
        else
        {
          if (!str.equals("propertyValuesHolder"))
            break label284;
          PropertyValuesHolder[] arrayOfPropertyValuesHolder = a(paramContext, paramResources, paramTheme, paramXmlPullParser, Xml.asAttributeSet(paramXmlPullParser));
          if ((arrayOfPropertyValuesHolder != null) && (localObject != null) && ((localObject instanceof ValueAnimator)))
            ((ValueAnimator)localObject).setValues(arrayOfPropertyValuesHolder);
          i1 = 1;
        }
        label249: if ((paramAnimatorSet != null) && (i1 == 0))
        {
          if (localArrayList == null)
            localArrayList = new ArrayList();
          localArrayList.add(localObject);
          continue;
          StringBuilder localStringBuilder = new StringBuilder("Unknown animator name: ");
          localStringBuilder.append(paramXmlPullParser.getName());
          throw new RuntimeException(localStringBuilder.toString());
        }
      }
    }
    if ((paramAnimatorSet != null) && (localArrayList != null))
    {
      Animator[] arrayOfAnimator = new Animator[localArrayList.size()];
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        Animator localAnimator = (Animator)localIterator.next();
        int m = k + 1;
        arrayOfAnimator[k] = localAnimator;
        k = m;
      }
      if (paramInt == 0)
      {
        paramAnimatorSet.playTogether(arrayOfAnimator);
        return localObject;
      }
      paramAnimatorSet.playSequentially(arrayOfAnimator);
    }
    return localObject;
  }

  private static Keyframe a(Keyframe paramKeyframe, float paramFloat)
  {
    if (paramKeyframe.getType() == Float.TYPE)
      return Keyframe.ofFloat(paramFloat);
    if (paramKeyframe.getType() == Integer.TYPE)
      return Keyframe.ofInt(paramFloat);
    return Keyframe.ofObject(paramFloat);
  }

  private static ObjectAnimator a(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, float paramFloat, XmlPullParser paramXmlPullParser)
    throws Resources.NotFoundException
  {
    ObjectAnimator localObjectAnimator = new ObjectAnimator();
    a(paramContext, paramResources, paramTheme, paramAttributeSet, localObjectAnimator, paramFloat, paramXmlPullParser);
    return localObjectAnimator;
  }

  private static PropertyValuesHolder a(TypedArray paramTypedArray, int paramInt1, int paramInt2, int paramInt3, String paramString)
  {
    TypedValue localTypedValue1 = paramTypedArray.peekValue(paramInt2);
    int i;
    if (localTypedValue1 != null)
      i = 1;
    else
      i = 0;
    int j;
    if (i != 0)
      j = localTypedValue1.type;
    else
      j = 0;
    TypedValue localTypedValue2 = paramTypedArray.peekValue(paramInt3);
    int k;
    if (localTypedValue2 != null)
      k = 1;
    else
      k = 0;
    int m;
    if (k != 0)
      m = localTypedValue2.type;
    else
      m = 0;
    if (paramInt1 == 4)
      if (((i != 0) && (a(j))) || ((k != 0) && (a(m))))
        paramInt1 = 3;
      else
        paramInt1 = 0;
    int n;
    if (paramInt1 == 0)
      n = 1;
    else
      n = 0;
    if (paramInt1 == 2)
    {
      String str1 = paramTypedArray.getString(paramInt2);
      String str2 = paramTypedArray.getString(paramInt3);
      b.b[] arrayOfb1 = b.b(str1);
      b.b[] arrayOfb2 = b.b(str2);
      PropertyValuesHolder localPropertyValuesHolder3;
      if (arrayOfb1 == null)
      {
        localPropertyValuesHolder3 = null;
        if (arrayOfb2 == null);
      }
      else if (arrayOfb1 != null)
      {
        a locala = new a();
        if (arrayOfb2 != null)
        {
          if (b.a(arrayOfb1, arrayOfb2))
          {
            localPropertyValuesHolder3 = PropertyValuesHolder.ofObject(paramString, locala, new Object[] { arrayOfb1, arrayOfb2 });
          }
          else
          {
            StringBuilder localStringBuilder = new StringBuilder(" Can't morph from ");
            localStringBuilder.append(str1);
            localStringBuilder.append(" to ");
            localStringBuilder.append(str2);
            throw new InflateException(localStringBuilder.toString());
          }
        }
        else
          return PropertyValuesHolder.ofObject(paramString, locala, new Object[] { arrayOfb1 });
      }
      else
      {
        localPropertyValuesHolder3 = null;
        if (arrayOfb2 != null)
          localPropertyValuesHolder3 = PropertyValuesHolder.ofObject(paramString, new a(), new Object[] { arrayOfb2 });
      }
      return localPropertyValuesHolder3;
    }
    f localf;
    if (paramInt1 == 3)
      localf = f.a();
    else
      localf = null;
    PropertyValuesHolder localPropertyValuesHolder1;
    if (n != 0)
    {
      if (i != 0)
      {
        float f2;
        if (j == 5)
          f2 = paramTypedArray.getDimension(paramInt2, 0.0F);
        else
          f2 = paramTypedArray.getFloat(paramInt2, 0.0F);
        if (k != 0)
        {
          float f3;
          if (m == 5)
            f3 = paramTypedArray.getDimension(paramInt3, 0.0F);
          else
            f3 = paramTypedArray.getFloat(paramInt3, 0.0F);
          localPropertyValuesHolder1 = PropertyValuesHolder.ofFloat(paramString, new float[] { f2, f3 });
        }
        else
        {
          localPropertyValuesHolder1 = PropertyValuesHolder.ofFloat(paramString, new float[] { f2 });
        }
      }
      else
      {
        float f1;
        if (m == 5)
          f1 = paramTypedArray.getDimension(paramInt3, 0.0F);
        else
          f1 = paramTypedArray.getFloat(paramInt3, 0.0F);
        localPropertyValuesHolder1 = PropertyValuesHolder.ofFloat(paramString, new float[] { f1 });
      }
    }
    else if (i != 0)
    {
      int i2;
      if (j == 5)
        i2 = (int)paramTypedArray.getDimension(paramInt2, 0.0F);
      else if (a(j))
        i2 = paramTypedArray.getColor(paramInt2, 0);
      else
        i2 = paramTypedArray.getInt(paramInt2, 0);
      if (k != 0)
      {
        int i3;
        if (m == 5)
          i3 = (int)paramTypedArray.getDimension(paramInt3, 0.0F);
        else if (a(m))
          i3 = paramTypedArray.getColor(paramInt3, 0);
        else
          i3 = paramTypedArray.getInt(paramInt3, 0);
        localPropertyValuesHolder1 = PropertyValuesHolder.ofInt(paramString, new int[] { i2, i3 });
      }
      else
      {
        localPropertyValuesHolder1 = PropertyValuesHolder.ofInt(paramString, new int[] { i2 });
      }
    }
    else
    {
      localPropertyValuesHolder1 = null;
      if (k != 0)
      {
        int i1;
        if (m == 5)
          i1 = (int)paramTypedArray.getDimension(paramInt3, 0.0F);
        else if (a(m))
          i1 = paramTypedArray.getColor(paramInt3, 0);
        else
          i1 = paramTypedArray.getInt(paramInt3, 0);
        localPropertyValuesHolder1 = PropertyValuesHolder.ofInt(paramString, new int[] { i1 });
      }
    }
    PropertyValuesHolder localPropertyValuesHolder2 = localPropertyValuesHolder1;
    if ((localPropertyValuesHolder2 != null) && (localf != null))
      localPropertyValuesHolder2.setEvaluator(localf);
    return localPropertyValuesHolder2;
  }

  private static ValueAnimator a(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, ValueAnimator paramValueAnimator, float paramFloat, XmlPullParser paramXmlPullParser)
    throws Resources.NotFoundException
  {
    TypedArray localTypedArray1 = g.a(paramResources, paramTheme, paramAttributeSet, a.g);
    TypedArray localTypedArray2 = g.a(paramResources, paramTheme, paramAttributeSet, a.k);
    if (paramValueAnimator == null)
      paramValueAnimator = new ValueAnimator();
    a(paramValueAnimator, localTypedArray1, localTypedArray2, paramFloat, paramXmlPullParser);
    int i = g.c(localTypedArray1, paramXmlPullParser, "interpolator", 0, 0);
    if (i > 0)
      paramValueAnimator.setInterpolator(d.a(paramContext, i));
    localTypedArray1.recycle();
    if (localTypedArray2 != null)
      localTypedArray2.recycle();
    return paramValueAnimator;
  }

  private static void a(ValueAnimator paramValueAnimator, TypedArray paramTypedArray1, TypedArray paramTypedArray2, float paramFloat, XmlPullParser paramXmlPullParser)
  {
    long l1 = g.a(paramTypedArray1, paramXmlPullParser, "duration", 1, 300);
    long l2 = g.a(paramTypedArray1, paramXmlPullParser, "startOffset", 2, 0);
    int i = g.a(paramTypedArray1, paramXmlPullParser, "valueType", 7, 4);
    if ((g.a(paramXmlPullParser, "valueFrom")) && (g.a(paramXmlPullParser, "valueTo")))
    {
      if (i == 4)
      {
        TypedValue localTypedValue1 = paramTypedArray1.peekValue(5);
        int j;
        if (localTypedValue1 != null)
          j = 1;
        else
          j = 0;
        int k;
        if (j != 0)
          k = localTypedValue1.type;
        else
          k = 0;
        TypedValue localTypedValue2 = paramTypedArray1.peekValue(6);
        int m;
        if (localTypedValue2 != null)
          m = 1;
        else
          m = 0;
        int n;
        if (m != 0)
          n = localTypedValue2.type;
        else
          n = 0;
        if (((j != 0) && (a(k))) || ((m != 0) && (a(n))))
          i = 3;
        else
          i = 0;
      }
      PropertyValuesHolder localPropertyValuesHolder = a(paramTypedArray1, i, 5, 6, "");
      if (localPropertyValuesHolder != null)
        paramValueAnimator.setValues(new PropertyValuesHolder[] { localPropertyValuesHolder });
    }
    paramValueAnimator.setDuration(l1);
    paramValueAnimator.setStartDelay(l2);
    paramValueAnimator.setRepeatCount(g.a(paramTypedArray1, paramXmlPullParser, "repeatCount", 3, 0));
    paramValueAnimator.setRepeatMode(g.a(paramTypedArray1, paramXmlPullParser, "repeatMode", 4, 1));
    if (paramTypedArray2 != null)
    {
      ObjectAnimator localObjectAnimator = (ObjectAnimator)paramValueAnimator;
      String str1 = g.a(paramTypedArray2, paramXmlPullParser, "pathData", 1);
      if (str1 != null)
      {
        String str2 = g.a(paramTypedArray2, paramXmlPullParser, "propertyXName", 2);
        String str3 = g.a(paramTypedArray2, paramXmlPullParser, "propertyYName", 3);
        if ((str2 == null) && (str3 == null))
        {
          StringBuilder localStringBuilder = new StringBuilder();
          localStringBuilder.append(paramTypedArray2.getPositionDescription());
          localStringBuilder.append(" propertyXName or propertyYName is needed for PathData");
          throw new InflateException(localStringBuilder.toString());
        }
        a(b.a(str1), localObjectAnimator, 0.5F * paramFloat, str2, str3);
        return;
      }
      localObjectAnimator.setPropertyName(g.a(paramTypedArray2, paramXmlPullParser, "propertyName", 0));
    }
  }

  private static void a(Path paramPath, ObjectAnimator paramObjectAnimator, float paramFloat, String paramString1, String paramString2)
  {
    PathMeasure localPathMeasure1 = new PathMeasure(paramPath, false);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(Float.valueOf(0.0F));
    float f1 = 0.0F;
    do
    {
      f1 += localPathMeasure1.getLength();
      localArrayList.add(Float.valueOf(f1));
    }
    while (localPathMeasure1.nextContour());
    PathMeasure localPathMeasure2 = new PathMeasure(paramPath, false);
    int i = Math.min(100, 1 + (int)(f1 / paramFloat));
    float[] arrayOfFloat1 = new float[i];
    float[] arrayOfFloat2 = new float[i];
    float[] arrayOfFloat3 = new float[2];
    float f2 = f1 / (i - 1);
    int j = 0;
    float f3 = 0.0F;
    int k = 0;
    while (j < i)
    {
      localPathMeasure2.getPosTan(f3 - ((Float)localArrayList.get(k)).floatValue(), arrayOfFloat3, null);
      arrayOfFloat1[j] = arrayOfFloat3[0];
      arrayOfFloat2[j] = arrayOfFloat3[1];
      f3 += f2;
      int m = k + 1;
      if ((m < localArrayList.size()) && (f3 > ((Float)localArrayList.get(m)).floatValue()))
      {
        localPathMeasure2.nextContour();
        k = m;
      }
      j++;
    }
    PropertyValuesHolder localPropertyValuesHolder1;
    if (paramString1 != null)
      localPropertyValuesHolder1 = PropertyValuesHolder.ofFloat(paramString1, arrayOfFloat1);
    else
      localPropertyValuesHolder1 = null;
    PropertyValuesHolder localPropertyValuesHolder2 = null;
    if (paramString2 != null)
      localPropertyValuesHolder2 = PropertyValuesHolder.ofFloat(paramString2, arrayOfFloat2);
    if (localPropertyValuesHolder1 == null)
    {
      paramObjectAnimator.setValues(new PropertyValuesHolder[] { localPropertyValuesHolder2 });
      return;
    }
    if (localPropertyValuesHolder2 == null)
    {
      paramObjectAnimator.setValues(new PropertyValuesHolder[] { localPropertyValuesHolder1 });
      return;
    }
    paramObjectAnimator.setValues(new PropertyValuesHolder[] { localPropertyValuesHolder1, localPropertyValuesHolder2 });
  }

  private static void a(Keyframe[] paramArrayOfKeyframe, float paramFloat, int paramInt1, int paramInt2)
  {
    float f = paramFloat / (2 + (paramInt2 - paramInt1));
    while (paramInt1 <= paramInt2)
    {
      paramArrayOfKeyframe[paramInt1].setFraction(f + paramArrayOfKeyframe[(paramInt1 - 1)].getFraction());
      paramInt1++;
    }
  }

  private static boolean a(int paramInt)
  {
    return (paramInt >= 28) && (paramInt <= 31);
  }

  private static PropertyValuesHolder[] a(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet)
    throws XmlPullParserException, IOException
  {
    ArrayList localArrayList1 = null;
    while (true)
    {
      int i = paramXmlPullParser.getEventType();
      if (i == 3)
        break;
      int m = 1;
      if (i == m)
        break;
      if (i != 2)
      {
        paramXmlPullParser.next();
      }
      else
      {
        if (paramXmlPullParser.getName().equals("propertyValuesHolder"))
        {
          TypedArray localTypedArray1 = g.a(paramResources, paramTheme, paramAttributeSet, a.i);
          String str = g.a(localTypedArray1, paramXmlPullParser, "propertyName", 3);
          int n = 4;
          int i1 = g.a(localTypedArray1, paramXmlPullParser, "valueType", 2, n);
          int i2 = i1;
          ArrayList localArrayList2 = null;
          while (true)
          {
            int i3 = paramXmlPullParser.next();
            if ((i3 == 3) || (i3 == m))
              break;
            if (paramXmlPullParser.getName().equals("keyframe"))
            {
              if (i2 == n)
              {
                TypedArray localTypedArray3 = g.a(paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), a.j);
                TypedValue localTypedValue2 = g.b(localTypedArray3, paramXmlPullParser, "value", 0);
                int i13;
                if (localTypedValue2 != null)
                  i13 = 1;
                else
                  i13 = 0;
                int i14;
                if ((i13 != 0) && (a(localTypedValue2.type)))
                  i14 = 3;
                else
                  i14 = 0;
                localTypedArray3.recycle();
                i2 = i14;
              }
              TypedArray localTypedArray2 = g.a(paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), a.j);
              float f3 = g.a(localTypedArray2, paramXmlPullParser, "fraction", 3, -1.0F);
              TypedValue localTypedValue1 = g.b(localTypedArray2, paramXmlPullParser, "value", 0);
              int i10;
              if (localTypedValue1 != null)
                i10 = 1;
              else
                i10 = 0;
              int i11;
              if (i2 == 4)
              {
                if ((i10 != 0) && (a(localTypedValue1.type)))
                  i11 = 3;
                else
                  i11 = 0;
              }
              else
                i11 = i2;
              Keyframe localKeyframe4;
              if (i10 != 0)
              {
                if (i11 != 0)
                {
                  if ((i11 != 1) && (i11 != 3))
                    localKeyframe4 = null;
                  else
                    localKeyframe4 = Keyframe.ofInt(f3, g.a(localTypedArray2, paramXmlPullParser, "value", 0, 0));
                }
                else
                  localKeyframe4 = Keyframe.ofFloat(f3, g.a(localTypedArray2, paramXmlPullParser, "value", 0, 0.0F));
              }
              else if (i11 == 0)
                localKeyframe4 = Keyframe.ofFloat(f3);
              else
                localKeyframe4 = Keyframe.ofInt(f3);
              int i12 = g.c(localTypedArray2, paramXmlPullParser, "interpolator", 1, 0);
              if (i12 > 0)
                localKeyframe4.setInterpolator(d.a(paramContext, i12));
              localTypedArray2.recycle();
              if (localKeyframe4 != null)
              {
                if (localArrayList2 == null)
                  localArrayList2 = new ArrayList();
                localArrayList2.add(localKeyframe4);
              }
              paramXmlPullParser.next();
            }
            m = 1;
            n = 4;
          }
          if (localArrayList2 != null)
          {
            int i4 = localArrayList2.size();
            if (i4 > 0)
            {
              Keyframe localKeyframe1 = (Keyframe)localArrayList2.get(0);
              Keyframe localKeyframe2 = (Keyframe)localArrayList2.get(i4 - 1);
              float f1 = localKeyframe2.getFraction();
              if (f1 < 1.0F)
                if (f1 < 0.0F)
                {
                  localKeyframe2.setFraction(1.0F);
                }
                else
                {
                  localArrayList2.add(localArrayList2.size(), a(localKeyframe2, 1.0F));
                  i4++;
                }
              float f2 = localKeyframe1.getFraction();
              if (f2 != 0.0F)
                if (f2 < 0.0F)
                {
                  localKeyframe1.setFraction(0.0F);
                }
                else
                {
                  localArrayList2.add(0, a(localKeyframe1, 0.0F));
                  i4++;
                }
              Keyframe[] arrayOfKeyframe = new Keyframe[i4];
              localArrayList2.toArray(arrayOfKeyframe);
              for (int i5 = 0; i5 < i4; i5++)
              {
                Keyframe localKeyframe3 = arrayOfKeyframe[i5];
                PropertyValuesHolder localPropertyValuesHolder;
                int j;
                int k;
                PropertyValuesHolder[] arrayOfPropertyValuesHolder;
                if (localKeyframe3.getFraction() < 0.0F)
                  if (i5 == 0)
                  {
                    localKeyframe3.setFraction(0.0F);
                  }
                  else
                  {
                    int i6 = i4 - 1;
                    if (i5 == i6)
                    {
                      localKeyframe3.setFraction(1.0F);
                    }
                    else
                    {
                      int i7 = i5 + 1;
                      int i8 = i5;
                      while ((i7 < i6) && (arrayOfKeyframe[i7].getFraction() < 0.0F))
                      {
                        int i9 = i7 + 1;
                        i8 = i7;
                        i7 = i9;
                      }
                      a(arrayOfKeyframe, arrayOfKeyframe[(i8 + 1)].getFraction() - arrayOfKeyframe[(i5 - 1)].getFraction(), i5, i8);
                    }
                  }
              }
              localPropertyValuesHolder = PropertyValuesHolder.ofKeyframe(str, arrayOfKeyframe);
              if (i2 != 3)
                break label816;
              localPropertyValuesHolder.setEvaluator(f.a());
              break label816;
            }
          }
          localPropertyValuesHolder = null;
          label816: if (localPropertyValuesHolder == null)
            localPropertyValuesHolder = a(localTypedArray1, i1, 0, 1, str);
          if (localPropertyValuesHolder != null)
          {
            if (localArrayList1 == null)
              localArrayList1 = new ArrayList();
            localArrayList1.add(localPropertyValuesHolder);
          }
          localTypedArray1.recycle();
        }
        paramXmlPullParser.next();
      }
    }
    j = 0;
    if (localArrayList1 != null)
    {
      k = localArrayList1.size();
      arrayOfPropertyValuesHolder = new PropertyValuesHolder[k];
      while (j < k)
      {
        arrayOfPropertyValuesHolder[j] = ((PropertyValuesHolder)localArrayList1.get(j));
        j++;
      }
      return arrayOfPropertyValuesHolder;
    }
    return null;
  }

  static final class a
    implements TypeEvaluator<b.b[]>
  {
    private b.b[] a;

    static
    {
      CoverageLogger.Log(24311808);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.l.a.a.e
 * JD-Core Version:    0.6.2
 */