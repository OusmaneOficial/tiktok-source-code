package androidx.l.a.a;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.InflateException;
import android.view.animation.Interpolator;
import androidx.core.graphics.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import org.xmlpull.v1.XmlPullParser;

public final class g
  implements Interpolator
{
  private float[] a;
  private float[] b;

  static
  {
    CoverageLogger.Log(24238080);
  }

  public g(Context paramContext, AttributeSet paramAttributeSet, XmlPullParser paramXmlPullParser)
  {
    this(paramContext.getResources(), paramContext.getTheme(), paramAttributeSet, paramXmlPullParser);
  }

  private g(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, XmlPullParser paramXmlPullParser)
  {
    TypedArray localTypedArray = androidx.core.content.a.g.a(paramResources, paramTheme, paramAttributeSet, a.l);
    if (androidx.core.content.a.g.a(paramXmlPullParser, "pathData"))
    {
      String str = androidx.core.content.a.g.a(localTypedArray, paramXmlPullParser, "pathData", 4);
      Path localPath3 = b.a(str);
      if (localPath3 != null)
      {
        a(localPath3);
      }
      else
      {
        StringBuilder localStringBuilder = new StringBuilder("The path is null, which is created from ");
        localStringBuilder.append(str);
        throw new InflateException(localStringBuilder.toString());
      }
    }
    else
    {
      if (!androidx.core.content.a.g.a(paramXmlPullParser, "controlX1"))
        break label287;
      if (!androidx.core.content.a.g.a(paramXmlPullParser, "controlY1"))
        break label277;
      float f1 = androidx.core.content.a.g.a(localTypedArray, paramXmlPullParser, "controlX1", 0, 0.0F);
      float f2 = androidx.core.content.a.g.a(localTypedArray, paramXmlPullParser, "controlY1", 1, 0.0F);
      boolean bool = androidx.core.content.a.g.a(paramXmlPullParser, "controlX2");
      if (bool != androidx.core.content.a.g.a(paramXmlPullParser, "controlY2"))
        break label267;
      if (!bool)
      {
        Path localPath1 = new Path();
        localPath1.moveTo(0.0F, 0.0F);
        localPath1.quadTo(f1, f2, 1.0F, 1.0F);
        a(localPath1);
      }
      else
      {
        float f3 = androidx.core.content.a.g.a(localTypedArray, paramXmlPullParser, "controlX2", 2, 0.0F);
        float f4 = androidx.core.content.a.g.a(localTypedArray, paramXmlPullParser, "controlY2", 3, 0.0F);
        Path localPath2 = new Path();
        localPath2.moveTo(0.0F, 0.0F);
        localPath2.cubicTo(f1, f2, f3, f4, 1.0F, 1.0F);
        a(localPath2);
      }
    }
    localTypedArray.recycle();
    return;
    label267: throw new InflateException("pathInterpolator requires both controlX2 and controlY2 for cubic Beziers.");
    label277: throw new InflateException("pathInterpolator requires the controlY1 attribute");
    label287: throw new InflateException("pathInterpolator requires the controlX1 attribute");
  }

  private void a(Path paramPath)
  {
    int i = 0;
    PathMeasure localPathMeasure = new PathMeasure(paramPath, false);
    float f1 = localPathMeasure.getLength();
    int j = Math.min(3000, 1 + (int)(f1 / 0.002F));
    if (j > 0)
    {
      this.a = new float[j];
      this.b = new float[j];
      float[] arrayOfFloat1 = new float[2];
      for (int k = 0; k < j; k++)
      {
        localPathMeasure.getPosTan(f1 * k / (j - 1), arrayOfFloat1, null);
        this.a[k] = arrayOfFloat1[0];
        this.b[k] = arrayOfFloat1[1];
      }
      if ((Math.abs(this.a[0]) <= 1.E-005D) && (Math.abs(this.b[0]) <= 1.E-005D))
      {
        float[] arrayOfFloat3 = this.a;
        int n = j - 1;
        if ((Math.abs(arrayOfFloat3[n] - 1.0F) <= 1.E-005D) && (Math.abs(this.b[n] - 1.0F) <= 1.E-005D))
        {
          int i1 = 0;
          float f2 = 0.0F;
          while (i < j)
          {
            float[] arrayOfFloat4 = this.a;
            int i2 = i1 + 1;
            float f3 = arrayOfFloat4[i1];
            if (f3 >= f2)
            {
              arrayOfFloat4[i] = f3;
              i++;
              f2 = f3;
              i1 = i2;
            }
            else
            {
              StringBuilder localStringBuilder3 = new StringBuilder("The Path cannot loop back on itself, x :");
              localStringBuilder3.append(f3);
              throw new IllegalArgumentException(localStringBuilder3.toString());
            }
          }
          if (!localPathMeasure.nextContour())
            return;
          throw new IllegalArgumentException("The Path should be continuous, can't have 2+ contours");
        }
      }
      StringBuilder localStringBuilder2 = new StringBuilder("The Path must start at (0,0) and end at (1,1) start: ");
      localStringBuilder2.append(this.a[0]);
      localStringBuilder2.append(",");
      localStringBuilder2.append(this.b[0]);
      localStringBuilder2.append(" end:");
      float[] arrayOfFloat2 = this.a;
      int m = j - 1;
      localStringBuilder2.append(arrayOfFloat2[m]);
      localStringBuilder2.append(",");
      localStringBuilder2.append(this.b[m]);
      throw new IllegalArgumentException(localStringBuilder2.toString());
    }
    StringBuilder localStringBuilder1 = new StringBuilder("The Path has a invalid length ");
    localStringBuilder1.append(f1);
    IllegalArgumentException localIllegalArgumentException = new IllegalArgumentException(localStringBuilder1.toString());
    while (true)
      throw localIllegalArgumentException;
  }

  public final float getInterpolation(float paramFloat)
  {
    if (paramFloat <= 0.0F)
      return 0.0F;
    if (paramFloat >= 1.0F)
      return 1.0F;
    int i = 0;
    int j = this.a.length - 1;
    while (j - i > 1)
    {
      int k = (i + j) / 2;
      if (paramFloat < this.a[k])
        j = k;
      else
        i = k;
    }
    float[] arrayOfFloat1 = this.a;
    float f1 = arrayOfFloat1[j] - arrayOfFloat1[i];
    if (f1 == 0.0F)
      return this.b[i];
    float f2 = (paramFloat - arrayOfFloat1[i]) / f1;
    float[] arrayOfFloat2 = this.b;
    float f3 = arrayOfFloat2[i];
    return f3 + f2 * (arrayOfFloat2[j] - f3);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.l.a.a.g
 * JD-Core Version:    0.6.2
 */