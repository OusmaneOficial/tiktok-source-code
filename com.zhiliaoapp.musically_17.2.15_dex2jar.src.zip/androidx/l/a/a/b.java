package androidx.l.a.a;

import android.graphics.drawable.Animatable;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface b extends Animatable
{
  static
  {
    CoverageLogger.Log(24287232);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.l.a.a.b
 * JD-Core Version:    0.6.2
 */