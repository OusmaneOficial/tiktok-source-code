package androidx.constraintlayout.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class f
{
  public long A;
  public long B;
  public ArrayList<String> C;
  public long D;
  public long a;
  public long b;
  public long c;
  public long d;
  public long e;
  public long f;
  public long g;
  public long h;
  public long i;
  public long j;
  public long k;
  public long l;
  public long m;
  public long n;
  public long o;
  public long p;
  public long q;
  public long r;
  public long s;
  public long t;
  public long u;
  public long v;
  public long w;
  public long x;
  public long y;
  public long z;

  static
  {
    CoverageLogger.Log(25567232);
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("\n*** Metrics ***\nmeasures: ");
    localStringBuilder.append(this.a);
    localStringBuilder.append("\nadditionalMeasures: ");
    localStringBuilder.append(this.b);
    localStringBuilder.append("\nresolutions passes: ");
    localStringBuilder.append(this.c);
    localStringBuilder.append("\ntable increases: ");
    localStringBuilder.append(this.d);
    localStringBuilder.append("\nmaxTableSize: ");
    localStringBuilder.append(this.p);
    localStringBuilder.append("\nmaxVariables: ");
    localStringBuilder.append(this.u);
    localStringBuilder.append("\nmaxRows: ");
    localStringBuilder.append(this.v);
    localStringBuilder.append("\n\nminimize: ");
    localStringBuilder.append(this.e);
    localStringBuilder.append("\nminimizeGoal: ");
    localStringBuilder.append(this.t);
    localStringBuilder.append("\nconstraints: ");
    localStringBuilder.append(this.f);
    localStringBuilder.append("\nsimpleconstraints: ");
    localStringBuilder.append(this.g);
    localStringBuilder.append("\noptimize: ");
    localStringBuilder.append(this.h);
    localStringBuilder.append("\niterations: ");
    localStringBuilder.append(this.i);
    localStringBuilder.append("\npivots: ");
    localStringBuilder.append(this.j);
    localStringBuilder.append("\nbfs: ");
    localStringBuilder.append(this.k);
    localStringBuilder.append("\nvariables: ");
    localStringBuilder.append(this.l);
    localStringBuilder.append("\nerrors: ");
    localStringBuilder.append(this.m);
    localStringBuilder.append("\nslackvariables: ");
    localStringBuilder.append(this.n);
    localStringBuilder.append("\nextravariables: ");
    localStringBuilder.append(this.o);
    localStringBuilder.append("\nfullySolved: ");
    localStringBuilder.append(this.q);
    localStringBuilder.append("\ngraphOptimizer: ");
    localStringBuilder.append(this.r);
    localStringBuilder.append("\nresolvedWidgets: ");
    localStringBuilder.append(this.s);
    localStringBuilder.append("\noldresolvedWidgets: ");
    localStringBuilder.append(this.A);
    localStringBuilder.append("\nnonresolvedWidgets: ");
    localStringBuilder.append(this.B);
    localStringBuilder.append("\ncenterConnectionResolved: ");
    localStringBuilder.append(this.w);
    localStringBuilder.append("\nmatchConnectionResolved: ");
    localStringBuilder.append(this.x);
    localStringBuilder.append("\nchainConnectionResolved: ");
    localStringBuilder.append(this.y);
    localStringBuilder.append("\nbarrierConnectionResolved: ");
    localStringBuilder.append(this.z);
    localStringBuilder.append("\nproblematicsLayouts: ");
    localStringBuilder.append(this.C);
    localStringBuilder.append("\n");
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.f
 * JD-Core Version:    0.6.2
 */