package androidx.constraintlayout.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Arrays;

public final class a
{
  int a;
  final b b;
  final c c;
  int[] d;
  int[] e;
  float[] f;
  int g;
  private int h = 8;
  private h i;
  private int j;
  private boolean k;

  static
  {
    CoverageLogger.Log(25552896);
  }

  a(b paramb, c paramc)
  {
    int m = this.h;
    this.d = new int[m];
    this.e = new int[m];
    this.f = new float[m];
    this.g = -1;
    this.j = -1;
    this.b = paramb;
    this.c = paramc;
  }

  static boolean a(h paramh, e parame)
  {
    return paramh.k <= 1;
  }

  public final float a(h paramh)
  {
    int m = this.g;
    for (int n = 0; (m != -1) && (n < this.a); n++)
    {
      if (this.d[m] == paramh.c)
        return this.f[m];
      m = this.e[m];
    }
    return 0.0F;
  }

  public final float a(h paramh, boolean paramBoolean)
  {
    if (this.i == paramh)
      this.i = null;
    int m = this.g;
    if (m == -1)
      return 0.0F;
    int n = 0;
    int i1 = -1;
    while ((m != -1) && (n < this.a))
    {
      if (this.d[m] == paramh.c)
      {
        if (m == this.g)
        {
          this.g = this.e[m];
        }
        else
        {
          int[] arrayOfInt = this.e;
          arrayOfInt[i1] = arrayOfInt[m];
        }
        if (paramBoolean)
          paramh.b(this.b);
        paramh.k = (-1 + paramh.k);
        this.a = (-1 + this.a);
        this.d[m] = -1;
        if (this.k)
          this.j = m;
        return this.f[m];
      }
      int i2 = this.e[m];
      n++;
      i1 = m;
      m = i2;
    }
    return 0.0F;
  }

  final h a(int paramInt)
  {
    int m = this.g;
    for (int n = 0; (m != -1) && (n < this.a); n++)
    {
      if (n == paramInt)
        return this.c.c[this.d[m]];
      m = this.e[m];
    }
    return null;
  }

  final h a(boolean[] paramArrayOfBoolean, h paramh)
  {
    int m = this.g;
    int n = 0;
    Object localObject = null;
    float f1 = 0.0F;
    while ((m != -1) && (n < this.a))
    {
      if (this.f[m] < 0.0F)
      {
        h localh = this.c.c[this.d[m]];
        if (((paramArrayOfBoolean == null) || (paramArrayOfBoolean[localh.c] == 0)) && (localh != paramh) && ((localh.h == h.a.SLACK) || (localh.h == h.a.ERROR)))
        {
          float f2 = this.f[m];
          if (f2 < f1)
          {
            localObject = localh;
            f1 = f2;
          }
        }
      }
      m = this.e[m];
      n++;
    }
    return localObject;
  }

  public final void a()
  {
    int m = this.g;
    for (int n = 0; (m != -1) && (n < this.a); n++)
    {
      h localh = this.c.c[this.d[m]];
      if (localh != null)
        localh.b(this.b);
      m = this.e[m];
    }
    this.g = -1;
    this.j = -1;
    this.k = false;
    this.a = 0;
  }

  final void a(float paramFloat)
  {
    int m = this.g;
    for (int n = 0; (m != -1) && (n < this.a); n++)
    {
      float[] arrayOfFloat = this.f;
      arrayOfFloat[m] /= paramFloat;
      m = this.e[m];
    }
  }

  final void a(b paramb1, b paramb2, boolean paramBoolean)
  {
    int m = this.g;
    for (int n = 0; ; n++)
    {
      if ((m == -1) || (n >= this.a))
        return;
      if (this.d[m] == paramb2.a.c)
      {
        float f1 = this.f[m];
        a(paramb2.a, false);
        a locala = (a)paramb2.d;
        int i1 = locala.g;
        for (int i2 = 0; (i1 != -1) && (i2 < locala.a); i2++)
        {
          a(this.c.c[locala.d[i1]], f1 * locala.f[i1], false);
          i1 = locala.e[i1];
        }
        paramb1.b += f1 * paramb2.b;
        m = this.g;
        break;
      }
      m = this.e[m];
    }
  }

  final void a(b paramb, b[] paramArrayOfb)
  {
    int m = this.g;
    for (int n = 0; ; n++)
    {
      if ((m == -1) || (n >= this.a))
        return;
      h localh = this.c.c[this.d[m]];
      if (localh.d != -1)
      {
        float f1 = this.f[m];
        a(localh, true);
        b localb = paramArrayOfb[localh.d];
        if (!localb.e)
        {
          a locala = (a)localb.d;
          int i1 = locala.g;
          for (int i2 = 0; (i1 != -1) && (i2 < locala.a); i2++)
          {
            a(this.c.c[locala.d[i1]], f1 * locala.f[i1], true);
            i1 = locala.e[i1];
          }
        }
        paramb.b += f1 * localb.b;
        localb.a.b(paramb);
        m = this.g;
        break;
      }
      m = this.e[m];
    }
  }

  public final void a(h paramh, float paramFloat)
  {
    if (paramFloat == 0.0F)
    {
      a(paramh, true);
      return;
    }
    int m = this.g;
    if (m == -1)
    {
      this.g = 0;
      float[] arrayOfFloat = this.f;
      int i6 = this.g;
      arrayOfFloat[i6] = paramFloat;
      this.d[i6] = paramh.c;
      this.e[this.g] = -1;
      paramh.k = (1 + paramh.k);
      paramh.a(this.b);
      this.a = (1 + this.a);
      if (!this.k)
      {
        this.j = (1 + this.j);
        int i7 = this.j;
        int[] arrayOfInt7 = this.d;
        if (i7 >= arrayOfInt7.length)
        {
          this.k = true;
          this.j = (arrayOfInt7.length - 1);
        }
      }
      return;
    }
    int n = 0;
    int i1 = -1;
    while ((m != -1) && (n < this.a))
    {
      if (this.d[m] == paramh.c)
      {
        this.f[m] = paramFloat;
        return;
      }
      if (this.d[m] < paramh.c)
        i1 = m;
      m = this.e[m];
      n++;
    }
    int i2 = this.j;
    int i3 = i2 + 1;
    if (this.k)
    {
      int[] arrayOfInt6 = this.d;
      if (arrayOfInt6[i2] != -1)
        i2 = arrayOfInt6.length;
    }
    else
    {
      i2 = i3;
    }
    int[] arrayOfInt1 = this.d;
    if ((i2 >= arrayOfInt1.length) && (this.a < arrayOfInt1.length))
      for (int i5 = 0; ; i5++)
      {
        int[] arrayOfInt5 = this.d;
        if (i5 >= arrayOfInt5.length)
          break;
        if (arrayOfInt5[i5] == -1)
        {
          i2 = i5;
          break;
        }
      }
    int[] arrayOfInt2 = this.d;
    if (i2 >= arrayOfInt2.length)
    {
      i2 = arrayOfInt2.length;
      this.h = (2 * this.h);
      this.k = false;
      this.j = (i2 - 1);
      this.f = Arrays.copyOf(this.f, this.h);
      this.d = Arrays.copyOf(this.d, this.h);
      this.e = Arrays.copyOf(this.e, this.h);
    }
    this.d[i2] = paramh.c;
    this.f[i2] = paramFloat;
    if (i1 != -1)
    {
      int[] arrayOfInt4 = this.e;
      arrayOfInt4[i2] = arrayOfInt4[i1];
      arrayOfInt4[i1] = i2;
    }
    else
    {
      this.e[i2] = this.g;
      this.g = i2;
    }
    paramh.k = (1 + paramh.k);
    paramh.a(this.b);
    this.a = (1 + this.a);
    if (!this.k)
      this.j = (1 + this.j);
    if (this.a >= this.d.length)
      this.k = true;
    int i4 = this.j;
    int[] arrayOfInt3 = this.d;
    if (i4 >= arrayOfInt3.length)
    {
      this.k = true;
      this.j = (arrayOfInt3.length - 1);
    }
  }

  final void a(h paramh, float paramFloat, boolean paramBoolean)
  {
    if (paramFloat == 0.0F)
      return;
    int m = this.g;
    if (m == -1)
    {
      this.g = 0;
      float[] arrayOfFloat2 = this.f;
      int i6 = this.g;
      arrayOfFloat2[i6] = paramFloat;
      this.d[i6] = paramh.c;
      this.e[this.g] = -1;
      paramh.k = (1 + paramh.k);
      paramh.a(this.b);
      this.a = (1 + this.a);
      if (!this.k)
      {
        this.j = (1 + this.j);
        int i7 = this.j;
        int[] arrayOfInt8 = this.d;
        if (i7 >= arrayOfInt8.length)
        {
          this.k = true;
          this.j = (arrayOfInt8.length - 1);
        }
      }
      return;
    }
    int n = 0;
    int i1 = -1;
    while ((m != -1) && (n < this.a))
    {
      if (this.d[m] == paramh.c)
      {
        float[] arrayOfFloat1 = this.f;
        arrayOfFloat1[m] = (paramFloat + arrayOfFloat1[m]);
        if (arrayOfFloat1[m] == 0.0F)
        {
          if (m == this.g)
          {
            this.g = this.e[m];
          }
          else
          {
            int[] arrayOfInt7 = this.e;
            arrayOfInt7[i1] = arrayOfInt7[m];
          }
          if (paramBoolean)
            paramh.b(this.b);
          if (this.k)
            this.j = m;
          paramh.k -= 1;
          this.a -= 1;
        }
        return;
      }
      if (this.d[m] < paramh.c)
        i1 = m;
      m = this.e[m];
      n++;
    }
    int i2 = this.j;
    int i3 = i2 + 1;
    if (this.k)
    {
      int[] arrayOfInt6 = this.d;
      if (arrayOfInt6[i2] != -1)
        i2 = arrayOfInt6.length;
    }
    else
    {
      i2 = i3;
    }
    int[] arrayOfInt1 = this.d;
    if ((i2 >= arrayOfInt1.length) && (this.a < arrayOfInt1.length))
      for (int i5 = 0; ; i5++)
      {
        int[] arrayOfInt5 = this.d;
        if (i5 >= arrayOfInt5.length)
          break;
        if (arrayOfInt5[i5] == -1)
        {
          i2 = i5;
          break;
        }
      }
    int[] arrayOfInt2 = this.d;
    if (i2 >= arrayOfInt2.length)
    {
      i2 = arrayOfInt2.length;
      this.h = (2 * this.h);
      this.k = false;
      this.j = (i2 - 1);
      this.f = Arrays.copyOf(this.f, this.h);
      this.d = Arrays.copyOf(this.d, this.h);
      this.e = Arrays.copyOf(this.e, this.h);
    }
    this.d[i2] = paramh.c;
    this.f[i2] = paramFloat;
    if (i1 != -1)
    {
      int[] arrayOfInt4 = this.e;
      arrayOfInt4[i2] = arrayOfInt4[i1];
      arrayOfInt4[i1] = i2;
    }
    else
    {
      this.e[i2] = this.g;
      this.g = i2;
    }
    paramh.k = (1 + paramh.k);
    paramh.a(this.b);
    this.a = (1 + this.a);
    if (!this.k)
      this.j = (1 + this.j);
    int i4 = this.j;
    int[] arrayOfInt3 = this.d;
    if (i4 >= arrayOfInt3.length)
    {
      this.k = true;
      this.j = (arrayOfInt3.length - 1);
    }
  }

  final float b(int paramInt)
  {
    int m = this.g;
    for (int n = 0; (m != -1) && (n < this.a); n++)
    {
      if (n == paramInt)
        return this.f[m];
      m = this.e[m];
    }
    return 0.0F;
  }

  public final String toString()
  {
    int m = this.g;
    String str1 = "";
    for (int n = 0; (m != -1) && (n < this.a); n++)
    {
      StringBuilder localStringBuilder1 = new StringBuilder();
      localStringBuilder1.append(str1);
      localStringBuilder1.append(" -> ");
      String str2 = localStringBuilder1.toString();
      StringBuilder localStringBuilder2 = new StringBuilder();
      localStringBuilder2.append(str2);
      localStringBuilder2.append(this.f[m]);
      localStringBuilder2.append(" : ");
      String str3 = localStringBuilder2.toString();
      StringBuilder localStringBuilder3 = new StringBuilder();
      localStringBuilder3.append(str3);
      localStringBuilder3.append(this.c.c[this.d[m]]);
      str1 = localStringBuilder3.toString();
      m = this.e[m];
    }
    return str1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a
 * JD-Core Version:    0.6.2
 */