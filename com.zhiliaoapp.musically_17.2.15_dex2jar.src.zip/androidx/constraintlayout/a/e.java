package androidx.constraintlayout.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Arrays;
import java.util.HashMap;

public final class e
{
  public static f h;
  private static int i = 1000;
  public int a;
  public a b;
  public b[] c;
  public boolean d;
  int e;
  public int f;
  public final c g;
  private HashMap<String, h> j;
  private int k = 32;
  private int l;
  private boolean[] m;
  private int n;
  private h[] o;
  private int p;
  private b[] q;
  private final a r;

  static
  {
    CoverageLogger.Log(25548800);
  }

  public e()
  {
    int i1 = this.k;
    this.l = i1;
    this.m = new boolean[i1];
    this.e = 1;
    this.n = i1;
    this.o = new h[i];
    this.q = new b[i1];
    this.c = new b[i1];
    g();
    this.g = new c();
    this.b = new d(this.g);
    this.r = new b(this.g);
  }

  private final int a(a parama, boolean paramBoolean)
  {
    f localf1 = h;
    if (localf1 != null)
      localf1.h = (1L + localf1.h);
    for (int i1 = 0; i1 < this.e; i1++)
      this.m[i1] = false;
    int i2 = 0;
    int i3 = 0;
    while (i2 == 0)
    {
      f localf2 = h;
      if (localf2 != null)
        localf2.i = (1L + localf2.i);
      i3++;
      if (i3 >= 2 * this.e)
        return i3;
      if (parama.b() != null)
        this.m[parama.b().c] = true;
      h localh = parama.a(this, this.m);
      if (localh != null)
      {
        if (this.m[localh.c] != 0)
          return i3;
        this.m[localh.c] = true;
      }
      if (localh != null)
      {
        int i4 = 0;
        int i5 = -1;
        float f1 = 3.4028235E+38F;
        while (i4 < this.f)
        {
          b localb2 = this.c[i4];
          if ((localb2.a.h != h.a.UNRESTRICTED) && (!localb2.e) && (localb2.a(localh)))
          {
            float f2 = localb2.d.a(localh);
            if (f2 < 0.0F)
            {
              float f3 = -localb2.b / f2;
              if (f3 < f1)
              {
                i5 = i4;
                f1 = f3;
              }
            }
          }
          i4++;
        }
        if (i5 >= 0)
        {
          b localb1 = this.c[i5];
          localb1.a.d = -1;
          f localf3 = h;
          if (localf3 != null)
            localf3.j = (1L + localf3.j);
          localb1.b(localh);
          localb1.a.d = i5;
          localb1.a.c(localb1);
        }
      }
      else
      {
        i2 = 1;
      }
    }
    return i3;
  }

  public static f a()
  {
    return h;
  }

  private h a(h.a parama, String paramString)
  {
    h localh = (h)this.g.b.a();
    if (localh == null)
    {
      localh = new h(parama, paramString);
      localh.a(parama, paramString);
    }
    else
    {
      localh.a();
      localh.a(parama, paramString);
    }
    int i1 = this.p;
    int i2 = i;
    if (i1 >= i2)
    {
      i = i2 * 2;
      this.o = ((h[])Arrays.copyOf(this.o, i));
    }
    h[] arrayOfh = this.o;
    int i3 = this.p;
    this.p = (i3 + 1);
    arrayOfh[i3] = localh;
    return localh;
  }

  private int b(a parama)
    throws Exception
  {
    for (int i1 = 0; i1 < this.f; i1++)
      if ((this.c[i1].a.h != h.a.UNRESTRICTED) && (this.c[i1].b < 0.0F))
      {
        i2 = 1;
        break label55;
      }
    int i2 = 0;
    label55: if (i2 != 0)
    {
      int i4 = 0;
      i3 = 0;
      while (i4 == 0)
      {
        f localf1 = h;
        if (localf1 != null)
          localf1.k = (1L + localf1.k);
        i3++;
        int i5 = 0;
        int i6 = -1;
        int i7 = -1;
        float f1 = 3.4028235E+38F;
        int i8 = 0;
        while (i5 < this.f)
        {
          b localb2 = this.c[i5];
          if ((localb2.a.h != h.a.UNRESTRICTED) && (!localb2.e) && (localb2.b < 0.0F))
            for (int i9 = 1; i9 < this.e; i9++)
            {
              h localh = this.g.c[i9];
              float f2 = localb2.d.a(localh);
              if (f2 > 0.0F)
              {
                int i10 = i8;
                float f3 = f1;
                int i11 = i7;
                int i12 = i6;
                for (int i13 = 0; i13 < 7; i13++)
                {
                  float f4 = localh.g[i13] / f2;
                  if (((f4 < f3) && (i13 == i10)) || (i13 > i10))
                  {
                    i11 = i9;
                    i12 = i5;
                    f3 = f4;
                    i10 = i13;
                  }
                }
                i6 = i12;
                i7 = i11;
                f1 = f3;
                i8 = i10;
              }
            }
          i5++;
        }
        if (i6 != -1)
        {
          b localb1 = this.c[i6];
          localb1.a.d = -1;
          f localf2 = h;
          if (localf2 != null)
            localf2.j = (1L + localf2.j);
          localb1.b(this.g.c[i7]);
          localb1.a.d = i6;
          localb1.a.c(localb1);
        }
        else
        {
          i4 = 1;
        }
        if (i3 > this.e / 2)
          i4 = 1;
      }
    }
    int i3 = 0;
    return i3;
  }

  public static int b(Object paramObject)
  {
    h localh = ((androidx.constraintlayout.a.a.e)paramObject).j;
    if (localh != null)
      return (int)(0.5F + localh.f);
    return 0;
  }

  private final void b(b paramb)
  {
    if (this.f > 0)
    {
      paramb.d.a(paramb, this.c);
      if (paramb.d.a == 0)
        paramb.e = true;
    }
  }

  private final void c(b paramb)
  {
    if (this.c[this.f] != null)
      this.g.a.a(this.c[this.f]);
    this.c[this.f] = paramb;
    h localh = paramb.a;
    int i1 = this.f;
    localh.d = i1;
    this.f = (i1 + 1);
    paramb.a.c(paramb);
  }

  private void f()
  {
    this.k = (2 * this.k);
    this.c = ((b[])Arrays.copyOf(this.c, this.k));
    c localc = this.g;
    localc.c = ((h[])Arrays.copyOf(localc.c, this.k));
    int i1 = this.k;
    this.m = new boolean[i1];
    this.l = i1;
    this.n = i1;
    f localf1 = h;
    if (localf1 != null)
    {
      localf1.d = (1L + localf1.d);
      f localf2 = h;
      localf2.p = Math.max(localf2.p, this.k);
      f localf3 = h;
      localf3.D = localf3.p;
    }
  }

  private void g()
  {
    for (int i1 = 0; ; i1++)
    {
      b[] arrayOfb = this.c;
      if (i1 >= arrayOfb.length)
        break;
      b localb = arrayOfb[i1];
      if (localb != null)
        this.g.a.a(localb);
      this.c[i1] = null;
    }
  }

  public final h a(int paramInt, String paramString)
  {
    f localf = h;
    if (localf != null)
      localf.m = (1L + localf.m);
    if (1 + this.e >= this.l)
      f();
    h localh = a(h.a.ERROR, paramString);
    this.a = (1 + this.a);
    this.e = (1 + this.e);
    localh.c = this.a;
    localh.e = paramInt;
    this.g.c[this.a] = localh;
    this.b.c(localh);
    return localh;
  }

  public final h a(Object paramObject)
  {
    if (paramObject == null)
      return null;
    if (1 + this.e >= this.l)
      f();
    boolean bool = paramObject instanceof androidx.constraintlayout.a.a.e;
    h localh = null;
    if (bool)
    {
      androidx.constraintlayout.a.a.e locale = (androidx.constraintlayout.a.a.e)paramObject;
      localh = locale.j;
      if (localh == null)
      {
        locale.a(this.g);
        localh = locale.j;
      }
      if ((localh.c == -1) || (localh.c > this.a) || (this.g.c[localh.c] == null))
      {
        if (localh.c != -1)
          localh.a();
        this.a = (1 + this.a);
        this.e = (1 + this.e);
        localh.c = this.a;
        localh.h = h.a.UNRESTRICTED;
        this.g.c[this.a] = localh;
      }
    }
    return localh;
  }

  public final void a(b paramb)
  {
    if (paramb == null)
      return;
    f localf1 = h;
    if (localf1 != null)
    {
      localf1.f = (1L + localf1.f);
      if (paramb.e)
      {
        f localf4 = h;
        localf4.g = (1L + localf4.g);
      }
    }
    if ((1 + this.f >= this.n) || (1 + this.e >= this.l))
      f();
    label373: int i1;
    if (!paramb.e)
    {
      b(paramb);
      int i2;
      if ((paramb.a == null) && (paramb.b == 0.0F) && (paramb.d.a == 0))
        i2 = 1;
      else
        i2 = 0;
      if (i2 != 0)
        return;
      float f1 = paramb.b;
      int i3 = -1;
      if (f1 < 0.0F)
      {
        paramb.b = (-1.0F * paramb.b);
        a locala2 = paramb.d;
        int i11 = locala2.g;
        for (int i12 = 0; (i11 != i3) && (i12 < locala2.a); i12++)
        {
          float[] arrayOfFloat = locala2.f;
          arrayOfFloat[i11] = (-1.0F * arrayOfFloat[i11]);
          i11 = locala2.e[i11];
        }
      }
      a locala1 = paramb.d;
      int i4 = locala1.g;
      int i5 = 0;
      Object localObject1 = null;
      Object localObject2 = null;
      float f2 = 0.0F;
      int i6 = 0;
      float f3 = 0.0F;
      int i7 = 0;
      while ((i4 != i3) && (i5 < locala1.a))
      {
        float f4 = locala1.f[i4];
        h localh3 = locala1.c.c[locala1.d[i4]];
        if (f4 < 0.0F)
        {
          if (f4 <= -0.001F)
            break label373;
          locala1.f[i4] = 0.0F;
          localh3.b(locala1.b);
        }
        else
        {
          if (f4 >= 0.001F)
            break label373;
          locala1.f[i4] = 0.0F;
          localh3.b(locala1.b);
        }
        f4 = 0.0F;
        if (f4 != 0.0F)
          if (localh3.h == h.a.UNRESTRICTED)
          {
            if (localObject2 == null);
            for (boolean bool2 = a.a(localh3, this); ; bool2 = a.a(localh3, this))
            {
              i6 = bool2;
              f2 = f4;
              localObject2 = localh3;
              break label550;
              if (f2 <= f4)
                break;
            }
            if ((i6 == 0) && (a.a(localh3, this)))
            {
              f2 = f4;
              localObject2 = localh3;
              i6 = 1;
            }
          }
          else if ((localObject2 == null) && (f4 < 0.0F))
          {
            if (localObject1 == null);
            for (boolean bool1 = a.a(localh3, this); ; bool1 = a.a(localh3, this))
            {
              i7 = bool1;
              f3 = f4;
              localObject1 = localh3;
              break label550;
              if (f3 <= f4)
                break;
            }
            if ((i7 == 0) && (a.a(localh3, this)))
            {
              f3 = f4;
              localObject1 = localh3;
              i7 = 1;
            }
          }
        label550: i4 = locala1.e[i4];
        i5++;
        i3 = -1;
      }
      if (localObject2 != null)
        localObject1 = localObject2;
      int i8;
      if (localObject1 == null)
      {
        i8 = 1;
      }
      else
      {
        paramb.b(localObject1);
        i8 = 0;
      }
      if (paramb.d.a == 0)
        paramb.e = true;
      int i9;
      if (i8 != 0)
      {
        f localf2 = h;
        if (localf2 != null)
          localf2.o = (1L + localf2.o);
        if (1 + this.e >= this.l)
          f();
        h localh1 = a(h.a.SLACK, null);
        this.a = (1 + this.a);
        this.e = (1 + this.e);
        localh1.c = this.a;
        this.g.c[this.a] = localh1;
        paramb.a = localh1;
        c(paramb);
        this.r.a(paramb);
        a(this.r, true);
        if (localh1.d == -1)
        {
          if (paramb.a == localh1)
          {
            h localh2 = paramb.d.a(null, localh1);
            if (localh2 != null)
            {
              f localf3 = h;
              if (localf3 != null)
                localf3.j = (1L + localf3.j);
              paramb.b(localh2);
            }
          }
          if (!paramb.e)
            paramb.a.c(paramb);
          this.f -= 1;
        }
        i9 = 1;
      }
      else
      {
        i9 = 0;
      }
      int i10;
      if ((paramb.a != null) && ((paramb.a.h == h.a.UNRESTRICTED) || (paramb.b >= 0.0F)))
        i10 = 1;
      else
        i10 = 0;
      if (i10 == 0)
        return;
      i1 = i9;
    }
    else
    {
      i1 = 0;
    }
    if (i1 == 0)
      c(paramb);
  }

  public final void a(b paramb, int paramInt1, int paramInt2)
  {
    h localh = a(paramInt2, null);
    paramb.d.a(localh, paramInt1);
  }

  public final void a(a parama)
    throws Exception
  {
    f localf1 = h;
    if (localf1 != null)
    {
      localf1.t = (1L + localf1.t);
      f localf2 = h;
      localf2.u = Math.max(localf2.u, this.e);
      f localf3 = h;
      localf3.v = Math.max(localf3.v, this.f);
    }
    b((b)parama);
    b(parama);
    a(parama, false);
    e();
  }

  public final void a(h paramh, int paramInt)
  {
    int i1 = paramh.d;
    if (paramh.d != -1)
    {
      b localb2 = this.c[i1];
      if (localb2.e)
      {
        localb2.b = paramInt;
        return;
      }
      if (localb2.d.a == 0)
      {
        localb2.e = true;
        localb2.b = paramInt;
        return;
      }
      b localb3 = c();
      if (paramInt < 0)
      {
        localb3.b = (paramInt * -1);
        localb3.d.a(paramh, 1.0F);
      }
      else
      {
        localb3.b = paramInt;
        localb3.d.a(paramh, -1.0F);
      }
      a(localb3);
      return;
    }
    b localb1 = c();
    localb1.a = paramh;
    float f1 = paramInt;
    paramh.f = f1;
    localb1.b = f1;
    localb1.e = true;
    a(localb1);
  }

  public final void a(h paramh1, h paramh2, int paramInt1, float paramFloat, h paramh3, h paramh4, int paramInt2, int paramInt3)
  {
    b localb = c();
    if (paramh2 == paramh3)
    {
      localb.d.a(paramh1, 1.0F);
      localb.d.a(paramh4, 1.0F);
      localb.d.a(paramh2, -2.0F);
    }
    else if (paramFloat == 0.5F)
    {
      localb.d.a(paramh1, 1.0F);
      localb.d.a(paramh2, -1.0F);
      localb.d.a(paramh3, -1.0F);
      localb.d.a(paramh4, 1.0F);
      if ((paramInt1 > 0) || (paramInt2 > 0))
        localb.b = (paramInt2 + -paramInt1);
    }
    else if (paramFloat <= 0.0F)
    {
      localb.d.a(paramh1, -1.0F);
      localb.d.a(paramh2, 1.0F);
      localb.b = paramInt1;
    }
    else if (paramFloat >= 1.0F)
    {
      localb.d.a(paramh3, -1.0F);
      localb.d.a(paramh4, 1.0F);
      localb.b = paramInt2;
    }
    else
    {
      a locala = localb.d;
      float f1 = 1.0F - paramFloat;
      locala.a(paramh1, f1 * 1.0F);
      localb.d.a(paramh2, f1 * -1.0F);
      localb.d.a(paramh3, -1.0F * paramFloat);
      localb.d.a(paramh4, 1.0F * paramFloat);
      if ((paramInt1 > 0) || (paramInt2 > 0))
        localb.b = (f1 * -paramInt1 + paramFloat * paramInt2);
    }
    if (paramInt3 != 6)
      localb.a(this, paramInt3);
    a(localb);
  }

  public final void a(h paramh1, h paramh2, int paramInt1, int paramInt2)
  {
    b localb = c();
    h localh = d();
    localh.e = 0;
    localb.a(paramh1, paramh2, localh, paramInt1);
    if (paramInt2 != 6)
      a(localb, (int)(-1.0F * localb.d.a(localh)), paramInt2);
    a(localb);
  }

  public final void a(h paramh1, h paramh2, h paramh3, h paramh4, float paramFloat, int paramInt)
  {
    b localb = c();
    localb.a(paramh1, paramh2, paramh3, paramh4, paramFloat);
    a(localb);
  }

  public final void b()
  {
    for (int i1 = 0; i1 < this.g.c.length; i1++)
    {
      h localh = this.g.c[i1];
      if (localh != null)
        localh.a();
    }
    this.g.b.a(this.o, this.p);
    this.p = 0;
    Arrays.fill(this.g.c, null);
    HashMap localHashMap = this.j;
    if (localHashMap != null)
      localHashMap.clear();
    this.a = 0;
    this.b.a();
    this.e = 1;
    for (int i2 = 0; i2 < this.f; i2++)
      this.c[i2].c = false;
    g();
    this.f = 0;
  }

  public final void b(h paramh1, h paramh2, int paramInt1, int paramInt2)
  {
    b localb = c();
    h localh = d();
    localh.e = 0;
    localb.b(paramh1, paramh2, localh, paramInt1);
    if (paramInt2 != 6)
      a(localb, (int)(-1.0F * localb.d.a(localh)), paramInt2);
    a(localb);
  }

  public final b c()
  {
    b localb = (b)this.g.a.a();
    if (localb == null)
    {
      localb = new b(this.g);
    }
    else
    {
      localb.a = null;
      localb.d.a();
      localb.b = 0.0F;
      localb.e = false;
    }
    h.a = 1 + h.a;
    return localb;
  }

  public final b c(h paramh1, h paramh2, int paramInt1, int paramInt2)
  {
    b localb = c();
    int i1 = 0;
    if (paramInt1 != 0)
    {
      i1 = 0;
      if (paramInt1 < 0)
      {
        paramInt1 *= -1;
        i1 = 1;
      }
      localb.b = paramInt1;
    }
    if (i1 == 0)
    {
      localb.d.a(paramh1, -1.0F);
      localb.d.a(paramh2, 1.0F);
    }
    else
    {
      localb.d.a(paramh1, 1.0F);
      localb.d.a(paramh2, -1.0F);
    }
    if (paramInt2 != 6)
      localb.a(this, paramInt2);
    a(localb);
    return localb;
  }

  public final h d()
  {
    f localf = h;
    if (localf != null)
      localf.n = (1L + localf.n);
    if (1 + this.e >= this.l)
      f();
    h localh = a(h.a.SLACK, null);
    this.a = (1 + this.a);
    this.e = (1 + this.e);
    localh.c = this.a;
    this.g.c[this.a] = localh;
    return localh;
  }

  public void e()
  {
    for (int i1 = 0; i1 < this.f; i1++)
    {
      b localb = this.c[i1];
      localb.a.f = localb.b;
    }
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(25333760);
    }

    public abstract h a(e parame, boolean[] paramArrayOfBoolean);

    public abstract void a();

    public abstract void a(a parama);

    public abstract h b();

    public abstract void c(h paramh);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.e
 * JD-Core Version:    0.6.2
 */