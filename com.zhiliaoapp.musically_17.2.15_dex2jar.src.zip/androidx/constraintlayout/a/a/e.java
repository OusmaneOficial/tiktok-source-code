package androidx.constraintlayout.a.a;

import androidx.constraintlayout.a.c;
import androidx.constraintlayout.a.h;
import androidx.constraintlayout.a.h.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
{
  public m a = new m(this);
  public final f b;
  public final c c;
  public e d;
  public int e = 0;
  int f = -1;
  public b g = b.NONE;
  public a h = a.RELAXED;
  public int i = 0;
  public h j;

  static
  {
    CoverageLogger.Log(25323520);
  }

  public e(f paramf, c paramc)
  {
    this.b = paramf;
    this.c = paramc;
  }

  private boolean a(e parame)
  {
    if (parame == null)
      return false;
    c localc1 = parame.c;
    c localc2 = this.c;
    if (localc1 == localc2)
      return (localc2 != c.BASELINE) || ((parame.b.s()) && (this.b.s()));
    switch (1.a[this.c.ordinal()])
    {
    default:
      throw new AssertionError(this.c.name());
    case 6:
    case 7:
    case 8:
    case 9:
      return false;
    case 4:
    case 5:
      boolean bool2;
      if ((localc1 != c.TOP) && (localc1 != c.BOTTOM))
        bool2 = false;
      else
        bool2 = true;
      if ((parame.b instanceof i))
      {
        if ((!bool2) && (localc1 != c.CENTER_Y))
          return false;
        bool2 = true;
      }
      return bool2;
    case 2:
    case 3:
      boolean bool1;
      if ((localc1 != c.LEFT) && (localc1 != c.RIGHT))
        bool1 = false;
      else
        bool1 = true;
      if ((parame.b instanceof i))
      {
        if ((!bool1) && (localc1 != c.CENTER_X))
          return false;
        bool1 = true;
      }
      return bool1;
    case 1:
    }
    return (localc1 != c.BASELINE) && (localc1 != c.CENTER_X) && (localc1 != c.CENTER_Y);
  }

  public final int a()
  {
    if (this.b.ag == 8)
      return 0;
    if (this.f >= 0)
    {
      e locale = this.d;
      if ((locale != null) && (locale.b.ag == 8))
        return this.f;
    }
    return this.e;
  }

  public final void a(c paramc)
  {
    h localh = this.j;
    if (localh == null)
    {
      this.j = new h(h.a.UNRESTRICTED, null);
      return;
    }
    localh.a();
  }

  public final boolean a(e parame, int paramInt1, int paramInt2, b paramb, int paramInt3, boolean paramBoolean)
  {
    if (parame == null)
    {
      this.d = null;
      this.e = 0;
      this.f = -1;
      this.g = b.NONE;
      this.i = 2;
      return true;
    }
    if ((!paramBoolean) && (!a(parame)))
      return false;
    this.d = parame;
    if (paramInt1 > 0)
      this.e = paramInt1;
    else
      this.e = 0;
    this.f = paramInt2;
    this.g = paramb;
    this.i = paramInt3;
    return true;
  }

  public final void b()
  {
    this.d = null;
    this.e = 0;
    this.f = -1;
    this.g = b.STRONG;
    this.i = 0;
    this.h = a.RELAXED;
    this.a.b();
  }

  public final boolean c()
  {
    return this.d != null;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.b.ah);
    localStringBuilder.append(":");
    localStringBuilder.append(this.c.toString());
    return localStringBuilder.toString();
  }

  public static enum a
  {
    static
    {
      CoverageLogger.Log(25305088);
      RELAXED = new a("RELAXED", 0);
      STRICT = new a("STRICT", 1);
      a[] arrayOfa = new a[2];
      arrayOfa[0] = RELAXED;
      arrayOfa[1] = STRICT;
    }
  }

  public static enum b
  {
    static
    {
      CoverageLogger.Log(25303040);
      NONE = new b("NONE", 0);
      STRONG = new b("STRONG", 1);
      WEAK = new b("WEAK", 2);
      b[] arrayOfb = new b[3];
      arrayOfb[0] = NONE;
      arrayOfb[1] = STRONG;
      arrayOfb[2] = WEAK;
    }
  }

  public static enum c
  {
    static
    {
      CoverageLogger.Log(25298944);
      NONE = new c("NONE", 0);
      LEFT = new c("LEFT", 1);
      TOP = new c("TOP", 2);
      RIGHT = new c("RIGHT", 3);
      BOTTOM = new c("BOTTOM", 4);
      BASELINE = new c("BASELINE", 5);
      CENTER = new c("CENTER", 6);
      CENTER_X = new c("CENTER_X", 7);
      CENTER_Y = new c("CENTER_Y", 8);
      c[] arrayOfc = new c[9];
      arrayOfc[0] = NONE;
      arrayOfc[1] = LEFT;
      arrayOfc[2] = TOP;
      arrayOfc[3] = RIGHT;
      arrayOfc[4] = BOTTOM;
      arrayOfc[5] = BASELINE;
      arrayOfc[6] = CENTER;
      arrayOfc[7] = CENTER_X;
      arrayOfc[8] = CENTER_Y;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.e
 * JD-Core Version:    0.6.2
 */