package androidx.constraintlayout.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class k
{
  static boolean[] a = new boolean[3];

  static
  {
    CoverageLogger.Log(25290752);
  }

  static void a(int paramInt, f paramf)
  {
    paramf.g();
    m localm1 = paramf.w.a;
    m localm2 = paramf.x.a;
    m localm3 = paramf.y.a;
    m localm4 = paramf.z.a;
    int i;
    if ((paramInt & 0x8) == 8)
      i = 1;
    else
      i = 0;
    int j;
    if ((paramf.G[0] == f.a.MATCH_CONSTRAINT) && (a(paramf, 0)))
      j = 1;
    else
      j = 0;
    if ((localm1.g != 4) && (localm3.g != 4))
      if ((paramf.G[0] != f.a.FIXED) && ((j == 0) || (paramf.ag != 8)))
      {
        if (j != 0)
        {
          int n = paramf.k();
          localm1.g = 1;
          localm3.g = 1;
          if ((paramf.w.d == null) && (paramf.y.d == null))
          {
            if (i != 0)
              localm3.a(localm1, 1, paramf.i());
            else
              localm3.a(localm1, n);
          }
          else if ((paramf.w.d != null) && (paramf.y.d == null))
          {
            if (i != 0)
              localm3.a(localm1, 1, paramf.i());
            else
              localm3.a(localm1, n);
          }
          else if ((paramf.w.d == null) && (paramf.y.d != null))
          {
            if (i != 0)
              localm1.a(localm3, -1, paramf.i());
            else
              localm1.a(localm3, -n);
          }
          else if ((paramf.w.d != null) && (paramf.y.d != null))
          {
            if (i != 0)
            {
              paramf.i().a(localm1);
              paramf.i().a(localm3);
            }
            if (paramf.K == 0.0F)
            {
              localm1.g = 3;
              localm3.g = 3;
              localm1.b(localm3, 0.0F);
              localm3.b(localm1, 0.0F);
            }
            else
            {
              localm1.g = 2;
              localm3.g = 2;
              localm1.b(localm3, -n);
              localm3.b(localm1, n);
              paramf.c(n);
            }
          }
        }
      }
      else if ((paramf.w.d == null) && (paramf.y.d == null))
      {
        localm1.g = 1;
        localm3.g = 1;
        if (i != 0)
          localm3.a(localm1, 1, paramf.i());
        else
          localm3.a(localm1, paramf.k());
      }
      else if ((paramf.w.d != null) && (paramf.y.d == null))
      {
        localm1.g = 1;
        localm3.g = 1;
        if (i != 0)
          localm3.a(localm1, 1, paramf.i());
        else
          localm3.a(localm1, paramf.k());
      }
      else if ((paramf.w.d == null) && (paramf.y.d != null))
      {
        localm1.g = 1;
        localm3.g = 1;
        localm1.a(localm3, -paramf.k());
        if (i != 0)
          localm1.a(localm3, -1, paramf.i());
        else
          localm1.a(localm3, -paramf.k());
      }
      else if ((paramf.w.d != null) && (paramf.y.d != null))
      {
        localm1.g = 2;
        localm3.g = 2;
        if (i != 0)
        {
          paramf.i().a(localm1);
          paramf.i().a(localm3);
          localm1.b(localm3, -1, paramf.i());
          localm3.b(localm1, 1, paramf.i());
        }
        else
        {
          localm1.b(localm3, -paramf.k());
          localm3.b(localm1, paramf.k());
        }
      }
    int k;
    if ((paramf.G[1] == f.a.MATCH_CONSTRAINT) && (a(paramf, 1)))
      k = 1;
    else
      k = 0;
    if ((localm2.g != 4) && (localm4.g != 4))
      if ((paramf.G[1] != f.a.FIXED) && ((k == 0) || (paramf.ag != 8)))
      {
        if (k != 0)
        {
          int m = paramf.l();
          localm2.g = 1;
          localm4.g = 1;
          if ((paramf.x.d == null) && (paramf.z.d == null))
          {
            if (i != 0)
            {
              localm4.a(localm2, 1, paramf.j());
              return;
            }
            localm4.a(localm2, m);
            return;
          }
          if ((paramf.x.d != null) && (paramf.z.d == null))
          {
            if (i != 0)
            {
              localm4.a(localm2, 1, paramf.j());
              return;
            }
            localm4.a(localm2, m);
            return;
          }
          if ((paramf.x.d == null) && (paramf.z.d != null))
          {
            if (i != 0)
            {
              localm2.a(localm4, -1, paramf.j());
              return;
            }
            localm2.a(localm4, -m);
            return;
          }
          if ((paramf.x.d != null) && (paramf.z.d != null))
          {
            if (i != 0)
            {
              paramf.j().a(localm2);
              paramf.i().a(localm4);
            }
            if (paramf.K == 0.0F)
            {
              localm2.g = 3;
              localm4.g = 3;
              localm2.b(localm4, 0.0F);
              localm4.b(localm2, 0.0F);
              return;
            }
            localm2.g = 2;
            localm4.g = 2;
            localm2.b(localm4, -m);
            localm4.b(localm2, m);
            paramf.d(m);
            if (paramf.W > 0)
              paramf.A.a.a(1, localm2, paramf.W);
          }
        }
      }
      else if ((paramf.x.d == null) && (paramf.z.d == null))
      {
        localm2.g = 1;
        localm4.g = 1;
        if (i != 0)
          localm4.a(localm2, 1, paramf.j());
        else
          localm4.a(localm2, paramf.l());
        if (paramf.A.d != null)
        {
          paramf.A.a.g = 1;
          localm2.a(1, paramf.A.a, -paramf.W);
        }
      }
      else if ((paramf.x.d != null) && (paramf.z.d == null))
      {
        localm2.g = 1;
        localm4.g = 1;
        if (i != 0)
          localm4.a(localm2, 1, paramf.j());
        else
          localm4.a(localm2, paramf.l());
        if (paramf.W > 0)
          paramf.A.a.a(1, localm2, paramf.W);
      }
      else if ((paramf.x.d == null) && (paramf.z.d != null))
      {
        localm2.g = 1;
        localm4.g = 1;
        if (i != 0)
          localm2.a(localm4, -1, paramf.j());
        else
          localm2.a(localm4, -paramf.l());
        if (paramf.W > 0)
          paramf.A.a.a(1, localm2, paramf.W);
      }
      else if ((paramf.x.d != null) && (paramf.z.d != null))
      {
        localm2.g = 2;
        localm4.g = 2;
        if (i != 0)
        {
          localm2.b(localm4, -1, paramf.j());
          localm4.b(localm2, 1, paramf.j());
          paramf.j().a(localm2);
          paramf.i().a(localm4);
        }
        else
        {
          localm2.b(localm4, -paramf.l());
          localm4.b(localm2, paramf.l());
        }
        if (paramf.W > 0)
          paramf.A.a.a(1, localm2, paramf.W);
      }
  }

  static void a(f paramf, int paramInt1, int paramInt2)
  {
    int i = paramInt1 * 2;
    int j = i + 1;
    paramf.E[i].a.e = paramf.H.w.a;
    paramf.E[i].a.f = paramInt2;
    paramf.E[i].a.i = 1;
    paramf.E[j].a.e = paramf.E[i].a;
    paramf.E[j].a.f = paramf.b(paramInt1);
    paramf.E[j].a.i = 1;
  }

  static void a(g paramg, androidx.constraintlayout.a.e parame, f paramf)
  {
    if ((paramg.G[0] != f.a.WRAP_CONTENT) && (paramf.G[0] == f.a.MATCH_PARENT))
    {
      int k = paramf.w.e;
      int m = paramg.k() - paramf.y.e;
      paramf.w.j = parame.a(paramf.w);
      paramf.y.j = parame.a(paramf.y);
      parame.a(paramf.w.j, k);
      parame.a(paramf.y.j, m);
      paramf.c = 2;
      paramf.b(k, m);
    }
    if ((paramg.G[1] != f.a.WRAP_CONTENT) && (paramf.G[1] == f.a.MATCH_PARENT))
    {
      int i = paramf.x.e;
      int j = paramg.l() - paramf.z.e;
      paramf.x.j = parame.a(paramf.x);
      paramf.z.j = parame.a(paramf.z);
      parame.a(paramf.x.j, i);
      parame.a(paramf.z.j, j);
      if ((paramf.W > 0) || (paramf.ag == 8))
      {
        paramf.A.j = parame.a(paramf.A);
        parame.a(paramf.A.j, i + paramf.W);
      }
      paramf.d = 2;
      paramf.c(i, j);
    }
  }

  private static boolean a(f paramf, int paramInt)
  {
    if (paramf.G[paramInt] != f.a.MATCH_CONSTRAINT)
      return false;
    float f = paramf.K;
    boolean bool = true;
    if (f != 0.0F)
    {
      f.a[] arrayOfa = paramf.G;
      if (paramInt != 0)
        bool = false;
      if (arrayOfa[bool] == f.a.MATCH_CONSTRAINT);
      return false;
    }
    if (paramInt == 0)
    {
      if (paramf.g != 0)
        return false;
      if ((paramf.j != 0) || (paramf.k != 0))
        return false;
    }
    else
    {
      if (paramf.h != 0)
        return false;
      if (paramf.m != 0)
        break label110;
      if (paramf.n != 0)
        return false;
    }
    return bool;
    label110: return false;
  }

  static boolean a(g paramg, androidx.constraintlayout.a.e parame, int paramInt1, int paramInt2, d paramd)
  {
    f localf1 = paramd.a;
    f localf2 = paramd.c;
    f localf3 = paramd.b;
    f localf4 = paramd.d;
    f localf5 = paramd.e;
    float f1 = paramd.k;
    int i;
    int j;
    if (paramInt1 == 0)
    {
      if (localf5.ao == 0)
        i = 1;
      else
        i = 0;
      if (localf5.ao == 1)
        j = 1;
      else
        j = 0;
      if (localf5.ao != 2);
    }
    int k;
    while (true)
    {
      k = 1;
      break;
      do
      {
        k = 0;
        break;
        if (localf5.ap == 0)
          i = 1;
        else
          i = 0;
        if (localf5.ap == 1)
          j = 1;
        else
          j = 0;
      }
      while (localf5.ap != 2);
    }
    Object localObject1 = localf1;
    int m = 0;
    int n = 0;
    int i1 = 0;
    float f2 = 0.0F;
    float f3 = 0.0F;
    while (n == 0)
    {
      if (((f)localObject1).ag != 8)
      {
        i1++;
        int i5;
        if (paramInt1 == 0)
          i5 = ((f)localObject1).k();
        else
          i5 = ((f)localObject1).l();
        f2 += i5;
        if (localObject1 != localf3)
          f2 += localObject1.E[paramInt2].a();
        if (localObject1 != localf4)
          f2 += localObject1.E[(paramInt2 + 1)].a();
        f3 = f3 + localObject1.E[paramInt2].a() + localObject1.E[(paramInt2 + 1)].a();
      }
      if ((((f)localObject1).ag != 8) && (localObject1.G[paramInt1] == f.a.MATCH_CONSTRAINT))
      {
        m++;
        if (paramInt1 == 0)
        {
          if (((f)localObject1).g != 0)
            return false;
          if ((((f)localObject1).j != 0) || (((f)localObject1).k != 0))
            return false;
        }
        else
        {
          if (((f)localObject1).h != 0)
            return false;
          if (((f)localObject1).m != 0)
            break label389;
          if (((f)localObject1).n != 0)
            return false;
        }
        if (((f)localObject1).K != 0.0F)
          label389: return false;
      }
      e locale = localObject1.E[(paramInt2 + 1)].d;
      if (locale != null)
      {
        f localf19 = locale.b;
        if ((localf19.E[paramInt2].d != null) && (localf19.E[paramInt2].d.b == localObject1))
        {
          localf18 = localf19;
          break label461;
        }
      }
      f localf18 = null;
      label461: if (localf18 != null)
        localObject1 = localf18;
      else
        n = 1;
    }
    m localm1 = localf1.E[paramInt2].a;
    e[] arrayOfe = localf2.E;
    int i2 = paramInt2 + 1;
    m localm2 = arrayOfe[i2].a;
    if ((localm1.c != null) && (localm2.c != null))
    {
      if ((localm1.c.i == 1) && (localm2.c.i == 1))
      {
        if ((m > 0) && (m != i1))
          return false;
        float f4;
        if ((k == 0) && (i == 0) && (j == 0))
        {
          f4 = 0.0F;
        }
        else
        {
          if (localf3 != null)
            f4 = localf3.E[paramInt2].a();
          else
            f4 = 0.0F;
          if (localf4 != null)
            f4 += localf4.E[i2].a();
        }
        float f5 = localm1.c.f;
        float f6 = localm2.c.f;
        float f7;
        if (f5 < f6)
          f7 = f6 - f5;
        else
          f7 = f5 - f6;
        float f8 = f7 - f2;
        float f9 = -1.0F;
        if ((m > 0) && (m == i1))
        {
          if ((((f)localObject1).H != null) && (localObject1.H.G[paramInt1] == f.a.WRAP_CONTENT))
            return false;
          float f19 = f8 + f2 - f3;
          float f20 = f5;
          f localf14;
          for (Object localObject4 = localf1; localObject4 != null; localObject4 = localf14)
          {
            if (androidx.constraintlayout.a.e.h != null)
            {
              androidx.constraintlayout.a.f localf15 = androidx.constraintlayout.a.e.h;
              localf15.B -= 1L;
              androidx.constraintlayout.a.f localf16 = androidx.constraintlayout.a.e.h;
              localf16.s = (1L + localf16.s);
              androidx.constraintlayout.a.f localf17 = androidx.constraintlayout.a.e.h;
              localf17.y = (1L + localf17.y);
            }
            localf14 = localObject4.au[paramInt1];
            if ((localf14 != null) || (localObject4 == localf2))
            {
              float f21 = f19 / m;
              if (f1 > 0.0F)
                if (localObject4.as[paramInt1] == f9)
                  f21 = 0.0F;
                else
                  f21 = f19 * localObject4.as[paramInt1] / f1;
              if (((f)localObject4).ag == 8)
                f21 = 0.0F;
              float f22 = f20 + localObject4.E[paramInt2].a();
              localObject4.E[paramInt2].a.a(localm1.e, f22);
              m localm5 = localObject4.E[i2].a;
              m localm6 = localm1.e;
              float f23 = f22 + f21;
              localm5.a(localm6, f23);
              localObject4.E[paramInt2].a.a(parame);
              localObject4.E[i2].a.a(parame);
              f20 = f23 + localObject4.E[i2].a();
            }
          }
          return true;
        }
        if (f8 < 0.0F)
        {
          k = 1;
          i = 0;
          j = 0;
        }
        if (k != 0)
        {
          float f14 = f8 - f4;
          Object localObject3;
          if (paramInt1 == 0)
          {
            localObject3 = localf1;
            f9 = ((f)localObject3).ac;
          }
          else
          {
            localObject3 = localf1;
            if (paramInt1 == 1)
              f9 = ((f)localObject3).ad;
          }
          float f15 = f5 + f14 * f9;
          while (localObject3 != null)
          {
            if (androidx.constraintlayout.a.e.h != null)
            {
              androidx.constraintlayout.a.f localf11 = androidx.constraintlayout.a.e.h;
              localf11.B -= 1L;
              androidx.constraintlayout.a.f localf12 = androidx.constraintlayout.a.e.h;
              localf12.s = (1L + localf12.s);
              androidx.constraintlayout.a.f localf13 = androidx.constraintlayout.a.e.h;
              localf13.y = (1L + localf13.y);
            }
            f localf10 = localObject3.au[paramInt1];
            if ((localf10 != null) || (localObject3 == localf2))
            {
              int i4;
              if (paramInt1 == 0)
                i4 = ((f)localObject3).k();
              else
                i4 = ((f)localObject3).l();
              float f16 = i4;
              float f17 = f15 + localObject3.E[paramInt2].a();
              localObject3.E[paramInt2].a.a(localm1.e, f17);
              m localm3 = localObject3.E[i2].a;
              m localm4 = localm1.e;
              float f18 = f17 + f16;
              localm3.a(localm4, f18);
              localObject3.E[paramInt2].a.a(parame);
              localObject3.E[i2].a.a(parame);
              f15 = f18 + localObject3.E[i2].a();
            }
            localObject3 = localf10;
          }
        }
        Object localObject2 = localf1;
        if ((i == 0) && (j == 0));
        while (true)
        {
          return true;
          if (i != 0);
          while (j != 0)
          {
            f8 -= f4;
            break;
          }
          float f10 = f8 / (i1 + 1);
          if (j != 0)
          {
            float f13;
            if (i1 > 1)
              f13 = i1 - 1;
            else
              f13 = 2.0F;
            f10 = f8 / f13;
          }
          float f11;
          if (((f)localObject2).ag != 8)
            f11 = f5 + f10;
          else
            f11 = f5;
          if ((j != 0) && (i1 > 1))
            f11 = f5 + localf3.E[paramInt2].a();
          if ((i != 0) && (localf3 != null))
            f11 += localf3.E[paramInt2].a();
          while (localObject2 != null)
          {
            if (androidx.constraintlayout.a.e.h != null)
            {
              androidx.constraintlayout.a.f localf7 = androidx.constraintlayout.a.e.h;
              localf7.B -= 1L;
              androidx.constraintlayout.a.f localf8 = androidx.constraintlayout.a.e.h;
              localf8.s = (1L + localf8.s);
              androidx.constraintlayout.a.f localf9 = androidx.constraintlayout.a.e.h;
              localf9.y = (1L + localf9.y);
            }
            f localf6 = localObject2.au[paramInt1];
            if ((localf6 == null) && (localObject2 != localf2));
            while (true)
            {
              break;
              int i3;
              if (paramInt1 == 0)
                i3 = ((f)localObject2).k();
              else
                i3 = ((f)localObject2).l();
              float f12 = i3;
              if (localObject2 != localf3)
                f11 += localObject2.E[paramInt2].a();
              localObject2.E[paramInt2].a.a(localm1.e, f11);
              localObject2.E[i2].a.a(localm1.e, f11 + f12);
              localObject2.E[paramInt2].a.a(parame);
              localObject2.E[i2].a.a(parame);
              f11 += f12 + localObject2.E[i2].a();
              if (localf6 != null)
                if (localf6.ag != 8)
                  f11 += f10;
            }
            localObject2 = localf6;
          }
        }
      }
      return false;
    }
    return false;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.k
 * JD-Core Version:    0.6.2
 */