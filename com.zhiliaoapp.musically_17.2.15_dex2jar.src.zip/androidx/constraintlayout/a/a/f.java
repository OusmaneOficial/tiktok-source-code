package androidx.constraintlayout.a.a;

import androidx.constraintlayout.a.c;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public class f
{
  public static float ab = 0.5F;
  e A = new e(this, e.c.BASELINE);
  e B = new e(this, e.c.CENTER_X);
  e C = new e(this, e.c.CENTER_Y);
  e D = new e(this, e.c.CENTER);
  protected e[] E;
  protected ArrayList<e> F;
  protected a[] G;
  public f H;
  int I;
  int J;
  public float K;
  public int L;
  public int M;
  public int N;
  int O;
  int P;
  public int Q;
  public int R;
  public int S;
  public int T;
  protected int U;
  protected int V;
  public int W;
  public int X;
  public int Y;
  public int Z;
  public int aa;
  public float ac;
  public float ad;
  public Object ae;
  public int af;
  public int ag;
  public String ah;
  public String ai;
  boolean aj;
  boolean ak;
  boolean al;
  boolean am;
  public boolean an;
  public int ao;
  public int ap;
  boolean aq;
  boolean ar;
  public float[] as;
  protected f[] at;
  protected f[] au;
  f av;
  f aw;
  public int c = -1;
  public int d = -1;
  n e;
  n f;
  public int g;
  public int h;
  int[] i = new int[2];
  public int j;
  public int k;
  public float l = 1.0F;
  public int m;
  public int n;
  public float o = 1.0F;
  public boolean p;
  public boolean q;
  int r = -1;
  float s = 1.0F;
  public h t;
  public int[] u = { 2147483647, 2147483647 };
  public float v;
  e w = new e(this, e.c.LEFT);
  e x = new e(this, e.c.TOP);
  e y = new e(this, e.c.RIGHT);
  e z = new e(this, e.c.BOTTOM);

  static
  {
    CoverageLogger.Log(25319424);
  }

  public f()
  {
    e[] arrayOfe = new e[6];
    arrayOfe[0] = this.w;
    arrayOfe[1] = this.y;
    arrayOfe[2] = this.x;
    arrayOfe[3] = this.z;
    arrayOfe[4] = this.A;
    arrayOfe[5] = this.D;
    this.E = arrayOfe;
    this.F = new ArrayList();
    a[] arrayOfa = new a[2];
    arrayOfa[0] = a.FIXED;
    arrayOfa[1] = a.FIXED;
    this.G = arrayOfa;
    this.H = null;
    this.I = 0;
    this.J = 0;
    this.K = 0.0F;
    this.L = -1;
    this.M = 0;
    this.N = 0;
    this.O = 0;
    this.P = 0;
    this.Q = 0;
    this.R = 0;
    this.S = 0;
    this.T = 0;
    this.U = 0;
    this.V = 0;
    this.W = 0;
    float f1 = ab;
    this.ac = f1;
    this.ad = f1;
    this.af = 0;
    this.ag = 0;
    this.ah = null;
    this.ai = null;
    this.al = false;
    this.am = false;
    this.an = false;
    this.ao = 0;
    this.ap = 0;
    this.as = new float[] { -1.0F, -1.0F };
    this.at = new f[] { null, null };
    this.au = new f[] { null, null };
    this.av = null;
    this.aw = null;
    this.F.add(this.w);
    this.F.add(this.x);
    this.F.add(this.y);
    this.F.add(this.z);
    this.F.add(this.B);
    this.F.add(this.C);
    this.F.add(this.D);
    this.F.add(this.A);
  }

  private void a(androidx.constraintlayout.a.e parame, boolean paramBoolean1, androidx.constraintlayout.a.h paramh1, androidx.constraintlayout.a.h paramh2, a parama, boolean paramBoolean2, e parame1, e parame2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, boolean paramBoolean3, boolean paramBoolean4, int paramInt5, int paramInt6, int paramInt7, float paramFloat2, boolean paramBoolean5)
  {
    androidx.constraintlayout.a.h localh1 = parame.a(parame1);
    androidx.constraintlayout.a.h localh2 = parame.a(parame2);
    androidx.constraintlayout.a.h localh3 = parame.a(parame1.d);
    androidx.constraintlayout.a.h localh4 = parame.a(parame2.d);
    if ((parame.d) && (parame1.a.i == 1) && (parame2.a.i == 1))
    {
      if (androidx.constraintlayout.a.e.a() != null)
      {
        androidx.constraintlayout.a.f localf4 = androidx.constraintlayout.a.e.a();
        localf4.s = (1L + localf4.s);
      }
      parame1.a.a(parame);
      parame2.a.a(parame);
      if ((!paramBoolean4) && (paramBoolean1))
        parame.a(paramh2, localh2, 0, 6);
      return;
    }
    if (androidx.constraintlayout.a.e.a() != null)
    {
      androidx.constraintlayout.a.f localf3 = androidx.constraintlayout.a.e.a();
      localf3.B = (1L + localf3.B);
    }
    boolean bool1 = parame1.c();
    boolean bool2 = parame2.c();
    boolean bool3 = this.D.c();
    int i1;
    if (bool1)
      i1 = 1;
    else
      i1 = 0;
    if (bool2)
      i1++;
    if (bool3)
      i1++;
    int i2 = i1;
    int i3;
    if (paramBoolean3)
      i3 = 3;
    else
      i3 = paramInt5;
    int i4 = 1.b[parama.ordinal()];
    if ((i4 == 1) || (i4 == 2) || (i4 == 3) || (i4 != 4));
    while (i3 == 4)
    {
      i5 = 0;
      break;
    }
    int i5 = 1;
    int i6;
    int i7;
    if (this.ag == 8)
    {
      i6 = 0;
      i7 = 0;
    }
    else
    {
      i7 = i5;
      i6 = paramInt2;
    }
    if (paramBoolean5)
      if ((!bool1) && (!bool2) && (!bool3))
      {
        parame.a(localh1, paramInt1);
      }
      else if ((bool1) && (!bool2))
      {
        int i36 = parame1.a();
        i8 = 6;
        parame.c(localh1, localh3, i36, i8);
        break label377;
      }
    int i8 = 6;
    label377: int i17;
    int i10;
    int i12;
    androidx.constraintlayout.a.h localh5;
    androidx.constraintlayout.a.h localh6;
    int i15;
    if (i7 == 0)
    {
      if (paramBoolean2)
      {
        parame.c(localh2, localh1, 0, 3);
        if (paramInt3 > 0)
          parame.a(localh2, localh1, paramInt3, 6);
        if (paramInt4 < 2147483647)
          parame.b(localh2, localh1, paramInt4, 6);
      }
      else
      {
        parame.c(localh2, localh1, i6, i8);
      }
      i17 = paramInt6;
      i10 = paramInt7;
      i12 = i3;
      localh5 = localh4;
      localh6 = localh3;
      i15 = i2;
    }
    else
    {
      int i9;
      if (paramInt6 == -2)
      {
        i10 = paramInt7;
        i9 = i6;
      }
      else
      {
        i9 = paramInt6;
        i10 = paramInt7;
      }
      if (i10 == -2)
        i10 = i6;
      if (i9 > 0)
      {
        parame.a(localh2, localh1, i9, 6);
        i6 = Math.max(i6, i9);
      }
      if (i10 > 0)
      {
        parame.b(localh2, localh1, i10, 6);
        i6 = Math.min(i6, i10);
      }
      int i11;
      if (i3 == 1)
      {
        if (paramBoolean1)
        {
          parame.c(localh2, localh1, i6, 6);
          i12 = i3;
          i13 = i6;
          localh5 = localh4;
          localh6 = localh3;
          i11 = i7;
          i15 = i2;
          i14 = i9;
          break label872;
        }
        if (paramBoolean4)
        {
          i11 = i7;
          parame.c(localh2, localh1, i6, 4);
        }
        else
        {
          i11 = i7;
          parame.c(localh2, localh1, i6, 1);
        }
      }
      else
      {
        i11 = i7;
        if (i3 == 2)
        {
          Object localObject1;
          androidx.constraintlayout.a.h localh15;
          if ((parame1.c != e.c.TOP) && (parame1.c != e.c.BOTTOM))
          {
            androidx.constraintlayout.a.h localh17 = parame.a(this.H.a(e.c.LEFT));
            f localf2 = this.H;
            localObject1 = localh17;
            localh15 = parame.a(localf2.a(e.c.RIGHT));
          }
          else
          {
            androidx.constraintlayout.a.h localh14 = parame.a(this.H.a(e.c.TOP));
            f localf1 = this.H;
            localObject1 = localh14;
            localh15 = parame.a(localf1.a(e.c.BOTTOM));
          }
          Object localObject2 = localObject1;
          androidx.constraintlayout.a.h localh16 = localh15;
          androidx.constraintlayout.a.b localb = parame.c();
          int i35 = i3;
          i13 = i6;
          localh6 = localh3;
          i15 = i2;
          i12 = i35;
          i14 = i9;
          localh5 = localh4;
          parame.a(localb.a(localh2, localh1, localh16, localObject2, paramFloat2));
          i16 = 0;
          break label876;
        }
      }
      i12 = i3;
      int i13 = i6;
      int i14 = i9;
      localh5 = localh4;
      localh6 = localh3;
      i15 = i2;
      label872: int i16 = i11;
      label876: if ((i16 != 0) && (i15 != 2) && (!paramBoolean3))
      {
        int i34 = Math.max(i14, i13);
        if (i10 > 0)
          i34 = Math.min(i10, i34);
        parame.c(localh2, localh1, i34, 6);
        i17 = i14;
        i7 = 0;
      }
      else
      {
        i17 = i14;
        i7 = i16;
      }
    }
    if ((paramBoolean5) && (!paramBoolean4))
    {
      if ((!bool1) && (!bool2) && (!bool3))
      {
        if (paramBoolean1)
          parame.a(paramh2, localh2, 0, 5);
      }
      else if ((bool1) && (!bool2))
      {
        if (paramBoolean1)
          parame.a(paramh2, localh2, 0, 5);
      }
      else if ((!bool1) && (bool2))
      {
        int i33 = -parame2.a();
        parame.c(localh2, localh5, i33, 6);
        if (paramBoolean1)
          parame.a(localh1, paramh1, 0, 5);
      }
      else
      {
        androidx.constraintlayout.a.h localh7 = localh5;
        int i18 = 4;
        if ((bool1) && (bool2))
        {
          androidx.constraintlayout.a.h localh9;
          int i20;
          if (i7 != 0)
          {
            if ((paramBoolean1) && (paramInt3 == 0))
              parame.a(localh2, localh1, 0, 6);
            int i28;
            if (i12 == 0)
            {
              int i30;
              if ((i10 <= 0) && (i17 <= 0))
              {
                i18 = 6;
                i30 = 0;
              }
              else
              {
                i30 = 1;
              }
              int i31 = parame1.a();
              localh9 = localh6;
              parame.c(localh1, localh9, i31, i18);
              parame.c(localh2, localh7, -parame2.a(), i18);
              int i32;
              if ((i10 <= 0) && (i17 <= 0))
                i32 = 0;
              else
                i32 = 1;
              i21 = 5;
              i22 = i30;
              i20 = i32;
            }
            else
            {
              i28 = i12;
              localh9 = localh6;
              if (i28 != 1)
                break label1245;
              i20 = 1;
              i21 = 6;
              i22 = 1;
            }
            break label1343;
            label1245: if (i28 == 3)
            {
              int i29;
              if ((!paramBoolean3) && (this.r != -1) && (i10 <= 0))
                i29 = 6;
              else
                i29 = 4;
              parame.c(localh1, localh9, parame1.a(), i29);
              parame.c(localh2, localh7, -parame2.a(), i29);
              i20 = 1;
              i21 = 5;
              i22 = 1;
              break label1343;
            }
            i20 = 0;
          }
          else
          {
            localh9 = localh6;
            i20 = 1;
          }
          int i21 = 5;
          int i22 = 0;
          label1343: androidx.constraintlayout.a.h localh11;
          androidx.constraintlayout.a.h localh10;
          int i23;
          if (i20 != 0)
          {
            int i26 = parame1.a();
            int i27 = parame2.a();
            bool5 = true;
            androidx.constraintlayout.a.h localh12 = localh9;
            androidx.constraintlayout.a.h localh13 = localh9;
            localh11 = localh7;
            localh10 = localh13;
            i23 = 5;
            localh8 = localh2;
            parame.a(localh1, localh12, i26, paramFloat1, localh7, localh2, i27, i21);
            boolean bool6 = parame1.d.b instanceof b;
            boolean bool7 = parame2.d.b instanceof b;
            if ((bool6) && (!bool7))
            {
              bool5 = paramBoolean1;
              bool4 = true;
              i24 = 5;
              i23 = 6;
              break label1505;
            }
            if ((!bool6) && (bool7))
            {
              bool4 = paramBoolean1;
              i24 = 6;
              break label1505;
            }
          }
          else
          {
            localh10 = localh9;
            localh11 = localh7;
            localh8 = localh2;
            i23 = 5;
          }
          boolean bool4 = paramBoolean1;
          boolean bool5 = bool4;
          int i24 = 5;
          label1505: int i25;
          if (i22 != 0)
          {
            i24 = 6;
            i25 = 6;
          }
          else
          {
            i25 = i23;
          }
          if (((i7 == 0) && (bool5)) || (i22 != 0))
            parame.a(localh1, localh10, parame1.a(), i24);
          if (((i7 == 0) && (bool4)) || (i22 != 0))
            parame.b(localh8, localh11, -parame2.a(), i25);
          if (!paramBoolean1)
            break label1611;
          i19 = 6;
          parame.a(localh1, paramh1, 0, i19);
          break label1615;
        }
      }
      androidx.constraintlayout.a.h localh8 = localh2;
      label1611: int i19 = 6;
      label1615: if (paramBoolean1)
        parame.a(paramh2, localh8, 0, i19);
      return;
    }
    if ((i15 < 2) && (paramBoolean1))
    {
      parame.a(localh1, paramh1, 0, 6);
      parame.a(paramh2, localh2, 0, 6);
    }
  }

  private boolean h(int paramInt)
  {
    int i1 = paramInt * 2;
    if (this.E[i1].d != null)
    {
      e locale = this.E[i1].d.d;
      e[] arrayOfe = this.E;
      if (locale != arrayOfe[i1])
      {
        int i2 = i1 + 1;
        if ((arrayOfe[i2].d != null) && (this.E[i2].d.d == this.E[i2]))
          return true;
      }
    }
    return false;
  }

  public e a(e.c paramc)
  {
    switch (1.a[paramc.ordinal()])
    {
    default:
      throw new AssertionError(paramc.name());
    case 9:
      return null;
    case 8:
      return this.C;
    case 7:
      return this.B;
    case 6:
      return this.D;
    case 5:
      return this.A;
    case 4:
      return this.z;
    case 3:
      return this.y;
    case 2:
      return this.x;
    case 1:
    }
    return this.w;
  }

  public void a(int paramInt)
  {
    k.a(paramInt, this);
  }

  public void a(int paramInt1, int paramInt2)
  {
    this.U = paramInt1;
    this.V = paramInt2;
  }

  public final void a(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt3 == 0)
      b(paramInt1, paramInt2);
    else if (paramInt3 == 1)
      c(paramInt1, paramInt2);
    this.am = true;
  }

  public final void a(e.c paramc1, f paramf, e.c paramc2, int paramInt1, int paramInt2)
  {
    a(paramc1).a(paramf.a(paramc2), paramInt1, paramInt2, e.b.STRONG, 0, true);
  }

  public final void a(a parama)
  {
    this.G[0] = parama;
    if (parama == a.WRAP_CONTENT)
      c(this.Z);
  }

  public void a(c paramc)
  {
    this.w.a(paramc);
    this.x.a(paramc);
    this.y.a(paramc);
    this.z.a(paramc);
    this.A.a(paramc);
    this.D.a(paramc);
    this.B.a(paramc);
    this.C.a(paramc);
  }

  public void a(androidx.constraintlayout.a.e parame)
  {
    androidx.constraintlayout.a.h localh1 = parame.a(this.w);
    androidx.constraintlayout.a.h localh2 = parame.a(this.y);
    androidx.constraintlayout.a.h localh3 = parame.a(this.x);
    androidx.constraintlayout.a.h localh4 = parame.a(this.z);
    androidx.constraintlayout.a.h localh5 = parame.a(this.A);
    f localf1 = this.H;
    boolean bool1;
    boolean bool3;
    boolean bool2;
    boolean bool4;
    if (localf1 != null)
    {
      boolean bool14;
      if ((localf1 != null) && (localf1.G[0] == a.WRAP_CONTENT))
        bool14 = true;
      else
        bool14 = false;
      f localf7 = this.H;
      boolean bool15;
      if ((localf7 != null) && (localf7.G[1] == a.WRAP_CONTENT))
        bool15 = true;
      else
        bool15 = false;
      if (h(0))
        ((g)this.H).a(this, 0);
      while (((this.w.d != null) && (this.w.d.d == this.w)) || ((this.y.d != null) && (this.y.d.d == this.y)))
      {
        bool16 = true;
        break;
      }
      boolean bool16 = false;
      if (h(1))
        ((g)this.H).a(this, 1);
      while (((this.x.d != null) && (this.x.d.d == this.x)) || ((this.z.d != null) && (this.z.d.d == this.z)))
      {
        bool17 = true;
        break;
      }
      boolean bool17 = false;
      if ((bool14) && (this.ag != 8) && (this.w.d == null) && (this.y.d == null))
        parame.a(parame.a(this.H.y), localh2, 0, 1);
      if ((bool15) && (this.ag != 8) && (this.x.d == null) && (this.z.d == null) && (this.A == null))
        parame.a(parame.a(this.H.z), localh4, 0, 1);
      bool1 = bool14;
      bool3 = bool15;
      bool2 = bool16;
      bool4 = bool17;
    }
    else
    {
      bool1 = false;
      bool2 = false;
      bool3 = false;
      bool4 = false;
    }
    int i1 = this.I;
    int i2 = this.X;
    if (i1 < i2)
      i1 = i2;
    int i3 = this.J;
    int i4 = this.Y;
    if (i3 < i4)
      i3 = i4;
    int i5;
    if (this.G[0] != a.MATCH_CONSTRAINT)
      i5 = 1;
    else
      i5 = 0;
    int i6;
    if (this.G[1] != a.MATCH_CONSTRAINT)
      i6 = 1;
    else
      i6 = 0;
    this.r = this.L;
    float f1 = this.K;
    this.s = f1;
    int i7 = this.g;
    int i8 = this.h;
    int i9;
    int i10;
    int i12;
    int i11;
    if ((f1 > 0.0F) && (this.ag != 8))
    {
      if ((this.G[0] == a.MATCH_CONSTRAINT) && (i7 == 0))
        i7 = 3;
      if ((this.G[1] == a.MATCH_CONSTRAINT) && (i8 == 0))
        i8 = 3;
      if ((this.G[0] == a.MATCH_CONSTRAINT) && (this.G[1] == a.MATCH_CONSTRAINT) && (i7 == 3) && (i8 == 3))
      {
        if (this.r == -1)
          if ((i5 != 0) && (i6 == 0))
          {
            this.r = 0;
          }
          else if ((i5 == 0) && (i6 != 0))
          {
            this.r = 1;
            if (this.L == -1)
              this.s = (1.0F / this.s);
          }
        if ((this.r == 0) && ((!this.x.c()) || (!this.z.c())))
          this.r = 1;
        else if ((this.r == 1) && ((!this.w.c()) || (!this.y.c())))
          this.r = 0;
        if ((this.r == -1) && ((!this.x.c()) || (!this.z.c()) || (!this.w.c()) || (!this.y.c())))
          if ((this.x.c()) && (this.z.c()))
          {
            this.r = 0;
          }
          else if ((this.w.c()) && (this.y.c()))
          {
            this.s = (1.0F / this.s);
            this.r = 1;
          }
        if (this.r == -1)
          if ((bool1) && (!bool3))
          {
            this.r = 0;
          }
          else if ((!bool1) && (bool3))
          {
            this.s = (1.0F / this.s);
            this.r = 1;
          }
        if (this.r == -1)
          if ((this.j > 0) && (this.m == 0))
          {
            this.r = 0;
          }
          else if ((this.j == 0) && (this.m > 0))
          {
            this.s = (1.0F / this.s);
            this.r = 1;
          }
        if ((this.r == -1) && (bool1) && (bool3))
        {
          this.s = (1.0F / this.s);
          this.r = 1;
        }
      }
      else if ((this.G[0] == a.MATCH_CONSTRAINT) && (i7 == 3))
      {
        this.r = 0;
        i1 = (int)(this.s * this.J);
        if (this.G[1] != a.MATCH_CONSTRAINT)
        {
          i9 = i1;
          i10 = i3;
          i12 = i8;
          i11 = 4;
          break label1226;
        }
      }
      else if ((this.G[1] == a.MATCH_CONSTRAINT) && (i8 == 3))
      {
        this.r = 1;
        if (this.L == -1)
          this.s = (1.0F / this.s);
        int i28 = (int)(this.s * this.I);
        a locala3 = this.G[0];
        a locala4 = a.MATCH_CONSTRAINT;
        i9 = i1;
        i10 = i28;
        i11 = i7;
        if (locala3 == locala4)
          break label1200;
        i12 = 4;
        break label1226;
      }
      i9 = i1;
      i10 = i3;
      i11 = i7;
      label1200: i12 = i8;
      i13 = 1;
      break label1229;
    }
    else
    {
      i9 = i1;
      i10 = i3;
      i11 = i7;
      i12 = i8;
    }
    label1226: int i13 = 0;
    label1229: int[] arrayOfInt = this.i;
    arrayOfInt[0] = i11;
    arrayOfInt[1] = i12;
    if (i13 != 0)
    {
      int i27 = this.r;
      if ((i27 == 0) || (i27 == -1))
      {
        bool5 = true;
        break label1278;
      }
    }
    boolean bool5 = false;
    label1278: boolean bool6;
    if ((this.G[0] == a.WRAP_CONTENT) && ((this instanceof g)))
      bool6 = true;
    else
      bool6 = false;
    boolean bool7 = true ^ this.D.c();
    androidx.constraintlayout.a.h localh6;
    androidx.constraintlayout.a.h localh7;
    androidx.constraintlayout.a.h localh8;
    androidx.constraintlayout.a.h localh9;
    if (this.c != 2)
    {
      f localf5 = this.H;
      androidx.constraintlayout.a.h localh23;
      if (localf5 != null)
        localh23 = parame.a(localf5.y);
      else
        localh23 = null;
      f localf6 = this.H;
      androidx.constraintlayout.a.h localh24;
      if (localf6 != null)
        localh24 = parame.a(localf6.w);
      else
        localh24 = null;
      a locala2 = this.G[0];
      e locale3 = this.w;
      e locale4 = this.y;
      int i22 = this.M;
      int i23 = this.X;
      int i24 = this.u[0];
      float f7 = this.ac;
      int i25 = this.j;
      int i26 = this.k;
      float f8 = this.l;
      boolean bool12 = bool1;
      localh6 = localh5;
      androidx.constraintlayout.a.h localh25 = localh24;
      localh7 = localh4;
      androidx.constraintlayout.a.h localh26 = localh23;
      localh8 = localh3;
      boolean bool13 = bool6;
      localh9 = localh2;
      a(parame, bool12, localh25, localh26, locala2, bool13, locale3, locale4, i22, i9, i23, i24, f7, bool5, bool2, i11, i25, i26, f8, bool7);
    }
    else
    {
      localh6 = localh5;
      localh7 = localh4;
      localh8 = localh3;
      localh9 = localh2;
    }
    if (this.d == 2)
      return;
    boolean bool8;
    if ((this.G[1] == a.WRAP_CONTENT) && ((this instanceof g)))
      bool8 = true;
    else
      bool8 = false;
    if (i13 != 0)
    {
      int i21 = this.r;
      if ((i21 == 1) || (i21 == -1))
      {
        bool9 = true;
        break label1606;
      }
    }
    boolean bool9 = false;
    label1606: androidx.constraintlayout.a.e locale;
    if (this.W > 0)
    {
      if (this.A.a.i == 1)
      {
        m localm = this.A.a;
        locale = parame;
        localm.a(locale);
      }
      else
      {
        locale = parame;
        int i20 = this.W;
        androidx.constraintlayout.a.h localh22 = localh6;
        localh10 = localh8;
        locale.c(localh22, localh10, i20, 6);
        if (this.A.d == null)
          break label1726;
        locale.c(localh22, locale.a(this.A.d), 0, 6);
        bool10 = false;
        break label1730;
      }
    }
    else
      locale = parame;
    androidx.constraintlayout.a.h localh10 = localh8;
    label1726: boolean bool10 = bool7;
    label1730: f localf2 = this.H;
    androidx.constraintlayout.a.h localh11;
    if (localf2 != null)
      localh11 = locale.a(localf2.z);
    else
      localh11 = null;
    f localf3 = this.H;
    androidx.constraintlayout.a.h localh12;
    if (localf3 != null)
      localh12 = locale.a(localf3.x);
    else
      localh12 = null;
    a locala1 = this.G[1];
    e locale1 = this.x;
    e locale2 = this.z;
    int i14 = this.N;
    int i15 = this.Y;
    int i16 = this.u[1];
    float f2 = this.ad;
    int i17 = this.m;
    int i18 = this.n;
    float f3 = this.o;
    boolean bool11 = bool3;
    androidx.constraintlayout.a.h localh13 = localh10;
    a(parame, bool11, localh12, localh11, locala1, bool8, locale1, locale2, i14, i10, i15, i16, f2, bool9, bool4, i12, i17, i18, f3, bool10);
    if (i13 != 0)
      if (this.r == 1)
      {
        float f6 = this.s;
        parame.a(localh7, localh13, localh9, localh1, f6, 6);
      }
      else
      {
        float f5 = this.s;
        parame.a(localh9, localh1, localh7, localh13, f5, 6);
      }
    if (this.D.c())
    {
      f localf4 = this.D.d.b;
      float f4 = (float)Math.toRadians(90.0F + this.v);
      int i19 = this.D.a();
      androidx.constraintlayout.a.h localh14 = parame.a(a(e.c.LEFT));
      androidx.constraintlayout.a.h localh15 = parame.a(a(e.c.TOP));
      androidx.constraintlayout.a.h localh16 = parame.a(a(e.c.RIGHT));
      androidx.constraintlayout.a.h localh17 = parame.a(a(e.c.BOTTOM));
      androidx.constraintlayout.a.h localh18 = parame.a(localf4.a(e.c.LEFT));
      androidx.constraintlayout.a.h localh19 = parame.a(localf4.a(e.c.TOP));
      androidx.constraintlayout.a.h localh20 = parame.a(localf4.a(e.c.RIGHT));
      androidx.constraintlayout.a.h localh21 = parame.a(localf4.a(e.c.BOTTOM));
      androidx.constraintlayout.a.b localb1 = parame.c();
      double d1 = f4;
      double d2 = Math.sin(d1);
      double d3 = i19;
      Double.isNaN(d3);
      localb1.b(localh15, localh17, localh19, localh21, (float)(d2 * d3));
      parame.a(localb1);
      androidx.constraintlayout.a.b localb2 = parame.c();
      double d4 = Math.cos(d1);
      Double.isNaN(d3);
      localb2.b(localh14, localh16, localh18, localh20, (float)(d4 * d3));
      parame.a(localb2);
    }
  }

  // ERROR //
  public final void a(String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +259 -> 260
    //   4: aload_1
    //   5: invokevirtual 446	java/lang/String:length	()I
    //   8: ifne +6 -> 14
    //   11: goto +249 -> 260
    //   14: iconst_m1
    //   15: istore_2
    //   16: aload_1
    //   17: invokevirtual 446	java/lang/String:length	()I
    //   20: istore_3
    //   21: aload_1
    //   22: bipush 44
    //   24: invokevirtual 450	java/lang/String:indexOf	(I)I
    //   27: istore 4
    //   29: iconst_0
    //   30: istore 5
    //   32: iload 4
    //   34: ifle +62 -> 96
    //   37: iload_3
    //   38: iconst_1
    //   39: isub
    //   40: istore 13
    //   42: iconst_0
    //   43: istore 5
    //   45: iload 4
    //   47: iload 13
    //   49: if_icmpge +47 -> 96
    //   52: aload_1
    //   53: iconst_0
    //   54: iload 4
    //   56: invokevirtual 454	java/lang/String:substring	(II)Ljava/lang/String;
    //   59: astore 14
    //   61: aload 14
    //   63: ldc_w 455
    //   66: invokevirtual 459	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   69: ifeq +8 -> 77
    //   72: iconst_0
    //   73: istore_2
    //   74: goto +16 -> 90
    //   77: aload 14
    //   79: ldc_w 460
    //   82: invokevirtual 459	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   85: ifeq +5 -> 90
    //   88: iconst_1
    //   89: istore_2
    //   90: iload 4
    //   92: iconst_1
    //   93: iadd
    //   94: istore 5
    //   96: aload_1
    //   97: bipush 58
    //   99: invokevirtual 450	java/lang/String:indexOf	(I)I
    //   102: istore 6
    //   104: iload 6
    //   106: iflt +106 -> 212
    //   109: iload 6
    //   111: iload_3
    //   112: iconst_1
    //   113: isub
    //   114: if_icmpge +98 -> 212
    //   117: aload_1
    //   118: iload 5
    //   120: iload 6
    //   122: invokevirtual 454	java/lang/String:substring	(II)Ljava/lang/String;
    //   125: astore 9
    //   127: aload_1
    //   128: iload 6
    //   130: iconst_1
    //   131: iadd
    //   132: invokevirtual 463	java/lang/String:substring	(I)Ljava/lang/String;
    //   135: astore 10
    //   137: aload 9
    //   139: invokevirtual 446	java/lang/String:length	()I
    //   142: ifle +96 -> 238
    //   145: aload 10
    //   147: invokevirtual 446	java/lang/String:length	()I
    //   150: ifle +88 -> 238
    //   153: aload 9
    //   155: invokestatic 469	java/lang/Float:parseFloat	(Ljava/lang/String;)F
    //   158: fstore 11
    //   160: aload 10
    //   162: invokestatic 469	java/lang/Float:parseFloat	(Ljava/lang/String;)F
    //   165: fstore 12
    //   167: fload 11
    //   169: fconst_0
    //   170: fcmpl
    //   171: ifle +67 -> 238
    //   174: fload 12
    //   176: fconst_0
    //   177: fcmpl
    //   178: ifle +60 -> 238
    //   181: iload_2
    //   182: iconst_1
    //   183: if_icmpne +16 -> 199
    //   186: fload 12
    //   188: fload 11
    //   190: fdiv
    //   191: invokestatic 473	java/lang/Math:abs	(F)F
    //   194: fstore 8
    //   196: goto +45 -> 241
    //   199: fload 11
    //   201: fload 12
    //   203: fdiv
    //   204: invokestatic 473	java/lang/Math:abs	(F)F
    //   207: fstore 8
    //   209: goto +32 -> 241
    //   212: aload_1
    //   213: iload 5
    //   215: invokevirtual 463	java/lang/String:substring	(I)Ljava/lang/String;
    //   218: astore 7
    //   220: aload 7
    //   222: invokevirtual 446	java/lang/String:length	()I
    //   225: ifle +13 -> 238
    //   228: aload 7
    //   230: invokestatic 469	java/lang/Float:parseFloat	(Ljava/lang/String;)F
    //   233: fstore 8
    //   235: goto +6 -> 241
    //   238: fconst_0
    //   239: fstore 8
    //   241: fload 8
    //   243: fconst_0
    //   244: fcmpl
    //   245: ifle +14 -> 259
    //   248: aload_0
    //   249: fload 8
    //   251: putfield 193	androidx/constraintlayout/a/a/f:K	F
    //   254: aload_0
    //   255: iload_2
    //   256: putfield 195	androidx/constraintlayout/a/a/f:L	I
    //   259: return
    //   260: aload_0
    //   261: fconst_0
    //   262: putfield 193	androidx/constraintlayout/a/a/f:K	F
    //   265: return
    //
    // Exception table:
    //   from	to	target	type
    //   153	167	238	java/lang/NumberFormatException
    //   186	196	238	java/lang/NumberFormatException
    //   199	209	238	java/lang/NumberFormatException
    //   228	235	238	java/lang/NumberFormatException
  }

  public boolean a()
  {
    return this.ag != 8;
  }

  public final int b(int paramInt)
  {
    if (paramInt == 0)
      return k();
    if (paramInt == 1)
      return l();
    return 0;
  }

  public void b()
  {
    for (int i1 = 0; i1 < 6; i1++)
      this.E[i1].a.b();
  }

  public final void b(int paramInt1, int paramInt2)
  {
    this.M = paramInt1;
    this.I = (paramInt2 - paramInt1);
    int i1 = this.I;
    int i2 = this.X;
    if (i1 < i2)
      this.I = i2;
  }

  public final void b(a parama)
  {
    this.G[1] = parama;
    if (parama == a.WRAP_CONTENT)
      d(this.aa);
  }

  public final void b(androidx.constraintlayout.a.e parame)
  {
    parame.a(this.w);
    parame.a(this.x);
    parame.a(this.y);
    parame.a(this.z);
    if (this.W > 0)
      parame.a(this.A);
  }

  public void c()
  {
  }

  public final void c(int paramInt)
  {
    this.I = paramInt;
    int i1 = this.I;
    int i2 = this.X;
    if (i1 < i2)
      this.I = i2;
  }

  public final void c(int paramInt1, int paramInt2)
  {
    this.N = paramInt1;
    this.J = (paramInt2 - paramInt1);
    int i1 = this.J;
    int i2 = this.Y;
    if (i1 < i2)
      this.J = i2;
  }

  public void c(androidx.constraintlayout.a.e parame)
  {
    int i1 = androidx.constraintlayout.a.e.b(this.w);
    int i2 = androidx.constraintlayout.a.e.b(this.x);
    int i3 = androidx.constraintlayout.a.e.b(this.y);
    int i4 = androidx.constraintlayout.a.e.b(this.z);
    int i5 = i3 - i1;
    int i6 = i4 - i2;
    if ((i5 < 0) || (i6 < 0) || (i1 == -2147483648) || (i1 == 2147483647) || (i2 == -2147483648) || (i2 == 2147483647) || (i3 == -2147483648) || (i3 == 2147483647) || (i4 == -2147483648) || (i4 == 2147483647))
    {
      i1 = 0;
      i2 = 0;
      i3 = 0;
      i4 = 0;
    }
    int i7 = i3 - i1;
    int i8 = i4 - i2;
    this.M = i1;
    this.N = i2;
    if (this.ag == 8)
    {
      this.I = 0;
      this.J = 0;
      return;
    }
    int i9;
    if (this.G[0] == a.FIXED)
    {
      i9 = this.I;
      if (i7 < i9);
    }
    else
    {
      i9 = i7;
    }
    int i10;
    if (this.G[1] == a.FIXED)
    {
      i10 = this.J;
      if (i8 < i10);
    }
    else
    {
      i10 = i8;
    }
    this.I = i9;
    this.J = i10;
    int i11 = this.J;
    int i12 = this.Y;
    if (i11 < i12)
      this.J = i12;
    int i13 = this.I;
    int i14 = this.X;
    if (i13 < i14)
      this.I = i14;
    this.am = true;
  }

  public final void d(int paramInt)
  {
    this.J = paramInt;
    int i1 = this.J;
    int i2 = this.Y;
    if (i1 < i2)
      this.J = i2;
  }

  final void d(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
    {
      this.O = paramInt1;
      return;
    }
    if (paramInt2 == 1)
      this.P = paramInt1;
  }

  public final boolean d()
  {
    return (this.g == 0) && (this.K == 0.0F) && (this.j == 0) && (this.k == 0) && (this.G[0] == a.MATCH_CONSTRAINT);
  }

  public final void e(int paramInt)
  {
    if (paramInt < 0)
    {
      this.X = 0;
      return;
    }
    this.X = paramInt;
  }

  public final boolean e()
  {
    return (this.h == 0) && (this.K == 0.0F) && (this.m == 0) && (this.n == 0) && (this.G[1] == a.MATCH_CONSTRAINT);
  }

  public void f()
  {
    this.w.b();
    this.x.b();
    this.y.b();
    this.z.b();
    this.A.b();
    this.B.b();
    this.C.b();
    this.D.b();
    this.H = null;
    this.v = 0.0F;
    this.I = 0;
    this.J = 0;
    this.K = 0.0F;
    this.L = -1;
    this.M = 0;
    this.N = 0;
    this.Q = 0;
    this.R = 0;
    this.S = 0;
    this.T = 0;
    this.U = 0;
    this.V = 0;
    this.W = 0;
    this.X = 0;
    this.Y = 0;
    this.Z = 0;
    this.aa = 0;
    float f1 = ab;
    this.ac = f1;
    this.ad = f1;
    this.G[0] = a.FIXED;
    this.G[1] = a.FIXED;
    this.ae = null;
    this.af = 0;
    this.ag = 0;
    this.ai = null;
    this.aj = false;
    this.ak = false;
    this.ao = 0;
    this.ap = 0;
    this.aq = false;
    this.ar = false;
    float[] arrayOfFloat = this.as;
    arrayOfFloat[0] = -1.0F;
    arrayOfFloat[1] = -1.0F;
    this.c = -1;
    this.d = -1;
    int[] arrayOfInt = this.u;
    arrayOfInt[0] = 2147483647;
    arrayOfInt[1] = 2147483647;
    this.g = 0;
    this.h = 0;
    this.l = 1.0F;
    this.o = 1.0F;
    this.k = 2147483647;
    this.n = 2147483647;
    this.j = 0;
    this.m = 0;
    this.r = -1;
    this.s = 1.0F;
    n localn1 = this.e;
    if (localn1 != null)
      localn1.b();
    n localn2 = this.f;
    if (localn2 != null)
      localn2.b();
    this.t = null;
    this.al = false;
    this.am = false;
    this.an = false;
  }

  public final void f(int paramInt)
  {
    if (paramInt < 0)
    {
      this.Y = 0;
      return;
    }
    this.Y = paramInt;
  }

  public final a g(int paramInt)
  {
    if (paramInt == 0)
      return w();
    if (paramInt == 1)
      return x();
    return null;
  }

  public final void g()
  {
    for (int i1 = 0; i1 < 6; i1++)
    {
      m localm = this.E[i1].a;
      e locale = localm.a.d;
      if (locale != null)
      {
        if (locale.d == localm.a)
        {
          localm.g = 4;
          locale.a.g = 4;
        }
        int i2 = localm.a.a();
        if ((localm.a.c == e.c.RIGHT) || (localm.a.c == e.c.BOTTOM))
          i2 = -i2;
        localm.a(locale.a, i2);
      }
    }
  }

  public final boolean h()
  {
    return (this.w.a.i == 1) && (this.y.a.i == 1) && (this.x.a.i == 1) && (this.z.a.i == 1);
  }

  public final n i()
  {
    if (this.e == null)
      this.e = new n();
    return this.e;
  }

  public final n j()
  {
    if (this.f == null)
      this.f = new n();
    return this.f;
  }

  public final int k()
  {
    if (this.ag == 8)
      return 0;
    return this.I;
  }

  public final int l()
  {
    if (this.ag == 8)
      return 0;
    return this.J;
  }

  public final int m()
  {
    return this.Q + this.U;
  }

  public final int n()
  {
    return this.R + this.V;
  }

  protected final int o()
  {
    return this.M + this.U;
  }

  protected final int p()
  {
    return this.N + this.V;
  }

  public final int q()
  {
    return this.M + this.I;
  }

  public final int r()
  {
    return this.N + this.J;
  }

  public final boolean s()
  {
    return this.W > 0;
  }

  public ArrayList<e> t()
  {
    return this.F;
  }

  public String toString()
  {
    StringBuilder localStringBuilder1 = new StringBuilder();
    String str1 = this.ai;
    String str2 = "";
    String str3;
    if (str1 != null)
    {
      StringBuilder localStringBuilder2 = new StringBuilder("type: ");
      localStringBuilder2.append(this.ai);
      localStringBuilder2.append(" ");
      str3 = localStringBuilder2.toString();
    }
    else
    {
      str3 = str2;
    }
    localStringBuilder1.append(str3);
    if (this.ah != null)
    {
      StringBuilder localStringBuilder3 = new StringBuilder("id: ");
      localStringBuilder3.append(this.ah);
      localStringBuilder3.append(" ");
      str2 = localStringBuilder3.toString();
    }
    localStringBuilder1.append(str2);
    localStringBuilder1.append("(");
    localStringBuilder1.append(this.M);
    localStringBuilder1.append(", ");
    localStringBuilder1.append(this.N);
    localStringBuilder1.append(") - (");
    localStringBuilder1.append(this.I);
    localStringBuilder1.append(" x ");
    localStringBuilder1.append(this.J);
    localStringBuilder1.append(") wrap: (");
    localStringBuilder1.append(this.Z);
    localStringBuilder1.append(" x ");
    localStringBuilder1.append(this.aa);
    localStringBuilder1.append(")");
    return localStringBuilder1.toString();
  }

  public void u()
  {
    int i1 = this.M;
    int i2 = this.N;
    int i3 = i1 + this.I;
    int i4 = i2 + this.J;
    this.Q = i1;
    this.R = i2;
    this.S = (i3 - i1);
    this.T = (i4 - i2);
  }

  public final void v()
  {
    int i1 = this.F.size();
    for (int i2 = 0; i2 < i1; i2++)
      ((e)this.F.get(i2)).b();
  }

  public final a w()
  {
    return this.G[0];
  }

  public final a x()
  {
    return this.G[1];
  }

  public static enum a
  {
    static
    {
      CoverageLogger.Log(25292800);
      FIXED = new a("FIXED", 0);
      WRAP_CONTENT = new a("WRAP_CONTENT", 1);
      MATCH_CONSTRAINT = new a("MATCH_CONSTRAINT", 2);
      MATCH_PARENT = new a("MATCH_PARENT", 3);
      a[] arrayOfa = new a[4];
      arrayOfa[0] = FIXED;
      arrayOfa[1] = WRAP_CONTENT;
      arrayOfa[2] = MATCH_CONSTRAINT;
      arrayOfa[3] = MATCH_PARENT;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.f
 * JD-Core Version:    0.6.2
 */