package androidx.constraintlayout.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.HashSet;
import java.util.Iterator;

public class o
{
  HashSet<o> h = new HashSet(2);
  int i = 0;

  static
  {
    CoverageLogger.Log(25335808);
  }

  public void a()
  {
  }

  public final void a(o paramo)
  {
    this.h.add(paramo);
  }

  public void b()
  {
    this.i = 0;
    this.h.clear();
  }

  public final void d()
  {
    this.i = 0;
    Iterator localIterator = this.h.iterator();
    while (localIterator.hasNext())
      ((o)localIterator.next()).d();
  }

  public final void e()
  {
    this.i = 1;
    Iterator localIterator = this.h.iterator();
    while (localIterator.hasNext())
      ((o)localIterator.next()).a();
  }

  public final boolean f()
  {
    return this.i == 1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.o
 * JD-Core Version:    0.6.2
 */