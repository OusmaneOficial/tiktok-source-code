package androidx.constraintlayout.a.a;

import androidx.constraintlayout.a.b;
import androidx.constraintlayout.a.h;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

final class c
{
  static
  {
    CoverageLogger.Log(25591808);
  }

  static void a(g paramg, androidx.constraintlayout.a.e parame, int paramInt)
  {
    int i = 0;
    Object localObject;
    int m;
    int j;
    if (paramInt == 0)
    {
      int n = paramg.aB;
      localObject = paramg.aE;
      m = n;
      i = 0;
      j = 0;
    }
    else
    {
      j = 2;
      int k = paramg.aC;
      d[] arrayOfd = paramg.aD;
      m = k;
      localObject = arrayOfd;
    }
    while (i < m)
    {
      d locald = localObject[i];
      if (!locald.o)
        locald.a();
      locald.o = true;
      if ((!paramg.h(4)) || (!k.a(paramg, parame, paramInt, j, locald)))
        a(paramg, parame, paramInt, j, locald);
      i++;
    }
  }

  private static void a(g paramg, androidx.constraintlayout.a.e parame, int paramInt1, int paramInt2, d paramd)
  {
    f localf1 = paramd.a;
    Object localObject1 = paramd.c;
    f localf2 = paramd.b;
    f localf3 = paramd.d;
    Object localObject2 = paramd.e;
    float f1 = paramd.k;
    int i;
    if (paramg.G[paramInt1] == f.a.WRAP_CONTENT)
      i = 1;
    else
      i = 0;
    int j;
    int k;
    if (paramInt1 == 0)
    {
      if (((f)localObject2).ao == 0)
        j = 1;
      else
        j = 0;
      if (((f)localObject2).ao == 1)
        k = 1;
      else
        k = 0;
      if (((f)localObject2).ao != 2)
        break label164;
    }
    else
    {
      if (((f)localObject2).ap == 0)
        j = 1;
      else
        j = 0;
      if (((f)localObject2).ap == 1)
        k = 1;
      else
        k = 0;
      if (((f)localObject2).ap != 2)
        break label164;
    }
    int m = 1;
    break label167;
    label164: m = 0;
    label167: int n = j;
    Object localObject3 = localf1;
    int i1 = k;
    int i2 = m;
    int i3 = 0;
    while (i3 == 0)
    {
      e locale15 = localObject3.E[paramInt2];
      int i37;
      if ((i == 0) && (i2 == 0))
        i37 = 4;
      else
        i37 = 1;
      int i38 = locale15.a();
      if ((locale15.d != null) && (localObject3 != localf1))
        i38 += locale15.d.a();
      int i39 = i38;
      float f8;
      int i41;
      int i40;
      if ((i2 != 0) && (localObject3 != localf1) && (localObject3 != localf2))
      {
        f8 = f1;
        i41 = i3;
        i40 = 6;
      }
      else if ((n != 0) && (i != 0))
      {
        f8 = f1;
        i41 = i3;
        i40 = 4;
      }
      else
      {
        f8 = f1;
        i40 = i37;
        i41 = i3;
      }
      int i42;
      Object localObject16;
      if (locale15.d != null)
      {
        if (localObject3 == localf2)
        {
          h localh27 = locale15.j;
          i42 = n;
          h localh28 = locale15.d.j;
          localObject16 = localObject2;
          parame.a(localh27, localh28, i39, 5);
        }
        else
        {
          localObject16 = localObject2;
          i42 = n;
          parame.a(locale15.j, locale15.d.j, i39, 6);
        }
        parame.c(locale15.j, locale15.d.j, i39, i40);
      }
      else
      {
        localObject16 = localObject2;
        i42 = n;
      }
      if (i != 0)
      {
        if ((((f)localObject3).ag != 8) && (localObject3.G[paramInt1] == f.a.MATCH_CONSTRAINT))
          parame.a(localObject3.E[(paramInt2 + 1)].j, localObject3.E[paramInt2].j, 0, 5);
        parame.a(localObject3.E[paramInt2].j, paramg.E[paramInt2].j, 0, 6);
      }
      e locale16 = localObject3.E[(paramInt2 + 1)].d;
      Object localObject17 = null;
      if (locale16 != null)
      {
        f localf7 = locale16.b;
        e locale17 = localf7.E[paramInt2].d;
        localObject17 = null;
        if (locale17 != null)
          if (localf7.E[paramInt2].d.b != localObject3)
            localObject17 = null;
          else
            localObject17 = localf7;
      }
      if (localObject17 != null)
      {
        localObject3 = localObject17;
        i3 = i41;
        f1 = f8;
        n = i42;
        localObject2 = localObject16;
      }
      else
      {
        f1 = f8;
        n = i42;
        localObject2 = localObject16;
        i3 = 1;
      }
    }
    Object localObject4 = localObject2;
    float f2 = f1;
    int i4 = n;
    if (localf3 != null)
    {
      e[] arrayOfe8 = ((f)localObject1).E;
      int i36 = paramInt2 + 1;
      if (arrayOfe8[i36].d != null)
      {
        e locale14 = localf3.E[i36];
        parame.b(locale14.j, localObject1.E[i36].d.j, -locale14.a(), 5);
      }
    }
    if (i != 0)
    {
      e[] arrayOfe7 = paramg.E;
      int i35 = paramInt2 + 1;
      parame.a(arrayOfe7[i35].j, localObject1.E[i35].j, localObject1.E[i35].a(), 6);
    }
    Object localObject5 = paramd.h;
    if (localObject5 != null)
    {
      int i31 = ((ArrayList)localObject5).size();
      if (i31 > 1)
      {
        float f5;
        if ((paramd.l) && (!paramd.n))
          f5 = paramd.j;
        else
          f5 = f2;
        Object localObject14 = null;
        int i32 = 0;
        float f6 = 0.0F;
        while (i32 < i31)
        {
          f localf6 = (f)((ArrayList)localObject5).get(i32);
          float f7 = localf6.as[paramInt1];
          if (f7 < 0.0F)
          {
            if (paramd.n)
            {
              parame.c(localf6.E[(paramInt2 + 1)].j, localf6.E[paramInt2].j, 0, 4);
              break label973;
            }
            f7 = 1.0F;
          }
          label973: Object localObject15;
          int i33;
          if (f7 == 0.0F)
          {
            parame.c(localf6.E[(paramInt2 + 1)].j, localf6.E[paramInt2].j, 0, 6);
            localObject15 = localObject5;
            i33 = i31;
          }
          else
          {
            if (localObject14 != null)
            {
              h localh23 = localObject14.E[paramInt2].j;
              e[] arrayOfe6 = localObject14.E;
              int i34 = paramInt2 + 1;
              h localh24 = arrayOfe6[i34].j;
              h localh25 = localf6.E[paramInt2].j;
              localObject15 = localObject5;
              h localh26 = localf6.E[i34].j;
              i33 = i31;
              b localb = parame.c();
              localb.a(f6, f5, f7, localh23, localh24, localh25, localh26);
              parame.a(localb);
            }
            else
            {
              localObject15 = localObject5;
              i33 = i31;
            }
            f6 = f7;
            localObject14 = localf6;
          }
          i32++;
          i31 = i33;
          localObject5 = localObject15;
        }
      }
    }
    if ((localf2 != null) && ((localf2 == localf3) || (i2 != 0)))
    {
      e locale12 = localf1.E[paramInt2];
      e[] arrayOfe5 = ((f)localObject1).E;
      int i28 = paramInt2 + 1;
      e locale13 = arrayOfe5[i28];
      h localh19;
      if (localf1.E[paramInt2].d != null)
        localh19 = localf1.E[paramInt2].d.j;
      else
        localh19 = null;
      h localh20;
      if (localObject1.E[i28].d != null)
        localh20 = localObject1.E[i28].d.j;
      else
        localh20 = null;
      if (localf2 == localf3)
      {
        locale12 = localf2.E[paramInt2];
        locale13 = localf2.E[i28];
      }
      if ((localh19 != null) && (localh20 != null))
      {
        float f3;
        if (paramInt1 == 0)
          f3 = localObject4.ac;
        else
          f3 = localObject4.ad;
        float f4 = f3;
        int i29 = locale12.a();
        int i30 = locale13.a();
        h localh21 = locale12.j;
        h localh22 = locale13.j;
        parame.a(localh21, localh19, i29, f4, localh20, localh22, i30, 5);
      }
    }
    else
    {
      int i20;
      Object localObject12;
      Object localObject13;
      if ((i4 != 0) && (localf2 != null))
      {
        if ((paramd.j > 0) && (paramd.i == paramd.j))
          i20 = 1;
        else
          i20 = 0;
        localObject12 = localf2;
        localObject13 = localObject12;
      }
      while (localObject12 != null)
      {
        for (f localf4 = localObject12.au[paramInt1]; (localf4 != null) && (localf4.ag == 8); localf4 = localf4.au[paramInt1]);
        if ((localf4 == null) && (localObject12 != localf3));
        h localh14;
        h localh15;
        int i21;
        int i22;
        int i23;
        h localh16;
        h localh17;
        do
        {
          localf5 = localf4;
          break;
          e locale10 = localObject12.E[paramInt2];
          localh14 = locale10.j;
          if (locale10.d != null)
            localh15 = locale10.d.j;
          else
            localh15 = null;
          if (localObject13 != localObject12)
            localh15 = localObject13.E[(paramInt2 + 1)].j;
          else if ((localObject12 == localf2) && (localObject13 == localObject12))
            if (localf1.E[paramInt2].d != null)
              localh15 = localf1.E[paramInt2].d.j;
            else
              localh15 = null;
          i21 = locale10.a();
          e[] arrayOfe4 = ((f)localObject12).E;
          i22 = paramInt2 + 1;
          i23 = arrayOfe4[i22].a();
          e locale11;
          if (localf4 != null)
          {
            locale11 = localf4.E[paramInt2];
            localh16 = locale11.j;
          }
          else
          {
            locale11 = localObject1.E[i22].d;
            if (locale11 != null)
              localh16 = locale11.j;
            else
              localh16 = null;
          }
          localh17 = localObject12.E[i22].j;
          if (locale11 != null)
            i23 += locale11.a();
          if (localObject13 != null)
            i21 += localObject13.E[i22].a();
        }
        while ((localh14 == null) || (localh15 == null) || (localh16 == null) || (localh17 == null));
        if (localObject12 == localf2)
          i21 = localf2.E[paramInt2].a();
        int i24 = i21;
        int i25;
        if (localObject12 == localf3)
          i25 = localf3.E[i22].a();
        else
          i25 = i23;
        int i26;
        if (i20 != 0)
          i26 = 6;
        else
          i26 = 4;
        h localh18 = localh16;
        int i27 = i25;
        f localf5 = localf4;
        parame.a(localh14, localh15, i24, 0.5F, localh18, localh17, i27, i26);
        if (((f)localObject12).ag != 8)
          localObject13 = localObject12;
        localObject12 = localf5;
        continue;
        int i5 = 8;
        if ((i1 != 0) && (localf2 != null))
        {
          int i9;
          if ((paramd.j > 0) && (paramd.i == paramd.j))
            i9 = 1;
          else
            i9 = 0;
          Object localObject6 = localf2;
          Object localObject7 = localObject6;
          while (localObject6 != null)
          {
            for (Object localObject8 = localObject6.au[paramInt1]; (localObject8 != null) && (((f)localObject8).ag == i5); localObject8 = localObject8.au[paramInt1]);
            Object localObject9;
            int i13;
            if ((localObject6 != localf2) && (localObject6 != localf3) && (localObject8 != null))
            {
              Object localObject10;
              if (localObject8 == localf3)
                localObject10 = null;
              else
                localObject10 = localObject8;
              e locale8 = localObject6.E[paramInt2];
              h localh8 = locale8.j;
              e[] arrayOfe3 = localObject7.E;
              int i14 = paramInt2 + 1;
              h localh9 = arrayOfe3[i14].j;
              int i15 = locale8.a();
              int i16 = localObject6.E[i14].a();
              e locale9;
              h localh10;
              h localh11;
              if (localObject10 != null)
              {
                locale9 = localObject10.E[paramInt2];
                localh10 = locale9.j;
                if (locale9.d != null)
                  localh11 = locale9.d.j;
                else
                  localh11 = null;
              }
              else
              {
                locale9 = localObject6.E[i14].d;
                if (locale9 != null)
                  localh10 = locale9.j;
                else
                  localh10 = null;
                localh11 = localObject6.E[i14].j;
              }
              if (locale9 != null)
                i16 += locale9.a();
              int i17 = i16;
              if (localObject7 != null)
                i15 += localObject7.E[i14].a();
              int i18 = i15;
              int i19;
              if (i9 != 0)
                i19 = 6;
              else
                i19 = 4;
              Object localObject11;
              if ((localh8 != null) && (localh9 != null) && (localh10 != null) && (localh11 != null))
              {
                h localh12 = localh10;
                h localh13 = localh11;
                localObject11 = localObject10;
                localObject9 = localObject7;
                i13 = 8;
                parame.a(localh8, localh9, i18, 0.5F, localh12, localh13, i17, i19);
              }
              else
              {
                localObject11 = localObject10;
                localObject9 = localObject7;
                i13 = 8;
              }
              localObject8 = localObject11;
            }
            else
            {
              localObject9 = localObject7;
              i13 = 8;
            }
            if (((f)localObject6).ag == i13)
              localObject6 = localObject9;
            localObject7 = localObject6;
            i5 = 8;
            localObject6 = localObject8;
          }
          e locale4 = localf2.E[paramInt2];
          e locale5 = localf1.E[paramInt2].d;
          e[] arrayOfe2 = localf3.E;
          int i10 = paramInt2 + 1;
          e locale6 = arrayOfe2[i10];
          e locale7 = localObject1.E[i10].d;
          int i11;
          if (locale5 != null)
          {
            if (localf2 != localf3)
            {
              h localh6 = locale4.j;
              h localh7 = locale5.j;
              int i12 = locale4.a();
              i11 = 5;
              parame.c(localh6, localh7, i12, i11);
            }
            else
            {
              i11 = 5;
              if (locale7 != null)
                parame.a(locale4.j, locale5.j, locale4.a(), 0.5F, locale6.j, locale7.j, locale6.a(), 5);
            }
          }
          else
            i11 = 5;
          if ((locale7 != null) && (localf2 != localf3))
            parame.c(locale6.j, locale7.j, -locale6.a(), i11);
        }
      }
    }
    if (((i4 != 0) || (i1 != 0)) && (localf2 != null))
    {
      e locale1 = localf2.E[paramInt2];
      e[] arrayOfe1 = localf3.E;
      int i6 = paramInt2 + 1;
      e locale2 = arrayOfe1[i6];
      h localh1;
      if (locale1.d != null)
        localh1 = locale1.d.j;
      else
        localh1 = null;
      h localh2;
      if (locale2.d != null)
        localh2 = locale2.d.j;
      else
        localh2 = null;
      if (localObject1 != localf3)
      {
        e locale3 = localObject1.E[i6];
        if (locale3.d != null)
          localh2 = locale3.d.j;
        else
          localh2 = null;
      }
      h localh3 = localh2;
      if (localf2 == localf3)
      {
        locale1 = localf2.E[paramInt2];
        locale2 = localf2.E[i6];
      }
      if ((localh1 != null) && (localh3 != null))
      {
        int i7 = locale1.a();
        if (localf3 != null)
          localObject1 = localf3;
        int i8 = localObject1.E[i6].a();
        h localh4 = locale1.j;
        h localh5 = locale2.j;
        parame.a(localh4, localh1, i7, 0.5F, localh3, localh5, i8, 5);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.c
 * JD-Core Version:    0.6.2
 */