package androidx.constraintlayout.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class p
{
  int a;
  int b;
  int c;
  int d;
  ArrayList<a> e = new ArrayList();

  static
  {
    CoverageLogger.Log(25266176);
  }

  public p(f paramf)
  {
    this.a = paramf.M;
    this.b = paramf.N;
    this.c = paramf.k();
    this.d = paramf.l();
    ArrayList localArrayList = paramf.t();
    int i = localArrayList.size();
    for (int j = 0; j < i; j++)
    {
      e locale = (e)localArrayList.get(j);
      this.e.add(new a(locale));
    }
  }

  public final void a(f paramf)
  {
    paramf.M = this.a;
    paramf.N = this.b;
    paramf.c(this.c);
    paramf.d(this.d);
    int i = this.e.size();
    for (int j = 0; j < i; j++)
    {
      a locala = (a)this.e.get(j);
      paramf.a(locala.a.c).a(locala.b, locala.c, -1, locala.d, locala.e, false);
    }
  }

  static final class a
  {
    e a;
    e b;
    int c;
    e.b d;
    int e;

    static
    {
      CoverageLogger.Log(25339904);
    }

    public a(e parame)
    {
      this.a = parame;
      this.b = parame.d;
      this.c = parame.a();
      this.d = parame.g;
      this.e = parame.i;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.p
 * JD-Core Version:    0.6.2
 */