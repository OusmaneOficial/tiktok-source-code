package androidx.constraintlayout.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class d
{
  public f a;
  public f b;
  public f c;
  public f d;
  public f e;
  public f f;
  public f g;
  protected ArrayList<f> h;
  protected int i;
  protected int j;
  public float k;
  protected boolean l;
  protected boolean m;
  protected boolean n;
  boolean o;
  private int p;
  private boolean q;

  static
  {
    CoverageLogger.Log(25309184);
  }

  public d(f paramf, int paramInt, boolean paramBoolean)
  {
    this.a = paramf;
    this.p = paramInt;
    this.q = paramBoolean;
  }

  void a()
  {
    int i1 = 2 * this.p;
    Object localObject1 = this.a;
    Object localObject2 = localObject1;
    int i2 = 0;
    while (i2 == 0)
    {
      this.i = (1 + this.i);
      ((f)localObject1).au[this.p] = null;
      ((f)localObject1).at[this.p] = null;
      if (((f)localObject1).ag != 8)
      {
        if (this.b == null)
          this.b = ((f)localObject1);
        this.d = ((f)localObject1);
        if ((localObject1.G[this.p] == f.a.MATCH_CONSTRAINT) && ((localObject1.i[this.p] == 0) || (localObject1.i[this.p] == 3) || (localObject1.i[this.p] == 2)))
        {
          this.j = (1 + this.j);
          float f1 = localObject1.as[this.p];
          if (f1 > 0.0F)
            this.k += localObject1.as[this.p];
          int i3 = this.p;
          int i4;
          if ((((f)localObject1).ag != 8) && (localObject1.G[i3] == f.a.MATCH_CONSTRAINT) && ((localObject1.i[i3] == 0) || (localObject1.i[i3] == 3)))
            i4 = 1;
          else
            i4 = 0;
          if (i4 != 0)
          {
            if (f1 < 0.0F)
              this.l = true;
            else
              this.m = true;
            if (this.h == null)
              this.h = new ArrayList();
            this.h.add(localObject1);
          }
          if (this.f == null)
            this.f = ((f)localObject1);
          f localf2 = this.g;
          if (localf2 != null)
            localf2.at[this.p] = localObject1;
          this.g = ((f)localObject1);
        }
      }
      if (localObject2 != localObject1)
        localObject2.au[this.p] = localObject1;
      e locale1 = localObject1.E[(i1 + 1)].d;
      Object localObject3 = null;
      if (locale1 != null)
      {
        f localf1 = locale1.b;
        e locale2 = localf1.E[i1].d;
        localObject3 = null;
        if (locale2 != null)
          if (localf1.E[i1].d.b != localObject1)
            localObject3 = null;
          else
            localObject3 = localf1;
      }
      if (localObject3 != null)
      {
        localObject2 = localObject1;
        localObject1 = localObject3;
      }
      else
      {
        localObject2 = localObject1;
        i2 = 1;
      }
    }
    this.c = ((f)localObject1);
    if ((this.p == 0) && (this.q))
      this.e = this.c;
    else
      this.e = this.a;
    boolean bool1 = this.m;
    boolean bool2 = false;
    if (bool1)
    {
      boolean bool3 = this.l;
      bool2 = false;
      if (bool3)
        bool2 = true;
    }
    this.n = bool2;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.d
 * JD-Core Version:    0.6.2
 */