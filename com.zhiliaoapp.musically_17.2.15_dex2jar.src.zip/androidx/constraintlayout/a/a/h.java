package androidx.constraintlayout.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public final class h
{
  public List<f> a;
  int b = -1;
  int c = -1;
  public boolean d;
  public final int[] e;
  List<f> f;
  List<f> g;
  HashSet<f> h;
  HashSet<f> i;
  List<f> j;
  List<f> k;

  static
  {
    CoverageLogger.Log(25325568);
  }

  h(List<f> paramList)
  {
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = this.b;
    arrayOfInt[1] = this.c;
    this.e = arrayOfInt;
    this.f = new ArrayList();
    this.g = new ArrayList();
    this.h = new HashSet();
    this.i = new HashSet();
    this.j = new ArrayList();
    this.k = new ArrayList();
    this.a = paramList;
  }

  public h(List<f> paramList, boolean paramBoolean)
  {
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = this.b;
    arrayOfInt[1] = this.c;
    this.e = arrayOfInt;
    this.f = new ArrayList();
    this.g = new ArrayList();
    this.h = new HashSet();
    this.i = new HashSet();
    this.j = new ArrayList();
    this.k = new ArrayList();
    this.a = paramList;
    this.d = true;
  }

  private void a(f paramf)
  {
    if (paramf.al)
    {
      if (paramf.h())
        return;
      int m;
      if (paramf.y.d != null)
        m = 1;
      else
        m = 0;
      e locale1;
      if (m != 0)
        locale1 = paramf.y.d;
      else
        locale1 = paramf.w.d;
      if (locale1 != null)
      {
        if (!locale1.b.am)
          a(locale1.b);
        if (locale1.c == e.c.RIGHT)
        {
          n = locale1.b.M + locale1.b.k();
          break label132;
        }
        if (locale1.c == e.c.LEFT)
        {
          n = locale1.b.M;
          break label132;
        }
      }
      int n = 0;
      label132: int i1;
      if (m != 0)
        i1 = n - paramf.y.a();
      else
        i1 = n + (paramf.w.a() + paramf.k());
      paramf.b(i1 - paramf.k(), i1);
      if (paramf.A.d != null)
      {
        e locale4 = paramf.A.d;
        if (!locale4.b.am)
          a(locale4.b);
        int i4 = locale4.b.N + locale4.b.W - paramf.W;
        paramf.c(i4, i4 + paramf.J);
        paramf.am = true;
        return;
      }
      e locale2 = paramf.z.d;
      int i2 = 0;
      if (locale2 != null)
        i2 = 1;
      e locale3;
      if (i2 != 0)
        locale3 = paramf.z.d;
      else
        locale3 = paramf.x.d;
      if (locale3 != null)
      {
        if (!locale3.b.am)
          a(locale3.b);
        if (locale3.c == e.c.BOTTOM)
          i1 = locale3.b.N + locale3.b.l();
        else if (locale3.c == e.c.TOP)
          i1 = locale3.b.N;
      }
      int i3;
      if (i2 != 0)
        i3 = i1 - paramf.z.a();
      else
        i3 = i1 + (paramf.x.a() + paramf.l());
      paramf.c(i3 - paramf.l(), i3);
      paramf.am = true;
    }
  }

  final void a()
  {
    int m = this.k.size();
    for (int n = 0; n < m; n++)
      a((f)this.k.get(n));
  }

  final void a(f paramf, int paramInt)
  {
    if (paramInt == 0)
    {
      this.h.add(paramf);
      return;
    }
    if (paramInt == 1)
      this.i.add(paramf);
  }

  void a(ArrayList<f> paramArrayList, f paramf)
  {
    if (paramf.an)
      return;
    paramArrayList.add(paramf);
    paramf.an = true;
    if (paramf.h())
      return;
    boolean bool = paramf instanceof j;
    int m = 0;
    if (bool)
    {
      j localj = (j)paramf;
      int i1 = localj.ay;
      for (int i2 = 0; i2 < i1; i2++)
        a(paramArrayList, localj.ax[i2]);
    }
    int n = paramf.E.length;
    while (m < n)
    {
      e locale = paramf.E[m].d;
      if (locale != null)
      {
        f localf = locale.b;
        if ((locale != null) && (localf != paramf.H))
          a(paramArrayList, localf);
      }
      m++;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.h
 * JD-Core Version:    0.6.2
 */