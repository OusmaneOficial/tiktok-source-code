package androidx.constraintlayout.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public final class a
{
  static
  {
    CoverageLogger.Log(25331712);
  }

  private static int a(f paramf)
  {
    if (paramf.w() == f.a.MATCH_CONSTRAINT)
    {
      float f2;
      if (paramf.L == 0)
        f2 = paramf.l() * paramf.K;
      else
        f2 = paramf.l() / paramf.K;
      int j = (int)f2;
      paramf.c(j);
      return j;
    }
    if (paramf.x() == f.a.MATCH_CONSTRAINT)
    {
      float f1;
      if (paramf.L == 1)
        f1 = paramf.k() * paramf.K;
      else
        f1 = paramf.k() / paramf.K;
      int i = (int)f1;
      paramf.d(i);
      return i;
    }
    return -1;
  }

  private static int a(f paramf, int paramInt)
  {
    int i = paramInt * 2;
    e locale1 = paramf.E[i];
    e locale2 = paramf.E[(i + 1)];
    if ((locale1.d != null) && (locale1.d.b == paramf.H) && (locale2.d != null) && (locale2.d.b == paramf.H))
    {
      int j = paramf.H.b(paramInt);
      float f;
      if (paramInt == 0)
        f = paramf.ac;
      else
        f = paramf.ad;
      int k = paramf.b(paramInt);
      return (int)(f * (j - locale1.a() - locale2.a() - k));
    }
    return 0;
  }

  private static int a(f paramf, int paramInt1, boolean paramBoolean, int paramInt2)
  {
    boolean bool = paramf.al;
    int i = 0;
    if (!bool)
      return 0;
    int j;
    if ((paramf.A.d != null) && (paramInt1 == 1))
      j = 1;
    else
      j = 0;
    int k;
    int m;
    int i1;
    int n;
    if (paramBoolean)
    {
      k = paramf.W;
      m = paramf.l() - paramf.W;
      i1 = paramInt1 * 2;
      n = i1 + 1;
    }
    else
    {
      k = paramf.l() - paramf.W;
      m = paramf.W;
      n = paramInt1 * 2;
      i1 = n + 1;
    }
    int i2;
    int i3;
    if ((paramf.E[n].d != null) && (paramf.E[i1].d == null))
    {
      i2 = i1;
      i1 = n;
      i3 = -1;
    }
    else
    {
      i2 = n;
      i3 = 1;
    }
    int i4;
    if (j != 0)
      i4 = paramInt2 - k;
    else
      i4 = paramInt2;
    int i5 = i3 * paramf.E[i1].a() + a(paramf, paramInt1);
    int i6 = i4 + i5;
    int i7;
    if (paramInt1 == 0)
      i7 = paramf.k();
    else
      i7 = paramf.l();
    int i8 = i7 * i3;
    Iterator localIterator = paramf.E[i1].a.h.iterator();
    while (localIterator.hasNext())
      i = Math.max(i, a(((m)localIterator.next()).a.b, paramInt1, paramBoolean, i6));
    Object localObject1 = paramf.E[i2].a.h.iterator();
    int i9 = 0;
    while (((Iterator)localObject1).hasNext())
    {
      f localf3 = ((m)((Iterator)localObject1).next()).a.b;
      Object localObject4 = localObject1;
      i9 = Math.max(i9, a(localf3, paramInt1, paramBoolean, i8 + i6));
      localObject1 = localObject4;
    }
    if (j != 0)
      i -= k;
    int i12;
    int i10;
    for (int i11 = i9 + m; ; i11 = i9 + i10 * i3)
    {
      i12 = 1;
      break;
      if (paramInt1 == 0)
        i10 = paramf.k();
      else
        i10 = paramf.l();
    }
    int i13;
    int i14;
    if (paramInt1 == i12)
    {
      Object localObject2 = paramf.A.a.h.iterator();
      int i18 = 0;
      while (((Iterator)localObject2).hasNext())
      {
        o localo = (o)((Iterator)localObject2).next();
        Object localObject3 = localObject2;
        m localm = (m)localo;
        if (i3 == i12)
        {
          int i23 = a(localm.a.b, paramInt1, paramBoolean, k + i6);
          i18 = Math.max(i18, i23);
          localObject2 = localObject3;
        }
        else
        {
          int i20 = i18;
          f localf2 = localm.a.b;
          int i21 = m * i3;
          int i22 = i2;
          i18 = Math.max(i20, a(localf2, paramInt1, paramBoolean, i21 + i6));
          localObject2 = localObject3;
          i2 = i22;
        }
        i12 = 1;
      }
      i13 = i2;
      int i19 = i18;
      if ((paramf.A.a.h.size() > 0) && (j == 0))
      {
        if (i3 == 1)
          i14 = i19 + k;
        else
          i14 = i19 - m;
      }
      else
        i14 = i19;
    }
    else
    {
      i13 = i2;
      i14 = 0;
    }
    int i15 = i5 + Math.max(i, Math.max(i11, i14));
    int i16 = i6 + i8;
    if (i3 == -1)
    {
      int i17 = i6;
      i6 = i16;
      i16 = i17;
    }
    if (paramBoolean)
    {
      k.a(paramf, paramInt1, i6);
      paramf.a(i6, i16, paramInt1);
    }
    else
    {
      paramf.t.a(paramf, paramInt1);
      paramf.d(i6, paramInt1);
    }
    if ((paramf.g(paramInt1) == f.a.MATCH_CONSTRAINT) && (paramf.K != 0.0F))
      paramf.t.a(paramf, paramInt1);
    if ((paramf.E[i1].d != null) && (paramf.E[i13].d != null))
    {
      f localf1 = paramf.H;
      if ((paramf.E[i1].d.b == localf1) && (paramf.E[i13].d.b == localf1))
        paramf.t.a(paramf, paramInt1);
    }
    return i15;
  }

  public static int a(h paramh, int paramInt)
  {
    int i = paramInt * 2;
    List localList;
    if (paramInt == 0)
      localList = paramh.f;
    else if (paramInt == 1)
      localList = paramh.g;
    else
      localList = null;
    int j = localList.size();
    int k = 0;
    int m = 0;
    while (k < j)
    {
      f localf = (f)localList.get(k);
      e[] arrayOfe = localf.E;
      int n = i + 1;
      boolean bool;
      if ((arrayOfe[n].d != null) && ((localf.E[i].d == null) || (localf.E[n].d == null)))
        bool = false;
      else
        bool = true;
      m = Math.max(m, a(localf, paramInt, bool, 0));
      k++;
    }
    paramh.e[paramInt] = m;
    return m;
  }

  public static void a(g paramg)
  {
    paramg.aF.clear();
    paramg.aF.add(0, new h(paramg.aQ));
  }

  private static void a(g paramg, f paramf, h paramh)
  {
    paramh.d = false;
    paramg.aM = false;
    paramf.al = false;
  }

  public static void a(List<h> paramList, int paramInt1, int paramInt2)
  {
    int i = paramList.size();
    for (int j = 0; j < i; j++)
    {
      h localh = (h)paramList.get(j);
      HashSet localHashSet;
      if (paramInt1 == 0)
        localHashSet = localh.h;
      else if (paramInt1 == 1)
        localHashSet = localh.i;
      else
        localHashSet = null;
      Iterator localIterator = localHashSet.iterator();
      while (localIterator.hasNext())
      {
        f localf = (f)localIterator.next();
        if (localf.al)
        {
          int k = paramInt1 * 2;
          e locale1 = localf.E[k];
          e locale2 = localf.E[(k + 1)];
          int m;
          if ((locale1.d != null) && (locale2.d != null))
            m = 1;
          else
            m = 0;
          if (m != 0)
          {
            k.a(localf, paramInt1, a(localf, paramInt1) + locale1.a());
          }
          else if ((localf.K != 0.0F) && (localf.g(paramInt1) == f.a.MATCH_CONSTRAINT))
          {
            int i3 = a(localf);
            int i4 = (int)localf.E[k].a.f;
            int i5 = i4 + i3;
            locale2.a.e = locale1.a;
            locale2.a.f = i3;
            locale2.a.i = 1;
            localf.a(i4, i5, paramInt1);
          }
          else
          {
            int n;
            if (paramInt1 == 0)
              n = localf.O;
            else if (paramInt1 == 1)
              n = localf.P;
            else
              n = 0;
            int i1 = paramInt2 - n;
            int i2 = i1 - localf.b(paramInt1);
            localf.a(i2, i1, paramInt1);
            k.a(localf, paramInt1, i2);
          }
        }
      }
    }
  }

  public static boolean a(f paramf, h paramh, List<h> paramList, boolean paramBoolean)
  {
    if (paramf == null)
      return true;
    paramf.am = false;
    g localg = (g)paramf.H;
    if (paramf.t == null)
    {
      paramf.al = true;
      paramh.a.add(paramf);
      paramf.t = paramh;
      if ((paramf.w.d == null) && (paramf.y.d == null) && (paramf.x.d == null) && (paramf.z.d == null) && (paramf.A.d == null) && (paramf.D.d == null))
      {
        a(localg, paramf, paramh);
        if (paramBoolean)
          return false;
      }
      if ((paramf.x.d != null) && (paramf.z.d != null))
      {
        localg.x();
        if (paramBoolean)
        {
          a(localg, paramf, paramh);
          return false;
        }
        if ((paramf.x.d.b != paramf.H) || (paramf.z.d.b != paramf.H))
          a(localg, paramf, paramh);
      }
      if ((paramf.w.d != null) && (paramf.y.d != null))
      {
        localg.w();
        if (paramBoolean)
        {
          a(localg, paramf, paramh);
          return false;
        }
        if ((paramf.w.d.b != paramf.H) || (paramf.y.d.b != paramf.H))
          a(localg, paramf, paramh);
      }
      int i;
      if (paramf.w() == f.a.MATCH_CONSTRAINT)
        i = 1;
      else
        i = 0;
      int j;
      if (paramf.x() == f.a.MATCH_CONSTRAINT)
        j = 1;
      else
        j = 0;
      if (((i ^ j) != 0) && (paramf.K != 0.0F))
      {
        a(paramf);
      }
      else if ((paramf.w() == f.a.MATCH_CONSTRAINT) || (paramf.x() == f.a.MATCH_CONSTRAINT))
      {
        a(localg, paramf, paramh);
        if (paramBoolean)
          return false;
      }
      if (((paramf.w.d == null) && (paramf.y.d == null)) || ((paramf.w.d != null) && (paramf.w.d.b == paramf.H) && (paramf.y.d == null)) || ((paramf.y.d != null) && (paramf.y.d.b == paramf.H) && (paramf.w.d == null)) || ((paramf.w.d != null) && (paramf.w.d.b == paramf.H) && (paramf.y.d != null) && (paramf.y.d.b == paramf.H) && (paramf.D.d == null) && (!(paramf instanceof i)) && (!(paramf instanceof j))))
        paramh.f.add(paramf);
      if (((paramf.x.d == null) && (paramf.z.d == null)) || ((paramf.x.d != null) && (paramf.x.d.b == paramf.H) && (paramf.z.d == null)) || ((paramf.z.d != null) && (paramf.z.d.b == paramf.H) && (paramf.x.d == null)) || ((paramf.x.d != null) && (paramf.x.d.b == paramf.H) && (paramf.z.d != null) && (paramf.z.d.b == paramf.H) && (paramf.D.d == null) && (paramf.A.d == null) && (!(paramf instanceof i)) && (!(paramf instanceof j))))
        paramh.g.add(paramf);
      if ((paramf instanceof j))
      {
        a(localg, paramf, paramh);
        if (paramBoolean)
          return false;
        j localj = (j)paramf;
        for (int n = 0; n < localj.ay; n++)
          if (!a(localj.ax[n], paramh, paramList, paramBoolean))
            return false;
      }
      int k = paramf.E.length;
      for (int m = 0; m < k; m++)
      {
        e locale = paramf.E[m];
        if ((locale.d != null) && (locale.d.b != paramf.H))
        {
          if (locale.c == e.c.CENTER)
          {
            a(localg, paramf, paramh);
            if (paramBoolean)
              return false;
          }
          else
          {
            m localm = locale.a;
            if ((locale.d != null) && (locale.d.d != locale))
              locale.d.a.a(localm);
          }
          if (!a(locale.d.b, paramh, paramList, paramBoolean))
            return false;
        }
      }
      return true;
    }
    if (paramf.t != paramh)
    {
      paramh.a.addAll(paramf.t.a);
      paramh.f.addAll(paramf.t.f);
      paramh.g.addAll(paramf.t.g);
      if (!paramf.t.d)
        paramh.d = false;
      paramList.remove(paramf.t);
      Iterator localIterator = paramf.t.a.iterator();
      while (localIterator.hasNext())
        ((f)localIterator.next()).t = paramh;
    }
    return true;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.a.a
 * JD-Core Version:    0.6.2
 */