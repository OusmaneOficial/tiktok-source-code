package androidx.constraintlayout.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Arrays;

public final class h
{
  static int a = 1;
  private static int l;
  private static int m = 1;
  private static int n = 1;
  private static int o = 1;
  public String b;
  public int c = -1;
  int d = -1;
  public int e;
  public float f;
  float[] g = new float[7];
  a h;
  b[] i = new b[8];
  int j;
  public int k;

  static
  {
    CoverageLogger.Log(25587712);
    l = 1;
  }

  public h(a parama, String paramString)
  {
    this.h = parama;
  }

  public final void a()
  {
    this.b = null;
    this.h = a.UNKNOWN;
    this.e = 0;
    this.c = -1;
    this.d = -1;
    this.f = 0.0F;
    this.j = 0;
    this.k = 0;
  }

  public final void a(b paramb)
  {
    int i2;
    for (int i1 = 0; ; i1++)
    {
      i2 = this.j;
      if (i1 >= i2)
        break;
      if (this.i[i1] == paramb)
        return;
    }
    b[] arrayOfb1 = this.i;
    if (i2 >= arrayOfb1.length)
      this.i = ((b[])Arrays.copyOf(arrayOfb1, 2 * arrayOfb1.length));
    b[] arrayOfb2 = this.i;
    int i3 = this.j;
    arrayOfb2[i3] = paramb;
    this.j = (i3 + 1);
  }

  public final void a(a parama, String paramString)
  {
    this.h = parama;
  }

  public final void b(b paramb)
  {
    int i1 = this.j;
    for (int i2 = 0; i2 < i1; i2++)
    {
      b localb = this.i[i2];
      int i3 = 0;
      if (localb == paramb)
      {
        while (i3 < -1 + (i1 - i2))
        {
          b[] arrayOfb = this.i;
          int i4 = i2 + i3;
          arrayOfb[i4] = arrayOfb[(i4 + 1)];
          i3++;
        }
        this.j = (-1 + this.j);
        return;
      }
    }
  }

  public final void c(b paramb)
  {
    int i1 = this.j;
    for (int i2 = 0; i2 < i1; i2++)
      this.i[i2].d.a(this.i[i2], paramb, false);
    this.j = 0;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("");
    localStringBuilder.append(this.b);
    return localStringBuilder.toString();
  }

  public static enum a
  {
    static
    {
      CoverageLogger.Log(25597952);
      UNRESTRICTED = new a("UNRESTRICTED", 0);
      CONSTANT = new a("CONSTANT", 1);
      SLACK = new a("SLACK", 2);
      ERROR = new a("ERROR", 3);
      UNKNOWN = new a("UNKNOWN", 4);
      a[] arrayOfa = new a[5];
      arrayOfa[0] = UNRESTRICTED;
      arrayOfa[1] = CONSTANT;
      arrayOfa[2] = SLACK;
      arrayOfa[3] = ERROR;
      arrayOfa[4] = UNKNOWN;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.h
 * JD-Core Version:    0.6.2
 */