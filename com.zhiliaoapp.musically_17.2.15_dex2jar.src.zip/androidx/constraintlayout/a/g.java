package androidx.constraintlayout.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class g
{
  static
  {
    CoverageLogger.Log(25317376);
  }

  static abstract interface a<T>
  {
    static
    {
      CoverageLogger.Log(25573376);
    }

    public abstract T a();

    public abstract void a(T[] paramArrayOfT, int paramInt);

    public abstract boolean a(T paramT);
  }

  static final class b<T>
    implements g.a<T>
  {
    private final Object[] a = new Object[256];
    private int b;

    static
    {
      CoverageLogger.Log(25583616);
    }

    b(int paramInt)
    {
    }

    public final T a()
    {
      int i = this.b;
      if (i > 0)
      {
        int j = i - 1;
        Object[] arrayOfObject = this.a;
        Object localObject = arrayOfObject[j];
        arrayOfObject[j] = null;
        this.b = (i - 1);
        return localObject;
      }
      return null;
    }

    public final void a(T[] paramArrayOfT, int paramInt)
    {
      if (paramInt > paramArrayOfT.length)
        paramInt = paramArrayOfT.length;
      for (int i = 0; i < paramInt; i++)
      {
        T ? = paramArrayOfT[i];
        int j = this.b;
        Object[] arrayOfObject = this.a;
        if (j < arrayOfObject.length)
        {
          arrayOfObject[j] = ?;
          this.b = (j + 1);
        }
      }
    }

    public final boolean a(T paramT)
    {
      int i = this.b;
      Object[] arrayOfObject = this.a;
      if (i < arrayOfObject.length)
      {
        arrayOfObject[i] = paramT;
        this.b = (i + 1);
        return true;
      }
      return false;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.a.g
 * JD-Core Version:    0.6.2
 */