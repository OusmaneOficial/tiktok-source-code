package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c extends View
{
  int a;
  View b;
  int c;

  static
  {
    CoverageLogger.Log(1976320);
  }

  public final View getContent()
  {
    return this.b;
  }

  public final int getEmptyVisibility()
  {
    return this.c;
  }

  public final void onDraw(Canvas paramCanvas)
  {
    if (isInEditMode())
    {
      paramCanvas.drawRGB(223, 223, 223);
      Paint localPaint = new Paint();
      localPaint.setARGB(255, 210, 210, 210);
      localPaint.setTextAlign(Paint.Align.CENTER);
      localPaint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect localRect = new Rect();
      paramCanvas.getClipBounds(localRect);
      localPaint.setTextSize(localRect.height());
      int i = localRect.height();
      int j = localRect.width();
      localPaint.setTextAlign(Paint.Align.LEFT);
      localPaint.getTextBounds("?", 0, 1, localRect);
      paramCanvas.drawText("?", j / 2.0F - localRect.width() / 2.0F - localRect.left, i / 2.0F + localRect.height() / 2.0F - localRect.bottom, localPaint);
    }
  }

  public final void setContentId(int paramInt)
  {
    if (this.a == paramInt)
      return;
    View localView1 = this.b;
    if (localView1 != null)
    {
      localView1.setVisibility(0);
      ((ConstraintLayout.LayoutParams)this.b.getLayoutParams()).aa = false;
      this.b = null;
    }
    this.a = paramInt;
    if (paramInt != -1)
    {
      View localView2 = ((View)getParent()).findViewById(paramInt);
      if (localView2 != null)
        localView2.setVisibility(8);
    }
  }

  public final void setEmptyVisibility(int paramInt)
  {
    this.c = paramInt;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.widget.c
 * JD-Core Version:    0.6.2
 */