package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.HashMap;

public final class Constraints extends ViewGroup
{
  b a;

  static
  {
    CoverageLogger.Log(2129920);
  }

  protected final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new ConstraintLayout.LayoutParams(paramLayoutParams);
  }

  public final b getConstraintSet()
  {
    if (this.a == null)
      this.a = new b();
    b localb = this.a;
    int i = getChildCount();
    localb.b.clear();
    int j = 0;
    while (j < i)
    {
      View localView = getChildAt(j);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      int k = localView.getId();
      if (k != -1)
      {
        if (!localb.b.containsKey(Integer.valueOf(k)))
          localb.b.put(Integer.valueOf(k), new b.a(null));
        b.a locala = (b.a)localb.b.get(Integer.valueOf(k));
        if ((localView instanceof ConstraintHelper))
        {
          ConstraintHelper localConstraintHelper = (ConstraintHelper)localView;
          locala.a(k, localLayoutParams);
          if ((localConstraintHelper instanceof a))
          {
            locala.at = 1;
            a locala1 = (a)localConstraintHelper;
            locala.as = locala1.getType();
            locala.au = locala1.getReferencedIds();
          }
        }
        locala.a(k, localLayoutParams);
        j++;
      }
      else
      {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      }
    }
    return this.a;
  }

  protected final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
  }

  public static class LayoutParams extends ConstraintLayout.LayoutParams
  {
    public float an = 1.0F;
    public boolean ao;
    public float ap;
    public float aq;
    public float ar;
    public float as;
    public float at = 1.0F;
    public float au = 1.0F;
    public float av;
    public float aw;
    public float ax;
    public float ay;
    public float az;

    static
    {
      CoverageLogger.Log(1982464);
    }

    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(-2);
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843039, 16843040, 16843071, 16843072, 16843551, 16843552, 16843553, 16843554, 16843555, 16843556, 16843557, 16843558, 16843559, 16843560, 16843701, 16843702, 16843770, 16843840, 2130968702, 2130968703, 2130968860, 2130968956, 2130969289, 2130969290, 2130969291, 2130969292, 2130969293, 2130969294, 2130969295, 2130969296, 2130969297, 2130969298, 2130969299, 2130969300, 2130969301, 2130969302, 2130969303, 2130969304, 2130969305, 2130969306, 2130969307, 2130969308, 2130969309, 2130969310, 2130969311, 2130969312, 2130969313, 2130969314, 2130969315, 2130969316, 2130969317, 2130969318, 2130969319, 2130969320, 2130969321, 2130969322, 2130969323, 2130969324, 2130969325, 2130969326, 2130969327, 2130969328, 2130969329, 2130969336, 2130969337, 2130969338, 2130969339, 2130969340, 2130969341, 2130969342, 2130969343 });
      int i = localTypedArray.getIndexCount();
      for (int j = 0; j < i; j++)
      {
        int k = localTypedArray.getIndex(j);
        if (k == 13)
        {
          this.an = localTypedArray.getFloat(k, this.an);
        }
        else if (k == 26)
        {
          this.ap = localTypedArray.getFloat(k, this.ap);
          this.ao = true;
        }
        else if (k == 21)
        {
          this.ar = localTypedArray.getFloat(k, this.ar);
        }
        else if (k == 22)
        {
          this.as = localTypedArray.getFloat(k, this.as);
        }
        else if (k == 20)
        {
          this.aq = localTypedArray.getFloat(k, this.aq);
        }
        else if (k == 18)
        {
          this.at = localTypedArray.getFloat(k, this.at);
        }
        else if (k == 19)
        {
          this.au = localTypedArray.getFloat(k, this.au);
        }
        else if (k == 14)
        {
          this.av = localTypedArray.getFloat(k, this.av);
        }
        else if (k == 15)
        {
          this.aw = localTypedArray.getFloat(k, this.aw);
        }
        else if (k == 16)
        {
          this.ax = localTypedArray.getFloat(k, this.ax);
        }
        else if (k == 17)
        {
          this.ay = localTypedArray.getFloat(k, this.ay);
        }
        else if (k == 25)
        {
          this.ax = localTypedArray.getFloat(k, this.az);
        }
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.widget.Constraints
 * JD-Core Version:    0.6.2
 */