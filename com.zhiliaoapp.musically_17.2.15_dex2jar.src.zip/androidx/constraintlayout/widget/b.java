package androidx.constraintlayout.widget;

import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.util.SparseIntArray;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public final class b
{
  static final int[] a;
  static SparseIntArray c;
  HashMap<Integer, a> b = new HashMap();

  static
  {
    CoverageLogger.Log(2127872);
    a = new int[] { 0, 4, 8 };
    SparseIntArray localSparseIntArray = new SparseIntArray();
    c = localSparseIntArray;
    localSparseIntArray.append(55, 25);
    c.append(56, 26);
    c.append(58, 29);
    c.append(59, 30);
    c.append(64, 36);
    c.append(63, 35);
    c.append(37, 4);
    c.append(36, 3);
    c.append(34, 1);
    c.append(72, 6);
    c.append(73, 7);
    c.append(44, 17);
    c.append(45, 18);
    c.append(46, 19);
    c.append(0, 27);
    c.append(60, 32);
    c.append(61, 33);
    c.append(43, 10);
    c.append(42, 9);
    c.append(76, 13);
    c.append(79, 16);
    c.append(77, 14);
    c.append(74, 11);
    c.append(78, 15);
    c.append(75, 12);
    c.append(67, 40);
    c.append(53, 39);
    c.append(52, 41);
    c.append(66, 42);
    c.append(51, 20);
    c.append(65, 37);
    c.append(41, 5);
    c.append(54, 75);
    c.append(62, 75);
    c.append(57, 75);
    c.append(35, 75);
    c.append(33, 75);
    c.append(5, 24);
    c.append(7, 28);
    c.append(23, 31);
    c.append(24, 8);
    c.append(6, 34);
    c.append(8, 2);
    c.append(3, 23);
    c.append(4, 21);
    c.append(2, 22);
    c.append(13, 43);
    c.append(26, 44);
    c.append(21, 45);
    c.append(22, 46);
    c.append(20, 60);
    c.append(18, 47);
    c.append(19, 48);
    c.append(14, 49);
    c.append(15, 50);
    c.append(16, 51);
    c.append(17, 52);
    c.append(25, 53);
    c.append(68, 54);
    c.append(47, 55);
    c.append(69, 56);
    c.append(48, 57);
    c.append(70, 58);
    c.append(49, 59);
    c.append(38, 61);
    c.append(40, 62);
    c.append(39, 63);
    c.append(1, 38);
    c.append(71, 69);
    c.append(50, 70);
    c.append(29, 71);
    c.append(28, 72);
    c.append(30, 73);
    c.append(27, 74);
  }

  static int a(TypedArray paramTypedArray, int paramInt1, int paramInt2)
  {
    int i = paramTypedArray.getResourceId(paramInt1, paramInt2);
    if (i == -1)
      i = paramTypedArray.getInt(paramInt1, -1);
    return i;
  }

  private a a(int paramInt)
  {
    if (!this.b.containsKey(Integer.valueOf(paramInt)))
      this.b.put(Integer.valueOf(paramInt), new a(null));
    return (a)this.b.get(Integer.valueOf(paramInt));
  }

  // ERROR //
  private static int[] a(View paramView, String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ldc 78
    //   3: invokevirtual 84	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   6: astore_2
    //   7: aload_0
    //   8: invokevirtual 90	android/view/View:getContext	()Landroid/content/Context;
    //   11: astore_3
    //   12: aload_2
    //   13: arraylength
    //   14: newarray int
    //   16: astore 4
    //   18: iconst_0
    //   19: istore 5
    //   21: iconst_0
    //   22: istore 6
    //   24: iload 5
    //   26: aload_2
    //   27: arraylength
    //   28: if_icmpge +136 -> 164
    //   31: aload_2
    //   32: iload 5
    //   34: aaload
    //   35: invokevirtual 94	java/lang/String:trim	()Ljava/lang/String;
    //   38: astore 7
    //   40: ldc 96
    //   42: aload 7
    //   44: invokevirtual 102	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   47: aconst_null
    //   48: invokevirtual 107	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
    //   51: istore 8
    //   53: goto +6 -> 59
    //   56: iconst_0
    //   57: istore 8
    //   59: iload 8
    //   61: ifne +20 -> 81
    //   64: aload_3
    //   65: invokevirtual 113	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   68: aload 7
    //   70: ldc 115
    //   72: aload_3
    //   73: invokevirtual 118	android/content/Context:getPackageName	()Ljava/lang/String;
    //   76: invokevirtual 124	android/content/res/Resources:getIdentifier	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   79: istore 8
    //   81: iload 8
    //   83: ifne +58 -> 141
    //   86: aload_0
    //   87: invokevirtual 128	android/view/View:isInEditMode	()Z
    //   90: ifeq +51 -> 141
    //   93: aload_0
    //   94: invokevirtual 132	android/view/View:getParent	()Landroid/view/ViewParent;
    //   97: instanceof 134
    //   100: ifeq +41 -> 141
    //   103: aload_0
    //   104: invokevirtual 132	android/view/View:getParent	()Landroid/view/ViewParent;
    //   107: checkcast 134	androidx/constraintlayout/widget/ConstraintLayout
    //   110: iconst_0
    //   111: aload 7
    //   113: invokevirtual 137	androidx/constraintlayout/widget/ConstraintLayout:a	(ILjava/lang/Object;)Ljava/lang/Object;
    //   116: astore 10
    //   118: aload 10
    //   120: ifnull +21 -> 141
    //   123: aload 10
    //   125: instanceof 52
    //   128: ifeq +13 -> 141
    //   131: aload 10
    //   133: checkcast 52	java/lang/Integer
    //   136: invokevirtual 141	java/lang/Integer:intValue	()I
    //   139: istore 8
    //   141: iload 6
    //   143: iconst_1
    //   144: iadd
    //   145: istore 9
    //   147: aload 4
    //   149: iload 6
    //   151: iload 8
    //   153: iastore
    //   154: iinc 5 1
    //   157: iload 9
    //   159: istore 6
    //   161: goto -137 -> 24
    //   164: iload 6
    //   166: aload_2
    //   167: arraylength
    //   168: if_icmpeq +12 -> 180
    //   171: aload 4
    //   173: iload 6
    //   175: invokestatic 147	java/util/Arrays:copyOf	([II)[I
    //   178: astore 4
    //   180: aload 4
    //   182: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   40	53	56	java/lang/Exception
  }

  public final void a(int paramInt1, int paramInt2)
  {
    a(paramInt1).al = paramInt2;
  }

  public final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (!this.b.containsKey(Integer.valueOf(paramInt1)))
      this.b.put(Integer.valueOf(paramInt1), new a(null));
    a locala = (a)this.b.get(Integer.valueOf(paramInt1));
    locala.m = paramInt3;
    locala.l = -1;
    locala.p = -1;
  }

  public final void a(int paramInt, String paramString)
  {
    a(paramInt).w = paramString;
  }

  public final void a(ConstraintLayout paramConstraintLayout)
  {
    int i = paramConstraintLayout.getChildCount();
    this.b.clear();
    int j = 0;
    while (j < i)
    {
      View localView = paramConstraintLayout.getChildAt(j);
      ConstraintLayout.LayoutParams localLayoutParams = (ConstraintLayout.LayoutParams)localView.getLayoutParams();
      int k = localView.getId();
      if (k != -1)
      {
        if (!this.b.containsKey(Integer.valueOf(k)))
          this.b.put(Integer.valueOf(k), new a(null));
        a locala = (a)this.b.get(Integer.valueOf(k));
        locala.a(k, localLayoutParams);
        locala.J = localView.getVisibility();
        if (Build.VERSION.SDK_INT >= 17)
        {
          locala.U = localView.getAlpha();
          locala.X = localView.getRotation();
          locala.Y = localView.getRotationX();
          locala.Z = localView.getRotationY();
          locala.aa = localView.getScaleX();
          locala.ab = localView.getScaleY();
          float f1 = localView.getPivotX();
          float f2 = localView.getPivotY();
          if ((f1 != 0.0D) || (f2 != 0.0D))
          {
            locala.ac = f1;
            locala.ad = f2;
          }
          locala.ae = localView.getTranslationX();
          locala.af = localView.getTranslationY();
          if (Build.VERSION.SDK_INT >= 21)
          {
            locala.ag = localView.getTranslationZ();
            if (locala.V)
              locala.W = localView.getElevation();
          }
        }
        if ((localView instanceof a))
        {
          a locala1 = (a)localView;
          locala.ar = locala1.a.b;
          locala.au = locala1.getReferencedIds();
          locala.as = locala1.getType();
        }
        j++;
      }
      else
      {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      }
    }
  }

  public final void b(ConstraintLayout paramConstraintLayout)
  {
    c(paramConstraintLayout);
    paramConstraintLayout.setConstraintSet(null);
  }

  final void c(ConstraintLayout paramConstraintLayout)
  {
    int i = paramConstraintLayout.getChildCount();
    HashSet localHashSet = new HashSet(this.b.keySet());
    int j = 0;
    while (j < i)
    {
      View localView = paramConstraintLayout.getChildAt(j);
      int k = localView.getId();
      if (k != -1)
      {
        if (this.b.containsKey(Integer.valueOf(k)))
        {
          localHashSet.remove(Integer.valueOf(k));
          a locala3 = (a)this.b.get(Integer.valueOf(k));
          if ((localView instanceof a))
            locala3.at = 1;
          if ((locala3.at != -1) && (locala3.at == 1))
          {
            a locala4 = (a)localView;
            locala4.setId(k);
            locala4.setType(locala3.as);
            locala4.setAllowsGoneWidget(locala3.ar);
            if (locala3.au != null)
            {
              locala4.setReferencedIds(locala3.au);
            }
            else if (locala3.av != null)
            {
              locala3.au = a(locala4, locala3.av);
              locala4.setReferencedIds(locala3.au);
            }
          }
          ConstraintLayout.LayoutParams localLayoutParams3 = (ConstraintLayout.LayoutParams)localView.getLayoutParams();
          locala3.a(localLayoutParams3);
          localView.setLayoutParams(localLayoutParams3);
          localView.setVisibility(locala3.J);
          if (Build.VERSION.SDK_INT >= 17)
          {
            localView.setAlpha(locala3.U);
            localView.setRotation(locala3.X);
            localView.setRotationX(locala3.Y);
            localView.setRotationY(locala3.Z);
            localView.setScaleX(locala3.aa);
            localView.setScaleY(locala3.ab);
            if (!Float.isNaN(locala3.ac))
              localView.setPivotX(locala3.ac);
            if (!Float.isNaN(locala3.ad))
              localView.setPivotY(locala3.ad);
            localView.setTranslationX(locala3.ae);
            localView.setTranslationY(locala3.af);
            if (Build.VERSION.SDK_INT >= 21)
            {
              localView.setTranslationZ(locala3.ag);
              if (locala3.V)
                localView.setElevation(locala3.W);
            }
          }
        }
        j++;
      }
      else
      {
        throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
      }
    }
    Iterator localIterator = localHashSet.iterator();
    while (localIterator.hasNext())
    {
      Integer localInteger = (Integer)localIterator.next();
      a locala1 = (a)this.b.get(localInteger);
      if ((locala1.at != -1) && (locala1.at == 1))
      {
        a locala2 = new a(paramConstraintLayout.getContext());
        locala2.setId(localInteger.intValue());
        if (locala1.au != null)
        {
          locala2.setReferencedIds(locala1.au);
        }
        else if (locala1.av != null)
        {
          locala1.au = a(locala2, locala1.av);
          locala2.setReferencedIds(locala1.au);
        }
        locala2.setType(locala1.as);
        ConstraintLayout.LayoutParams localLayoutParams2 = ConstraintLayout.a();
        locala2.a();
        locala1.a(localLayoutParams2);
        paramConstraintLayout.addView(locala2, localLayoutParams2);
      }
      if (locala1.a)
      {
        Guideline localGuideline = new Guideline(paramConstraintLayout.getContext());
        localGuideline.setId(localInteger.intValue());
        ConstraintLayout.LayoutParams localLayoutParams1 = ConstraintLayout.a();
        locala1.a(localLayoutParams1);
        paramConstraintLayout.addView(localGuideline, localLayoutParams1);
      }
    }
  }

  static final class a
  {
    public int A = -1;
    public int B = -1;
    public int C = -1;
    public int D = -1;
    public int E = -1;
    public int F = -1;
    public int G = -1;
    public int H = -1;
    public int I = -1;
    public int J;
    public int K = -1;
    public int L = -1;
    public int M = -1;
    public int N = -1;
    public int O = -1;
    public int P = -1;
    public float Q;
    public float R;
    public int S;
    public int T;
    public float U = 1.0F;
    public boolean V;
    public float W;
    public float X;
    public float Y;
    public float Z;
    boolean a;
    public float aa = 1.0F;
    public float ab = 1.0F;
    public float ac = (0.0F / 0.0F);
    public float ad = (0.0F / 0.0F);
    public float ae;
    public float af;
    public float ag;
    public boolean ah;
    public boolean ai;
    public int aj;
    public int ak;
    public int al = -1;
    public int am = -1;
    public int an = -1;
    public int ao = -1;
    public float ap = 1.0F;
    public float aq = 1.0F;
    public boolean ar;
    public int as = -1;
    public int at = -1;
    public int[] au;
    public String av;
    public int b;
    public int c;
    int d;
    public int e = -1;
    public int f = -1;
    public float g = -1.0F;
    public int h = -1;
    public int i = -1;
    public int j = -1;
    public int k = -1;
    public int l = -1;
    public int m = -1;
    public int n = -1;
    public int o = -1;
    public int p = -1;
    public int q = -1;
    public int r = -1;
    public int s = -1;
    public int t = -1;
    public float u = 0.5F;
    public float v = 0.5F;
    public String w;
    public int x = -1;
    public int y;
    public float z;

    static
    {
      CoverageLogger.Log(2121728);
    }

    public final void a(int paramInt, ConstraintLayout.LayoutParams paramLayoutParams)
    {
      this.d = paramInt;
      this.h = paramLayoutParams.d;
      this.i = paramLayoutParams.e;
      this.j = paramLayoutParams.f;
      this.k = paramLayoutParams.g;
      this.l = paramLayoutParams.h;
      this.m = paramLayoutParams.i;
      this.n = paramLayoutParams.j;
      this.o = paramLayoutParams.k;
      this.p = paramLayoutParams.l;
      this.q = paramLayoutParams.p;
      this.r = paramLayoutParams.q;
      this.s = paramLayoutParams.r;
      this.t = paramLayoutParams.s;
      this.u = paramLayoutParams.z;
      this.v = paramLayoutParams.A;
      this.w = paramLayoutParams.B;
      this.x = paramLayoutParams.m;
      this.y = paramLayoutParams.n;
      this.z = paramLayoutParams.o;
      this.A = paramLayoutParams.Q;
      this.B = paramLayoutParams.R;
      this.C = paramLayoutParams.S;
      this.g = paramLayoutParams.c;
      this.e = paramLayoutParams.a;
      this.f = paramLayoutParams.b;
      this.b = paramLayoutParams.width;
      this.c = paramLayoutParams.height;
      this.D = paramLayoutParams.leftMargin;
      this.E = paramLayoutParams.rightMargin;
      this.F = paramLayoutParams.topMargin;
      this.G = paramLayoutParams.bottomMargin;
      this.Q = paramLayoutParams.F;
      this.R = paramLayoutParams.E;
      this.T = paramLayoutParams.H;
      this.S = paramLayoutParams.G;
      this.ah = paramLayoutParams.T;
      this.ai = paramLayoutParams.U;
      this.aj = paramLayoutParams.I;
      this.ak = paramLayoutParams.J;
      this.ah = paramLayoutParams.T;
      this.al = paramLayoutParams.M;
      this.am = paramLayoutParams.N;
      this.an = paramLayoutParams.K;
      this.ao = paramLayoutParams.L;
      this.ap = paramLayoutParams.O;
      this.aq = paramLayoutParams.P;
      if (Build.VERSION.SDK_INT >= 17)
      {
        this.H = paramLayoutParams.getMarginEnd();
        this.I = paramLayoutParams.getMarginStart();
      }
    }

    public final void a(int paramInt, Constraints.LayoutParams paramLayoutParams)
    {
      a(paramInt, paramLayoutParams);
      this.U = paramLayoutParams.an;
      this.X = paramLayoutParams.aq;
      this.Y = paramLayoutParams.ar;
      this.Z = paramLayoutParams.as;
      this.aa = paramLayoutParams.at;
      this.ab = paramLayoutParams.au;
      this.ac = paramLayoutParams.av;
      this.ad = paramLayoutParams.aw;
      this.ae = paramLayoutParams.ax;
      this.af = paramLayoutParams.ay;
      this.ag = paramLayoutParams.az;
      this.W = paramLayoutParams.ap;
      this.V = paramLayoutParams.ao;
    }

    public final void a(ConstraintLayout.LayoutParams paramLayoutParams)
    {
      paramLayoutParams.d = this.h;
      paramLayoutParams.e = this.i;
      paramLayoutParams.f = this.j;
      paramLayoutParams.g = this.k;
      paramLayoutParams.h = this.l;
      paramLayoutParams.i = this.m;
      paramLayoutParams.j = this.n;
      paramLayoutParams.k = this.o;
      paramLayoutParams.l = this.p;
      paramLayoutParams.p = this.q;
      paramLayoutParams.q = this.r;
      paramLayoutParams.r = this.s;
      paramLayoutParams.s = this.t;
      paramLayoutParams.leftMargin = this.D;
      paramLayoutParams.rightMargin = this.E;
      paramLayoutParams.topMargin = this.F;
      paramLayoutParams.bottomMargin = this.G;
      paramLayoutParams.x = this.P;
      paramLayoutParams.y = this.O;
      paramLayoutParams.z = this.u;
      paramLayoutParams.A = this.v;
      paramLayoutParams.m = this.x;
      paramLayoutParams.n = this.y;
      paramLayoutParams.o = this.z;
      paramLayoutParams.B = this.w;
      paramLayoutParams.Q = this.A;
      paramLayoutParams.R = this.B;
      paramLayoutParams.F = this.Q;
      paramLayoutParams.E = this.R;
      paramLayoutParams.H = this.T;
      paramLayoutParams.G = this.S;
      paramLayoutParams.T = this.ah;
      paramLayoutParams.U = this.ai;
      paramLayoutParams.I = this.aj;
      paramLayoutParams.J = this.ak;
      paramLayoutParams.M = this.al;
      paramLayoutParams.N = this.am;
      paramLayoutParams.K = this.an;
      paramLayoutParams.L = this.ao;
      paramLayoutParams.O = this.ap;
      paramLayoutParams.P = this.aq;
      paramLayoutParams.S = this.C;
      paramLayoutParams.c = this.g;
      paramLayoutParams.a = this.e;
      paramLayoutParams.b = this.f;
      paramLayoutParams.width = this.b;
      paramLayoutParams.height = this.c;
      if (Build.VERSION.SDK_INT >= 17)
      {
        paramLayoutParams.setMarginStart(this.I);
        paramLayoutParams.setMarginEnd(this.H);
      }
      paramLayoutParams.a();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.widget.b
 * JD-Core Version:    0.6.2
 */