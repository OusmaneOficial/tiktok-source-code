package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import androidx.constraintlayout.a.a.j;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Arrays;

public abstract class ConstraintHelper extends View
{
  private String a;
  protected int[] b = new int[32];
  protected int c;
  protected Context d;
  protected j e;
  protected boolean f;

  static
  {
    CoverageLogger.Log(2117632);
  }

  public ConstraintHelper(Context paramContext)
  {
    super(paramContext);
    this.d = paramContext;
    a(null);
  }

  public ConstraintHelper(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.d = paramContext;
    a(paramAttributeSet);
  }

  public ConstraintHelper(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.d = paramContext;
    a(paramAttributeSet);
  }

  // ERROR //
  private void a(String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +4 -> 5
    //   4: return
    //   5: aload_0
    //   6: getfield 33	androidx/constraintlayout/widget/ConstraintHelper:d	Landroid/content/Context;
    //   9: ifnonnull +4 -> 13
    //   12: return
    //   13: aload_1
    //   14: invokevirtual 51	java/lang/String:trim	()Ljava/lang/String;
    //   17: astore_2
    //   18: ldc 53
    //   20: aload_2
    //   21: invokevirtual 59	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   24: aconst_null
    //   25: invokevirtual 65	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
    //   28: istore_3
    //   29: goto +5 -> 34
    //   32: iconst_0
    //   33: istore_3
    //   34: iload_3
    //   35: ifne +24 -> 59
    //   38: aload_0
    //   39: getfield 33	androidx/constraintlayout/widget/ConstraintHelper:d	Landroid/content/Context;
    //   42: invokevirtual 71	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   45: aload_2
    //   46: ldc 73
    //   48: aload_0
    //   49: getfield 33	androidx/constraintlayout/widget/ConstraintHelper:d	Landroid/content/Context;
    //   52: invokevirtual 76	android/content/Context:getPackageName	()Ljava/lang/String;
    //   55: invokevirtual 82	android/content/res/Resources:getIdentifier	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   58: istore_3
    //   59: iload_3
    //   60: ifne +56 -> 116
    //   63: aload_0
    //   64: invokevirtual 86	androidx/constraintlayout/widget/ConstraintHelper:isInEditMode	()Z
    //   67: ifeq +49 -> 116
    //   70: aload_0
    //   71: invokevirtual 90	androidx/constraintlayout/widget/ConstraintHelper:getParent	()Landroid/view/ViewParent;
    //   74: instanceof 92
    //   77: ifeq +39 -> 116
    //   80: aload_0
    //   81: invokevirtual 90	androidx/constraintlayout/widget/ConstraintHelper:getParent	()Landroid/view/ViewParent;
    //   84: checkcast 92	androidx/constraintlayout/widget/ConstraintLayout
    //   87: iconst_0
    //   88: aload_2
    //   89: invokevirtual 95	androidx/constraintlayout/widget/ConstraintLayout:a	(ILjava/lang/Object;)Ljava/lang/Object;
    //   92: astore 4
    //   94: aload 4
    //   96: ifnull +20 -> 116
    //   99: aload 4
    //   101: instanceof 97
    //   104: ifeq +12 -> 116
    //   107: aload 4
    //   109: checkcast 97	java/lang/Integer
    //   112: invokevirtual 101	java/lang/Integer:intValue	()I
    //   115: istore_3
    //   116: iload_3
    //   117: ifeq +9 -> 126
    //   120: aload_0
    //   121: iload_3
    //   122: aconst_null
    //   123: invokevirtual 105	androidx/constraintlayout/widget/ConstraintHelper:setTag	(ILjava/lang/Object;)V
    //   126: return
    //
    // Exception table:
    //   from	to	target	type
    //   18	29	32	java/lang/Exception
  }

  private void setIds(String paramString)
  {
    if (paramString == null)
      return;
    int j;
    for (int i = 0; ; i = j + 1)
    {
      j = paramString.indexOf(',', i);
      if (j == -1)
      {
        a(paramString.substring(i));
        return;
      }
      a(paramString.substring(i, j));
    }
  }

  public final void a()
  {
    if (this.e == null)
      return;
    ViewGroup.LayoutParams localLayoutParams = getLayoutParams();
    if ((localLayoutParams instanceof ConstraintLayout.LayoutParams))
      ((ConstraintLayout.LayoutParams)localLayoutParams).al = this.e;
  }

  protected void a(AttributeSet paramAttributeSet)
  {
    if (paramAttributeSet != null)
    {
      TypedArray localTypedArray = getContext().obtainStyledAttributes(paramAttributeSet, new int[] { 16842948, 16843039, 16843040, 16843071, 16843072, 2130968702, 2130968703, 2130968860, 2130968955, 2130968956, 2130969289, 2130969290, 2130969291, 2130969292, 2130969293, 2130969294, 2130969295, 2130969296, 2130969297, 2130969298, 2130969299, 2130969300, 2130969301, 2130969302, 2130969303, 2130969304, 2130969305, 2130969306, 2130969307, 2130969308, 2130969309, 2130969310, 2130969311, 2130969312, 2130969313, 2130969314, 2130969315, 2130969316, 2130969317, 2130969318, 2130969319, 2130969320, 2130969321, 2130969322, 2130969323, 2130969324, 2130969325, 2130969326, 2130969327, 2130969328, 2130969329, 2130969336, 2130969337, 2130969338, 2130969339, 2130969340, 2130969341, 2130969342, 2130969343, 2130969347 });
      int i = localTypedArray.getIndexCount();
      for (int j = 0; j < i; j++)
      {
        int k = localTypedArray.getIndex(j);
        if (k == 9)
        {
          this.a = localTypedArray.getString(k);
          setIds(this.a);
        }
      }
    }
  }

  public void a(ConstraintLayout paramConstraintLayout)
  {
    if (isInEditMode())
      setIds(this.a);
    j localj = this.e;
    if (localj == null)
      return;
    localj.y();
    for (int i = 0; i < this.c; i++)
    {
      View localView = paramConstraintLayout.a(this.b[i]);
      if (localView != null)
        this.e.a(paramConstraintLayout.a(localView));
    }
  }

  public void b(ConstraintLayout paramConstraintLayout)
  {
  }

  public int[] getReferencedIds()
  {
    return Arrays.copyOf(this.b, this.c);
  }

  public void onDraw(Canvas paramCanvas)
  {
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    if (this.f)
    {
      super.onMeasure(paramInt1, paramInt2);
      return;
    }
    setMeasuredDimension(0, 0);
  }

  public void setReferencedIds(int[] paramArrayOfInt)
  {
    int i = 0;
    this.c = 0;
    while (i < paramArrayOfInt.length)
    {
      setTag(paramArrayOfInt[i], null);
      i++;
    }
  }

  public void setTag(int paramInt, Object paramObject)
  {
    int i = 1 + this.c;
    int[] arrayOfInt1 = this.b;
    if (i > arrayOfInt1.length)
      this.b = Arrays.copyOf(arrayOfInt1, 2 * arrayOfInt1.length);
    int[] arrayOfInt2 = this.b;
    int j = this.c;
    arrayOfInt2[j] = paramInt;
    this.c = (j + 1);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.constraintlayout.widget.ConstraintHelper
 * JD-Core Version:    0.6.2
 */