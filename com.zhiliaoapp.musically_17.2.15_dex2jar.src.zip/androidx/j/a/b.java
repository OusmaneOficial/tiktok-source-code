package androidx.j.a;

import android.database.Cursor;
import android.database.SQLException;
import android.util.Pair;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.Closeable;
import java.util.List;

public abstract interface b extends Closeable
{
  static
  {
    CoverageLogger.Log(28088320);
  }

  public abstract Cursor a(e parame);

  public abstract f a(String paramString);

  public abstract void a();

  public abstract Cursor b(String paramString);

  public abstract void b();

  public abstract void c();

  public abstract void c(String paramString)
    throws SQLException;

  public abstract boolean d();

  public abstract boolean e();

  public abstract String f();

  public abstract List<Pair<String, String>> g();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.j.a.b
 * JD-Core Version:    0.6.2
 */