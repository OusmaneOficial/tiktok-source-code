package androidx.j.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.Closeable;

public abstract interface d extends Closeable
{
  static
  {
    CoverageLogger.Log(28076032);
  }

  public abstract void a(int paramInt);

  public abstract void a(int paramInt, double paramDouble);

  public abstract void a(int paramInt, long paramLong);

  public abstract void a(int paramInt, String paramString);

  public abstract void a(int paramInt, byte[] paramArrayOfByte);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.j.a.d
 * JD-Core Version:    0.6.2
 */