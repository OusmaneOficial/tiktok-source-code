package androidx.j.a;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.File;

public abstract interface c
{
  static
  {
    CoverageLogger.Log(28217344);
  }

  public abstract b a();

  public abstract void a(boolean paramBoolean);

  public static abstract class a
  {
    public final int a;

    static
    {
      CoverageLogger.Log(28213248);
    }

    public a(int paramInt)
    {
      this.a = paramInt;
    }

    public static void a(String paramString)
    {
      if (!paramString.equalsIgnoreCase(":memory:"))
        if (paramString.trim().length() == 0)
          return;
      try
      {
        if (Build.VERSION.SDK_INT >= 16)
        {
          SQLiteDatabase.deleteDatabase(new File(paramString));
          return;
        }
        new File(paramString).delete();
      }
      catch (Exception localException)
      {
      }
    }

    public abstract void a(b paramb);

    public abstract void a(b paramb, int paramInt1, int paramInt2);

    public void b(b paramb)
    {
    }

    public void b(b paramb, int paramInt1, int paramInt2)
    {
      StringBuilder localStringBuilder = new StringBuilder("Can't downgrade database from version ");
      localStringBuilder.append(paramInt1);
      localStringBuilder.append(" to ");
      localStringBuilder.append(paramInt2);
      throw new SQLiteException(localStringBuilder.toString());
    }
  }

  public static final class b
  {
    public final Context a;
    public final String b;
    public final c.a c;

    static
    {
      CoverageLogger.Log(28082176);
    }

    b(Context paramContext, String paramString, c.a parama)
    {
      this.a = paramContext;
      this.b = paramString;
      this.c = parama;
    }

    public static a a(Context paramContext)
    {
      return new a(paramContext);
    }

    public static final class a
    {
      Context a;
      String b;
      c.a c;

      static
      {
        CoverageLogger.Log(28084224);
      }

      a(Context paramContext)
      {
        this.a = paramContext;
      }

      public final a a(c.a parama)
      {
        this.c = parama;
        return this;
      }

      public final a a(String paramString)
      {
        this.b = paramString;
        return this;
      }

      public final c.b a()
      {
        c.a locala = this.c;
        if (locala != null)
        {
          Context localContext = this.a;
          if (localContext != null)
            return new c.b(localContext, this.b, locala);
          throw new IllegalArgumentException("Must set a non-null context to create the configuration.");
        }
        throw new IllegalArgumentException("Must set a callback to create the configuration.");
      }
    }
  }

  public static abstract interface c
  {
    static
    {
      CoverageLogger.Log(28080128);
    }

    public abstract c a(c.b paramb);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.j.a.c
 * JD-Core Version:    0.6.2
 */