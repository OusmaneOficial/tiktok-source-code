package androidx.j.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface e
{
  static
  {
    CoverageLogger.Log(28223488);
  }

  public abstract void a(d paramd);

  public abstract String b();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.j.a.e
 * JD-Core Version:    0.6.2
 */