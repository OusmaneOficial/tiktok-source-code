package androidx.i;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class g
{
  static
  {
    CoverageLogger.Log(20174848);
  }

  public static String a(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \"");
    localStringBuilder.append(paramString);
    localStringBuilder.append("\")");
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.g
 * JD-Core Version:    0.6.2
 */