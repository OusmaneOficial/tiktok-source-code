package androidx.i;

import android.app.ActivityManager;
import android.content.Context;
import android.database.Cursor;
import android.os.Build.VERSION;
import android.os.Looper;
import androidx.c.h;
import androidx.j.a.b;
import androidx.j.a.c.c;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

public abstract class f
{
  public volatile b a;
  public Executor b;
  public androidx.j.a.c c;
  public final d d = a();
  boolean e;
  public List<b> f;
  public final ReentrantLock g = new ReentrantLock();
  private boolean h;

  static
  {
    CoverageLogger.Log(82116608);
  }

  public final Cursor a(androidx.j.a.e parame)
  {
    b();
    return this.c.a().a(parame);
  }

  protected abstract d a();

  public final androidx.j.a.f a(String paramString)
  {
    b();
    return this.c.a().a(paramString);
  }

  public final void a(a parama)
  {
    this.c = b(parama);
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    if (i >= 16)
    {
      c localc1 = parama.g;
      c localc2 = c.WRITE_AHEAD_LOGGING;
      bool = false;
      if (localc1 == localc2)
        bool = true;
      this.c.a(bool);
    }
    this.f = parama.e;
    this.b = parama.h;
    this.h = parama.f;
    this.e = bool;
  }

  public final void a(b paramb)
  {
    synchronized (this.d)
    {
      if (???.g)
        return;
      paramb.a();
      try
      {
        paramb.c("PRAGMA temp_store = MEMORY;");
        paramb.c("PRAGMA recursive_triggers='ON';");
        paramb.c("CREATE TEMP TABLE room_table_modification_log(version INTEGER PRIMARY KEY AUTOINCREMENT, table_id INTEGER)");
        paramb.c();
        paramb.b();
        ???.a(paramb);
        ???.h = paramb.a("DELETE FROM room_table_modification_log WHERE version NOT IN( SELECT MAX(version) FROM room_table_modification_log GROUP BY table_id)");
        ???.g = true;
        return;
      }
      finally
      {
        localObject2 = finally;
        paramb.b();
        throw localObject2;
      }
    }
  }

  protected abstract androidx.j.a.c b(a parama);

  public final void b()
  {
    if (this.h)
      return;
    int i;
    if (Looper.getMainLooper().getThread() == Thread.currentThread())
      i = 1;
    else
      i = 0;
    if (i == 0)
      return;
    throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
  }

  public final void c()
  {
    b();
    b localb = this.c.a();
    this.d.a(localb);
    localb.a();
  }

  public final void d()
  {
    this.c.a().b();
    if (!f())
    {
      d locald = this.d;
      if (locald.f.compareAndSet(false, true))
        locald.e.b.execute(locald.j);
    }
  }

  public final void e()
  {
    this.c.a().c();
  }

  public final boolean f()
  {
    return this.c.a().d();
  }

  public static final class a<T extends f>
  {
    public ArrayList<f.b> a;
    public boolean b;
    private final Class<T> c;
    private final String d;
    private final Context e;
    private Executor f;
    private c.c g;
    private boolean h;
    private f.c i;
    private final f.d j;
    private Set<Integer> k;
    private Set<Integer> l;

    static
    {
      CoverageLogger.Log(82096128);
    }

    public a(Context paramContext, Class<T> paramClass, String paramString)
    {
      this.e = paramContext;
      this.c = paramClass;
      this.d = paramString;
      this.i = f.c.AUTOMATIC;
      this.b = true;
      this.j = new f.d();
    }

    public final a<T> a()
    {
      this.h = true;
      return this;
    }

    public final a<T> a(androidx.i.a.a[] paramArrayOfa)
    {
      if (this.l == null)
        this.l = new HashSet();
      int m = paramArrayOfa.length;
      for (int n = 0; n < m; n++)
      {
        androidx.i.a.a locala = paramArrayOfa[n];
        this.l.add(Integer.valueOf(locala.a));
        this.l.add(Integer.valueOf(locala.b));
      }
      this.j.a(paramArrayOfa);
      return this;
    }

    public final T b()
    {
      if (this.e != null)
      {
        if (this.c != null)
        {
          if (this.f == null)
            this.f = androidx.a.a.a.a.c();
          Set localSet = this.l;
          if ((localSet != null) && (this.k != null))
          {
            Iterator localIterator = localSet.iterator();
            while (localIterator.hasNext())
            {
              Integer localInteger = (Integer)localIterator.next();
              if (this.k.contains(localInteger))
              {
                StringBuilder localStringBuilder = new StringBuilder("Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: ");
                localStringBuilder.append(localInteger);
                throw new IllegalArgumentException(localStringBuilder.toString());
              }
            }
          }
          if (this.g == null)
            this.g = new androidx.j.a.a.c();
          Context localContext = this.e;
          String str = this.d;
          c.c localc = this.g;
          f.d locald = this.j;
          ArrayList localArrayList = this.a;
          boolean bool1 = this.h;
          f.c localc1 = this.i;
          if (localc1 != f.c.AUTOMATIC);
          f.c localc2;
          while (true)
          {
            localc2 = localc1;
            break;
            if (Build.VERSION.SDK_INT >= 16)
            {
              ActivityManager localActivityManager = (ActivityManager)localContext.getSystemService("activity");
              if (localActivityManager != null)
              {
                boolean bool2;
                if (Build.VERSION.SDK_INT >= 19)
                  bool2 = localActivityManager.isLowRamDevice();
                else
                  bool2 = false;
                if (!bool2)
                  localc1 = f.c.WRITE_AHEAD_LOGGING;
              }
            }
            else
            {
              localc1 = f.c.TRUNCATE;
            }
          }
          a locala = new a(localContext, str, localc, locald, localArrayList, bool1, localc2, this.f, this.b, this.k);
          f localf = (f)e.a(this.c, "_Impl");
          localf.a(locala);
          return localf;
        }
        throw new IllegalArgumentException("Must provide an abstract class that extends RoomDatabase");
      }
      IllegalArgumentException localIllegalArgumentException = new IllegalArgumentException("Cannot provide null context for the database.");
      while (true)
        throw localIllegalArgumentException;
    }
  }

  public static abstract class b
  {
    static
    {
      CoverageLogger.Log(82028544);
    }

    public void a(b paramb)
    {
    }
  }

  public static enum c
  {
    static
    {
      CoverageLogger.Log(82100224);
      AUTOMATIC = new c("AUTOMATIC", 0);
      TRUNCATE = new c("TRUNCATE", 1);
      WRITE_AHEAD_LOGGING = new c("WRITE_AHEAD_LOGGING", 2);
      c[] arrayOfc = new c[3];
      arrayOfc[0] = AUTOMATIC;
      arrayOfc[1] = TRUNCATE;
      arrayOfc[2] = WRITE_AHEAD_LOGGING;
    }
  }

  public static final class d
  {
    private h<h<androidx.i.a.a>> a = new h();

    static
    {
      CoverageLogger.Log(82024448);
    }

    List<androidx.i.a.a> a(List<androidx.i.a.a> paramList, boolean paramBoolean, int paramInt1, int paramInt2)
    {
      int i;
      if (paramBoolean)
        i = -1;
      else
        i = 1;
      while (paramBoolean ? paramInt1 < paramInt2 : paramInt1 > paramInt2)
      {
        h localh = (h)this.a.a(paramInt1);
        if (localh == null)
          return null;
        int j = localh.b();
        int m;
        int k;
        if (paramBoolean)
        {
          m = j - 1;
          k = -1;
        }
        else
        {
          k = j;
          m = 0;
        }
        int n;
        while (true)
        {
          n = 0;
          if (m == k)
            break;
          int i1 = localh.c(m);
          if (paramBoolean)
            if ((i1 > paramInt2) || (i1 <= paramInt1));
          int i2;
          while (true)
          {
            i2 = 1;
            break;
            do
            {
              i2 = 0;
              break;
            }
            while ((i1 < paramInt2) || (i1 >= paramInt1));
          }
          if (i2 != 0)
          {
            paramList.add(localh.d(m));
            paramInt1 = i1;
            n = 1;
            break;
          }
          m += i;
        }
        if (n == 0)
          return null;
      }
      return paramList;
    }

    public final void a(androidx.i.a.a[] paramArrayOfa)
    {
      int i = paramArrayOfa.length;
      for (int j = 0; j < i; j++)
      {
        androidx.i.a.a locala = paramArrayOfa[j];
        int k = locala.a;
        int m = locala.b;
        h localh = (h)this.a.a(k);
        if (localh == null)
        {
          localh = new h();
          this.a.b(k, localh);
        }
        localh.a(m);
        localh.c(m, locala);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.f
 * JD-Core Version:    0.6.2
 */