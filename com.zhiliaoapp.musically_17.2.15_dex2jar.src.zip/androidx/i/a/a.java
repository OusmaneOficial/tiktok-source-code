package androidx.i.a;

import androidx.j.a.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class a
{
  public final int a;
  public final int b;

  static
  {
    CoverageLogger.Log(82145280);
  }

  public a(int paramInt1, int paramInt2)
  {
    this.a = paramInt1;
    this.b = paramInt2;
  }

  public abstract void a(b paramb);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.a.a
 * JD-Core Version:    0.6.2
 */