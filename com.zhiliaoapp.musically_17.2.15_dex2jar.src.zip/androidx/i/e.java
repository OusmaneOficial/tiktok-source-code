package androidx.i;

import android.content.Context;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
{
  static
  {
    CoverageLogger.Log(82034688);
  }

  public static <T extends f> f.a<T> a(Context paramContext, Class<T> paramClass, String paramString)
  {
    if (paramString.trim().length() != 0)
      return new f.a(paramContext, paramClass, paramString);
    throw new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder");
  }

  // ERROR //
  static <T, C> T a(Class<C> paramClass, String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 51	java/lang/Class:getPackage	()Ljava/lang/Package;
    //   4: invokevirtual 56	java/lang/Package:getName	()Ljava/lang/String;
    //   7: astore_2
    //   8: aload_0
    //   9: invokevirtual 59	java/lang/Class:getCanonicalName	()Ljava/lang/String;
    //   12: astore_3
    //   13: aload_2
    //   14: invokevirtual 63	java/lang/String:isEmpty	()Z
    //   17: ifeq +6 -> 23
    //   20: goto +14 -> 34
    //   23: aload_3
    //   24: iconst_1
    //   25: aload_2
    //   26: invokevirtual 25	java/lang/String:length	()I
    //   29: iadd
    //   30: invokevirtual 67	java/lang/String:substring	(I)Ljava/lang/String;
    //   33: astore_3
    //   34: new 69	java/lang/StringBuilder
    //   37: dup
    //   38: invokespecial 71	java/lang/StringBuilder:<init>	()V
    //   41: astore 4
    //   43: aload 4
    //   45: aload_3
    //   46: bipush 46
    //   48: bipush 95
    //   50: invokevirtual 75	java/lang/String:replace	(CC)Ljava/lang/String;
    //   53: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: pop
    //   57: aload 4
    //   59: aload_1
    //   60: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: pop
    //   64: aload 4
    //   66: invokevirtual 82	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   69: astore 7
    //   71: aload_2
    //   72: invokevirtual 63	java/lang/String:isEmpty	()Z
    //   75: ifeq +10 -> 85
    //   78: aload 7
    //   80: astore 17
    //   82: goto +42 -> 124
    //   85: new 69	java/lang/StringBuilder
    //   88: dup
    //   89: invokespecial 71	java/lang/StringBuilder:<init>	()V
    //   92: astore 19
    //   94: aload 19
    //   96: aload_2
    //   97: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: pop
    //   101: aload 19
    //   103: ldc 84
    //   105: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: pop
    //   109: aload 19
    //   111: aload 7
    //   113: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: pop
    //   117: aload 19
    //   119: invokevirtual 82	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   122: astore 17
    //   124: aload 17
    //   126: invokestatic 88	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   129: invokevirtual 92	java/lang/Class:newInstance	()Ljava/lang/Object;
    //   132: astore 18
    //   134: aload 18
    //   136: areturn
    //   137: new 69	java/lang/StringBuilder
    //   140: dup
    //   141: ldc 94
    //   143: invokespecial 95	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   146: astore 15
    //   148: aload 15
    //   150: aload_0
    //   151: invokevirtual 59	java/lang/Class:getCanonicalName	()Ljava/lang/String;
    //   154: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: pop
    //   158: new 97	java/lang/RuntimeException
    //   161: dup
    //   162: aload 15
    //   164: invokevirtual 82	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   167: invokespecial 98	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   170: athrow
    //   171: new 69	java/lang/StringBuilder
    //   174: dup
    //   175: ldc 100
    //   177: invokespecial 95	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   180: astore 13
    //   182: aload 13
    //   184: aload_0
    //   185: invokevirtual 59	java/lang/Class:getCanonicalName	()Ljava/lang/String;
    //   188: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: pop
    //   192: new 97	java/lang/RuntimeException
    //   195: dup
    //   196: aload 13
    //   198: invokevirtual 82	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   201: invokespecial 98	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   204: athrow
    //   205: new 69	java/lang/StringBuilder
    //   208: dup
    //   209: ldc 102
    //   211: invokespecial 95	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   214: astore 8
    //   216: aload 8
    //   218: aload_0
    //   219: invokevirtual 59	java/lang/Class:getCanonicalName	()Ljava/lang/String;
    //   222: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: pop
    //   226: aload 8
    //   228: ldc 104
    //   230: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   233: pop
    //   234: aload 8
    //   236: aload 7
    //   238: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   241: pop
    //   242: aload 8
    //   244: ldc 106
    //   246: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   249: pop
    //   250: new 97	java/lang/RuntimeException
    //   253: dup
    //   254: aload 8
    //   256: invokevirtual 82	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   259: invokespecial 98	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   262: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   71	78	137	java/lang/InstantiationException
    //   85	124	137	java/lang/InstantiationException
    //   124	134	137	java/lang/InstantiationException
    //   71	78	171	java/lang/IllegalAccessException
    //   85	124	171	java/lang/IllegalAccessException
    //   124	134	171	java/lang/IllegalAccessException
    //   71	78	205	java/lang/ClassNotFoundException
    //   85	124	205	java/lang/ClassNotFoundException
    //   124	134	205	java/lang/ClassNotFoundException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.e
 * JD-Core Version:    0.6.2
 */