package androidx.i;

import android.content.Context;
import androidx.j.a.c.c;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

public final class a
{
  public final c.c a;
  public final Context b;
  public final String c;
  public final f.d d;
  public final List<f.b> e;
  public final boolean f;
  public final f.c g;
  public final Executor h;
  public final boolean i;
  final Set<Integer> j;

  static
  {
    CoverageLogger.Log(82046976);
  }

  public a(Context paramContext, String paramString, c.c paramc, f.d paramd, List<f.b> paramList, boolean paramBoolean1, f.c paramc1, Executor paramExecutor, boolean paramBoolean2, Set<Integer> paramSet)
  {
    this.a = paramc;
    this.b = paramContext;
    this.c = paramString;
    this.d = paramd;
    this.e = paramList;
    this.f = paramBoolean1;
    this.g = paramc1;
    this.h = paramExecutor;
    this.i = paramBoolean2;
    this.j = paramSet;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.a
 * JD-Core Version:    0.6.2
 */