package androidx.i;

import android.database.Cursor;
import androidx.j.a.c;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Arrays;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public final class d
{
  private static final String[] k = { "UPDATE", "DELETE", "INSERT" };
  androidx.c.a<String, Integer> a;
  long[] b;
  Object[] c = new Object[1];
  long d;
  final f e;
  AtomicBoolean f;
  volatile boolean g;
  volatile androidx.j.a.f h;
  final androidx.a.a.b.b<Object, b> i;
  Runnable j;
  private String[] l;
  private a m;

  static
  {
    CoverageLogger.Log(82092032);
  }

  public d(f paramf, String[] paramArrayOfString)
  {
    int n = 0;
    this.f = new AtomicBoolean(false);
    this.g = false;
    this.i = new androidx.a.a.b.b();
    this.j = new Runnable()
    {
      static
      {
        CoverageLogger.Log(82089984);
      }

      private boolean a()
      {
        f localf = d.this.e;
        Object[] arrayOfObject = d.this.c;
        Cursor localCursor = localf.c.a().a(new androidx.j.a.a("SELECT * FROM room_table_modification_log WHERE version  > ? ORDER BY version ASC;", arrayOfObject));
        boolean bool = false;
        try
        {
          while (localCursor.moveToNext())
          {
            long l = localCursor.getLong(0);
            int i = localCursor.getInt(1);
            d.this.b[i] = l;
            d.this.d = l;
            bool = true;
          }
          localCursor.close();
          return bool;
        }
        finally
        {
          localCursor.close();
        }
        while (true)
          throw localObject;
      }

      // ERROR //
      public final void run()
      {
        // Byte code:
        //   0: aload_0
        //   1: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   4: getfield 30	androidx/i/d:e	Landroidx/i/f;
        //   7: getfield 89	androidx/i/f:g	Ljava/util/concurrent/locks/ReentrantLock;
        //   10: astore_1
        //   11: aload_1
        //   12: invokeinterface 94 1 0
        //   17: aload_0
        //   18: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   21: astore 15
        //   23: aload 15
        //   25: getfield 30	androidx/i/d:e	Landroidx/i/f;
        //   28: getfield 97	androidx/i/f:a	Landroidx/j/a/b;
        //   31: astore 16
        //   33: aload 16
        //   35: ifnull +438 -> 473
        //   38: aload 16
        //   40: invokeinterface 99 1 0
        //   45: ifeq +428 -> 473
        //   48: iconst_1
        //   49: istore 17
        //   51: goto +425 -> 476
        //   54: aload 15
        //   56: getfield 102	androidx/i/d:g	Z
        //   59: ifne +17 -> 76
        //   62: aload 15
        //   64: getfield 30	androidx/i/d:e	Landroidx/i/f;
        //   67: getfield 39	androidx/i/f:c	Landroidx/j/a/c;
        //   70: invokeinterface 44 1 0
        //   75: pop
        //   76: aload 15
        //   78: getfield 102	androidx/i/d:g	Z
        //   81: istore 18
        //   83: iload 18
        //   85: ifne +6 -> 91
        //   88: goto +393 -> 481
        //   91: iconst_1
        //   92: istore 19
        //   94: iload 19
        //   96: ifne +10 -> 106
        //   99: aload_1
        //   100: invokeinterface 105 1 0
        //   105: return
        //   106: aload_0
        //   107: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   110: getfield 109	androidx/i/d:f	Ljava/util/concurrent/atomic/AtomicBoolean;
        //   113: iconst_1
        //   114: iconst_0
        //   115: invokevirtual 115	java/util/concurrent/atomic/AtomicBoolean:compareAndSet	(ZZ)Z
        //   118: istore 20
        //   120: iload 20
        //   122: ifne +10 -> 132
        //   125: aload_1
        //   126: invokeinterface 105 1 0
        //   131: return
        //   132: aload_0
        //   133: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   136: getfield 30	androidx/i/d:e	Landroidx/i/f;
        //   139: invokevirtual 117	androidx/i/f:f	()Z
        //   142: istore 21
        //   144: iload 21
        //   146: ifeq +10 -> 156
        //   149: aload_1
        //   150: invokeinterface 105 1 0
        //   155: return
        //   156: aload_0
        //   157: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   160: getfield 121	androidx/i/d:h	Landroidx/j/a/f;
        //   163: invokeinterface 126 1 0
        //   168: pop
        //   169: aload_0
        //   170: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   173: getfield 34	androidx/i/d:c	[Ljava/lang/Object;
        //   176: iconst_0
        //   177: aload_0
        //   178: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   181: getfield 77	androidx/i/d:d	J
        //   184: invokestatic 132	java/lang/Long:valueOf	(J)Ljava/lang/Long;
        //   187: aastore
        //   188: aload_0
        //   189: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   192: getfield 30	androidx/i/d:e	Landroidx/i/f;
        //   195: getfield 134	androidx/i/f:e	Z
        //   198: ifeq +59 -> 257
        //   201: aload_0
        //   202: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   205: getfield 30	androidx/i/d:e	Landroidx/i/f;
        //   208: getfield 39	androidx/i/f:c	Landroidx/j/a/c;
        //   211: invokeinterface 44 1 0
        //   216: astore 24
        //   218: aload 24
        //   220: invokeinterface 136 1 0
        //   225: aload_0
        //   226: invokespecial 138	androidx/i/d$1:a	()Z
        //   229: istore_2
        //   230: aload 24
        //   232: invokeinterface 140 1 0
        //   237: aload 24
        //   239: invokeinterface 142 1 0
        //   244: goto +37 -> 281
        //   247: aload 24
        //   249: invokeinterface 142 1 0
        //   254: aload 25
        //   256: athrow
        //   257: aload_0
        //   258: invokespecial 138	androidx/i/d$1:a	()Z
        //   261: istore_2
        //   262: goto +19 -> 281
        //   265: astore 14
        //   267: aload_1
        //   268: invokeinterface 105 1 0
        //   273: aload 14
        //   275: athrow
        //   276: iconst_0
        //   277: istore_2
        //   278: goto +4 -> 282
        //   281: pop
        //   282: aload_1
        //   283: invokeinterface 105 1 0
        //   288: iload_2
        //   289: ifeq +183 -> 472
        //   292: aload_0
        //   293: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   296: getfield 146	androidx/i/d:i	Landroidx/a/a/b/b;
        //   299: astore_3
        //   300: aload_3
        //   301: monitorenter
        //   302: aload_0
        //   303: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   306: getfield 146	androidx/i/d:i	Landroidx/a/a/b/b;
        //   309: invokevirtual 152	androidx/a/a/b/b:iterator	()Ljava/util/Iterator;
        //   312: astore 5
        //   314: aload 5
        //   316: invokeinterface 157 1 0
        //   321: ifeq +141 -> 462
        //   324: aload 5
        //   326: invokeinterface 161 1 0
        //   331: checkcast 163	java/util/Map$Entry
        //   334: invokeinterface 166 1 0
        //   339: checkcast 168	androidx/i/d$b
        //   342: astore 6
        //   344: aload_0
        //   345: getfield 23	androidx/i/d$1:a	Landroidx/i/d;
        //   348: getfield 73	androidx/i/d:b	[J
        //   351: astore 7
        //   353: aload 6
        //   355: getfield 171	androidx/i/d$b:a	[I
        //   358: arraylength
        //   359: istore 8
        //   361: aconst_null
        //   362: astore 9
        //   364: iconst_0
        //   365: istore 10
        //   367: iload 10
        //   369: iload 8
        //   371: if_icmpge -57 -> 314
        //   374: aload 7
        //   376: aload 6
        //   378: getfield 171	androidx/i/d$b:a	[I
        //   381: iload 10
        //   383: iaload
        //   384: laload
        //   385: lstore 11
        //   387: aload 6
        //   389: getfield 173	androidx/i/d$b:c	[J
        //   392: iload 10
        //   394: laload
        //   395: lload 11
        //   397: lcmp
        //   398: ifge +101 -> 499
        //   401: aload 6
        //   403: getfield 173	androidx/i/d$b:c	[J
        //   406: iload 10
        //   408: lload 11
        //   410: lastore
        //   411: iload 8
        //   413: iconst_1
        //   414: if_icmpne +13 -> 427
        //   417: aload 6
        //   419: getfield 176	androidx/i/d$b:d	Ljava/util/Set;
        //   422: astore 9
        //   424: goto +75 -> 499
        //   427: aload 9
        //   429: ifnonnull +14 -> 443
        //   432: new 178	androidx/c/b
        //   435: dup
        //   436: iload 8
        //   438: invokespecial 180	androidx/c/b:<init>	(I)V
        //   441: astore 9
        //   443: aload 9
        //   445: aload 6
        //   447: getfield 183	androidx/i/d$b:b	[Ljava/lang/String;
        //   450: iload 10
        //   452: aaload
        //   453: invokeinterface 189 2 0
        //   458: pop
        //   459: goto +40 -> 499
        //   462: aload_3
        //   463: monitorexit
        //   464: return
        //   465: astore 4
        //   467: aload_3
        //   468: monitorexit
        //   469: aload 4
        //   471: athrow
        //   472: return
        //   473: iconst_0
        //   474: istore 17
        //   476: iload 17
        //   478: ifne -424 -> 54
        //   481: iconst_0
        //   482: istore 19
        //   484: goto -390 -> 94
        //   487: astore 25
        //   489: goto -242 -> 247
        //   492: astore 25
        //   494: iconst_0
        //   495: istore_2
        //   496: goto -249 -> 247
        //   499: iinc 10 1
        //   502: goto -135 -> 367
        //
        // Exception table:
        //   from	to	target	type
        //   11	33	265	finally
        //   38	48	265	finally
        //   54	76	265	finally
        //   76	83	265	finally
        //   106	120	265	finally
        //   132	144	265	finally
        //   156	218	265	finally
        //   237	244	265	finally
        //   247	257	265	finally
        //   257	262	265	finally
        //   11	33	276	java/lang/IllegalStateException
        //   11	33	276	android/database/sqlite/SQLiteException
        //   38	48	276	java/lang/IllegalStateException
        //   38	48	276	android/database/sqlite/SQLiteException
        //   54	76	276	java/lang/IllegalStateException
        //   54	76	276	android/database/sqlite/SQLiteException
        //   76	83	276	java/lang/IllegalStateException
        //   76	83	276	android/database/sqlite/SQLiteException
        //   106	120	276	java/lang/IllegalStateException
        //   106	120	276	android/database/sqlite/SQLiteException
        //   132	144	276	java/lang/IllegalStateException
        //   132	144	276	android/database/sqlite/SQLiteException
        //   156	218	276	java/lang/IllegalStateException
        //   156	218	276	android/database/sqlite/SQLiteException
        //   257	262	276	java/lang/IllegalStateException
        //   257	262	276	android/database/sqlite/SQLiteException
        //   237	244	281	java/lang/IllegalStateException
        //   237	244	281	android/database/sqlite/SQLiteException
        //   247	257	281	java/lang/IllegalStateException
        //   247	257	281	android/database/sqlite/SQLiteException
        //   302	314	465	finally
        //   314	361	465	finally
        //   374	411	465	finally
        //   417	424	465	finally
        //   432	443	465	finally
        //   443	459	465	finally
        //   462	464	465	finally
        //   467	469	465	finally
        //   230	237	487	finally
        //   218	230	492	finally
      }
    };
    this.e = paramf;
    this.m = new a(paramArrayOfString.length);
    this.a = new androidx.c.a();
    int i1 = paramArrayOfString.length;
    this.l = new String[i1];
    while (n < i1)
    {
      String str = paramArrayOfString[n].toLowerCase(Locale.US);
      this.a.put(str, Integer.valueOf(n));
      this.l[n] = str;
      n++;
    }
    this.b = new long[paramArrayOfString.length];
    Arrays.fill(this.b, 0L);
  }

  private void a(androidx.j.a.b paramb, int paramInt)
  {
    String str1 = this.l[paramInt];
    StringBuilder localStringBuilder = new StringBuilder();
    for (String str2 : k)
    {
      localStringBuilder.setLength(0);
      localStringBuilder.append("DROP TRIGGER IF EXISTS ");
      a(localStringBuilder, str1, str2);
      paramb.c(localStringBuilder.toString());
    }
  }

  private static void a(StringBuilder paramStringBuilder, String paramString1, String paramString2)
  {
    paramStringBuilder.append("`room_table_modification_trigger_");
    paramStringBuilder.append(paramString1);
    paramStringBuilder.append("_");
    paramStringBuilder.append(paramString2);
    paramStringBuilder.append("`");
  }

  private void b(androidx.j.a.b paramb, int paramInt)
  {
    String str1 = this.l[paramInt];
    StringBuilder localStringBuilder = new StringBuilder();
    for (String str2 : k)
    {
      localStringBuilder.setLength(0);
      localStringBuilder.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
      a(localStringBuilder, str1, str2);
      localStringBuilder.append(" AFTER ");
      localStringBuilder.append(str2);
      localStringBuilder.append(" ON `");
      localStringBuilder.append(str1);
      localStringBuilder.append("` BEGIN INSERT OR REPLACE INTO room_table_modification_log");
      localStringBuilder.append(" VALUES(null, ");
      localStringBuilder.append(paramInt);
      localStringBuilder.append("); END");
      paramb.c(localStringBuilder.toString());
    }
  }

  // ERROR //
  final void a(androidx.j.a.b paramb)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface 174 1 0
    //   6: ifeq +4 -> 10
    //   9: return
    //   10: aload_0
    //   11: getfield 79	androidx/i/d:e	Landroidx/i/f;
    //   14: getfield 179	androidx/i/f:g	Ljava/util/concurrent/locks/ReentrantLock;
    //   17: astore_2
    //   18: aload_2
    //   19: invokeinterface 184 1 0
    //   24: aload_0
    //   25: getfield 85	androidx/i/d:m	Landroidx/i/d$a;
    //   28: invokevirtual 187	androidx/i/d$a:a	()[I
    //   31: astore 4
    //   33: aload 4
    //   35: ifnonnull +10 -> 45
    //   38: aload_2
    //   39: invokeinterface 190 1 0
    //   44: return
    //   45: aload 4
    //   47: arraylength
    //   48: istore 5
    //   50: aload_1
    //   51: invokeinterface 192 1 0
    //   56: iconst_0
    //   57: istore 7
    //   59: iload 7
    //   61: iload 5
    //   63: if_icmpge +45 -> 108
    //   66: aload 4
    //   68: iload 7
    //   70: iaload
    //   71: istore 8
    //   73: iload 8
    //   75: iconst_1
    //   76: if_icmpeq +22 -> 98
    //   79: iload 8
    //   81: iconst_2
    //   82: if_icmpeq +6 -> 88
    //   85: goto +72 -> 157
    //   88: aload_0
    //   89: aload_1
    //   90: iload 7
    //   92: invokespecial 194	androidx/i/d:a	(Landroidx/j/a/b;I)V
    //   95: goto +62 -> 157
    //   98: aload_0
    //   99: aload_1
    //   100: iload 7
    //   102: invokespecial 196	androidx/i/d:b	(Landroidx/j/a/b;I)V
    //   105: goto +52 -> 157
    //   108: aload_1
    //   109: invokeinterface 198 1 0
    //   114: aload_1
    //   115: invokeinterface 200 1 0
    //   120: aload_0
    //   121: getfield 85	androidx/i/d:m	Landroidx/i/d$a;
    //   124: invokevirtual 201	androidx/i/d$a:b	()V
    //   127: aload_2
    //   128: invokeinterface 190 1 0
    //   133: goto -123 -> 10
    //   136: astore 6
    //   138: aload_1
    //   139: invokeinterface 200 1 0
    //   144: aload 6
    //   146: athrow
    //   147: astore_3
    //   148: aload_2
    //   149: invokeinterface 190 1 0
    //   154: aload_3
    //   155: athrow
    //   156: return
    //   157: iinc 7 1
    //   160: goto -101 -> 59
    //
    // Exception table:
    //   from	to	target	type
    //   50	56	136	finally
    //   66	73	136	finally
    //   88	95	136	finally
    //   98	105	136	finally
    //   108	114	136	finally
    //   24	33	147	finally
    //   45	50	147	finally
    //   114	127	147	finally
    //   138	147	147	finally
    //   10	24	156	java/lang/IllegalStateException
    //   10	24	156	android/database/sqlite/SQLiteException
    //   38	44	156	java/lang/IllegalStateException
    //   38	44	156	android/database/sqlite/SQLiteException
    //   127	133	156	java/lang/IllegalStateException
    //   127	133	156	android/database/sqlite/SQLiteException
    //   148	156	156	java/lang/IllegalStateException
    //   148	156	156	android/database/sqlite/SQLiteException
  }

  static final class a
  {
    final long[] a;
    final boolean[] b;
    final int[] c;
    boolean d;
    boolean e;

    static
    {
      CoverageLogger.Log(82040832);
    }

    a(int paramInt)
    {
      this.a = new long[paramInt];
      this.b = new boolean[paramInt];
      this.c = new int[paramInt];
      Arrays.fill(this.a, 0L);
      Arrays.fill(this.b, false);
    }

    final int[] a()
    {
      try
      {
        if ((this.d) && (!this.e))
        {
          int i = this.a.length;
          for (int j = 0; ; j++)
          {
            k = 1;
            if (j >= i)
              break;
            if (this.a[j] <= 0L)
              break label144;
            m = 1;
            if (m != this.b[j])
            {
              int[] arrayOfInt1 = this.c;
              if (m == 0)
                break label150;
              arrayOfInt1[j] = k;
            }
            else
            {
              this.c[j] = 0;
            }
            this.b[j] = m;
          }
          this.e = k;
          this.d = false;
          int[] arrayOfInt2 = this.c;
          return arrayOfInt2;
        }
        return null;
      }
      finally
      {
        while (true)
        {
          while (true)
            throw localObject;
          label144: int m = 0;
          continue;
          label150: int k = 2;
        }
      }
    }

    final void b()
    {
      try
      {
        this.e = false;
        return;
      }
      finally
      {
      }
    }
  }

  static final class b
  {
    final int[] a;
    final String[] b;
    final long[] c;
    final Set<String> d;

    static
    {
      CoverageLogger.Log(82094080);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.d
 * JD-Core Version:    0.6.2
 */