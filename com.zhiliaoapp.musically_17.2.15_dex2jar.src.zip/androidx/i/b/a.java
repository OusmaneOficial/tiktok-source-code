package androidx.i.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  public static final String[] a = new String[0];

  static
  {
    CoverageLogger.Log(82155520);
  }

  public static void a(StringBuilder paramStringBuilder, int paramInt)
  {
    for (int i = 0; i < paramInt; i++)
    {
      paramStringBuilder.append("?");
      if (i < paramInt - 1)
        paramStringBuilder.append(",");
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.b.a
 * JD-Core Version:    0.6.2
 */