package androidx.i.b;

import android.database.Cursor;
import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public final class b
{
  public final String a;
  public final Map<String, a> b;
  public final Set<b> c;
  public final Set<d> d;

  static
  {
    CoverageLogger.Log(82006016);
  }

  public b(String paramString, Map<String, a> paramMap, Set<b> paramSet, Set<d> paramSet1)
  {
    this.a = paramString;
    this.b = Collections.unmodifiableMap(paramMap);
    this.c = Collections.unmodifiableSet(paramSet);
    Set localSet;
    if (paramSet1 == null)
      localSet = null;
    else
      localSet = Collections.unmodifiableSet(paramSet1);
    this.d = localSet;
  }

  private static d a(androidx.j.a.b paramb, String paramString, boolean paramBoolean)
  {
    StringBuilder localStringBuilder = new StringBuilder("PRAGMA index_xinfo(`");
    localStringBuilder.append(paramString);
    localStringBuilder.append("`)");
    Cursor localCursor = paramb.b(localStringBuilder.toString());
    try
    {
      int i = localCursor.getColumnIndex("seqno");
      int j = localCursor.getColumnIndex("cid");
      int k = localCursor.getColumnIndex("name");
      if ((i != -1) && (j != -1) && (k != -1))
      {
        TreeMap localTreeMap = new TreeMap();
        while (localCursor.moveToNext())
          if (localCursor.getInt(j) >= 0)
          {
            int m = localCursor.getInt(i);
            String str = localCursor.getString(k);
            localTreeMap.put(Integer.valueOf(m), str);
          }
        ArrayList localArrayList = new ArrayList(localTreeMap.size());
        localArrayList.addAll(localTreeMap.values());
        d locald = new d(paramString, paramBoolean, localArrayList);
        localCursor.close();
        return locald;
      }
      localCursor.close();
      return null;
    }
    finally
    {
      localCursor.close();
    }
    while (true)
      throw localObject;
  }

  public static b a(androidx.j.a.b paramb, String paramString)
  {
    return new b(paramString, c(paramb, paramString), b(paramb, paramString), d(paramb, paramString));
  }

  private static List<c> a(Cursor paramCursor)
  {
    int i = paramCursor.getColumnIndex("id");
    int j = paramCursor.getColumnIndex("seq");
    int k = paramCursor.getColumnIndex("from");
    int m = paramCursor.getColumnIndex("to");
    int n = paramCursor.getCount();
    ArrayList localArrayList = new ArrayList();
    for (int i1 = 0; i1 < n; i1++)
    {
      paramCursor.moveToPosition(i1);
      localArrayList.add(new c(paramCursor.getInt(i), paramCursor.getInt(j), paramCursor.getString(k), paramCursor.getString(m)));
    }
    Collections.sort(localArrayList);
    return localArrayList;
  }

  private static Set<b> b(androidx.j.a.b paramb, String paramString)
  {
    HashSet localHashSet = new HashSet();
    StringBuilder localStringBuilder = new StringBuilder("PRAGMA foreign_key_list(`");
    localStringBuilder.append(paramString);
    localStringBuilder.append("`)");
    Cursor localCursor = paramb.b(localStringBuilder.toString());
    try
    {
      int i = localCursor.getColumnIndex("id");
      int j = localCursor.getColumnIndex("seq");
      int k = localCursor.getColumnIndex("table");
      int m = localCursor.getColumnIndex("on_delete");
      int n = localCursor.getColumnIndex("on_update");
      List localList = a(localCursor);
      int i1 = localCursor.getCount();
      for (int i2 = 0; i2 < i1; i2++)
      {
        localCursor.moveToPosition(i2);
        if (localCursor.getInt(j) == 0)
        {
          int i3 = localCursor.getInt(i);
          ArrayList localArrayList1 = new ArrayList();
          ArrayList localArrayList2 = new ArrayList();
          Iterator localIterator = localList.iterator();
          while (localIterator.hasNext())
          {
            c localc = (c)localIterator.next();
            if (localc.a == i3)
            {
              localArrayList1.add(localc.c);
              localArrayList2.add(localc.d);
            }
          }
          b localb = new b(localCursor.getString(k), localCursor.getString(m), localCursor.getString(n), localArrayList1, localArrayList2);
          localHashSet.add(localb);
        }
      }
      localCursor.close();
      return localHashSet;
    }
    finally
    {
      localCursor.close();
    }
    while (true)
      throw localObject;
  }

  private static Map<String, a> c(androidx.j.a.b paramb, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder("PRAGMA table_info(`");
    localStringBuilder.append(paramString);
    localStringBuilder.append("`)");
    Cursor localCursor = paramb.b(localStringBuilder.toString());
    HashMap localHashMap = new HashMap();
    try
    {
      if (localCursor.getColumnCount() > 0)
      {
        int i = localCursor.getColumnIndex("name");
        int j = localCursor.getColumnIndex("type");
        int k = localCursor.getColumnIndex("notnull");
        int m = localCursor.getColumnIndex("pk");
        while (localCursor.moveToNext())
        {
          String str1 = localCursor.getString(i);
          String str2 = localCursor.getString(j);
          if (localCursor.getInt(k) == 0)
            break label211;
          bool = true;
          localHashMap.put(str1, new a(str1, str2, bool, localCursor.getInt(m)));
        }
      }
      localCursor.close();
      return localHashMap;
    }
    finally
    {
      while (true)
      {
        localCursor.close();
        while (true)
          throw localObject;
        label211: boolean bool = false;
      }
    }
  }

  private static Set<d> d(androidx.j.a.b paramb, String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder("PRAGMA index_list(`");
    localStringBuilder.append(paramString);
    localStringBuilder.append("`)");
    Cursor localCursor = paramb.b(localStringBuilder.toString());
    try
    {
      int i = localCursor.getColumnIndex("name");
      int j = localCursor.getColumnIndex("origin");
      int k = localCursor.getColumnIndex("unique");
      if ((i != -1) && (j != -1) && (k != -1))
      {
        HashSet localHashSet = new HashSet();
        while (localCursor.moveToNext())
          if ("c".equals(localCursor.getString(j)))
          {
            String str = localCursor.getString(i);
            int m = localCursor.getInt(k);
            int n = 1;
            if (m != n)
              break label232;
            d locald = a(paramb, str, n);
            if (locald == null)
            {
              localCursor.close();
              return null;
            }
            localHashSet.add(locald);
          }
        localCursor.close();
        return localHashSet;
      }
      localCursor.close();
      return null;
    }
    finally
    {
      while (true)
      {
        localCursor.close();
        while (true)
          throw localObject;
        label232: int i1 = 0;
      }
    }
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass())
        return false;
      b localb = (b)paramObject;
      String str = this.a;
      if (str != null)
      {
        if (!str.equals(localb.a))
          return false;
      }
      else if (localb.a != null)
        return false;
      Map localMap = this.b;
      if (localMap != null)
      {
        if (!localMap.equals(localb.b))
          return false;
      }
      else if (localb.b != null)
        return false;
      Set localSet1 = this.c;
      if (localSet1 != null)
      {
        if (!localSet1.equals(localb.c))
          return false;
      }
      else if (localb.c != null)
        return false;
      Set localSet2 = this.d;
      if (localSet2 != null)
      {
        Set localSet3 = localb.d;
        if (localSet3 == null)
          return true;
        return localSet2.equals(localSet3);
      }
      return true;
    }
    return false;
  }

  public final int hashCode()
  {
    String str = this.a;
    int i;
    if (str != null)
      i = str.hashCode();
    else
      i = 0;
    int j = i * 31;
    Map localMap = this.b;
    int k;
    if (localMap != null)
      k = localMap.hashCode();
    else
      k = 0;
    int m = 31 * (j + k);
    Set localSet = this.c;
    int n = 0;
    if (localSet != null)
      n = localSet.hashCode();
    return m + n;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("TableInfo{name='");
    localStringBuilder.append(this.a);
    localStringBuilder.append('\'');
    localStringBuilder.append(", columns=");
    localStringBuilder.append(this.b);
    localStringBuilder.append(", foreignKeys=");
    localStringBuilder.append(this.c);
    localStringBuilder.append(", indices=");
    localStringBuilder.append(this.d);
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }

  public static final class a
  {
    public final String a;
    public final String b;
    public final int c;
    public final boolean d;
    public final int e;

    static
    {
      CoverageLogger.Log(82008064);
    }

    public a(String paramString1, String paramString2, boolean paramBoolean, int paramInt)
    {
      this.a = paramString1;
      this.b = paramString2;
      this.d = paramBoolean;
      this.e = paramInt;
      int i = 5;
      if (paramString2 != null)
      {
        String str = paramString2.toUpperCase(Locale.US);
        if (str.contains("INT"))
          i = 3;
        else if ((!str.contains("CHAR")) && (!str.contains("CLOB")) && (!str.contains("TEXT")))
        {
          if (!str.contains("BLOB"))
            if ((!str.contains("REAL")) && (!str.contains("FLOA")) && (!str.contains("DOUB")))
              i = 1;
            else
              i = 4;
        }
        else
          i = 2;
      }
      this.c = i;
    }

    private boolean a()
    {
      return this.e > 0;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject != null)
      {
        if (getClass() != paramObject.getClass())
          return false;
        a locala = (a)paramObject;
        if (Build.VERSION.SDK_INT >= 20)
        {
          if (this.e != locala.e)
            return false;
        }
        else if (a() != locala.a())
          return false;
        if (!this.a.equals(locala.a))
          return false;
        if (this.d != locala.d)
          return false;
        if (this.c == locala.c)
          return true;
      }
      return false;
    }

    public final int hashCode()
    {
      int i = 31 * (31 * this.a.hashCode() + this.c);
      int j;
      if (this.d)
        j = 1231;
      else
        j = 1237;
      return 31 * (i + j) + this.e;
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("Column{name='");
      localStringBuilder.append(this.a);
      localStringBuilder.append('\'');
      localStringBuilder.append(", type='");
      localStringBuilder.append(this.b);
      localStringBuilder.append('\'');
      localStringBuilder.append(", affinity='");
      localStringBuilder.append(this.c);
      localStringBuilder.append('\'');
      localStringBuilder.append(", notNull=");
      localStringBuilder.append(this.d);
      localStringBuilder.append(", primaryKeyPosition=");
      localStringBuilder.append(this.e);
      localStringBuilder.append('}');
      return localStringBuilder.toString();
    }
  }

  public static final class b
  {
    public final String a;
    public final String b;
    public final String c;
    public final List<String> d;
    public final List<String> e;

    static
    {
      CoverageLogger.Log(82157568);
    }

    public b(String paramString1, String paramString2, String paramString3, List<String> paramList1, List<String> paramList2)
    {
      this.a = paramString1;
      this.b = paramString2;
      this.c = paramString3;
      this.d = Collections.unmodifiableList(paramList1);
      this.e = Collections.unmodifiableList(paramList2);
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject != null)
      {
        if (getClass() != paramObject.getClass())
          return false;
        b localb = (b)paramObject;
        if (!this.a.equals(localb.a))
          return false;
        if (!this.b.equals(localb.b))
          return false;
        if (!this.c.equals(localb.c))
          return false;
        if (!this.d.equals(localb.d))
          return false;
        return this.e.equals(localb.e);
      }
      return false;
    }

    public final int hashCode()
    {
      return 31 * (31 * (31 * (31 * this.a.hashCode() + this.b.hashCode()) + this.c.hashCode()) + this.d.hashCode()) + this.e.hashCode();
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("ForeignKey{referenceTable='");
      localStringBuilder.append(this.a);
      localStringBuilder.append('\'');
      localStringBuilder.append(", onDelete='");
      localStringBuilder.append(this.b);
      localStringBuilder.append('\'');
      localStringBuilder.append(", onUpdate='");
      localStringBuilder.append(this.c);
      localStringBuilder.append('\'');
      localStringBuilder.append(", columnNames=");
      localStringBuilder.append(this.d);
      localStringBuilder.append(", referenceColumnNames=");
      localStringBuilder.append(this.e);
      localStringBuilder.append('}');
      return localStringBuilder.toString();
    }
  }

  static final class c
    implements Comparable<c>
  {
    final int a;
    final int b;
    final String c;
    final String d;

    static
    {
      CoverageLogger.Log(82161664);
    }

    c(int paramInt1, int paramInt2, String paramString1, String paramString2)
    {
      this.a = paramInt1;
      this.b = paramInt2;
      this.c = paramString1;
      this.d = paramString2;
    }
  }

  public static final class d
  {
    public final String a;
    public final boolean b;
    public final List<String> c;

    static
    {
      CoverageLogger.Log(82001920);
    }

    public d(String paramString, boolean paramBoolean, List<String> paramList)
    {
      this.a = paramString;
      this.b = paramBoolean;
      this.c = paramList;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject != null)
      {
        if (getClass() != paramObject.getClass())
          return false;
        d locald = (d)paramObject;
        if (this.b != locald.b)
          return false;
        if (!this.c.equals(locald.c))
          return false;
        if (this.a.startsWith("index_"))
          return locald.a.startsWith("index_");
        return this.a.equals(locald.a);
      }
      return false;
    }

    public final int hashCode()
    {
      int i;
      if (this.a.startsWith("index_"))
        i = "index_".hashCode();
      else
        i = this.a.hashCode();
      return 31 * (i * 31 + this.b) + this.c.hashCode();
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("Index{name='");
      localStringBuilder.append(this.a);
      localStringBuilder.append('\'');
      localStringBuilder.append(", unique=");
      localStringBuilder.append(this.b);
      localStringBuilder.append(", columns=");
      localStringBuilder.append(this.c);
      localStringBuilder.append('}');
      return localStringBuilder.toString();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.b.b
 * JD-Core Version:    0.6.2
 */