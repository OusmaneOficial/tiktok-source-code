package androidx.i;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class j
{
  private final AtomicBoolean a = new AtomicBoolean(false);
  private final f b;
  private volatile androidx.j.a.f c;

  static
  {
    CoverageLogger.Log(82143232);
  }

  public j(f paramf)
  {
    this.b = paramf;
  }

  private androidx.j.a.f c()
  {
    String str = a();
    return this.b.a(str);
  }

  protected abstract String a();

  public final void a(androidx.j.a.f paramf)
  {
    if (paramf == this.c)
      this.a.set(false);
  }

  public final androidx.j.a.f b()
  {
    this.b.b();
    if (this.a.compareAndSet(false, true))
    {
      if (this.c == null)
        this.c = c();
      return this.c;
    }
    return c();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.i.j
 * JD-Core Version:    0.6.2
 */