package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class u
{
  public final RecyclerView.i a;
  int b = -2147483648;
  final Rect c = new Rect();

  static
  {
    CoverageLogger.Log(115007488);
  }

  private u(RecyclerView.i parami)
  {
    this.a = parami;
  }

  public static u a(RecyclerView.i parami)
  {
    // Byte code:
    //   0: new 39	androidx/recyclerview/widget/u$1
    //   3: dup
    //   4: aload_0
    //   5: invokespecial 40	androidx/recyclerview/widget/u$1:<init>	(Landroidx/recyclerview/widget/RecyclerView$i;)V
    //   8: areturn
  }

  public static u a(RecyclerView.i parami, int paramInt)
  {
    if (paramInt != 0)
    {
      if (paramInt == 1)
        return b(parami);
      throw new IllegalArgumentException("invalid orientation");
    }
    return a(parami);
  }

  public static u b(RecyclerView.i parami)
  {
    // Byte code:
    //   0: new 54	androidx/recyclerview/widget/u$2
    //   3: dup
    //   4: aload_0
    //   5: invokespecial 55	androidx/recyclerview/widget/u$2:<init>	(Landroidx/recyclerview/widget/RecyclerView$i;)V
    //   8: areturn
  }

  public final int a()
  {
    if (-2147483648 == this.b)
      return 0;
    return e() - this.b;
  }

  public abstract int a(View paramView);

  public abstract void a(int paramInt);

  public abstract int b();

  public abstract int b(View paramView);

  public abstract int c();

  public abstract int c(View paramView);

  public abstract int d();

  public abstract int d(View paramView);

  public abstract int e();

  public abstract int e(View paramView);

  public abstract int f();

  public abstract int f(View paramView);

  public abstract int g();

  public abstract int h();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.u
 * JD-Core Version:    0.6.2
 */