package androidx.recyclerview.widget;

import android.os.Handler;
import android.os.Looper;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executor;

public final class d<T>
{
  private static final Executor g = new a();
  final s a;
  final c<T> b;
  final Executor c;
  List<T> d;
  public List<T> e = Collections.emptyList();
  int f;

  static
  {
    CoverageLogger.Log(114817024);
  }

  public d(s params, c<T> paramc)
  {
    this.a = params;
    this.b = paramc;
    if (paramc.a != null)
    {
      this.c = paramc.a;
      return;
    }
    this.c = g;
  }

  static final class a
    implements Executor
  {
    final Handler a = new Handler(Looper.getMainLooper());

    static
    {
      CoverageLogger.Log(114819072);
    }

    public final void execute(Runnable paramRunnable)
    {
      this.a.post(paramRunnable);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.d
 * JD-Core Version:    0.6.2
 */