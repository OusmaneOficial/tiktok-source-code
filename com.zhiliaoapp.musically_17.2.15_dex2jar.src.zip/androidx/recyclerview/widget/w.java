package androidx.recyclerview.widget;

import com.ss.android.ugc.aweme.app.q;
import com.ss.android.ugc.aweme.framework.a.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import org.json.JSONException;
import org.json.JSONObject;

public final class w
{
  static
  {
    CoverageLogger.Log(1323008);
  }

  public static RecyclerView.v a(RecyclerView.o paramo, int paramInt, boolean paramBoolean, long paramLong)
  {
    try
    {
      RecyclerView.v localv = paramo.b(paramInt, paramBoolean, paramLong);
      return localv;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
      JSONObject localJSONObject1 = new JSONObject();
      try
      {
        JSONObject localJSONObject2 = new JSONObject();
        localJSONObject2.put("error", localIndexOutOfBoundsException.toString());
        localJSONObject1.put("success", 1);
        localJSONObject1.put("errorResponse", localJSONObject2.toString());
      }
      catch (JSONException localJSONException)
      {
      }
      q.a("aweme_profile_recyclerview_crash_log", localJSONObject1);
      a.a(localIndexOutOfBoundsException);
    }
    return null;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.w
 * JD-Core Version:    0.6.2
 */