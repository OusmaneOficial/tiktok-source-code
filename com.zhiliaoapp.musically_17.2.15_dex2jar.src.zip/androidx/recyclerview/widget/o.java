package androidx.recyclerview.widget;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class o
{
  boolean a = true;
  int b;
  int c;
  int d;
  int e;
  int f;
  int g;
  boolean h;
  boolean i;

  static
  {
    CoverageLogger.Log(114976768);
  }

  final View a(RecyclerView.o paramo)
  {
    View localView = paramo.b(this.c);
    this.c += this.d;
    return localView;
  }

  final boolean a(RecyclerView.s params)
  {
    int j = this.c;
    return (j >= 0) && (j < params.a());
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("LayoutState{mAvailable=");
    localStringBuilder.append(this.b);
    localStringBuilder.append(", mCurrentPosition=");
    localStringBuilder.append(this.c);
    localStringBuilder.append(", mItemDirection=");
    localStringBuilder.append(this.d);
    localStringBuilder.append(", mLayoutDirection=");
    localStringBuilder.append(this.e);
    localStringBuilder.append(", mStartLine=");
    localStringBuilder.append(this.f);
    localStringBuilder.append(", mEndLine=");
    localStringBuilder.append(this.g);
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.o
 * JD-Core Version:    0.6.2
 */