package androidx.recyclerview.widget;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class t
{
  final a a;

  static
  {
    CoverageLogger.Log(114679808);
  }

  t(a parama)
  {
    this.a = parama;
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(114995200);
    }

    public abstract a.b a(int paramInt1, int paramInt2, int paramInt3, Object paramObject);

    public abstract void a(a.b paramb);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.t
 * JD-Core Version:    0.6.2
 */