package androidx.recyclerview.widget;

import android.graphics.Canvas;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface m
{
  static
  {
    CoverageLogger.Log(114710528);
  }

  public abstract void a(Canvas paramCanvas, RecyclerView paramRecyclerView, View paramView, float paramFloat1, float paramFloat2, int paramInt, boolean paramBoolean);

  public abstract void a(View paramView);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.m
 * JD-Core Version:    0.6.2
 */