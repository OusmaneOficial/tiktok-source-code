package androidx.recyclerview.widget;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

final class k
  implements Runnable
{
  static final ThreadLocal<k> a = new ThreadLocal();
  static Comparator<b> e = new Comparator()
  {
    static
    {
      CoverageLogger.Log(114935808);
    }
  };
  ArrayList<RecyclerView> b = new ArrayList();
  long c;
  long d;
  private ArrayList<b> f = new ArrayList();

  static
  {
    CoverageLogger.Log(114933760);
  }

  private static RecyclerView.v a(RecyclerView paramRecyclerView, int paramInt, long paramLong)
  {
    int i = paramRecyclerView.g.b();
    for (int j = 0; j < i; j++)
    {
      RecyclerView.v localv2 = RecyclerView.d(paramRecyclerView.g.c(j));
      if ((localv2.mPosition == paramInt) && (!localv2.isInvalid()))
      {
        k = 1;
        break label65;
      }
    }
    int k = 0;
    label65: if (k != 0)
      return null;
    RecyclerView.o localo = paramRecyclerView.e;
    try
    {
      paramRecyclerView.g();
      RecyclerView.v localv1 = localo.a(paramInt, false, paramLong);
      if (localv1 != null)
        if ((localv1.isBound()) && (!localv1.isInvalid()))
          localo.a(localv1.itemView);
        else
          localo.a(localv1, false);
      paramRecyclerView.a(false);
      return localv1;
    }
    finally
    {
      paramRecyclerView.a(false);
    }
    while (true)
      throw localObject;
  }

  final void a(RecyclerView paramRecyclerView, int paramInt1, int paramInt2)
  {
    if ((paramRecyclerView.isAttachedToWindow()) && (this.c == 0L))
    {
      this.c = paramRecyclerView.getNanoTime();
      paramRecyclerView.post(this);
    }
    a locala = paramRecyclerView.D;
    locala.a = paramInt1;
    locala.b = paramInt2;
  }

  public final void run()
  {
    long l1 = 0L;
    label772: 
    while (true)
    {
      long l2;
      int j;
      long l3;
      int m;
      int i1;
      int i2;
      int i4;
      long l4;
      try
      {
        androidx.core.d.f.a("RV Prefetch");
        boolean bool1 = this.b.isEmpty();
        if (bool1)
        {
          this.c = l1;
          androidx.core.d.f.a();
          return;
        }
        int i = this.b.size();
        l2 = l1;
        j = 0;
        if (j >= i)
          break label744;
        RecyclerView localRecyclerView1 = (RecyclerView)this.b.get(j);
        if (localRecyclerView1.getWindowVisibility() != 0)
          break label738;
        l2 = Math.max(localRecyclerView1.getDrawingTime(), l2);
        break label738;
        l3 = TimeUnit.MILLISECONDS.toNanos(l2) + this.d;
        int k = this.b.size();
        m = 0;
        int n = 0;
        if (m < k)
        {
          RecyclerView localRecyclerView2 = (RecyclerView)this.b.get(m);
          if (localRecyclerView2.getWindowVisibility() != 0)
            break label754;
          localRecyclerView2.D.a(localRecyclerView2, false);
          n += localRecyclerView2.D.d;
          break label754;
        }
        this.f.ensureCapacity(n);
        i1 = 0;
        i2 = 0;
        RecyclerView localRecyclerView3;
        a locala1;
        int i3;
        int i5;
        b localb1;
        int i6;
        boolean bool2;
        if (i1 < k)
        {
          localRecyclerView3 = (RecyclerView)this.b.get(i1);
          if (localRecyclerView3.getWindowVisibility() != 0)
            break label764;
          locala1 = localRecyclerView3.D;
          i3 = Math.abs(locala1.a) + Math.abs(locala1.b);
          i4 = i2;
          i5 = 0;
          if (i5 >= 2 * locala1.d)
            break label760;
          if (i4 >= this.f.size())
          {
            localb1 = new b();
            this.f.add(localb1);
          }
          else
          {
            localb1 = (b)this.f.get(i4);
          }
          i6 = locala1.c[(i5 + 1)];
          if (i6 <= i3)
            bool2 = true;
          else
            bool2 = false;
        }
        try
        {
          localb1.a = bool2;
          localb1.b = i3;
          localb1.c = i6;
          localb1.d = localRecyclerView3;
          localb1.e = locala1.c[i5];
          i4++;
          i5 += 2;
          l1 = 0L;
          continue;
          Collections.sort(this.f, e);
          int i7 = 0;
          if (i7 < this.f.size())
          {
            b localb2 = (b)this.f.get(i7);
            if (localb2.d != null)
            {
              if (!localb2.a)
                break label772;
              l4 = 9223372036854775807L;
              RecyclerView.v localv = a(localb2.d, localb2.e, l4);
              if ((localv != null) && (localv.mNestedRecyclerView != null) && (localv.isBound()) && (!localv.isInvalid()))
              {
                RecyclerView localRecyclerView4 = (RecyclerView)localv.mNestedRecyclerView.get();
                if (localRecyclerView4 != null)
                {
                  if ((localRecyclerView4.y) && (localRecyclerView4.g.b() != 0))
                    localRecyclerView4.b();
                  a locala2 = localRecyclerView4.D;
                  locala2.a(localRecyclerView4, true);
                  int i8 = locala2.d;
                  if (i8 != 0)
                    try
                    {
                      androidx.core.d.f.a("RV Nested Prefetch");
                      RecyclerView.s locals = localRecyclerView4.E;
                      RecyclerView.a locala = localRecyclerView4.m;
                      locals.d = 1;
                      locals.e = locala.getItemCount();
                      locals.g = false;
                      locals.h = false;
                      locals.i = false;
                      int i9 = 0;
                      if (i9 < 2 * locala2.d)
                      {
                        a(localRecyclerView4, locala2.c[i9], l3);
                        i9 += 2;
                        continue;
                      }
                    }
                    finally
                    {
                      androidx.core.d.f.a();
                    }
                }
              }
              localb2.a = false;
              localb2.b = 0;
              localb2.c = 0;
              localb2.d = null;
              localb2.e = 0;
              i7++;
              continue;
            }
          }
        }
        finally
        {
          l1 = 0L;
        }
      }
      finally
      {
      }
      this.c = l1;
      androidx.core.d.f.a();
      while (true)
        throw localObject2;
      label738: j++;
      continue;
      label744: if (l2 == l1)
      {
        continue;
        label754: m++;
        continue;
        label760: i2 = i4;
        label764: i1++;
        l1 = 0L;
        continue;
        l4 = l3;
      }
    }
  }

  static final class a
    implements RecyclerView.i.a
  {
    int a;
    int b;
    int[] c;
    int d;

    static
    {
      CoverageLogger.Log(114927616);
    }

    final void a()
    {
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1);
      this.d = 0;
    }

    public final void a(int paramInt1, int paramInt2)
    {
      if (paramInt1 >= 0)
      {
        if (paramInt2 >= 0)
        {
          int i = 2 * this.d;
          int[] arrayOfInt1 = this.c;
          if (arrayOfInt1 == null)
          {
            this.c = new int[4];
            Arrays.fill(this.c, -1);
          }
          else if (i >= arrayOfInt1.length)
          {
            this.c = new int[i * 2];
            System.arraycopy(arrayOfInt1, 0, this.c, 0, arrayOfInt1.length);
          }
          int[] arrayOfInt2 = this.c;
          arrayOfInt2[i] = paramInt1;
          arrayOfInt2[(i + 1)] = paramInt2;
          this.d = (1 + this.d);
          return;
        }
        throw new IllegalArgumentException("Pixel distance must be non-negative");
      }
      throw new IllegalArgumentException("Layout positions must be non-negative");
    }

    final void a(RecyclerView paramRecyclerView, boolean paramBoolean)
    {
      this.d = 0;
      int[] arrayOfInt = this.c;
      if (arrayOfInt != null)
        Arrays.fill(arrayOfInt, -1);
      RecyclerView.i locali = paramRecyclerView.n;
      if ((paramRecyclerView.m != null) && (locali != null) && (locali.D))
      {
        if (paramBoolean)
        {
          if (!paramRecyclerView.f.d())
            locali.a(paramRecyclerView.m.getItemCount(), this);
        }
        else if (!paramRecyclerView.n())
          locali.a(this.a, this.b, paramRecyclerView.E, this);
        if (this.d > locali.E)
        {
          locali.E = this.d;
          locali.F = paramBoolean;
          paramRecyclerView.e.b();
        }
      }
    }

    final boolean a(int paramInt)
    {
      if (this.c != null)
      {
        int i = 2 * this.d;
        for (int j = 0; j < i; j += 2)
          if (this.c[j] == paramInt)
            return true;
      }
      return false;
    }
  }

  static final class b
  {
    public boolean a;
    public int b;
    public int c;
    public RecyclerView d;
    public int e;

    static
    {
      CoverageLogger.Log(114747392);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.k
 * JD-Core Version:    0.6.2
 */