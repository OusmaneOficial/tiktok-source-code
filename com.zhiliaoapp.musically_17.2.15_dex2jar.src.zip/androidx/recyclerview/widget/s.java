package androidx.recyclerview.widget;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface s
{
  static
  {
    CoverageLogger.Log(114683904);
  }

  public abstract void a(int paramInt1, int paramInt2);

  public abstract void a(int paramInt1, int paramInt2, Object paramObject);

  public abstract void b(int paramInt1, int paramInt2);

  public abstract void c(int paramInt1, int paramInt2);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.s
 * JD-Core Version:    0.6.2
 */