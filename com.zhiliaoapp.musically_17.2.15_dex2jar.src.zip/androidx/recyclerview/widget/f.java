package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup.LayoutParams;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.List;

final class f
{
  final b a;
  final a b;
  final List<View> c;

  static
  {
    CoverageLogger.Log(114857984);
  }

  f(b paramb)
  {
    this.a = paramb;
    this.b = new a();
    this.c = new ArrayList();
  }

  private int e(int paramInt)
  {
    if (paramInt < 0)
      return -1;
    int i = this.a.a();
    int j = paramInt;
    while (j < i)
    {
      int k = paramInt - (j - this.b.e(j));
      if (k == 0)
      {
        while (this.b.c(j))
          j++;
        return j;
      }
      j += k;
    }
    return -1;
  }

  final int a()
  {
    return this.a.a() - this.c.size();
  }

  final void a(int paramInt)
  {
    int i = e(paramInt);
    View localView = this.a.b(i);
    if (localView == null)
      return;
    if (this.b.d(i))
      b(localView);
    this.a.a(i);
  }

  void a(View paramView)
  {
    this.c.add(paramView);
    this.a.c(paramView);
  }

  final void a(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean)
  {
    int i;
    if (paramInt < 0)
      i = this.a.a();
    else
      i = e(paramInt);
    this.b.a(i, paramBoolean);
    if (paramBoolean)
      a(paramView);
    this.a.a(paramView, i, paramLayoutParams);
  }

  final void a(View paramView, int paramInt, boolean paramBoolean)
  {
    int i;
    if (paramInt < 0)
      i = this.a.a();
    else
      i = e(paramInt);
    this.b.a(i, paramBoolean);
    if (paramBoolean)
      a(paramView);
    this.a.a(paramView, i);
  }

  final int b()
  {
    return this.a.a();
  }

  final View b(int paramInt)
  {
    int i = e(paramInt);
    return this.a.b(i);
  }

  boolean b(View paramView)
  {
    if (this.c.remove(paramView))
    {
      this.a.d(paramView);
      return true;
    }
    return false;
  }

  final int c(View paramView)
  {
    int i = this.a.a(paramView);
    if (i == -1)
      return -1;
    if (this.b.c(i))
      return -1;
    return i - this.b.e(i);
  }

  final View c(int paramInt)
  {
    return this.a.b(paramInt);
  }

  final void d(int paramInt)
  {
    int i = e(paramInt);
    this.b.d(i);
    this.a.c(i);
  }

  final boolean d(View paramView)
  {
    return this.c.contains(paramView);
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.b.toString());
    localStringBuilder.append(", hidden list:");
    localStringBuilder.append(this.c.size());
    return localStringBuilder.toString();
  }

  static final class a
  {
    long a;
    a b;

    static
    {
      CoverageLogger.Log(114855936);
    }

    private void b()
    {
      if (this.b == null)
        this.b = new a();
    }

    final void a()
    {
      a locala = this;
      do
      {
        locala.a = 0L;
        locala = locala.b;
      }
      while (locala != null);
    }

    final void a(int paramInt)
    {
      if (paramInt >= 64)
      {
        b();
        this.b.a(paramInt - 64);
        return;
      }
      this.a |= 1L << paramInt;
    }

    final void a(int paramInt, boolean paramBoolean)
    {
      boolean bool1 = paramBoolean;
      a locala = this;
      while (true)
      {
        if (paramInt >= 64)
        {
          locala.b();
          locala.b.a(paramInt - 64, bool1);
          return;
        }
        boolean bool2;
        if ((0x0 & locala.a) != 0L)
          bool2 = true;
        else
          bool2 = false;
        long l1 = (1L << paramInt) - 1L;
        long l2 = locala.a;
        locala.a = (l2 & l1 | (l2 & (l1 ^ 0xFFFFFFFF)) << 1);
        if (bool1)
          locala.a(paramInt);
        else
          locala.b(paramInt);
        if ((!bool2) && (locala.b == null))
          return;
        locala.b();
        locala = locala.b;
        bool1 = bool2;
        paramInt = 0;
      }
    }

    final void b(int paramInt)
    {
      if (paramInt >= 64)
      {
        a locala = this.b;
        if (locala != null)
          locala.b(paramInt - 64);
      }
      else
      {
        this.a &= (0xFFFFFFFF ^ 1L << paramInt);
      }
    }

    final boolean c(int paramInt)
    {
      a locala = this;
      while (paramInt >= 64)
      {
        locala.b();
        locala = locala.b;
        paramInt -= 64;
      }
      return (locala.a & 1L << paramInt) != 0L;
    }

    final boolean d(int paramInt)
    {
      a locala1 = this;
      while (paramInt >= 64)
      {
        locala1.b();
        locala1 = locala1.b;
        paramInt -= 64;
      }
      long l1 = 1L << paramInt;
      boolean bool;
      if ((l1 & locala1.a) != 0L)
        bool = true;
      else
        bool = false;
      locala1.a &= (l1 ^ 0xFFFFFFFF);
      long l2 = l1 - 1L;
      long l3 = locala1.a;
      locala1.a = (l3 & l2 | Long.rotateRight(l3 & (l2 ^ 0xFFFFFFFF), 1));
      a locala2 = locala1.b;
      if (locala2 != null)
      {
        if (locala2.c(0))
          locala1.a(63);
        locala1.b.d(0);
      }
      return bool;
    }

    final int e(int paramInt)
    {
      a locala = this.b;
      if (locala == null)
      {
        if (paramInt >= 64)
          return Long.bitCount(this.a);
        return Long.bitCount(this.a & (1L << paramInt) - 1L);
      }
      if (paramInt < 64)
        return Long.bitCount(this.a & (1L << paramInt) - 1L);
      return locala.e(paramInt - 64) + Long.bitCount(this.a);
    }

    public final String toString()
    {
      if (this.b == null)
        return Long.toBinaryString(this.a);
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(this.b.toString());
      localStringBuilder.append("xx");
      localStringBuilder.append(Long.toBinaryString(this.a));
      return localStringBuilder.toString();
    }
  }

  static abstract interface b
  {
    static
    {
      CoverageLogger.Log(114860032);
    }

    public abstract int a();

    public abstract int a(View paramView);

    public abstract void a(int paramInt);

    public abstract void a(View paramView, int paramInt);

    public abstract void a(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams);

    public abstract View b(int paramInt);

    public abstract RecyclerView.v b(View paramView);

    public abstract void b();

    public abstract void c(int paramInt);

    public abstract void c(View paramView);

    public abstract void d(View paramView);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.f
 * JD-Core Version:    0.6.2
 */