package androidx.recyclerview.widget;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class ab
{
  final b a;
  a b;

  static
  {
    CoverageLogger.Log(114829312);
  }

  ab(b paramb)
  {
    this.a = paramb;
    this.b = new a();
  }

  final View a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = this.a.a();
    int j = this.a.b();
    int k;
    if (paramInt2 > paramInt1)
      k = 1;
    else
      k = -1;
    Object localObject = null;
    while (paramInt1 != paramInt2)
    {
      View localView = this.a.a(paramInt1);
      int m = this.a.a(localView);
      int n = this.a.b(localView);
      this.b.a(i, j, m, n);
      if (paramInt3 != 0)
      {
        this.b.a();
        this.b.a(paramInt3);
        if (this.b.b())
          return localView;
      }
      if (paramInt4 != 0)
      {
        this.b.a();
        this.b.a(paramInt4);
        if (this.b.b())
          localObject = localView;
      }
      paramInt1 += k;
    }
    return localObject;
  }

  final boolean a(View paramView, int paramInt)
  {
    this.b.a(this.a.a(), this.a.b(), this.a.a(paramView), this.a.b(paramView));
    this.b.a();
    this.b.a(24579);
    return this.b.b();
  }

  static final class a
  {
    int a;
    int b;
    int c;
    int d;
    int e;

    static
    {
      CoverageLogger.Log(114544640);
    }

    private static int a(int paramInt1, int paramInt2)
    {
      if (paramInt1 > paramInt2)
        return 1;
      if (paramInt1 == paramInt2)
        return 2;
      return 4;
    }

    final void a()
    {
      this.a = 0;
    }

    final void a(int paramInt)
    {
      this.a = (paramInt | this.a);
    }

    final void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      this.b = paramInt1;
      this.c = paramInt2;
      this.d = paramInt3;
      this.e = paramInt4;
    }

    final boolean b()
    {
      int i = this.a;
      if (((i & 0x7) != 0) && ((i & a(this.d, this.b) << 0) == 0))
        return false;
      int j = this.a;
      if (((j & 0x70) != 0) && ((j & a(this.d, this.c) << 4) == 0))
        return false;
      int k = this.a;
      if (((k & 0x700) != 0) && ((k & a(this.e, this.b) << 8) == 0))
        return false;
      int m = this.a;
      return ((m & 0x7000) == 0) || ((m & a(this.e, this.c) << 12) != 0);
    }
  }

  static abstract interface b
  {
    static
    {
      CoverageLogger.Log(114814976);
    }

    public abstract int a();

    public abstract int a(View paramView);

    public abstract View a(int paramInt);

    public abstract int b();

    public abstract int b(View paramView);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.ab
 * JD-Core Version:    0.6.2
 */