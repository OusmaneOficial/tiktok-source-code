package androidx.recyclerview.widget;

import androidx.c.a;
import androidx.c.d;
import androidx.core.g.f.a;
import androidx.core.g.f.b;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class ac
{
  final a<RecyclerView.v, a> a = new a();
  final d<RecyclerView.v> b = new d();

  static
  {
    CoverageLogger.Log(114536448);
  }

  private RecyclerView.f.c a(RecyclerView.v paramv, int paramInt)
  {
    int i = this.a.a(paramv);
    if (i < 0)
      return null;
    a locala = (a)this.a.c(i);
    if ((locala != null) && ((paramInt & locala.a) != 0))
    {
      locala.a &= (paramInt ^ 0xFFFFFFFF);
      RecyclerView.f.c localc;
      if (paramInt == 4)
      {
        localc = locala.b;
      }
      else
      {
        if (paramInt != 8)
          break label113;
        localc = locala.c;
      }
      if ((0xC & locala.a) == 0)
      {
        this.a.d(i);
        a.a(locala);
      }
      return localc;
      label113: throw new IllegalArgumentException("Must provide flag PRE or POST");
    }
    return null;
  }

  final RecyclerView.v a(long paramLong)
  {
    return (RecyclerView.v)this.b.a(paramLong);
  }

  final void a()
  {
    this.a.clear();
    this.b.c();
  }

  final void a(long paramLong, RecyclerView.v paramv)
  {
    this.b.b(paramLong, paramv);
  }

  final void a(RecyclerView.v paramv, RecyclerView.f.c paramc)
  {
    a locala = (a)this.a.get(paramv);
    if (locala == null)
    {
      locala = a.a();
      this.a.put(paramv, locala);
    }
    locala.b = paramc;
    locala.a = (0x4 | locala.a);
  }

  final void a(b paramb)
  {
    for (int i = -1 + this.a.size(); i >= 0; i--)
    {
      RecyclerView.v localv = (RecyclerView.v)this.a.b(i);
      a locala = (a)this.a.d(i);
      if ((0x3 & locala.a) == 3)
        paramb.a(localv);
      else if ((0x1 & locala.a) != 0)
      {
        if (locala.b == null)
          paramb.a(localv);
        else
          paramb.a(localv, locala.b, locala.c);
      }
      else if ((0xE & locala.a) == 14)
        paramb.b(localv, locala.b, locala.c);
      else if ((0xC & locala.a) == 12)
        paramb.c(localv, locala.b, locala.c);
      else if ((0x4 & locala.a) != 0)
        paramb.a(localv, locala.b, null);
      else if ((0x8 & locala.a) != 0)
        paramb.b(localv, locala.b, locala.c);
      a.a(locala);
    }
  }

  final boolean a(RecyclerView.v paramv)
  {
    a locala = (a)this.a.get(paramv);
    return (locala != null) && ((0x1 & locala.a) != 0);
  }

  final RecyclerView.f.c b(RecyclerView.v paramv)
  {
    return a(paramv, 4);
  }

  final void b(RecyclerView.v paramv, RecyclerView.f.c paramc)
  {
    a locala = (a)this.a.get(paramv);
    if (locala == null)
    {
      locala = a.a();
      this.a.put(paramv, locala);
    }
    locala.a = (0x2 | locala.a);
    locala.b = paramc;
  }

  final RecyclerView.f.c c(RecyclerView.v paramv)
  {
    return a(paramv, 8);
  }

  final void c(RecyclerView.v paramv, RecyclerView.f.c paramc)
  {
    a locala = (a)this.a.get(paramv);
    if (locala == null)
    {
      locala = a.a();
      this.a.put(paramv, locala);
    }
    locala.c = paramc;
    locala.a = (0x8 | locala.a);
  }

  final boolean d(RecyclerView.v paramv)
  {
    a locala = (a)this.a.get(paramv);
    return (locala != null) && ((0x4 & locala.a) != 0);
  }

  final void e(RecyclerView.v paramv)
  {
    a locala = (a)this.a.get(paramv);
    if (locala == null)
    {
      locala = a.a();
      this.a.put(paramv, locala);
    }
    locala.a = (0x1 | locala.a);
  }

  final void f(RecyclerView.v paramv)
  {
    a locala = (a)this.a.get(paramv);
    if (locala == null)
      return;
    locala.a = (0xFFFFFFFE & locala.a);
  }

  final void g(RecyclerView.v paramv)
  {
    for (int i = -1 + this.b.b(); i >= 0; i--)
      if (paramv == this.b.c(i))
      {
        this.b.a(i);
        break;
      }
    a locala = (a)this.a.remove(paramv);
    if (locala != null)
      a.a(locala);
  }

  static final class a
  {
    static f.a<a> d = new f.b(20);
    int a;
    RecyclerView.f.c b;
    RecyclerView.f.c c;

    static
    {
      CoverageLogger.Log(114831360);
    }

    static a a()
    {
      a locala = (a)d.acquire();
      if (locala == null)
        locala = new a();
      return locala;
    }

    static void a(a parama)
    {
      parama.a = 0;
      parama.b = null;
      parama.c = null;
      d.release(parama);
    }
  }

  static abstract interface b
  {
    static
    {
      CoverageLogger.Log(114532352);
    }

    public abstract void a(RecyclerView.v paramv);

    public abstract void a(RecyclerView.v paramv, RecyclerView.f.c paramc1, RecyclerView.f.c paramc2);

    public abstract void b(RecyclerView.v paramv, RecyclerView.f.c paramc1, RecyclerView.f.c paramc2);

    public abstract void c(RecyclerView.v paramv, RecyclerView.f.c paramc1, RecyclerView.f.c paramc2);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.ac
 * JD-Core Version:    0.6.2
 */