package androidx.recyclerview.widget;

import com.ss.android.ugc.aweme.bn.g;
import com.ss.android.ugc.aweme.bn.l;
import com.ss.android.ugc.aweme.bn.l.a;
import com.ss.android.ugc.aweme.bn.o;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

public final class c<T>
{
  public final Executor a;
  public final Executor b;
  public final h.c<T> c;

  static
  {
    CoverageLogger.Log(114823168);
  }

  c(Executor paramExecutor1, Executor paramExecutor2, h.c<T> paramc)
  {
    this.a = paramExecutor1;
    this.b = paramExecutor2;
    this.c = paramc;
  }

  public static final class a<T>
  {
    private static final Object d = new Object();
    private static Executor e = null;
    private Executor a;
    private Executor b;
    private final h.c<T> c;

    static
    {
      CoverageLogger.Log(114825216);
    }

    public a(h.c<T> paramc)
    {
      this.c = paramc;
    }

    public final c<T> a()
    {
      if (this.b == null)
        synchronized (d)
        {
          if (e == null)
            e = g.a(l.a(o.FIXED).a(2).a());
          this.b = e;
        }
      return new c(this.a, this.b, this.c);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.c
 * JD-Core Version:    0.6.2
 */