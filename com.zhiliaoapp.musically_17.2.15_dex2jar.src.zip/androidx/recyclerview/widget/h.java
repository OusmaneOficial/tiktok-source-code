package androidx.recyclerview.widget;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public final class h
{
  private static final Comparator<f> a = new Comparator()
  {
    static
    {
      CoverageLogger.Log(114898944);
    }
  };

  static
  {
    CoverageLogger.Log(114776064);
  }

  public static b a(a parama)
  {
    return a(parama, true);
  }

  public static b a(a parama, boolean paramBoolean)
  {
    int i = parama.a();
    int j = parama.b();
    ArrayList localArrayList1 = new ArrayList();
    ArrayList localArrayList2 = new ArrayList();
    localArrayList2.add(new e(0, i, 0, j));
    int k = i + j + Math.abs(i - j);
    int m = k * 2;
    int[] arrayOfInt1 = new int[m];
    int[] arrayOfInt2 = new int[m];
    ArrayList localArrayList3 = new ArrayList();
    while (!localArrayList2.isEmpty())
    {
      e locale1 = (e)localArrayList2.remove(-1 + localArrayList2.size());
      f localf = a(parama, locale1.a, locale1.b, locale1.c, locale1.d, arrayOfInt1, arrayOfInt2, k);
      if (localf != null)
      {
        if (localf.c > 0)
          localArrayList1.add(localf);
        localf.a += locale1.a;
        localf.b += locale1.c;
        e locale2;
        if (localArrayList3.isEmpty())
          locale2 = new e();
        else
          locale2 = (e)localArrayList3.remove(-1 + localArrayList3.size());
        locale2.a = locale1.a;
        locale2.c = locale1.c;
        if (localf.e)
        {
          locale2.b = localf.a;
          locale2.d = localf.b;
        }
        else if (localf.d)
        {
          locale2.b = (-1 + localf.a);
          locale2.d = localf.b;
        }
        else
        {
          locale2.b = localf.a;
          locale2.d = (-1 + localf.b);
        }
        localArrayList2.add(locale2);
        if (localf.e)
        {
          if (localf.d)
          {
            locale1.a = (1 + (localf.a + localf.c));
            locale1.c = (localf.b + localf.c);
          }
          else
          {
            locale1.a = (localf.a + localf.c);
            locale1.c = (1 + (localf.b + localf.c));
          }
        }
        else
        {
          locale1.a = (localf.a + localf.c);
          locale1.c = (localf.b + localf.c);
        }
        localArrayList2.add(locale1);
      }
      else
      {
        localArrayList3.add(locale1);
      }
    }
    Collections.sort(localArrayList1, a);
    b localb = new b(parama, localArrayList1, arrayOfInt1, arrayOfInt2, paramBoolean);
    return localb;
  }

  private static f a(a parama, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt5)
  {
    int i = paramInt2 - paramInt1;
    int j = paramInt4 - paramInt3;
    if ((i > 0) && (j > 0))
    {
      int k = i - j;
      int m = i + j;
      int n = 1;
      int i1 = (m + n) / 2;
      int i2 = paramInt5 - i1 - n;
      int i3 = n + (paramInt5 + i1);
      Arrays.fill(paramArrayOfInt1, i2, i3, 0);
      Arrays.fill(paramArrayOfInt2, i2 + k, i3 + k, i);
      int i4;
      if (k % 2 != 0)
        i4 = 1;
      else
        i4 = 0;
      int i5 = 0;
      while (i5 <= i1)
      {
        int i6 = -i5;
        int i7 = i6;
        while (i7 <= i5)
        {
          if (i7 != i6)
            if (i7 != i5)
            {
              int i23 = paramInt5 + i7;
              if (paramArrayOfInt1[(i23 - 1)] < paramArrayOfInt1[(i23 + n)]);
            }
            else
            {
              i20 = n + paramArrayOfInt1[(paramInt5 + i7 - n)];
              bool2 = true;
              break label219;
            }
          int i20 = paramArrayOfInt1[(n + (paramInt5 + i7))];
          boolean bool2 = false;
          label219: for (int i21 = i20 - i7; (i20 < i) && (i21 < j) && (parama.b(paramInt1 + i20, paramInt3 + i21)); i21++)
            i20++;
          int i22 = paramInt5 + i7;
          paramArrayOfInt1[i22] = i20;
          if ((i4 != 0) && (i7 >= 1 + (k - i5)) && (i7 <= k + i5 - 1) && (paramArrayOfInt1[i22] >= paramArrayOfInt2[i22]))
          {
            f localf2 = new f();
            localf2.a = paramArrayOfInt2[i22];
            localf2.b = (localf2.a - i7);
            localf2.c = (paramArrayOfInt1[i22] - paramArrayOfInt2[i22]);
            localf2.d = bool2;
            localf2.e = false;
            return localf2;
          }
          i7 += 2;
          n = 1;
        }
        int i8 = i6;
        while (i8 <= i5)
        {
          int i10 = i8 + k;
          int i11;
          if (i10 != i5 + k)
          {
            if (i10 != i6 + k)
            {
              int i18 = paramInt5 + i10;
              int i19 = paramArrayOfInt2[(i18 - 1)];
              i11 = 1;
              if (i19 < paramArrayOfInt2[(i18 + i11)])
                break label494;
            }
            else
            {
              i11 = 1;
            }
            i12 = paramArrayOfInt2[(i11 + (paramInt5 + i10))] - i11;
            bool1 = true;
            break label510;
          }
          else
          {
            i11 = 1;
          }
          label494: int i12 = paramArrayOfInt2[(paramInt5 + i10 - i11)];
          boolean bool1 = false;
          label510: int i13 = i12 - i10;
          while ((i12 > 0) && (i13 > 0))
          {
            int i16 = -1 + (paramInt1 + i12);
            int i17 = paramInt3 + i13;
            i14 = i;
            if (!parama.b(i16, i17 - 1))
              break label575;
            i12--;
            i13--;
            i = i14;
          }
          int i14 = i;
          label575: int i15 = paramInt5 + i10;
          paramArrayOfInt2[i15] = i12;
          if ((i4 == 0) && (i10 >= i6) && (i10 <= i5) && (paramArrayOfInt1[i15] >= paramArrayOfInt2[i15]))
          {
            f localf1 = new f();
            localf1.a = paramArrayOfInt2[i15];
            localf1.b = (localf1.a - i10);
            localf1.c = (paramArrayOfInt1[i15] - paramArrayOfInt2[i15]);
            localf1.d = bool1;
            localf1.e = true;
            return localf1;
          }
          i8 += 2;
          i = i14;
        }
        int i9 = i;
        i5++;
        i = i9;
        n = 1;
      }
      throw new IllegalStateException("DiffUtil hit an unexpected case while trying to calculate the optimal path. Please make sure your data is not changing during the diff calculation.");
    }
    return null;
  }

  public static abstract class a
  {
    static
    {
      CoverageLogger.Log(114907136);
    }

    public abstract int a();

    public Object a(int paramInt1, int paramInt2)
    {
      return null;
    }

    public abstract int b();

    public abstract boolean b(int paramInt1, int paramInt2);

    public abstract boolean c(int paramInt1, int paramInt2);
  }

  public static final class b
  {
    public final List<h.f> a;
    public final int[] b;
    private final int[] c;
    private final h.a d;
    private final int e;
    private final int f;
    private final boolean g;

    static
    {
      CoverageLogger.Log(114786304);
    }

    b(h.a parama, List<h.f> paramList, int[] paramArrayOfInt1, int[] paramArrayOfInt2, boolean paramBoolean)
    {
      this.a = paramList;
      this.b = paramArrayOfInt1;
      this.c = paramArrayOfInt2;
      Arrays.fill(this.b, 0);
      Arrays.fill(this.c, 0);
      this.d = parama;
      this.e = parama.a();
      this.f = parama.b();
      this.g = paramBoolean;
      h.f localf1;
      if (this.a.isEmpty())
        localf1 = null;
      else
        localf1 = (h.f)this.a.get(0);
      if ((localf1 == null) || (localf1.a != 0) || (localf1.b != 0))
      {
        h.f localf2 = new h.f();
        localf2.a = 0;
        localf2.b = 0;
        localf2.d = false;
        localf2.c = 0;
        localf2.e = false;
        this.a.add(0, localf2);
      }
      a();
    }

    private static h.d a(List<h.d> paramList, int paramInt, boolean paramBoolean)
    {
      for (int i = paramList.size() - 1; i >= 0; i--)
      {
        h.d locald1 = (h.d)paramList.get(i);
        if ((locald1.a == paramInt) && (locald1.c == paramBoolean))
        {
          paramList.remove(i);
          while (i < paramList.size())
          {
            h.d locald2 = (h.d)paramList.get(i);
            int j = locald2.b;
            int k;
            if (paramBoolean)
              k = 1;
            else
              k = -1;
            locald2.b = (j + k);
            i++;
          }
          return locald1;
        }
      }
      return null;
    }

    private void a()
    {
      int i = this.e;
      int j = this.f;
      for (int k = this.a.size() - 1; k >= 0; k--)
      {
        h.f localf = (h.f)this.a.get(k);
        int m = localf.a + localf.c;
        int n = localf.b + localf.c;
        boolean bool = this.g;
        int i1 = 0;
        if (bool)
        {
          while (i > m)
          {
            if (this.b[(i - 1)] == 0)
              a(i, j, k, false);
            i--;
          }
          while (true)
          {
            i1 = 0;
            if (j <= n)
              break;
            if (this.c[(j - 1)] == 0)
              a(i, j, k, true);
            j--;
          }
        }
        while (i1 < localf.c)
        {
          int i2 = i1 + localf.a;
          int i3 = i1 + localf.b;
          int i4;
          if (this.d.c(i2, i3))
            i4 = 1;
          else
            i4 = 2;
          this.b[i2] = (i4 | i3 << 5);
          this.c[i3] = (i4 | i2 << 5);
          i1++;
        }
        i = localf.a;
        j = localf.b;
      }
    }

    private void a(List<h.d> paramList, s params, int paramInt1, int paramInt2, int paramInt3)
    {
      if (!this.g)
      {
        params.a(paramInt1, paramInt2);
        return;
      }
      for (int i = paramInt2 - 1; i >= 0; i--)
      {
        int[] arrayOfInt = this.c;
        int j = paramInt3 + i;
        int k = 0x1F & arrayOfInt[j];
        if (k != 0)
        {
          if ((k != 4) && (k != 8))
          {
            if (k == 16)
            {
              paramList.add(new h.d(j, paramInt1, false));
            }
            else
            {
              StringBuilder localStringBuilder = new StringBuilder("unknown flag for pos ");
              localStringBuilder.append(j);
              localStringBuilder.append(" ");
              localStringBuilder.append(Long.toBinaryString(k));
              throw new IllegalStateException(localStringBuilder.toString());
            }
          }
          else
          {
            int m = this.c[j] >> 5;
            params.c(a(paramList, m, true).b, paramInt1);
            if (k == 4)
              params.a(paramInt1, 1, this.d.a(m, j));
          }
        }
        else
        {
          params.a(paramInt1, 1);
          Iterator localIterator = paramList.iterator();
          while (localIterator.hasNext())
          {
            h.d locald = (h.d)localIterator.next();
            locald.b = (1 + locald.b);
          }
        }
      }
    }

    private boolean a(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
    {
      int i;
      int j;
      if (paramBoolean)
      {
        paramInt2--;
        i = paramInt1;
        j = paramInt2;
      }
      else
      {
        i = paramInt1 - 1;
        j = i;
      }
      while (paramInt3 >= 0)
      {
        h.f localf = (h.f)this.a.get(paramInt3);
        int k = localf.a + localf.c;
        int m = localf.b + localf.c;
        int n = 8;
        if (paramBoolean)
          for (int i3 = i - 1; i3 >= k; i3--)
            if (this.d.b(i3, j))
            {
              if (!this.d.c(i3, j))
                n = 4;
              this.c[j] = (0x10 | i3 << 5);
              this.b[i3] = (n | j << 5);
              return true;
            }
        for (int i1 = paramInt2 - 1; i1 >= m; i1--)
          if (this.d.b(j, i1))
          {
            if (!this.d.c(j, i1))
              n = 4;
            int[] arrayOfInt = this.b;
            int i2 = paramInt1 - 1;
            arrayOfInt[i2] = (0x10 | i1 << 5);
            this.c[i1] = (n | i2 << 5);
            return true;
          }
        i = localf.a;
        paramInt2 = localf.b;
        paramInt3--;
      }
      return false;
    }

    private void b(List<h.d> paramList, s params, int paramInt1, int paramInt2, int paramInt3)
    {
      if (!this.g)
      {
        params.b(paramInt1, paramInt2);
        return;
      }
      for (int i = paramInt2 - 1; i >= 0; i--)
      {
        int[] arrayOfInt = this.b;
        int j = paramInt3 + i;
        int k = 0x1F & arrayOfInt[j];
        if (k != 0)
        {
          if ((k != 4) && (k != 8))
          {
            if (k == 16)
            {
              paramList.add(new h.d(j, paramInt1 + i, true));
            }
            else
            {
              StringBuilder localStringBuilder = new StringBuilder("unknown flag for pos ");
              localStringBuilder.append(j);
              localStringBuilder.append(" ");
              localStringBuilder.append(Long.toBinaryString(k));
              throw new IllegalStateException(localStringBuilder.toString());
            }
          }
          else
          {
            int m = this.b[j] >> 5;
            h.d locald2 = a(paramList, m, false);
            params.c(paramInt1 + i, locald2.b - 1);
            if (k == 4)
              params.a(locald2.b - 1, 1, this.d.a(j, m));
          }
        }
        else
        {
          params.b(paramInt1 + i, 1);
          Iterator localIterator = paramList.iterator();
          while (localIterator.hasNext())
          {
            h.d locald1 = (h.d)localIterator.next();
            locald1.b -= 1;
          }
        }
      }
    }

    public final void a(RecyclerView.a parama)
    {
      a(new b(parama));
    }

    public final void a(s params)
    {
      e locale;
      if ((params instanceof e))
        locale = (e)params;
      else
        locale = new e(params);
      ArrayList localArrayList = new ArrayList();
      int i = this.e;
      int j = this.f;
      int k = this.a.size() - 1;
      int m = j;
      for (int n = k; n >= 0; n--)
      {
        h.f localf = (h.f)this.a.get(n);
        int i1 = localf.c;
        int i2 = i1 + localf.a;
        int i3 = i1 + localf.b;
        if (i2 < i)
        {
          int i6 = i - i2;
          b(localArrayList, locale, i2, i6, i2);
        }
        if (i3 < m)
        {
          int i5 = m - i3;
          a(localArrayList, locale, i2, i5, i3);
        }
        for (int i4 = i1 - 1; i4 >= 0; i4--)
          if ((0x1F & this.b[(i4 + localf.a)]) == 2)
            locale.a(i4 + localf.a, 1, this.d.a(i4 + localf.a, i4 + localf.b));
        i = localf.a;
        m = localf.b;
      }
      locale.a();
    }
  }

  public static abstract class c<T>
  {
    static
    {
      CoverageLogger.Log(114911232);
    }

    public abstract boolean a(T paramT1, T paramT2);

    public abstract boolean b(T paramT1, T paramT2);

    public Object c(T paramT1, T paramT2)
    {
      return null;
    }
  }

  static final class d
  {
    int a;
    int b;
    boolean c;

    static
    {
      CoverageLogger.Log(114774016);
    }

    public d(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      this.a = paramInt1;
      this.b = paramInt2;
      this.c = paramBoolean;
    }
  }

  static final class e
  {
    int a;
    int b;
    int c;
    int d;

    static
    {
      CoverageLogger.Log(114771968);
    }

    public e()
    {
    }

    public e(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      this.a = 0;
      this.b = paramInt2;
      this.c = 0;
      this.d = paramInt4;
    }
  }

  static final class f
  {
    int a;
    int b;
    int c;
    boolean d;
    boolean e;

    static
    {
      CoverageLogger.Log(114769920);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.h
 * JD-Core Version:    0.6.2
 */