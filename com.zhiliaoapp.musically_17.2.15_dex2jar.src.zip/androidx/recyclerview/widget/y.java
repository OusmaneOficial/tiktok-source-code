package androidx.recyclerview.widget;

import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class y
{
  static
  {
    CoverageLogger.Log(114784256);
  }

  static int a(RecyclerView.s params, u paramu, View paramView1, View paramView2, RecyclerView.i parami, boolean paramBoolean)
  {
    if ((parami.s() != 0) && (params.a() != 0) && (paramView1 != null) && (paramView2 != null))
    {
      if (!paramBoolean)
        return 1 + Math.abs(RecyclerView.i.c(paramView1) - RecyclerView.i.c(paramView2));
      int i = paramu.b(paramView2) - paramu.a(paramView1);
      return Math.min(paramu.e(), i);
    }
    return 0;
  }

  static int a(RecyclerView.s params, u paramu, View paramView1, View paramView2, RecyclerView.i parami, boolean paramBoolean1, boolean paramBoolean2)
  {
    if ((parami.s() != 0) && (params.a() != 0) && (paramView1 != null))
    {
      if (paramView2 == null)
        return 0;
      int i = Math.min(RecyclerView.i.c(paramView1), RecyclerView.i.c(paramView2));
      int j = Math.max(RecyclerView.i.c(paramView1), RecyclerView.i.c(paramView2));
      int k;
      if (paramBoolean2)
        k = Math.max(0, -1 + (params.a() - j));
      else
        k = Math.max(0, i);
      if (!paramBoolean1)
        return k;
      int m = Math.abs(paramu.b(paramView2) - paramu.a(paramView1));
      int n = 1 + Math.abs(RecyclerView.i.c(paramView1) - RecyclerView.i.c(paramView2));
      return Math.round(m / n * k + (paramu.b() - paramu.a(paramView1)));
    }
    return 0;
  }

  static int b(RecyclerView.s params, u paramu, View paramView1, View paramView2, RecyclerView.i parami, boolean paramBoolean)
  {
    if ((parami.s() != 0) && (params.a() != 0) && (paramView1 != null) && (paramView2 != null))
    {
      if (!paramBoolean)
        return params.a();
      int i = paramu.b(paramView2) - paramu.a(paramView1);
      int j = 1 + Math.abs(RecyclerView.i.c(paramView1) - RecyclerView.i.c(paramView2));
      return (int)(i / j * params.a());
    }
    return 0;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.recyclerview.widget.y
 * JD-Core Version:    0.6.2
 */