package androidx.work;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public abstract class f
{
  private static final String a = g.a("InputMerger");

  static
  {
    CoverageLogger.Log(38631424);
  }

  public static f a(String paramString)
  {
    try
    {
      f localf = (f)Class.forName(paramString).newInstance();
      return localf;
    }
    catch (Exception localException)
    {
      g.a();
      new StringBuilder("Trouble instantiating + ").append(paramString);
      new Throwable[] { localException };
    }
    return null;
  }

  public abstract e a(List<e> paramList);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.f
 * JD-Core Version:    0.6.2
 */