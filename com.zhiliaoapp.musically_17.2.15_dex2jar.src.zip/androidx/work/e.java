package androidx.work;

import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class e
{
  public static final e a = new a().a();
  private static final String c;
  public Map<String, Object> b;

  static
  {
    CoverageLogger.Log(38629376);
    c = g.a("Data");
  }

  e()
  {
  }

  e(Map<String, ?> paramMap)
  {
    this.b = new HashMap(paramMap);
  }

  // ERROR //
  public static e a(byte[] paramArrayOfByte)
    throws java.lang.IllegalStateException
  {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: sipush 10240
    //   5: if_icmpgt +148 -> 153
    //   8: new 43	java/util/HashMap
    //   11: dup
    //   12: invokespecial 55	java/util/HashMap:<init>	()V
    //   15: astore_1
    //   16: new 57	java/io/ByteArrayInputStream
    //   19: dup
    //   20: aload_0
    //   21: invokespecial 60	java/io/ByteArrayInputStream:<init>	([B)V
    //   24: astore_2
    //   25: aconst_null
    //   26: astore_3
    //   27: new 62	java/io/ObjectInputStream
    //   30: dup
    //   31: aload_2
    //   32: invokespecial 65	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
    //   35: astore 4
    //   37: aload 4
    //   39: invokevirtual 69	java/io/ObjectInputStream:readInt	()I
    //   42: istore 9
    //   44: iload 9
    //   46: ifle +26 -> 72
    //   49: aload_1
    //   50: aload 4
    //   52: invokevirtual 73	java/io/ObjectInputStream:readUTF	()Ljava/lang/String;
    //   55: aload 4
    //   57: invokevirtual 77	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
    //   60: invokeinterface 83 3 0
    //   65: pop
    //   66: iinc 9 255
    //   69: goto -25 -> 44
    //   72: aload 4
    //   74: invokevirtual 86	java/io/ObjectInputStream:close	()V
    //   77: goto +4 -> 81
    //   80: pop
    //   81: aload_2
    //   82: invokevirtual 87	java/io/ByteArrayInputStream:close	()V
    //   85: goto +59 -> 144
    //   88: astore 6
    //   90: goto +18 -> 108
    //   93: aload 4
    //   95: astore_3
    //   96: goto +37 -> 133
    //   99: astore 11
    //   101: aconst_null
    //   102: astore 4
    //   104: aload 11
    //   106: astore 6
    //   108: aload 4
    //   110: ifnull +11 -> 121
    //   113: aload 4
    //   115: invokevirtual 86	java/io/ObjectInputStream:close	()V
    //   118: goto +4 -> 122
    //   121: pop
    //   122: aload_2
    //   123: invokevirtual 87	java/io/ByteArrayInputStream:close	()V
    //   126: goto +4 -> 130
    //   129: pop
    //   130: aload 6
    //   132: athrow
    //   133: aload_3
    //   134: ifnull -54 -> 80
    //   137: aload_3
    //   138: invokevirtual 86	java/io/ObjectInputStream:close	()V
    //   141: goto -61 -> 80
    //   144: new 2	androidx/work/e
    //   147: dup
    //   148: aload_1
    //   149: invokespecial 88	androidx/work/e:<init>	(Ljava/util/Map;)V
    //   152: areturn
    //   153: new 50	java/lang/IllegalStateException
    //   156: dup
    //   157: ldc 90
    //   159: invokespecial 93	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   162: astore 12
    //   164: goto +6 -> 170
    //   167: aload 12
    //   169: athrow
    //   170: goto -3 -> 167
    //
    // Exception table:
    //   from	to	target	type
    //   72	77	80	java/io/IOException
    //   137	141	80	java/io/IOException
    //   37	44	88	finally
    //   49	66	88	finally
    //   37	44	93	java/io/IOException
    //   37	44	93	java/lang/ClassNotFoundException
    //   49	66	93	java/io/IOException
    //   49	66	93	java/lang/ClassNotFoundException
    //   27	37	99	finally
    //   113	118	121	java/io/IOException
    //   121	122	129	java/io/IOException
    //   122	126	129	java/io/IOException
    //   27	37	133	java/io/IOException
    //   27	37	133	java/lang/ClassNotFoundException
    //   80	81	144	java/io/IOException
    //   81	85	144	java/io/IOException
  }

  // ERROR //
  public static byte[] a(e parame)
    throws java.lang.IllegalStateException
  {
    // Byte code:
    //   0: new 96	java/io/ByteArrayOutputStream
    //   3: dup
    //   4: invokespecial 97	java/io/ByteArrayOutputStream:<init>	()V
    //   7: astore_1
    //   8: aconst_null
    //   9: astore_2
    //   10: new 99	java/io/ObjectOutputStream
    //   13: dup
    //   14: aload_1
    //   15: invokespecial 102	java/io/ObjectOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   18: astore_3
    //   19: aload_3
    //   20: aload_0
    //   21: getfield 47	androidx/work/e:b	Ljava/util/Map;
    //   24: invokeinterface 105 1 0
    //   29: invokevirtual 108	java/io/ObjectOutputStream:writeInt	(I)V
    //   32: aload_0
    //   33: getfield 47	androidx/work/e:b	Ljava/util/Map;
    //   36: invokeinterface 112 1 0
    //   41: invokeinterface 118 1 0
    //   46: astore 10
    //   48: aload 10
    //   50: invokeinterface 124 1 0
    //   55: ifeq +43 -> 98
    //   58: aload 10
    //   60: invokeinterface 127 1 0
    //   65: checkcast 129	java/util/Map$Entry
    //   68: astore 12
    //   70: aload_3
    //   71: aload 12
    //   73: invokeinterface 132 1 0
    //   78: checkcast 134	java/lang/String
    //   81: invokevirtual 137	java/io/ObjectOutputStream:writeUTF	(Ljava/lang/String;)V
    //   84: aload_3
    //   85: aload 12
    //   87: invokeinterface 140 1 0
    //   92: invokevirtual 144	java/io/ObjectOutputStream:writeObject	(Ljava/lang/Object;)V
    //   95: goto -47 -> 48
    //   98: aload_3
    //   99: invokevirtual 145	java/io/ObjectOutputStream:close	()V
    //   102: goto +4 -> 106
    //   105: pop
    //   106: aload_1
    //   107: invokevirtual 146	java/io/ByteArrayOutputStream:close	()V
    //   110: goto +3 -> 113
    //   113: aload_1
    //   114: invokevirtual 147	java/io/ByteArrayOutputStream:size	()I
    //   117: sipush 10240
    //   120: if_icmpgt +8 -> 128
    //   123: aload_1
    //   124: invokevirtual 151	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   127: areturn
    //   128: new 50	java/lang/IllegalStateException
    //   131: dup
    //   132: ldc 90
    //   134: invokespecial 93	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   137: athrow
    //   138: astore 7
    //   140: goto +44 -> 184
    //   143: aload_3
    //   144: astore_2
    //   145: goto +10 -> 155
    //   148: astore 7
    //   150: aload_2
    //   151: astore_3
    //   152: goto +32 -> 184
    //   155: aload_1
    //   156: invokevirtual 151	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   159: astore 4
    //   161: aload_2
    //   162: ifnull +10 -> 172
    //   165: aload_2
    //   166: invokevirtual 145	java/io/ObjectOutputStream:close	()V
    //   169: goto +4 -> 173
    //   172: pop
    //   173: aload_1
    //   174: invokevirtual 146	java/io/ByteArrayOutputStream:close	()V
    //   177: goto +4 -> 181
    //   180: pop
    //   181: aload 4
    //   183: areturn
    //   184: aload_3
    //   185: ifnull +10 -> 195
    //   188: aload_3
    //   189: invokevirtual 145	java/io/ObjectOutputStream:close	()V
    //   192: goto +4 -> 196
    //   195: pop
    //   196: aload_1
    //   197: invokevirtual 146	java/io/ByteArrayOutputStream:close	()V
    //   200: goto +4 -> 204
    //   203: pop
    //   204: goto +6 -> 210
    //   207: aload 7
    //   209: athrow
    //   210: goto -3 -> 207
    //
    // Exception table:
    //   from	to	target	type
    //   98	102	105	java/io/IOException
    //   105	106	113	java/io/IOException
    //   106	110	113	java/io/IOException
    //   19	48	138	finally
    //   48	95	138	finally
    //   19	48	143	java/io/IOException
    //   48	95	143	java/io/IOException
    //   10	19	148	finally
    //   155	161	148	finally
    //   10	19	155	java/io/IOException
    //   165	169	172	java/io/IOException
    //   172	173	180	java/io/IOException
    //   173	177	180	java/io/IOException
    //   188	192	195	java/io/IOException
    //   195	196	203	java/io/IOException
    //   196	200	203	java/io/IOException
  }

  public final Map<String, Object> a()
  {
    return Collections.unmodifiableMap(this.b);
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if ((paramObject != null) && (getClass() == paramObject.getClass()))
    {
      e locale = (e)paramObject;
      return this.b.equals(locale.b);
    }
    return false;
  }

  public final int hashCode()
  {
    return 31 * this.b.hashCode();
  }

  public static final class a
  {
    private Map<String, Object> a = new HashMap();

    static
    {
      CoverageLogger.Log(38627328);
    }

    public final a a(Map<String, Object> paramMap)
    {
      Iterator localIterator = paramMap.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        String str = (String)localEntry.getKey();
        Object localObject = localEntry.getValue();
        if (localObject == null)
        {
          this.a.put(str, null);
        }
        else
        {
          Class localClass = localObject.getClass();
          if ((localClass != Boolean.class) && (localClass != Integer.class) && (localClass != Long.class) && (localClass != Float.class) && (localClass != Double.class) && (localClass != String.class) && (localClass != [Ljava.lang.Boolean.class) && (localClass != [Ljava.lang.Integer.class) && (localClass != [Ljava.lang.Long.class) && (localClass != [Ljava.lang.Float.class) && (localClass != [Ljava.lang.Double.class) && (localClass != [Ljava.lang.String.class))
          {
            int i = 0;
            if (localClass == [Z.class)
            {
              Map localMap5 = this.a;
              boolean[] arrayOfBoolean = (boolean[])localObject;
              Boolean[] arrayOfBoolean1 = new Boolean[arrayOfBoolean.length];
              while (i < arrayOfBoolean.length)
              {
                arrayOfBoolean1[i] = Boolean.valueOf(arrayOfBoolean[i]);
                i++;
              }
              localMap5.put(str, arrayOfBoolean1);
            }
            else if (localClass == [I.class)
            {
              Map localMap4 = this.a;
              int[] arrayOfInt = (int[])localObject;
              Integer[] arrayOfInteger = new Integer[arrayOfInt.length];
              while (i < arrayOfInt.length)
              {
                arrayOfInteger[i] = Integer.valueOf(arrayOfInt[i]);
                i++;
              }
              localMap4.put(str, arrayOfInteger);
            }
            else if (localClass == [J.class)
            {
              Map localMap3 = this.a;
              long[] arrayOfLong = (long[])localObject;
              Long[] arrayOfLong1 = new Long[arrayOfLong.length];
              while (i < arrayOfLong.length)
              {
                arrayOfLong1[i] = Long.valueOf(arrayOfLong[i]);
                i++;
              }
              localMap3.put(str, arrayOfLong1);
            }
            else if (localClass == [F.class)
            {
              Map localMap2 = this.a;
              float[] arrayOfFloat = (float[])localObject;
              Float[] arrayOfFloat1 = new Float[arrayOfFloat.length];
              while (i < arrayOfFloat.length)
              {
                arrayOfFloat1[i] = Float.valueOf(arrayOfFloat[i]);
                i++;
              }
              localMap2.put(str, arrayOfFloat1);
            }
            else if (localClass == [D.class)
            {
              Map localMap1 = this.a;
              double[] arrayOfDouble = (double[])localObject;
              Double[] arrayOfDouble1 = new Double[arrayOfDouble.length];
              while (i < arrayOfDouble.length)
              {
                arrayOfDouble1[i] = Double.valueOf(arrayOfDouble[i]);
                i++;
              }
              localMap1.put(str, arrayOfDouble1);
            }
            else
            {
              throw new IllegalArgumentException(a.a("Key %s has invalid type %s", new Object[] { str, localClass }));
            }
          }
          else
          {
            this.a.put(str, localObject);
          }
        }
      }
      return this;
    }

    public final e a()
    {
      e locale = new e(this.a);
      e.a(locale);
      return locale;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.e
 * JD-Core Version:    0.6.2
 */