package androidx.work;

import android.net.Network;
import android.net.Uri;
import androidx.work.impl.utils.b.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class WorkerParameters
{
  public UUID a;
  public e b;
  public Set<String> c;
  public int d;
  public Executor e;
  public a f;
  public k g;
  private a h;

  static
  {
    CoverageLogger.Log(38553600);
  }

  public WorkerParameters(UUID paramUUID, e parame, Collection<String> paramCollection, a parama, int paramInt, Executor paramExecutor, a parama1, k paramk)
  {
    this.a = paramUUID;
    this.b = parame;
    this.c = new HashSet(paramCollection);
    this.h = parama;
    this.d = paramInt;
    this.e = paramExecutor;
    this.f = parama1;
    this.g = paramk;
  }

  public static final class a
  {
    public List<String> a = Collections.emptyList();
    public List<Uri> b = Collections.emptyList();
    public Network c;

    static
    {
      CoverageLogger.Log(38555648);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.WorkerParameters
 * JD-Core Version:    0.6.2
 */