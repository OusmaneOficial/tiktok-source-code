package androidx.work;

import com.ss.android.ugc.aweme.bn.g;
import com.ss.android.ugc.aweme.bn.l;
import com.ss.android.ugc.aweme.bn.l.a;
import com.ss.android.ugc.aweme.bn.o;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

public final class b
{
  public final Executor a;
  public final k b;
  public final int c;
  public final int d;
  public final int e;
  public final int f;

  static
  {
    CoverageLogger.Log(38612992);
  }

  b(a parama)
  {
    if (parama.a == null)
    {
      int i = Math.max(2, Math.min(-1 + Runtime.getRuntime().availableProcessors(), 4));
      this.a = g.a(l.a(o.FIXED).a(i).a());
    }
    else
    {
      this.a = parama.a;
    }
    if (parama.b == null)
      this.b = new k.1();
    else
      this.b = parama.b;
    this.c = parama.c;
    this.d = parama.d;
    this.e = parama.e;
    this.f = parama.f;
  }

  public static final class a
  {
    Executor a;
    k b;
    int c = 4;
    int d;
    int e = 2147483647;
    int f = 20;

    static
    {
      CoverageLogger.Log(38606848);
    }

    public final b a()
    {
      return new b(this);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.b
 * JD-Core Version:    0.6.2
 */