package androidx.work;

import android.content.Context;
import androidx.work.impl.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class j
{
  static
  {
    CoverageLogger.Log(38660096);
  }

  public static void a(Context paramContext, b paramb)
  {
    synchronized (f.l)
    {
      if ((f.j != null) && (f.k != null))
        throw new IllegalStateException("WorkManager is already initialized.  Did you try to initialize it manually without disabling WorkManagerInitializer? See WorkManager#initialize(Context, Configuration) or the class levelJavadoc for more information.");
      if (f.j == null)
      {
        Context localContext = paramContext.getApplicationContext();
        if (f.k == null)
          f.k = new f(localContext, paramb, new androidx.work.impl.utils.b.b());
        f.j = f.k;
      }
      return;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.j
 * JD-Core Version:    0.6.2
 */