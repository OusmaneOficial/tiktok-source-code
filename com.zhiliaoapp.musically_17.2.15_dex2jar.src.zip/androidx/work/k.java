package androidx.work;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class k
{
  private static final String a = g.a("WorkerFactory");

  static
  {
    CoverageLogger.Log(38559744);
  }

  // ERROR //
  public final ListenableWorker a(android.content.Context paramContext, String paramString, WorkerParameters paramWorkerParameters)
  {
    // Byte code:
    //   0: aload_2
    //   1: invokestatic 38	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   4: ldc 40
    //   6: invokevirtual 44	java/lang/Class:asSubclass	(Ljava/lang/Class;)Ljava/lang/Class;
    //   9: astore 6
    //   11: aload 6
    //   13: iconst_2
    //   14: anewarray 34	java/lang/Class
    //   17: dup
    //   18: iconst_0
    //   19: ldc 46
    //   21: aastore
    //   22: dup
    //   23: iconst_1
    //   24: ldc 48
    //   26: aastore
    //   27: invokevirtual 52	java/lang/Class:getDeclaredConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   30: iconst_2
    //   31: anewarray 4	java/lang/Object
    //   34: dup
    //   35: iconst_0
    //   36: aload_1
    //   37: aastore
    //   38: dup
    //   39: iconst_1
    //   40: aload_3
    //   41: aastore
    //   42: invokevirtual 58	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   45: checkcast 40	androidx/work/ListenableWorker
    //   48: astore 11
    //   50: aload 11
    //   52: areturn
    //   53: astore 7
    //   55: invokestatic 61	androidx/work/g:a	()Landroidx/work/g;
    //   58: pop
    //   59: new 63	java/lang/StringBuilder
    //   62: dup
    //   63: ldc 65
    //   65: invokespecial 68	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   68: aload_2
    //   69: invokevirtual 72	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: pop
    //   73: iconst_1
    //   74: anewarray 74	java/lang/Throwable
    //   77: dup
    //   78: iconst_0
    //   79: aload 7
    //   81: aastore
    //   82: pop
    //   83: aconst_null
    //   84: areturn
    //   85: invokestatic 61	androidx/work/g:a	()Landroidx/work/g;
    //   88: pop
    //   89: new 63	java/lang/StringBuilder
    //   92: dup
    //   93: ldc 76
    //   95: invokespecial 68	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   98: aload_2
    //   99: invokevirtual 72	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: pop
    //   103: aconst_null
    //   104: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   11	50	53	java/lang/Exception
    //   0	11	85	java/lang/ClassNotFoundException
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.k
 * JD-Core Version:    0.6.2
 */