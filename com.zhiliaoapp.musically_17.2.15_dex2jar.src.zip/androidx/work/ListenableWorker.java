package androidx.work;

import android.content.Context;
import com.google.b.h.a.m;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.UUID;
import java.util.concurrent.Executor;

public abstract class ListenableWorker
{
  public Context a;
  public WorkerParameters b;
  public volatile boolean c;
  public boolean d;

  static
  {
    CoverageLogger.Log(38580224);
  }

  public ListenableWorker(Context paramContext, WorkerParameters paramWorkerParameters)
  {
    if (paramContext != null)
    {
      if (paramWorkerParameters != null)
      {
        this.a = paramContext;
        this.b = paramWorkerParameters;
        return;
      }
      throw new IllegalArgumentException("WorkerParameters is null");
    }
    throw new IllegalArgumentException("Application Context is null");
  }

  public final UUID a()
  {
    return this.b.a;
  }

  public final e b()
  {
    return this.b.b;
  }

  public abstract m<a> c();

  public final void d()
  {
    this.c = true;
    e();
  }

  public void e()
  {
  }

  public final Executor f()
  {
    return this.b.e;
  }

  public static abstract class a
  {
    static
    {
      CoverageLogger.Log(38637568);
    }

    public static a a()
    {
      return new b();
    }

    public static a b()
    {
      return new a();
    }

    public static final class a extends ListenableWorker.a
    {
      public final e a;

      static
      {
        CoverageLogger.Log(38590464);
      }

      public a()
      {
        this(e.a);
      }

      private a(e parame)
      {
        this.a = parame;
      }

      public final boolean equals(Object paramObject)
      {
        if (this == paramObject)
          return true;
        if ((paramObject != null) && (getClass() == paramObject.getClass()))
        {
          a locala = (a)paramObject;
          return this.a.equals(locala.a);
        }
        return false;
      }

      public final int hashCode()
      {
        return 31 * a.class.getName().hashCode() + this.a.hashCode();
      }

      public final String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder("Failure {mOutputData=");
        localStringBuilder.append(this.a);
        localStringBuilder.append('}');
        return localStringBuilder.toString();
      }
    }

    public static final class b extends ListenableWorker.a
    {
      static
      {
        CoverageLogger.Log(38633472);
      }

      public final boolean equals(Object paramObject)
      {
        if (this == paramObject)
          return true;
        return (paramObject != null) && (getClass() == paramObject.getClass());
      }

      public final int hashCode()
      {
        return b.class.getName().hashCode();
      }

      public final String toString()
      {
        return "Retry";
      }
    }

    public static final class c extends ListenableWorker.a
    {
      public final e a;

      static
      {
        CoverageLogger.Log(38584320);
      }

      public c()
      {
        this(e.a);
      }

      public c(e parame)
      {
        this.a = parame;
      }

      public final boolean equals(Object paramObject)
      {
        if (this == paramObject)
          return true;
        if ((paramObject != null) && (getClass() == paramObject.getClass()))
        {
          c localc = (c)paramObject;
          return this.a.equals(localc.a);
        }
        return false;
      }

      public final int hashCode()
      {
        return 31 * c.class.getName().hashCode() + this.a.hashCode();
      }

      public final String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder("Success {mOutputData=");
        localStringBuilder.append(this.a);
        localStringBuilder.append('}');
        return localStringBuilder.toString();
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.ListenableWorker
 * JD-Core Version:    0.6.2
 */