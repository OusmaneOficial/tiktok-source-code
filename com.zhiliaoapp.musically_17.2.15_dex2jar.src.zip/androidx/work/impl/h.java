package androidx.work.impl;

import androidx.lifecycle.LiveData;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

final class h
{
  final Set<LiveData> a = Collections.newSetFromMap(new IdentityHashMap());

  static
  {
    CoverageLogger.Log(38729728);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.h
 * JD-Core Version:    0.6.2
 */