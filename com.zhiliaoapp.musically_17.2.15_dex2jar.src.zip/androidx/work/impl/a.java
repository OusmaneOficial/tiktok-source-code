package androidx.work.impl;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a
{
  static
  {
    CoverageLogger.Log(38680576);
  }

  public abstract void a(String paramString, boolean paramBoolean);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.a
 * JD-Core Version:    0.6.2
 */