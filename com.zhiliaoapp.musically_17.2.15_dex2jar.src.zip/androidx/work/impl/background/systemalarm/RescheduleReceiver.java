package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.BroadcastReceiver.PendingResult;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import androidx.work.g;
import androidx.work.impl.f;
import com.a;
import com.ss.android.ugc.aweme.push.downgrade.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class RescheduleReceiver extends BroadcastReceiver
{
  private static final String a = g.a("RescheduleReceiver");

  static
  {
    CoverageLogger.Log(38488064);
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    g.a();
    a.a("Received intent %s", new Object[] { paramIntent });
    if (Build.VERSION.SDK_INT >= 23)
    {
      f localf = f.a();
      if (localf == null)
      {
        g.a();
        return;
      }
      BroadcastReceiver.PendingResult localPendingResult = goAsync();
      synchronized (f.l)
      {
        localf.i = localPendingResult;
        if (localf.h)
        {
          localf.i.finish();
          localf.i = null;
        }
        return;
      }
    }
    Intent localIntent = new Intent(paramContext, SystemAlarmService.class);
    localIntent.setAction("ACTION_RESCHEDULE");
    if ((paramContext != null) && ((paramContext instanceof Context)) && (d.a((Context)paramContext, localIntent)))
      return;
    paramContext.startService(localIntent);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemalarm.RescheduleReceiver
 * JD-Core Version:    0.6.2
 */