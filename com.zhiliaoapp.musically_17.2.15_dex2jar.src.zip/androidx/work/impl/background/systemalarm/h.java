package androidx.work.impl.background.systemalarm;

import com.a;
import com.ss.android.ugc.aweme.bn.l;
import com.ss.android.ugc.aweme.bn.l.a;
import com.ss.android.ugc.aweme.bn.o;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;

final class h
{
  private static final String e = androidx.work.g.a("WorkTimer");
  public final ScheduledExecutorService a;
  final Map<String, b> b = new HashMap();
  final Map<String, a> c = new HashMap();
  final Object d = new Object();
  private final ThreadFactory f = new ThreadFactory()
  {
    private int b;

    static
    {
      CoverageLogger.Log(38776832);
    }

    public final Thread newThread(Runnable paramAnonymousRunnable)
    {
      Thread localThread = Executors.defaultThreadFactory().newThread(paramAnonymousRunnable);
      StringBuilder localStringBuilder = new StringBuilder("WorkManager-WorkTimer-thread-");
      localStringBuilder.append(this.b);
      localThread.setName(localStringBuilder.toString());
      this.b = (1 + this.b);
      return localThread;
    }
  };

  static
  {
    CoverageLogger.Log(38780928);
  }

  h()
  {
    ThreadFactory localThreadFactory = this.f;
    this.a = ((ScheduledExecutorService)com.ss.android.ugc.aweme.bn.g.a(l.a(o.SCHEDULED).a(1).a(localThreadFactory).a()));
  }

  final void a(String paramString)
  {
    synchronized (this.d)
    {
      if ((b)this.b.remove(paramString) != null)
      {
        androidx.work.g.a();
        a.a("Stopping timer for %s", new Object[] { paramString });
        this.c.remove(paramString);
      }
      return;
    }
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(38469632);
    }

    public abstract void a(String paramString);
  }

  static final class b
    implements Runnable
  {
    private final h a;
    private final String b;

    static
    {
      CoverageLogger.Log(38778880);
    }

    b(h paramh, String paramString)
    {
      this.a = paramh;
      this.b = paramString;
    }

    public final void run()
    {
      synchronized (this.a.d)
      {
        if ((b)this.a.b.remove(this.b) != null)
        {
          h.a locala = (h.a)this.a.c.remove(this.b);
          if (locala != null)
            locala.a(this.b);
        }
        else
        {
          androidx.work.g.a();
          Object[] arrayOfObject = new Object[1];
          arrayOfObject[0] = this.b;
          a.a("Timer with %s is already marked as complete.", arrayOfObject);
        }
        return;
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemalarm.h
 * JD-Core Version:    0.6.2
 */