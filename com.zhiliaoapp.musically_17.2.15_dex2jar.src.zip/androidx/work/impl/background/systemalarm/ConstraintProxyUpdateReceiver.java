package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.g;
import androidx.work.impl.utils.b;
import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class ConstraintProxyUpdateReceiver extends BroadcastReceiver
{
  private static final String a = g.a("ConstrntProxyUpdtRecvr");

  static
  {
    CoverageLogger.Log(38494208);
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str;
    if (paramIntent != null)
      str = paramIntent.getAction();
    else
      str = null;
    if (!"androidx.work.impl.background.systemalarm.UpdateProxies".equals(str))
    {
      g.a();
      a.a("Ignoring unknown action %s", new Object[] { str });
      return;
    }
    boolean bool1 = paramIntent.getBooleanExtra("KEY_BATTERY_NOT_LOW_PROXY_ENABLED", false);
    boolean bool2 = paramIntent.getBooleanExtra("KEY_BATTERY_CHARGING_PROXY_ENABLED", false);
    boolean bool3 = paramIntent.getBooleanExtra("KEY_STORAGE_NOT_LOW_PROXY_ENABLED", false);
    boolean bool4 = paramIntent.getBooleanExtra("KEY_NETWORK_STATE_PROXY_ENABLED", false);
    g.a();
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = Boolean.valueOf(bool1);
    arrayOfObject[1] = Boolean.valueOf(bool2);
    arrayOfObject[2] = Boolean.valueOf(bool3);
    arrayOfObject[3] = Boolean.valueOf(bool4);
    a.a("Updating proxies: BatteryNotLowProxy enabled (%s), BatteryChargingProxy enabled (%s), StorageNotLowProxy (%s), NetworkStateProxy enabled (%s)", arrayOfObject);
    b.a(paramContext, ConstraintProxy.BatteryNotLowProxy.class, bool1);
    b.a(paramContext, ConstraintProxy.BatteryChargingProxy.class, bool2);
    b.a(paramContext, ConstraintProxy.StorageNotLowProxy.class, bool3);
    b.a(paramContext, ConstraintProxy.NetworkStateProxy.class, bool4);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemalarm.ConstraintProxyUpdateReceiver
 * JD-Core Version:    0.6.2
 */