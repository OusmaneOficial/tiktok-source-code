package androidx.work.impl.background.systemalarm;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.ss.android.ugc.aweme.push.downgrade.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class g
{
  static
  {
    CoverageLogger.Log(1325056);
  }

  static ComponentName a(Context paramContext, Intent paramIntent)
  {
    if ((paramContext != null) && ((paramContext instanceof Context)))
    {
      if (d.a((Context)paramContext, paramIntent))
        return null;
      return paramContext.startService(paramIntent);
    }
    return paramContext.startService(paramIntent);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemalarm.g
 * JD-Core Version:    0.6.2
 */