package androidx.work.impl.background.systemalarm;

import android.content.Context;
import androidx.work.g;
import androidx.work.impl.a.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class c
{
  private static final String e = g.a("ConstraintsCmdHandler");
  final Context a;
  final int b;
  final e c;
  final d d;

  static
  {
    CoverageLogger.Log(38490112);
  }

  c(Context paramContext, int paramInt, e parame)
  {
    this.a = paramContext;
    this.b = paramInt;
    this.c = parame;
    this.d = new d(this.a, null);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemalarm.c
 * JD-Core Version:    0.6.2
 */