package androidx.work.impl.background.systemalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build.VERSION;
import androidx.work.g;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.b.d;
import androidx.work.impl.b.e;
import androidx.work.impl.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class a
{
  private static final String a = g.a("Alarms");

  static
  {
    CoverageLogger.Log(38504448);
  }

  public static void a(Context paramContext, f paramf, String paramString, long paramLong)
  {
    e locale = paramf.c.j();
    d locald = locale.a(paramString);
    if (locald != null)
    {
      a(paramContext, paramString, locald.b);
      a(paramContext, paramString, locald.b, paramLong);
      return;
    }
    int i = new androidx.work.impl.utils.a(paramContext).a();
    locale.a(new d(paramString, i));
    a(paramContext, paramString, i, paramLong);
  }

  static void a(Context paramContext, String paramString, int paramInt)
  {
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent localPendingIntent = PendingIntent.getService(paramContext, paramInt, b.b(paramContext, paramString), 536870912);
    if ((localPendingIntent != null) && (localAlarmManager != null))
    {
      g.a();
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = paramString;
      arrayOfObject[1] = Integer.valueOf(paramInt);
      com.a.a("Cancelling existing alarm with (workSpecId, systemId) (%s, %s)", arrayOfObject);
      localAlarmManager.cancel(localPendingIntent);
    }
  }

  private static void a(Context paramContext, String paramString, int paramInt, long paramLong)
  {
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent localPendingIntent = PendingIntent.getService(paramContext, paramInt, b.b(paramContext, paramString), 1073741824);
    if (localAlarmManager != null)
    {
      if (Build.VERSION.SDK_INT >= 19)
      {
        localAlarmManager.setExact(0, paramLong, localPendingIntent);
        return;
      }
      localAlarmManager.set(0, paramLong, localPendingIntent);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemalarm.a
 * JD-Core Version:    0.6.2
 */