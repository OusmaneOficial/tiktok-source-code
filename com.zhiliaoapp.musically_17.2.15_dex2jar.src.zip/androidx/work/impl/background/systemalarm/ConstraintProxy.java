package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.g;
import com.a;
import com.ss.android.ugc.aweme.push.downgrade.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

abstract class ConstraintProxy extends BroadcastReceiver
{
  private static final String a = g.a("ConstraintProxy");

  static
  {
    CoverageLogger.Log(38496256);
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    g.a();
    a.a("onReceive : %s", new Object[] { paramIntent });
    Intent localIntent = b.a(paramContext);
    if ((paramContext != null) && ((paramContext instanceof Context)) && (d.a((Context)paramContext, localIntent)))
      return;
    paramContext.startService(localIntent);
  }

  public static class BatteryChargingProxy extends ConstraintProxy
  {
    static
    {
      CoverageLogger.Log(38502400);
    }
  }

  public static class BatteryNotLowProxy extends ConstraintProxy
  {
    static
    {
      CoverageLogger.Log(38750208);
    }
  }

  public static class NetworkStateProxy extends ConstraintProxy
  {
    static
    {
      CoverageLogger.Log(38498304);
    }
  }

  public static class StorageNotLowProxy extends ConstraintProxy
  {
    static
    {
      CoverageLogger.Log(38754304);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemalarm.ConstraintProxy
 * JD-Core Version:    0.6.2
 */