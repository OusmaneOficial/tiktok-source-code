package androidx.work.impl.background.systemjob;

import android.app.job.JobInfo;
import android.app.job.JobInfo.Builder;
import android.app.job.JobInfo.TriggerContentUri;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.PersistableBundle;
import androidx.work.c;
import androidx.work.d;
import androidx.work.d.a;
import androidx.work.h;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Iterator;
import java.util.Set;

final class a
{
  private static final String a = androidx.work.g.a("SystemJobInfoConverter");
  private final ComponentName b;

  static
  {
    CoverageLogger.Log(38463488);
  }

  a(Context paramContext)
  {
    this.b = new ComponentName(paramContext.getApplicationContext(), SystemJobService.class);
  }

  final JobInfo a(androidx.work.impl.b.g paramg, int paramInt)
  {
    c localc = paramg.j;
    h localh = localc.b;
    int i = 1.a[localh.ordinal()];
    int j = 4;
    int k = 1;
    if (i != k)
    {
      if (i != 2)
      {
        if (i != 3)
        {
          if (i != j)
          {
            if ((i == 5) && (Build.VERSION.SDK_INT >= 26))
              break label128;
          }
          else if (Build.VERSION.SDK_INT >= 24)
          {
            j = 3;
            break label128;
          }
          androidx.work.g.a();
          Object[] arrayOfObject = new Object[k];
          arrayOfObject[0] = localh;
          com.a.a("API version too low. Cannot convert network type value %s", arrayOfObject);
        }
      }
      else
      {
        j = 1;
        break label128;
      }
      j = 2;
    }
    else
    {
      j = 0;
    }
    label128: PersistableBundle localPersistableBundle = new PersistableBundle();
    localPersistableBundle.putString("EXTRA_WORK_SPEC_ID", paramg.a);
    localPersistableBundle.putBoolean("EXTRA_IS_PERIODIC", paramg.a());
    JobInfo.Builder localBuilder = new JobInfo.Builder(paramInt, this.b).setRequiredNetworkType(j).setRequiresCharging(localc.c).setRequiresDeviceIdle(localc.d).setExtras(localPersistableBundle);
    if (!localc.d)
    {
      if (paramg.l == androidx.work.a.LINEAR)
        k = 0;
      localBuilder.setBackoffCriteria(paramg.m, k);
    }
    if (paramg.a())
    {
      if (Build.VERSION.SDK_INT >= 24)
      {
        localBuilder.setPeriodic(paramg.h, paramg.i);
      }
      else
      {
        androidx.work.g.a();
        localBuilder.setPeriodic(paramg.h);
      }
    }
    else
      localBuilder.setMinimumLatency(paramg.g);
    if ((Build.VERSION.SDK_INT >= 24) && (localc.a()))
    {
      Iterator localIterator = localc.i.a.iterator();
      while (localIterator.hasNext())
      {
        d.a locala = (d.a)localIterator.next();
        int m = locala.b;
        localBuilder.addTriggerContentUri(new JobInfo.TriggerContentUri(locala.a, m));
      }
      localBuilder.setTriggerContentUpdateDelay(localc.g);
      localBuilder.setTriggerContentMaxDelay(localc.h);
    }
    localBuilder.setPersisted(false);
    if (Build.VERSION.SDK_INT >= 26)
    {
      localBuilder.setRequiresBatteryNotLow(localc.e);
      localBuilder.setRequiresStorageNotLow(localc.f);
    }
    return localBuilder.build();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.background.systemjob.a
 * JD-Core Version:    0.6.2
 */