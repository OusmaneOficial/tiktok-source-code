package androidx.work.impl;

import android.content.Context;
import android.os.Build.VERSION;
import androidx.work.ListenableWorker;
import androidx.work.ListenableWorker.a;
import androidx.work.ListenableWorker.a.a;
import androidx.work.ListenableWorker.a.b;
import androidx.work.ListenableWorker.a.c;
import androidx.work.WorkerParameters;
import androidx.work.WorkerParameters.a;
import androidx.work.e;
import androidx.work.f;
import androidx.work.impl.b.h;
import androidx.work.impl.background.systemalarm.RescheduleReceiver;
import com.google.b.h.a.m;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class i
  implements Runnable
{
  static final String a = androidx.work.g.a("WorkerWrapper");
  androidx.work.impl.b.g b;
  ListenableWorker c;
  ListenableWorker.a d = ListenableWorker.a.b();
  public androidx.work.impl.utils.a.c<Boolean> e = androidx.work.impl.utils.a.c.a();
  m<ListenableWorker.a> f = null;
  volatile boolean g;
  private Context h;
  private String i;
  private List<c> j;
  private WorkerParameters.a k;
  private androidx.work.b l;
  private androidx.work.impl.utils.b.a m;
  private WorkDatabase n;
  private h o;
  private androidx.work.impl.b.b p;
  private androidx.work.impl.b.k q;
  private List<String> r;
  private String s;

  static
  {
    CoverageLogger.Log(38731776);
  }

  i(a parama)
  {
    this.h = parama.a;
    this.m = parama.c;
    this.i = parama.f;
    this.j = parama.g;
    this.k = parama.h;
    this.c = parama.b;
    this.l = parama.d;
    this.n = parama.e;
    this.o = this.n.g();
    this.p = this.n.h();
    this.q = this.n.i();
  }

  private void a(String paramString)
  {
    Iterator localIterator = this.p.b(paramString).iterator();
    while (localIterator.hasNext())
      a((String)localIterator.next());
    if (this.o.d(paramString) != androidx.work.i.a.CANCELLED)
      this.o.a(androidx.work.i.a.FAILED, new String[] { paramString });
  }

  private void a(boolean paramBoolean)
  {
    try
    {
      this.n.c();
      if (this.n.g().a().isEmpty())
        androidx.work.impl.utils.b.a(this.h, RescheduleReceiver.class, false);
      this.n.e();
      this.n.d();
      this.e.a(Boolean.valueOf(paramBoolean));
      return;
    }
    finally
    {
      this.n.d();
    }
  }

  private void c()
  {
    androidx.work.i.a locala = this.o.d(this.i);
    if (locala == androidx.work.i.a.RUNNING)
    {
      androidx.work.g.a();
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = this.i;
      com.a.a("Status for %s is RUNNING;not doing any work and rescheduling for later execution", arrayOfObject2);
      a(true);
      return;
    }
    androidx.work.g.a();
    Object[] arrayOfObject1 = new Object[2];
    arrayOfObject1[0] = this.i;
    arrayOfObject1[1] = locala;
    com.a.a("Status for %s is %s; not doing any work", arrayOfObject1);
    a(false);
  }

  private boolean d()
  {
    this.n.c();
    while (true)
    {
      try
      {
        androidx.work.i.a locala1 = this.o.d(this.i);
        androidx.work.i.a locala2 = androidx.work.i.a.ENQUEUED;
        bool = true;
        if (locala1 == locala2)
        {
          h localh = this.o;
          androidx.work.i.a locala3 = androidx.work.i.a.RUNNING;
          String[] arrayOfString = new String[bool];
          arrayOfString[0] = this.i;
          localh.a(locala3, arrayOfString);
          this.o.b(this.i);
          this.n.e();
          return bool;
        }
      }
      finally
      {
        this.n.d();
      }
      boolean bool = false;
    }
  }

  private void e()
  {
    this.n.c();
    try
    {
      a(this.i);
      e locale = ((ListenableWorker.a.a)this.d).a;
      this.o.a(this.i, locale);
      this.n.e();
      return;
    }
    finally
    {
      this.n.d();
      a(false);
    }
  }

  private void f()
  {
    this.n.c();
    try
    {
      h localh = this.o;
      androidx.work.i.a locala = androidx.work.i.a.ENQUEUED;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = this.i;
      localh.a(locala, arrayOfString);
      this.o.a(this.i, System.currentTimeMillis());
      if (Build.VERSION.SDK_INT < 23)
        this.o.b(this.i, -1L);
      this.n.e();
      return;
    }
    finally
    {
      this.n.d();
      a(true);
    }
  }

  private void g()
  {
    this.n.c();
    try
    {
      this.o.a(this.i, System.currentTimeMillis());
      h localh = this.o;
      androidx.work.i.a locala = androidx.work.i.a.ENQUEUED;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = this.i;
      localh.a(locala, arrayOfString);
      this.o.c(this.i);
      if (Build.VERSION.SDK_INT < 23)
        this.o.b(this.i, -1L);
      this.n.e();
      return;
    }
    finally
    {
      this.n.d();
      a(false);
    }
  }

  private void h()
  {
    this.n.c();
    try
    {
      h localh = this.o;
      androidx.work.i.a locala = androidx.work.i.a.SUCCEEDED;
      String[] arrayOfString = new String[1];
      arrayOfString[0] = this.i;
      localh.a(locala, arrayOfString);
      e locale = ((ListenableWorker.a.c)this.d).a;
      this.o.a(this.i, locale);
      long l1 = System.currentTimeMillis();
      Iterator localIterator = this.p.b(this.i).iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if ((this.o.d(str) == androidx.work.i.a.BLOCKED) && (this.p.a(str)))
        {
          androidx.work.g.a();
          com.a.a("Setting status to enqueued for %s", new Object[] { str });
          this.o.a(androidx.work.i.a.ENQUEUED, new String[] { str });
          this.o.a(str, l1);
        }
      }
      this.n.e();
      this.n.d();
      a(false);
      return;
    }
    finally
    {
      this.n.d();
      a(false);
    }
    while (true)
      throw localObject;
  }

  final void a()
  {
    if (this.m.b() == Thread.currentThread())
    {
      boolean bool1 = b();
      boolean bool2 = false;
      if (!bool1)
        try
        {
          this.n.c();
          androidx.work.i.a locala = this.o.d(this.i);
          if (locala == null)
          {
            a(false);
            bool2 = true;
          }
          else if (locala == androidx.work.i.a.RUNNING)
          {
            ListenableWorker.a locala1 = this.d;
            if ((locala1 instanceof ListenableWorker.a.c))
            {
              androidx.work.g.a();
              Object[] arrayOfObject3 = new Object[1];
              arrayOfObject3[0] = this.s;
              com.a.a("Worker result SUCCESS for %s", arrayOfObject3);
              if (this.b.a())
                g();
              else
                h();
            }
            else if ((locala1 instanceof ListenableWorker.a.b))
            {
              androidx.work.g.a();
              Object[] arrayOfObject2 = new Object[1];
              arrayOfObject2[0] = this.s;
              com.a.a("Worker result RETRY for %s", arrayOfObject2);
              f();
            }
            else
            {
              androidx.work.g.a();
              Object[] arrayOfObject1 = new Object[1];
              arrayOfObject1[0] = this.s;
              com.a.a("Worker result FAILURE for %s", arrayOfObject1);
              if (this.b.a())
                g();
              else
                e();
            }
            bool2 = this.o.d(this.i).isFinished();
          }
          else
          {
            boolean bool3 = locala.isFinished();
            bool2 = false;
            if (!bool3)
              f();
          }
          this.n.e();
        }
        finally
        {
          this.n.d();
        }
      List localList = this.j;
      if (localList != null)
      {
        if (bool2)
        {
          Iterator localIterator = localList.iterator();
          while (localIterator.hasNext())
            ((c)localIterator.next()).a(this.i);
        }
        d.a(this.l, this.n, this.j);
      }
      return;
    }
    IllegalStateException localIllegalStateException = new IllegalStateException("Needs to be executed on the Background executor thread.");
    while (true)
      throw localIllegalStateException;
  }

  boolean b()
  {
    if (this.g)
    {
      androidx.work.g.a();
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = this.s;
      com.a.a("Work interrupted for %s", arrayOfObject);
      androidx.work.i.a locala = this.o.d(this.i);
      boolean bool1;
      if (locala == null)
      {
        bool1 = false;
      }
      else
      {
        boolean bool2 = locala.isFinished();
        bool1 = false;
        if (!bool2)
          bool1 = true;
      }
      a(bool1);
      return true;
    }
    return false;
  }

  public final void run()
  {
    this.r = this.q.a(this.i);
    List localList = this.r;
    StringBuilder localStringBuilder = new StringBuilder("Work [ id=");
    localStringBuilder.append(this.i);
    localStringBuilder.append(", tags={ ");
    Iterator localIterator = localList.iterator();
    int i1 = 1;
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (i1 != 0)
        i1 = 0;
      else
        localStringBuilder.append(", ");
      localStringBuilder.append(str);
    }
    localStringBuilder.append(" } ]");
    this.s = localStringBuilder.toString();
    if (!b())
      this.n.c();
    while (true)
    {
      try
      {
        this.b = this.o.a(this.i);
        if (this.b == null)
        {
          androidx.work.g.a();
          Object[] arrayOfObject6 = new Object[1];
          arrayOfObject6[0] = this.i;
          com.a.a("Didn't find WorkSpec for id %s", arrayOfObject6);
          a(false);
          return;
        }
        if (this.b.b != androidx.work.i.a.ENQUEUED)
        {
          c();
          this.n.e();
          androidx.work.g.a();
          Object[] arrayOfObject5 = new Object[1];
          arrayOfObject5[0] = this.b.c;
          com.a.a("%s is not in ENQUEUED state. Nothing more to do.", arrayOfObject5);
          return;
        }
        if ((this.b.a()) || (this.b.b()))
        {
          long l1 = System.currentTimeMillis();
          if ((Build.VERSION.SDK_INT >= 23) || (this.b.h == this.b.i) || (this.b.n != 0L))
            break label819;
          i2 = 1;
          if ((i2 == 0) && (l1 < this.b.c()))
          {
            androidx.work.g.a();
            Object[] arrayOfObject4 = new Object[1];
            arrayOfObject4[0] = this.b.c;
            com.a.a("Delaying execution for %s because it is being executed before schedule.", arrayOfObject4);
            a(true);
            return;
          }
        }
        this.n.e();
        this.n.d();
        e locale1;
        e locale2;
        if (this.b.a())
        {
          locale1 = this.b.e;
          locale2 = locale1;
        }
        else
        {
          f localf = f.a(this.b.d);
          if (localf == null)
          {
            androidx.work.g.a();
            Object[] arrayOfObject3 = new Object[1];
            arrayOfObject3[0] = this.b.d;
            com.a.a("Could not create Input Merger %s", arrayOfObject3);
            e();
            return;
          }
          ArrayList localArrayList = new ArrayList();
          localArrayList.add(this.b.e);
          localArrayList.addAll(this.o.e(this.i));
          locale1 = localf.a(localArrayList);
          continue;
        }
        WorkerParameters localWorkerParameters = new WorkerParameters(UUID.fromString(this.i), locale2, this.r, this.k, this.b.k, this.l.a, this.m, this.l.b);
        if (this.c == null)
          this.c = this.l.b.a(this.h, this.b.c, localWorkerParameters);
        ListenableWorker localListenableWorker = this.c;
        if (localListenableWorker == null)
        {
          androidx.work.g.a();
          Object[] arrayOfObject2 = new Object[1];
          arrayOfObject2[0] = this.b.c;
          com.a.a("Could not create Worker %s", arrayOfObject2);
          e();
          return;
        }
        if (localListenableWorker.d)
        {
          androidx.work.g.a();
          Object[] arrayOfObject1 = new Object[1];
          arrayOfObject1[0] = this.b.c;
          com.a.a("Received an already-used Worker %s; WorkerFactory should return new instances", arrayOfObject1);
          e();
          return;
        }
        this.c.d = true;
        if (d())
        {
          if (!b())
          {
            final androidx.work.impl.utils.a.c localc = androidx.work.impl.utils.a.c.a();
            this.m.a().execute(new Runnable()
            {
              static
              {
                CoverageLogger.Log(38742016);
              }

              public final void run()
              {
                try
                {
                  androidx.work.g.a();
                  Object[] arrayOfObject = new Object[1];
                  arrayOfObject[0] = i.this.b.c;
                  com.a.a("Starting work for %s", arrayOfObject);
                  i.this.f = i.this.c.c();
                  return;
                }
                finally
                {
                  localc.a(localThrowable);
                }
              }
            });
            localc.a(new Runnable()
            {
              static
              {
                CoverageLogger.Log(38516736);
              }

              // ERROR //
              public final void run()
              {
                // Byte code:
                //   0: aload_0
                //   1: getfield 29	androidx/work/impl/i$2:a	Landroidx/work/impl/utils/a/c;
                //   4: invokevirtual 46	androidx/work/impl/utils/a/c:get	()Ljava/lang/Object;
                //   7: checkcast 48	androidx/work/ListenableWorker$a
                //   10: astore 12
                //   12: aload 12
                //   14: ifnonnull +38 -> 52
                //   17: invokestatic 53	androidx/work/g:a	()Landroidx/work/g;
                //   20: pop
                //   21: iconst_1
                //   22: anewarray 4	java/lang/Object
                //   25: astore 14
                //   27: aload 14
                //   29: iconst_0
                //   30: aload_0
                //   31: getfield 27	androidx/work/impl/i$2:c	Landroidx/work/impl/i;
                //   34: getfield 56	androidx/work/impl/i:b	Landroidx/work/impl/b/g;
                //   37: getfield 60	androidx/work/impl/b/g:c	Ljava/lang/String;
                //   40: aastore
                //   41: ldc 62
                //   43: aload 14
                //   45: invokestatic 67	com/a:a	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
                //   48: pop
                //   49: goto +50 -> 99
                //   52: invokestatic 53	androidx/work/g:a	()Landroidx/work/g;
                //   55: pop
                //   56: iconst_2
                //   57: anewarray 4	java/lang/Object
                //   60: astore 17
                //   62: aload 17
                //   64: iconst_0
                //   65: aload_0
                //   66: getfield 27	androidx/work/impl/i$2:c	Landroidx/work/impl/i;
                //   69: getfield 56	androidx/work/impl/i:b	Landroidx/work/impl/b/g;
                //   72: getfield 60	androidx/work/impl/b/g:c	Ljava/lang/String;
                //   75: aastore
                //   76: aload 17
                //   78: iconst_1
                //   79: aload 12
                //   81: aastore
                //   82: ldc 69
                //   84: aload 17
                //   86: invokestatic 67	com/a:a	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
                //   89: pop
                //   90: aload_0
                //   91: getfield 27	androidx/work/impl/i$2:c	Landroidx/work/impl/i;
                //   94: aload 12
                //   96: putfield 73	androidx/work/impl/i:d	Landroidx/work/ListenableWorker$a;
                //   99: aload_0
                //   100: getfield 27	androidx/work/impl/i$2:c	Landroidx/work/impl/i;
                //   103: invokevirtual 75	androidx/work/impl/i:a	()V
                //   106: return
                //   107: astore 6
                //   109: goto +85 -> 194
                //   112: astore 7
                //   114: goto +5 -> 119
                //   117: astore 7
                //   119: invokestatic 53	androidx/work/g:a	()Landroidx/work/g;
                //   122: pop
                //   123: iconst_1
                //   124: anewarray 4	java/lang/Object
                //   127: astore 9
                //   129: aload 9
                //   131: iconst_0
                //   132: aload_0
                //   133: getfield 31	androidx/work/impl/i$2:b	Ljava/lang/String;
                //   136: aastore
                //   137: ldc 77
                //   139: aload 9
                //   141: invokestatic 67	com/a:a	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
                //   144: pop
                //   145: iconst_1
                //   146: anewarray 79	java/lang/Throwable
                //   149: dup
                //   150: iconst_0
                //   151: aload 7
                //   153: aastore
                //   154: pop
                //   155: goto -56 -> 99
                //   158: astore_1
                //   159: invokestatic 53	androidx/work/g:a	()Landroidx/work/g;
                //   162: pop
                //   163: iconst_1
                //   164: anewarray 4	java/lang/Object
                //   167: astore_3
                //   168: aload_3
                //   169: iconst_0
                //   170: aload_0
                //   171: getfield 31	androidx/work/impl/i$2:b	Ljava/lang/String;
                //   174: aastore
                //   175: ldc 81
                //   177: aload_3
                //   178: invokestatic 67	com/a:a	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
                //   181: pop
                //   182: iconst_1
                //   183: anewarray 79	java/lang/Throwable
                //   186: dup
                //   187: iconst_0
                //   188: aload_1
                //   189: aastore
                //   190: pop
                //   191: goto -92 -> 99
                //   194: aload_0
                //   195: getfield 27	androidx/work/impl/i$2:c	Landroidx/work/impl/i;
                //   198: invokevirtual 75	androidx/work/impl/i:a	()V
                //   201: goto +6 -> 207
                //   204: aload 6
                //   206: athrow
                //   207: goto -3 -> 204
                //
                // Exception table:
                //   from	to	target	type
                //   0	12	107	finally
                //   17	49	107	finally
                //   52	99	107	finally
                //   119	155	107	finally
                //   159	191	107	finally
                //   0	12	112	java/util/concurrent/ExecutionException
                //   17	49	112	java/util/concurrent/ExecutionException
                //   52	99	112	java/util/concurrent/ExecutionException
                //   0	12	117	java/lang/InterruptedException
                //   17	49	117	java/lang/InterruptedException
                //   52	99	117	java/lang/InterruptedException
                //   0	12	158	java/util/concurrent/CancellationException
                //   17	49	158	java/util/concurrent/CancellationException
                //   52	99	158	java/util/concurrent/CancellationException
              }
            }
            , this.m.c());
          }
        }
        else
        {
          c();
          return;
        }
      }
      finally
      {
        this.n.d();
      }
      return;
      label819: int i2 = 0;
    }
  }

  public static final class a
  {
    Context a;
    ListenableWorker b;
    androidx.work.impl.utils.b.a c;
    androidx.work.b d;
    WorkDatabase e;
    String f;
    List<c> g;
    WorkerParameters.a h = new WorkerParameters.a();

    static
    {
      CoverageLogger.Log(38746112);
    }

    public a(Context paramContext, androidx.work.b paramb, androidx.work.impl.utils.b.a parama, WorkDatabase paramWorkDatabase, String paramString)
    {
      this.a = paramContext.getApplicationContext();
      this.c = parama;
      this.d = paramb;
      this.e = paramWorkDatabase;
      this.f = paramString;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.i
 * JD-Core Version:    0.6.2
 */