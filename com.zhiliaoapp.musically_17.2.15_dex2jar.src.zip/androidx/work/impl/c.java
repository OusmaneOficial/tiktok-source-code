package androidx.work.impl;

import androidx.work.impl.b.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface c
{
  static
  {
    CoverageLogger.Log(38684672);
  }

  public abstract void a(String paramString);

  public abstract void a(g[] paramArrayOfg);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.c
 * JD-Core Version:    0.6.2
 */