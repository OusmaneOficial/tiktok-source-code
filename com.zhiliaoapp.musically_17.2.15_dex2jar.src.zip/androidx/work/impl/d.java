package androidx.work.impl;

import android.content.Context;
import android.os.Build.VERSION;
import androidx.work.impl.b.h;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import androidx.work.impl.background.systemjob.SystemJobService;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Iterator;
import java.util.List;

public final class d
{
  private static final String a = androidx.work.g.a("Schedulers");

  static
  {
    CoverageLogger.Log(38690816);
  }

  static c a(Context paramContext, f paramf)
  {
    int i = Build.VERSION.SDK_INT;
    boolean bool = true;
    Object localObject;
    if (i >= 23)
    {
      localObject = new androidx.work.impl.background.systemjob.b(paramContext, paramf);
      androidx.work.impl.utils.b.a(paramContext, SystemJobService.class, bool);
      androidx.work.g.a();
      bool = false;
    }
    else
    {
      localObject = new androidx.work.impl.background.systemalarm.f(paramContext);
      androidx.work.g.a();
    }
    androidx.work.impl.utils.b.a(paramContext, SystemAlarmService.class, bool);
    return localObject;
  }

  public static void a(androidx.work.b paramb, WorkDatabase paramWorkDatabase, List<c> paramList)
  {
    if (paramList != null)
    {
      if (paramList.size() == 0)
        return;
      h localh = paramWorkDatabase.g();
      paramWorkDatabase.c();
      try
      {
        int i;
        if (Build.VERSION.SDK_INT == 23)
          i = paramb.f / 2;
        else
          i = paramb.f;
        List localList = localh.a(i);
        if (localList.size() > 0)
        {
          long l = System.currentTimeMillis();
          Iterator localIterator2 = localList.iterator();
          while (localIterator2.hasNext())
            localh.b(((androidx.work.impl.b.g)localIterator2.next()).a, l);
        }
        paramWorkDatabase.e();
        paramWorkDatabase.d();
        if (localList.size() > 0)
        {
          androidx.work.impl.b.g[] arrayOfg = (androidx.work.impl.b.g[])localList.toArray(new androidx.work.impl.b.g[0]);
          Iterator localIterator1 = paramList.iterator();
          while (localIterator1.hasNext())
            ((c)localIterator1.next()).a(arrayOfg);
        }
        return;
      }
      finally
      {
        paramWorkDatabase.d();
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.d
 * JD-Core Version:    0.6.2
 */