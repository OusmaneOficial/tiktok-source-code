package androidx.work.impl.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a<T>
{
  static
  {
    CoverageLogger.Log(38467584);
  }

  public abstract void a(T paramT);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.a.a
 * JD-Core Version:    0.6.2
 */