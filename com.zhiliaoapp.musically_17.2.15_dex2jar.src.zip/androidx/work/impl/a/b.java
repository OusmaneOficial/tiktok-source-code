package androidx.work.impl.a;

import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b
{
  public boolean a;
  public boolean b;
  public boolean c;
  public boolean d;

  static
  {
    CoverageLogger.Log(38465536);
  }

  public b(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    this.a = paramBoolean1;
    this.b = paramBoolean2;
    this.c = paramBoolean3;
    this.d = paramBoolean4;
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass())
        return false;
      b localb = (b)paramObject;
      if ((this.a == localb.a) && (this.b == localb.b) && (this.c == localb.c) && (this.d == localb.d))
        return true;
    }
    return false;
  }

  public final int hashCode()
  {
    int i;
    if (this.a)
      i = 1;
    else
      i = 0;
    if (this.b)
      i += 16;
    if (this.c)
      i += 256;
    if (this.d)
      i += 4096;
    return i;
  }

  public final String toString()
  {
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = Boolean.valueOf(this.a);
    arrayOfObject[1] = Boolean.valueOf(this.b);
    arrayOfObject[2] = Boolean.valueOf(this.c);
    arrayOfObject[3] = Boolean.valueOf(this.d);
    return a.a("[ Connected=%b Validated=%b Metered=%b NotRoaming=%b ]", arrayOfObject);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.a.b
 * JD-Core Version:    0.6.2
 */