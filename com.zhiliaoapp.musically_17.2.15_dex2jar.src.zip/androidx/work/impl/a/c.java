package androidx.work.impl.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public abstract interface c
{
  static
  {
    CoverageLogger.Log(38447104);
  }

  public abstract void a(List<String> paramList);

  public abstract void b(List<String> paramList);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.a.c
 * JD-Core Version:    0.6.2
 */