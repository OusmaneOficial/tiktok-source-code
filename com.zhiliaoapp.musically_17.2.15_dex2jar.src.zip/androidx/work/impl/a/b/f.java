package androidx.work.impl.a.b;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class f
{
  static
  {
    CoverageLogger.Log(1331200);
  }

  static NetworkInfo a(ConnectivityManager paramConnectivityManager)
  {
    try
    {
      NetworkInfo localNetworkInfo = paramConnectivityManager.getActiveNetworkInfo();
      return localNetworkInfo;
    }
    catch (Exception localException)
    {
      com.ss.android.ugc.aweme.framework.a.a.a(localException);
    }
    return com.ss.android.ugc.aweme.lancet.network.a.a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.a.b.f
 * JD-Core Version:    0.6.2
 */