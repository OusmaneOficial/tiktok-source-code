package androidx.work.impl.a.b;

import android.content.Context;
import androidx.work.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public abstract class d<T>
{
  private static final String b = g.a("ConstraintTracker");
  protected final Context a;
  private final Object c = new Object();
  private final Set<androidx.work.impl.a.a<T>> d = new LinkedHashSet();
  private T e;

  static
  {
    CoverageLogger.Log(38506496);
  }

  d(Context paramContext)
  {
    this.a = paramContext.getApplicationContext();
  }

  public final void a(androidx.work.impl.a.a<T> parama)
  {
    synchronized (this.c)
    {
      if (this.d.add(parama))
      {
        if (this.d.size() == 1)
        {
          this.e = b();
          g.a();
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = getClass().getSimpleName();
          arrayOfObject[1] = this.e;
          com.a.a("%s: initial state = %s", arrayOfObject);
          c();
        }
        parama.a(this.e);
      }
      return;
    }
  }

  public final void a(T paramT)
  {
    synchronized (this.c)
    {
      if ((this.e != paramT) && ((this.e == null) || (!this.e.equals(paramT))))
      {
        this.e = paramT;
        Iterator localIterator = new ArrayList(this.d).iterator();
        while (localIterator.hasNext())
          ((androidx.work.impl.a.a)localIterator.next()).a(this.e);
        return;
      }
      return;
    }
    while (true)
      throw localObject2;
  }

  public abstract T b();

  public final void b(androidx.work.impl.a.a<T> parama)
  {
    synchronized (this.c)
    {
      if ((this.d.remove(parama)) && (this.d.isEmpty()))
        d();
      return;
    }
  }

  public abstract void c();

  public abstract void d();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.a.b.d
 * JD-Core Version:    0.6.2
 */