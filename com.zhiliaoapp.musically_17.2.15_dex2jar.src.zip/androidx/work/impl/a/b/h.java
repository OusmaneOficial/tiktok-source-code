package androidx.work.impl.a.b;

import android.content.Context;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class h
{
  private static h e;
  public a a;
  public b b;
  public e c;
  public g d;

  static
  {
    CoverageLogger.Log(38524928);
  }

  private h(Context paramContext)
  {
    Context localContext = paramContext.getApplicationContext();
    this.a = new a(localContext);
    this.b = new b(localContext);
    this.c = new e(localContext);
    this.d = new g(localContext);
  }

  public static h a(Context paramContext)
  {
    try
    {
      if (e == null)
        e = new h(paramContext);
      h localh = e;
      return localh;
    }
    finally
    {
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.a.b.h
 * JD-Core Version:    0.6.2
 */