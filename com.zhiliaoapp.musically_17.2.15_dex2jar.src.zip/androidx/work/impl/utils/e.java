package androidx.work.impl.utils;

import androidx.work.g;
import androidx.work.i.a;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.b;
import androidx.work.impl.b.h;
import androidx.work.impl.f;
import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class e
  implements Runnable
{
  private static final String a = g.a("StopWorkRunnable");
  private f b;
  private String c;

  static
  {
    CoverageLogger.Log(38582272);
  }

  public e(f paramf, String paramString)
  {
    this.b = paramf;
    this.c = paramString;
  }

  public final void run()
  {
    WorkDatabase localWorkDatabase = this.b.c;
    h localh = localWorkDatabase.g();
    localWorkDatabase.c();
    try
    {
      if (localh.d(this.c) == i.a.RUNNING)
      {
        i.a locala = i.a.ENQUEUED;
        String[] arrayOfString = new String[1];
        arrayOfString[0] = this.c;
        localh.a(locala, arrayOfString);
      }
      boolean bool = this.b.f.a(this.c);
      g.a();
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = this.c;
      arrayOfObject[1] = Boolean.valueOf(bool);
      a.a("StopWorkRunnable for %s; Processor.stopWork = %s", arrayOfObject);
      localWorkDatabase.e();
      return;
    }
    finally
    {
      localWorkDatabase.d();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.e
 * JD-Core Version:    0.6.2
 */