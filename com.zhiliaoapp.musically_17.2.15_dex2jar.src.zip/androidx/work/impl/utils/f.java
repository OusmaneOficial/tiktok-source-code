package androidx.work.impl.utils;

import android.content.Context;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import androidx.work.g;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.WeakHashMap;

public final class f
{
  public static final WeakHashMap<PowerManager.WakeLock, String> a = new WeakHashMap();
  private static final String b;

  static
  {
    CoverageLogger.Log(38332416);
    b = g.a("WakeLocks");
  }

  public static PowerManager.WakeLock a(Context paramContext, String paramString)
  {
    PowerManager localPowerManager = (PowerManager)paramContext.getApplicationContext().getSystemService("power");
    StringBuilder localStringBuilder = new StringBuilder("WorkManager: ");
    localStringBuilder.append(paramString);
    String str = localStringBuilder.toString();
    PowerManager.WakeLock localWakeLock = localPowerManager.newWakeLock(1, str);
    synchronized (a)
    {
      a.put(localWakeLock, str);
      return localWakeLock;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.f
 * JD-Core Version:    0.6.2
 */