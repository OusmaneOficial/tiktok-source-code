package androidx.work.impl.utils;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.BroadcastReceiver.PendingResult;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build.VERSION;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.b.h;
import androidx.work.impl.d;
import androidx.work.impl.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

public final class ForceStopRunnable
  implements Runnable
{
  private static final String a = androidx.work.g.a("ForceStopRunnable");
  private static final long b = TimeUnit.DAYS.toMillis(3650L);
  private final Context c;
  private final f d;

  static
  {
    CoverageLogger.Log(38574080);
  }

  public ForceStopRunnable(Context paramContext, f paramf)
  {
    this.c = paramContext.getApplicationContext();
    this.d = paramf;
  }

  private static PendingIntent a(Context paramContext, int paramInt)
  {
    return PendingIntent.getBroadcast(paramContext, -1, b(paramContext), paramInt);
  }

  static void a(Context paramContext)
  {
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent localPendingIntent = a(paramContext, 134217728);
    long l = System.currentTimeMillis() + b;
    if (localAlarmManager != null)
    {
      if (Build.VERSION.SDK_INT >= 19)
      {
        localAlarmManager.setExact(0, l, localPendingIntent);
        return;
      }
      localAlarmManager.set(0, l, localPendingIntent);
    }
  }

  private static Intent b(Context paramContext)
  {
    Intent localIntent = new Intent();
    localIntent.setComponent(new ComponentName(paramContext, BroadcastReceiver.class));
    localIntent.setAction("ACTION_FORCE_STOP_RESCHEDULE");
    return localIntent;
  }

  public final void run()
  {
    WorkDatabase localWorkDatabase;
    h localh;
    if (this.d.g.a().getBoolean("reschedule_needed", false))
    {
      androidx.work.g.a();
      this.d.c();
      this.d.g.a(false);
    }
    else
    {
      PendingIntent localPendingIntent = a(this.c, 536870912);
      int i = 0;
      if (localPendingIntent == null)
      {
        a(this.c);
        i = 1;
      }
      if (i != 0)
      {
        androidx.work.g.a();
        this.d.c();
      }
      else
      {
        localWorkDatabase = this.d.c;
        localh = localWorkDatabase.g();
      }
    }
    try
    {
      localWorkDatabase.c();
      List localList = localh.d();
      if (!localList.isEmpty())
      {
        androidx.work.g.a();
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
          localh.b(((androidx.work.impl.b.g)localIterator.next()).a, -1L);
        d.a(this.d.b, localWorkDatabase, this.d.e);
      }
      localWorkDatabase.e();
      localWorkDatabase.d();
      androidx.work.g.a();
      f localf = this.d;
      synchronized (f.l)
      {
        localf.h = true;
        if (localf.i != null)
        {
          localf.i.finish();
          localf.i = null;
        }
        return;
      }
    }
    finally
    {
      localWorkDatabase.d();
    }
    while (true)
      throw localObject1;
  }

  public static class BroadcastReceiver extends BroadcastReceiver
  {
    private static final String a = androidx.work.g.a("ForceStopRunnable$Rcvr");

    static
    {
      CoverageLogger.Log(38572032);
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      if ((paramIntent != null) && ("ACTION_FORCE_STOP_RESCHEDULE".equals(paramIntent.getAction())))
      {
        androidx.work.g.a();
        ForceStopRunnable.a(paramContext);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.ForceStopRunnable
 * JD-Core Version:    0.6.2
 */