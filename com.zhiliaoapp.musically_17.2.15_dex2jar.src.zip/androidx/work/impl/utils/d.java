package androidx.work.impl.utils;

import androidx.work.WorkerParameters.a;
import androidx.work.impl.b;
import androidx.work.impl.f;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
  implements Runnable
{
  private f a;
  private String b;
  private WorkerParameters.a c;

  static
  {
    CoverageLogger.Log(38334464);
  }

  public d(f paramf, String paramString, WorkerParameters.a parama)
  {
    this.a = paramf;
    this.b = paramString;
    this.c = parama;
  }

  public final void run()
  {
    this.a.f.a(this.b, this.c);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.d
 * JD-Core Version:    0.6.2
 */