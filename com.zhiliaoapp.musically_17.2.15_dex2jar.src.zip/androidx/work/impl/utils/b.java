package androidx.work.impl.utils;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.work.g;
import com.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b
{
  private static final String a = g.a("PackageManagerHelper");

  static
  {
    CoverageLogger.Log(38578176);
  }

  public static void a(Context paramContext, Class paramClass, boolean paramBoolean)
  {
    String str1 = "enabled";
    while (true)
    {
      try
      {
        PackageManager localPackageManager = paramContext.getPackageManager();
        ComponentName localComponentName = new ComponentName(paramContext, paramClass.getName());
        if (paramBoolean)
        {
          i = 1;
          localPackageManager.setComponentEnabledSetting(localComponentName, i, 1);
          g.a();
          Object[] arrayOfObject2 = new Object[2];
          arrayOfObject2[0] = paramClass.getName();
          if (!paramBoolean)
            break label146;
          str2 = str1;
          arrayOfObject2[1] = str2;
          a.a("%s %s", arrayOfObject2);
          return;
        }
      }
      catch (Exception localException)
      {
        g.a();
        Object[] arrayOfObject1 = new Object[2];
        arrayOfObject1[0] = paramClass.getName();
        if (!paramBoolean)
          str1 = "disabled";
        arrayOfObject1[1] = str1;
        a.a("%s could not be %s", arrayOfObject1);
        new Throwable[] { localException };
        return;
      }
      int i = 2;
      continue;
      label146: String str2 = "disabled";
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.b
 * JD-Core Version:    0.6.2
 */