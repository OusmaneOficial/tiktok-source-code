package androidx.work.impl.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.ss.android.ugc.aweme.keva.e;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class a
{
  private final Context a;
  private SharedPreferences b;
  private boolean c;

  static
  {
    CoverageLogger.Log(38340608);
  }

  public a(Context paramContext)
  {
    this.a = paramContext;
  }

  private int a(String paramString)
  {
    int i = this.b.getInt(paramString, 0);
    int j;
    if (i == 2147483647)
      j = 0;
    else
      j = i + 1;
    a(paramString, j);
    return i;
  }

  private void a(String paramString, int paramInt)
  {
    this.b.edit().putInt(paramString, paramInt).apply();
  }

  private void b()
  {
    if (!this.c)
    {
      this.b = e.a(this.a, "androidx.work.util.id", 0);
      this.c = true;
    }
  }

  public final int a()
  {
    try
    {
      b();
      int i = a("next_alarm_manager_id");
      return i;
    }
    finally
    {
    }
  }

  public final int a(int paramInt1, int paramInt2)
  {
    while (true)
    {
      int i;
      try
      {
        b();
        i = a("next_job_scheduler_id");
        if (i >= paramInt1)
          if (i <= paramInt2)
            break label50;
        a("next_job_scheduler_id", paramInt1 + 1);
        return paramInt1;
      }
      finally
      {
      }
      label50: paramInt1 = i;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.a
 * JD-Core Version:    0.6.2
 */