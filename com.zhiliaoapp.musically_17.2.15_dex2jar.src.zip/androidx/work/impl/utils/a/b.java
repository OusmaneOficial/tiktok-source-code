package androidx.work.impl.utils.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

 enum b
  implements Executor
{
  static
  {
    CoverageLogger.Log(38303744);
    a = new b("INSTANCE", 0);
    b[] arrayOfb = new b[1];
    arrayOfb[0] = a;
  }

  public final void execute(Runnable paramRunnable)
  {
    paramRunnable.run();
  }

  public final String toString()
  {
    return "DirectExecutor";
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.a.b
 * JD-Core Version:    0.6.2
 */