package androidx.work.impl.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.ss.android.ugc.aweme.keva.e;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class c
{
  private Context a;
  private SharedPreferences b;

  static
  {
    CoverageLogger.Log(38336512);
  }

  public c(Context paramContext)
  {
    this.a = paramContext;
  }

  SharedPreferences a()
  {
    try
    {
      if (this.b == null)
        this.b = e.a(this.a, "androidx.work.util.preferences", 0);
      SharedPreferences localSharedPreferences = this.b;
      return localSharedPreferences;
    }
    finally
    {
    }
  }

  public final void a(boolean paramBoolean)
  {
    a().edit().putBoolean("reschedule_needed", paramBoolean).apply();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.c
 * JD-Core Version:    0.6.2
 */