package androidx.work.impl.utils.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

public abstract interface a
{
  static
  {
    CoverageLogger.Log(38307840);
  }

  public abstract Executor a();

  public abstract void a(Runnable paramRunnable);

  public abstract Thread b();

  public abstract Executor c();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.utils.b.a
 * JD-Core Version:    0.6.2
 */