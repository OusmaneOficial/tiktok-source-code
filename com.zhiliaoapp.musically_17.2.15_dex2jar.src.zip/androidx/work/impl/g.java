package androidx.work.impl;

import com.ss.android.ugc.aweme.lancet.a.d;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class g
{
  static
  {
    CoverageLogger.Log(1329152);
  }

  public static f a()
  {
    d.a();
    return f.b();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.g
 * JD-Core Version:    0.6.2
 */