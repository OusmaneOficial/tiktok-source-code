package androidx.work.impl.b;

import android.os.Build.VERSION;
import androidx.work.c;
import androidx.work.e;
import androidx.work.i;
import androidx.work.i.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public final class g
{
  public static final androidx.a.a.c.a<List<Object>, List<i>> q = new androidx.a.a.c.a()
  {
    static
    {
      CoverageLogger.Log(38385664);
    }
  };
  private static final String r;
  public String a;
  public i.a b = i.a.ENQUEUED;
  public String c;
  public String d;
  public e e = e.a;
  public e f = e.a;
  public long g;
  public long h;
  public long i;
  public c j = c.a;
  public int k;
  public androidx.work.a l = androidx.work.a.EXPONENTIAL;
  public long m = 30000L;
  public long n;
  public long o;
  public long p = -1L;

  static
  {
    CoverageLogger.Log(38541312);
    r = androidx.work.g.a("WorkSpec");
  }

  public g(String paramString1, String paramString2)
  {
    this.a = paramString1;
    this.c = paramString2;
  }

  public final boolean a()
  {
    return this.h != 0L;
  }

  public final boolean b()
  {
    return (this.b == i.a.ENQUEUED) && (this.k > 0);
  }

  public final long c()
  {
    if (b())
    {
      androidx.work.a locala1 = this.l;
      androidx.work.a locala2 = androidx.work.a.LINEAR;
      int i2 = 0;
      if (locala1 == locala2)
        i2 = 1;
      long l3;
      if (i2 != 0)
        l3 = this.m * this.k;
      else
        l3 = ()Math.scalb((float)this.m, this.k - 1);
      return this.n + Math.min(18000000L, l3);
    }
    if (a())
    {
      if (Build.VERSION.SDK_INT <= 22)
      {
        boolean bool = this.i < this.h;
        int i1 = 0;
        if (bool)
          i1 = 1;
        if (i1 != 0)
        {
          long l1;
          if (this.n == 0L)
            l1 = -1L * this.i;
          else
            l1 = 0L;
          long l2 = this.n;
          if (l2 == 0L)
            l2 = System.currentTimeMillis();
          return l1 + (l2 + this.h);
        }
        return this.n + this.h;
      }
      return this.n + this.h - this.i;
    }
    return this.n + this.g;
  }

  public final boolean d()
  {
    return !c.a.equals(this.j);
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass())
        return false;
      g localg = (g)paramObject;
      if (this.g != localg.g)
        return false;
      if (this.h != localg.h)
        return false;
      if (this.i != localg.i)
        return false;
      if (this.k != localg.k)
        return false;
      if (this.m != localg.m)
        return false;
      if (this.n != localg.n)
        return false;
      if (this.o != localg.o)
        return false;
      if (this.p != localg.p)
        return false;
      if (!this.a.equals(localg.a))
        return false;
      if (this.b != localg.b)
        return false;
      if (!this.c.equals(localg.c))
        return false;
      String str = this.d;
      if (str != null)
      {
        if (!str.equals(localg.d))
          return false;
      }
      else if (localg.d != null)
        return false;
      if (!this.e.equals(localg.e))
        return false;
      if (!this.f.equals(localg.f))
        return false;
      if (!this.j.equals(localg.j))
        return false;
      if (this.l == localg.l)
        return true;
    }
    return false;
  }

  public final int hashCode()
  {
    int i1 = 31 * (31 * (31 * this.a.hashCode() + this.b.hashCode()) + this.c.hashCode());
    String str = this.d;
    int i2;
    if (str != null)
      i2 = str.hashCode();
    else
      i2 = 0;
    int i3 = 31 * (31 * (31 * (i1 + i2) + this.e.hashCode()) + this.f.hashCode());
    long l1 = this.g;
    int i4 = 31 * (i3 + (int)(l1 ^ l1 >>> 32));
    long l2 = this.h;
    int i5 = 31 * (i4 + (int)(l2 ^ l2 >>> 32));
    long l3 = this.i;
    int i6 = 31 * (31 * (31 * (31 * (i5 + (int)(l3 ^ l3 >>> 32)) + this.j.hashCode()) + this.k) + this.l.hashCode());
    long l4 = this.m;
    int i7 = 31 * (i6 + (int)(l4 ^ l4 >>> 32));
    long l5 = this.n;
    int i8 = 31 * (i7 + (int)(l5 ^ l5 >>> 32));
    long l6 = this.o;
    int i9 = 31 * (i8 + (int)(l6 ^ l6 >>> 32));
    long l7 = this.p;
    return i9 + (int)(l7 ^ l7 >>> 32);
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("{WorkSpec: ");
    localStringBuilder.append(this.a);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.g
 * JD-Core Version:    0.6.2
 */