package androidx.work.impl.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public abstract interface k
{
  static
  {
    CoverageLogger.Log(38352896);
  }

  public abstract List<String> a(String paramString);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.k
 * JD-Core Version:    0.6.2
 */