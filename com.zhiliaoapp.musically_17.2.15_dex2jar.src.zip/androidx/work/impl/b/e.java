package androidx.work.impl.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface e
{
  static
  {
    CoverageLogger.Log(38539264);
  }

  public abstract d a(String paramString);

  public abstract void a(d paramd);

  public abstract void b(String paramString);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.e
 * JD-Core Version:    0.6.2
 */