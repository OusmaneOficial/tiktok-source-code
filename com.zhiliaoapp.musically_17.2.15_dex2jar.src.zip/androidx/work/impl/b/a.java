package androidx.work.impl.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class a
{
  public final String a;
  public final String b;

  static
  {
    CoverageLogger.Log(38526976);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.a
 * JD-Core Version:    0.6.2
 */