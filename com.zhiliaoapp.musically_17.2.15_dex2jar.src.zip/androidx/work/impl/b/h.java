package androidx.work.impl.b;

import androidx.work.e;
import androidx.work.i.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public abstract interface h
{
  static
  {
    CoverageLogger.Log(38543360);
  }

  public abstract int a(i.a parama, String[] paramArrayOfString);

  public abstract g a(String paramString);

  public abstract List<String> a();

  public abstract List<g> a(int paramInt);

  public abstract void a(String paramString, long paramLong);

  public abstract void a(String paramString, e parame);

  public abstract int b();

  public abstract int b(String paramString);

  public abstract int b(String paramString, long paramLong);

  public abstract int c(String paramString);

  public abstract List<g> c();

  public abstract i.a d(String paramString);

  public abstract List<g> d();

  public abstract List<e> e(String paramString);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.h
 * JD-Core Version:    0.6.2
 */