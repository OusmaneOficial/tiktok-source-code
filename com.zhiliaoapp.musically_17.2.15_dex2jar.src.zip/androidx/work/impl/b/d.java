package androidx.work.impl.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
{
  public final String a;
  public final int b;

  static
  {
    CoverageLogger.Log(38391808);
  }

  public d(String paramString, int paramInt)
  {
    this.a = paramString;
    this.b = paramInt;
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass())
        return false;
      d locald = (d)paramObject;
      if (this.b != locald.b)
        return false;
      return this.a.equals(locald.a);
    }
    return false;
  }

  public final int hashCode()
  {
    return 31 * this.a.hashCode() + this.b;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.d
 * JD-Core Version:    0.6.2
 */