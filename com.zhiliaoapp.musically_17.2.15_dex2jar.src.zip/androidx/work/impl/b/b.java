package androidx.work.impl.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public abstract interface b
{
  static
  {
    CoverageLogger.Log(38529024);
  }

  public abstract boolean a(String paramString);

  public abstract List<String> b(String paramString);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.b
 * JD-Core Version:    0.6.2
 */