package androidx.work.impl.b;

import androidx.work.a;
import androidx.work.h;
import androidx.work.i.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class m
{
  static
  {
    CoverageLogger.Log(38565888);
  }

  public static int a(i.a parama)
  {
    switch (1.a[parama.ordinal()])
    {
    default:
      StringBuilder localStringBuilder = new StringBuilder("Could not convert ");
      localStringBuilder.append(parama);
      localStringBuilder.append(" to int");
      throw new IllegalArgumentException(localStringBuilder.toString());
    case 6:
      return 5;
    case 5:
      return 4;
    case 4:
      return 3;
    case 3:
      return 2;
    case 2:
      return 1;
    case 1:
    }
    return 0;
  }

  // ERROR //
  public static androidx.work.d a(byte[] paramArrayOfByte)
  {
    // Byte code:
    //   0: new 55	androidx/work/d
    //   3: dup
    //   4: invokespecial 57	androidx/work/d:<init>	()V
    //   7: astore_1
    //   8: aload_0
    //   9: ifnonnull +5 -> 14
    //   12: aload_1
    //   13: areturn
    //   14: new 59	java/io/ByteArrayInputStream
    //   17: dup
    //   18: aload_0
    //   19: invokespecial 62	java/io/ByteArrayInputStream:<init>	([B)V
    //   22: astore_2
    //   23: aconst_null
    //   24: astore_3
    //   25: new 64	java/io/ObjectInputStream
    //   28: dup
    //   29: aload_2
    //   30: invokespecial 67	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
    //   33: astore 4
    //   35: aload 4
    //   37: invokevirtual 70	java/io/ObjectInputStream:readInt	()I
    //   40: istore 9
    //   42: iload 9
    //   44: ifle +43 -> 87
    //   47: new 72	androidx/work/d$a
    //   50: dup
    //   51: aload 4
    //   53: invokevirtual 75	java/io/ObjectInputStream:readUTF	()Ljava/lang/String;
    //   56: invokestatic 81	android/net/Uri:parse	(Ljava/lang/String;)Landroid/net/Uri;
    //   59: aload 4
    //   61: invokevirtual 85	java/io/ObjectInputStream:readBoolean	()Z
    //   64: invokespecial 88	androidx/work/d$a:<init>	(Landroid/net/Uri;Z)V
    //   67: astore 10
    //   69: aload_1
    //   70: getfield 91	androidx/work/d:a	Ljava/util/Set;
    //   73: aload 10
    //   75: invokeinterface 97 2 0
    //   80: pop
    //   81: iinc 9 255
    //   84: goto -42 -> 42
    //   87: aload 4
    //   89: invokevirtual 100	java/io/ObjectInputStream:close	()V
    //   92: goto +4 -> 96
    //   95: pop
    //   96: aload_2
    //   97: invokevirtual 101	java/io/ByteArrayInputStream:close	()V
    //   100: aload_1
    //   101: areturn
    //   102: astore 6
    //   104: goto +18 -> 122
    //   107: aload 4
    //   109: astore_3
    //   110: goto +37 -> 147
    //   113: astore 12
    //   115: aconst_null
    //   116: astore 4
    //   118: aload 12
    //   120: astore 6
    //   122: aload 4
    //   124: ifnull +11 -> 135
    //   127: aload 4
    //   129: invokevirtual 100	java/io/ObjectInputStream:close	()V
    //   132: goto +4 -> 136
    //   135: pop
    //   136: aload_2
    //   137: invokevirtual 101	java/io/ByteArrayInputStream:close	()V
    //   140: goto +4 -> 144
    //   143: pop
    //   144: aload 6
    //   146: athrow
    //   147: aload_3
    //   148: ifnull -53 -> 95
    //   151: aload_3
    //   152: invokevirtual 100	java/io/ObjectInputStream:close	()V
    //   155: goto -60 -> 95
    //   158: aload_1
    //   159: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   87	92	95	java/io/IOException
    //   151	155	95	java/io/IOException
    //   35	42	102	finally
    //   47	81	102	finally
    //   35	42	107	java/io/IOException
    //   47	81	107	java/io/IOException
    //   25	35	113	finally
    //   127	132	135	java/io/IOException
    //   135	136	143	java/io/IOException
    //   136	140	143	java/io/IOException
    //   25	35	147	java/io/IOException
    //   95	96	158	java/io/IOException
    //   96	100	158	java/io/IOException
  }

  public static i.a a(int paramInt)
  {
    if (paramInt != 0)
    {
      if (paramInt != 1)
      {
        if (paramInt != 2)
        {
          if (paramInt != 3)
          {
            if (paramInt != 4)
            {
              if (paramInt == 5)
                return i.a.CANCELLED;
              StringBuilder localStringBuilder = new StringBuilder("Could not convert ");
              localStringBuilder.append(paramInt);
              localStringBuilder.append(" to State");
              throw new IllegalArgumentException(localStringBuilder.toString());
            }
            return i.a.BLOCKED;
          }
          return i.a.FAILED;
        }
        return i.a.SUCCEEDED;
      }
      return i.a.RUNNING;
    }
    return i.a.ENQUEUED;
  }

  // ERROR //
  public static byte[] a(androidx.work.d paramd)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 129	androidx/work/d:a	()I
    //   4: istore_1
    //   5: aconst_null
    //   6: astore_2
    //   7: iload_1
    //   8: ifne +5 -> 13
    //   11: aconst_null
    //   12: areturn
    //   13: new 131	java/io/ByteArrayOutputStream
    //   16: dup
    //   17: invokespecial 132	java/io/ByteArrayOutputStream:<init>	()V
    //   20: astore_3
    //   21: new 134	java/io/ObjectOutputStream
    //   24: dup
    //   25: aload_3
    //   26: invokespecial 137	java/io/ObjectOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   29: astore 4
    //   31: aload 4
    //   33: aload_0
    //   34: invokevirtual 129	androidx/work/d:a	()I
    //   37: invokevirtual 140	java/io/ObjectOutputStream:writeInt	(I)V
    //   40: aload_0
    //   41: getfield 91	androidx/work/d:a	Ljava/util/Set;
    //   44: invokeinterface 144 1 0
    //   49: astore 9
    //   51: aload 9
    //   53: invokeinterface 149 1 0
    //   58: ifeq +41 -> 99
    //   61: aload 9
    //   63: invokeinterface 153 1 0
    //   68: checkcast 72	androidx/work/d$a
    //   71: astore 10
    //   73: aload 4
    //   75: aload 10
    //   77: getfield 156	androidx/work/d$a:a	Landroid/net/Uri;
    //   80: invokevirtual 157	android/net/Uri:toString	()Ljava/lang/String;
    //   83: invokevirtual 160	java/io/ObjectOutputStream:writeUTF	(Ljava/lang/String;)V
    //   86: aload 4
    //   88: aload 10
    //   90: getfield 164	androidx/work/d$a:b	Z
    //   93: invokevirtual 168	java/io/ObjectOutputStream:writeBoolean	(Z)V
    //   96: goto -45 -> 51
    //   99: aload 4
    //   101: invokevirtual 169	java/io/ObjectOutputStream:close	()V
    //   104: goto +4 -> 108
    //   107: pop
    //   108: aload_3
    //   109: invokevirtual 170	java/io/ByteArrayOutputStream:close	()V
    //   112: goto +55 -> 167
    //   115: astore 6
    //   117: goto +14 -> 131
    //   120: aload 4
    //   122: astore_2
    //   123: goto +33 -> 156
    //   126: astore 6
    //   128: aconst_null
    //   129: astore 4
    //   131: aload 4
    //   133: ifnull +11 -> 144
    //   136: aload 4
    //   138: invokevirtual 169	java/io/ObjectOutputStream:close	()V
    //   141: goto +4 -> 145
    //   144: pop
    //   145: aload_3
    //   146: invokevirtual 170	java/io/ByteArrayOutputStream:close	()V
    //   149: goto +4 -> 153
    //   152: pop
    //   153: aload 6
    //   155: athrow
    //   156: aload_2
    //   157: ifnull -50 -> 107
    //   160: aload_2
    //   161: invokevirtual 169	java/io/ObjectOutputStream:close	()V
    //   164: goto -57 -> 107
    //   167: aload_3
    //   168: invokevirtual 174	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   171: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   99	104	107	java/io/IOException
    //   160	164	107	java/io/IOException
    //   31	51	115	finally
    //   51	96	115	finally
    //   31	51	120	java/io/IOException
    //   51	96	120	java/io/IOException
    //   21	31	126	finally
    //   136	141	144	java/io/IOException
    //   144	145	152	java/io/IOException
    //   145	149	152	java/io/IOException
    //   21	31	156	java/io/IOException
    //   107	108	167	java/io/IOException
    //   108	112	167	java/io/IOException
  }

  public static a b(int paramInt)
  {
    if (paramInt != 0)
    {
      if (paramInt == 1)
        return a.LINEAR;
      StringBuilder localStringBuilder = new StringBuilder("Could not convert ");
      localStringBuilder.append(paramInt);
      localStringBuilder.append(" to BackoffPolicy");
      throw new IllegalArgumentException(localStringBuilder.toString());
    }
    return a.EXPONENTIAL;
  }

  public static h c(int paramInt)
  {
    if (paramInt != 0)
    {
      if (paramInt != 1)
      {
        if (paramInt != 2)
        {
          if (paramInt != 3)
          {
            if (paramInt == 4)
              return h.METERED;
            StringBuilder localStringBuilder = new StringBuilder("Could not convert ");
            localStringBuilder.append(paramInt);
            localStringBuilder.append(" to NetworkType");
            throw new IllegalArgumentException(localStringBuilder.toString());
          }
          return h.NOT_ROAMING;
        }
        return h.UNMETERED;
      }
      return h.CONNECTED;
    }
    return h.NOT_REQUIRED;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.impl.b.m
 * JD-Core Version:    0.6.2
 */