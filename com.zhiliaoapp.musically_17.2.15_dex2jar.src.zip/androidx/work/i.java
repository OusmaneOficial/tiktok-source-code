package androidx.work;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Set;
import java.util.UUID;

public final class i
{
  public UUID a;
  public a b;
  public e c;
  public Set<String> d;

  static
  {
    CoverageLogger.Log(38567936);
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass())
        return false;
      i locali = (i)paramObject;
      UUID localUUID = this.a;
      if (localUUID != null)
      {
        if (!localUUID.equals(locali.a))
          return false;
      }
      else if (locali.a != null)
        return false;
      if (this.b != locali.b)
        return false;
      e locale = this.c;
      if (locale != null)
      {
        if (!locale.equals(locali.c))
          return false;
      }
      else if (locali.c != null)
        return false;
      Set localSet1 = this.d;
      Set localSet2 = locali.d;
      if (localSet1 != null)
        return localSet1.equals(localSet2);
      if (localSet2 == null)
        return true;
    }
    return false;
  }

  public final int hashCode()
  {
    UUID localUUID = this.a;
    int i;
    if (localUUID != null)
      i = localUUID.hashCode();
    else
      i = 0;
    int j = i * 31;
    a locala = this.b;
    int k;
    if (locala != null)
      k = locala.hashCode();
    else
      k = 0;
    int m = 31 * (j + k);
    e locale = this.c;
    int n;
    if (locale != null)
      n = locale.hashCode();
    else
      n = 0;
    int i1 = 31 * (m + n);
    Set localSet = this.d;
    int i2 = 0;
    if (localSet != null)
      i2 = localSet.hashCode();
    return i1 + i2;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("WorkInfo{mId='");
    localStringBuilder.append(this.a);
    localStringBuilder.append('\'');
    localStringBuilder.append(", mState=");
    localStringBuilder.append(this.b);
    localStringBuilder.append(", mOutputData=");
    localStringBuilder.append(this.c);
    localStringBuilder.append(", mTags=");
    localStringBuilder.append(this.d);
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }

  public static enum a
  {
    static
    {
      CoverageLogger.Log(38569984);
      ENQUEUED = new a("ENQUEUED", 0);
      RUNNING = new a("RUNNING", 1);
      SUCCEEDED = new a("SUCCEEDED", 2);
      FAILED = new a("FAILED", 3);
      BLOCKED = new a("BLOCKED", 4);
      CANCELLED = new a("CANCELLED", 5);
      a[] arrayOfa = new a[6];
      arrayOfa[0] = ENQUEUED;
      arrayOfa[1] = RUNNING;
      arrayOfa[2] = SUCCEEDED;
      arrayOfa[3] = FAILED;
      arrayOfa[4] = BLOCKED;
      arrayOfa[5] = CANCELLED;
    }

    public final boolean isFinished()
    {
      return (this == SUCCEEDED) || (this == FAILED) || (this == CANCELLED);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.i
 * JD-Core Version:    0.6.2
 */