package androidx.work;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public enum a
{
  static
  {
    CoverageLogger.Log(38610944);
    EXPONENTIAL = new a("EXPONENTIAL", 0);
    LINEAR = new a("LINEAR", 1);
    a[] arrayOfa = new a[2];
    arrayOfa[0] = EXPONENTIAL;
    arrayOfa[1] = LINEAR;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.a
 * JD-Core Version:    0.6.2
 */