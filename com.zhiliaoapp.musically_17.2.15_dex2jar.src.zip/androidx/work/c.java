package androidx.work;

import android.os.Build.VERSION;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c
{
  public static final c a = new c(new a());
  public h b = h.NOT_REQUIRED;
  public boolean c;
  public boolean d;
  public boolean e;
  public boolean f;
  public long g = -1L;
  public long h = -1L;
  public d i = new d();

  static
  {
    CoverageLogger.Log(38604800);
  }

  public c()
  {
  }

  c(a parama)
  {
    this.c = parama.a;
    boolean bool;
    if ((Build.VERSION.SDK_INT >= 23) && (parama.b))
      bool = true;
    else
      bool = false;
    this.d = bool;
    this.b = parama.c;
    this.e = parama.d;
    this.f = parama.e;
    if (Build.VERSION.SDK_INT >= 24)
    {
      this.i = parama.h;
      this.g = parama.f;
      this.h = parama.g;
    }
  }

  public final boolean a()
  {
    return this.i.a() > 0;
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (paramObject != null)
    {
      if (getClass() != paramObject.getClass())
        return false;
      c localc = (c)paramObject;
      if (this.c != localc.c)
        return false;
      if (this.d != localc.d)
        return false;
      if (this.e != localc.e)
        return false;
      if (this.f != localc.f)
        return false;
      if (this.g != localc.g)
        return false;
      if (this.h != localc.h)
        return false;
      if (this.b != localc.b)
        return false;
      return this.i.equals(localc.i);
    }
    return false;
  }

  public final int hashCode()
  {
    int j = 31 * (31 * (31 * (31 * (31 * this.b.hashCode() + this.c) + this.d) + this.e) + this.f);
    long l1 = this.g;
    int k = 31 * (j + (int)(l1 ^ l1 >>> 32));
    long l2 = this.h;
    return 31 * (k + (int)(l2 ^ l2 >>> 32)) + this.i.hashCode();
  }

  public static final class a
  {
    boolean a;
    boolean b;
    h c = h.NOT_REQUIRED;
    boolean d;
    boolean e;
    long f = -1L;
    long g = -1L;
    d h = new d();

    static
    {
      CoverageLogger.Log(38602752);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.c
 * JD-Core Version:    0.6.2
 */