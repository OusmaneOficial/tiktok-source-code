package androidx.work;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public enum h
{
  static
  {
    CoverageLogger.Log(38645760);
    NOT_REQUIRED = new h("NOT_REQUIRED", 0);
    CONNECTED = new h("CONNECTED", 1);
    UNMETERED = new h("UNMETERED", 2);
    NOT_ROAMING = new h("NOT_ROAMING", 3);
    METERED = new h("METERED", 4);
    h[] arrayOfh = new h[5];
    arrayOfh[0] = NOT_REQUIRED;
    arrayOfh[1] = CONNECTED;
    arrayOfh[2] = UNMETERED;
    arrayOfh[3] = NOT_ROAMING;
    arrayOfh[4] = METERED;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.h
 * JD-Core Version:    0.6.2
 */