package androidx.work;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class g
{
  private static g a;
  private static final int b = 20;

  static
  {
    CoverageLogger.Log(38643712);
  }

  public g(int paramInt)
  {
  }

  public static g a()
  {
    try
    {
      if (a == null)
        a = new a(3);
      g localg = a;
      return localg;
    }
    finally
    {
    }
  }

  public static String a(String paramString)
  {
    int i = paramString.length();
    StringBuilder localStringBuilder = new StringBuilder(23);
    localStringBuilder.append("WM-");
    int j = b;
    if (i >= j)
      localStringBuilder.append(paramString.substring(0, j));
    else
      localStringBuilder.append(paramString);
    return localStringBuilder.toString();
  }

  public static void a(g paramg)
  {
    try
    {
      a = paramg;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public static final class a extends g
  {
    private int a;

    static
    {
      CoverageLogger.Log(38576128);
    }

    public a(int paramInt)
    {
      super();
      this.a = paramInt;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.g
 * JD-Core Version:    0.6.2
 */