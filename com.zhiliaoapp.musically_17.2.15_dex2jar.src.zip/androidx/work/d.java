package androidx.work;

import android.net.Uri;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.HashSet;
import java.util.Set;

public final class d
{
  public final Set<a> a = new HashSet();

  static
  {
    CoverageLogger.Log(38619136);
  }

  public final int a()
  {
    return this.a.size();
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if ((paramObject != null) && (getClass() == paramObject.getClass()))
    {
      d locald = (d)paramObject;
      return this.a.equals(locald.a);
    }
    return false;
  }

  public final int hashCode()
  {
    return this.a.hashCode();
  }

  public static final class a
  {
    public final Uri a;
    public final boolean b;

    static
    {
      CoverageLogger.Log(38598656);
    }

    public a(Uri paramUri, boolean paramBoolean)
    {
      this.a = paramUri;
      this.b = paramBoolean;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject)
        return true;
      if (paramObject != null)
      {
        if (getClass() != paramObject.getClass())
          return false;
        a locala = (a)paramObject;
        if ((this.b == locala.b) && (this.a.equals(locala.a)))
          return true;
      }
      return false;
    }

    public final int hashCode()
    {
      return 31 * this.a.hashCode() + this.b;
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.work.d
 * JD-Core Version:    0.6.2
 */