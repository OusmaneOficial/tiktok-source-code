package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import androidx.lifecycle.aa;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class FragmentState
  implements Parcelable
{
  public static final Parcelable.Creator<FragmentState> CREATOR = new Parcelable.Creator()
  {
    static
    {
      CoverageLogger.Log(16179200);
    }
  };
  final String a;
  final int b;
  final boolean c;
  final int d;
  final int e;
  final String f;
  final boolean g;
  final boolean h;
  final Bundle i;
  final boolean j;
  Bundle k;
  Fragment l;

  static
  {
    CoverageLogger.Log(16343040);
  }

  FragmentState(Parcel paramParcel)
  {
    this.a = paramParcel.readString();
    this.b = paramParcel.readInt();
    int m = paramParcel.readInt();
    boolean bool1 = true;
    boolean bool2;
    if (m != 0)
      bool2 = true;
    else
      bool2 = false;
    this.c = bool2;
    this.d = paramParcel.readInt();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readString();
    boolean bool3;
    if (paramParcel.readInt() != 0)
      bool3 = true;
    else
      bool3 = false;
    this.g = bool3;
    boolean bool4;
    if (paramParcel.readInt() != 0)
      bool4 = true;
    else
      bool4 = false;
    this.h = bool4;
    this.i = paramParcel.readBundle();
    if (paramParcel.readInt() == 0)
      bool1 = false;
    this.j = bool1;
    this.k = paramParcel.readBundle();
  }

  FragmentState(Fragment paramFragment)
  {
    this.a = paramFragment.getClass().getName();
    this.b = paramFragment.mIndex;
    this.c = paramFragment.mFromLayout;
    this.d = paramFragment.mFragmentId;
    this.e = paramFragment.mContainerId;
    this.f = paramFragment.mTag;
    this.g = paramFragment.mRetainInstance;
    this.h = paramFragment.mDetached;
    this.i = paramFragment.mArguments;
    this.j = paramFragment.mHidden;
  }

  public final Fragment a(e parame, c paramc, Fragment paramFragment, j paramj, aa paramaa)
  {
    if (this.l == null)
    {
      Context localContext = parame.c;
      Bundle localBundle1 = this.i;
      if (localBundle1 != null)
        localBundle1.setClassLoader(localContext.getClassLoader());
      if (paramc != null)
        this.l = paramc.a(localContext, this.a, this.i);
      else
        this.l = Fragment.instantiate(localContext, this.a, this.i);
      Bundle localBundle2 = this.k;
      if (localBundle2 != null)
      {
        localBundle2.setClassLoader(localContext.getClassLoader());
        this.l.mSavedFragmentState = this.k;
      }
      this.l.setIndex(this.b, paramFragment);
      Fragment localFragment2 = this.l;
      localFragment2.mFromLayout = this.c;
      localFragment2.mRestored = true;
      localFragment2.mFragmentId = this.d;
      localFragment2.mContainerId = this.e;
      localFragment2.mTag = this.f;
      localFragment2.mRetainInstance = this.g;
      localFragment2.mDetached = this.h;
      localFragment2.mHidden = this.j;
      localFragment2.mFragmentManager = parame.e;
    }
    Fragment localFragment1 = this.l;
    localFragment1.mChildNonConfig = paramj;
    localFragment1.mViewModelStore = paramaa;
    return localFragment1;
  }

  public final int describeContents()
  {
    return 0;
  }

  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.a);
    paramParcel.writeInt(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeInt(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeString(this.f);
    paramParcel.writeInt(this.g);
    paramParcel.writeInt(this.h);
    paramParcel.writeBundle(this.i);
    paramParcel.writeInt(this.j);
    paramParcel.writeBundle(this.k);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.FragmentState
 * JD-Core Version:    0.6.2
 */