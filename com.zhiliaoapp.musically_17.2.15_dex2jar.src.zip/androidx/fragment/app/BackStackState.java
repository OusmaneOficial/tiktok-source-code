package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.SparseArray;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

final class BackStackState
  implements Parcelable
{
  public static final Parcelable.Creator<BackStackState> CREATOR = new Parcelable.Creator()
  {
    static
    {
      CoverageLogger.Log(16265216);
    }
  };
  final int[] a;
  final int b;
  final int c;
  final String d;
  final int e;
  final int f;
  final CharSequence g;
  final int h;
  final CharSequence i;
  final ArrayList<String> j;
  final ArrayList<String> k;
  final boolean l;

  static
  {
    CoverageLogger.Log(16547840);
  }

  public BackStackState(Parcel paramParcel)
  {
    this.a = paramParcel.createIntArray();
    this.b = paramParcel.readInt();
    this.c = paramParcel.readInt();
    this.d = paramParcel.readString();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readInt();
    this.g = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.h = paramParcel.readInt();
    this.i = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.j = paramParcel.createStringArrayList();
    this.k = paramParcel.createStringArrayList();
    boolean bool;
    if (paramParcel.readInt() != 0)
      bool = true;
    else
      bool = false;
    this.l = bool;
  }

  public BackStackState(a parama)
  {
    int m = parama.b.size();
    this.a = new int[m * 6];
    if (parama.i)
    {
      int n = 0;
      int i8;
      for (int i1 = 0; n < m; i1 = i8)
      {
        a.a locala = (a.a)parama.b.get(n);
        int[] arrayOfInt1 = this.a;
        int i2 = i1 + 1;
        arrayOfInt1[i1] = locala.a;
        int[] arrayOfInt2 = this.a;
        int i3 = i2 + 1;
        int i4;
        if (locala.b != null)
          i4 = locala.b.mIndex;
        else
          i4 = -1;
        arrayOfInt2[i2] = i4;
        int[] arrayOfInt3 = this.a;
        int i5 = i3 + 1;
        arrayOfInt3[i3] = locala.c;
        int[] arrayOfInt4 = this.a;
        int i6 = i5 + 1;
        arrayOfInt4[i5] = locala.d;
        int[] arrayOfInt5 = this.a;
        int i7 = i6 + 1;
        arrayOfInt5[i6] = locala.e;
        int[] arrayOfInt6 = this.a;
        i8 = i7 + 1;
        arrayOfInt6[i7] = locala.f;
        n++;
      }
      this.b = parama.g;
      this.c = parama.h;
      this.d = parama.k;
      this.e = parama.m;
      this.f = parama.n;
      this.g = parama.o;
      this.h = parama.p;
      this.i = parama.q;
      this.j = parama.r;
      this.k = parama.s;
      this.l = parama.t;
      return;
    }
    IllegalStateException localIllegalStateException = new IllegalStateException("Not on back stack");
    while (true)
      throw localIllegalStateException;
  }

  public final a a(h paramh)
  {
    a locala = new a(paramh);
    int m = 0;
    while (m < this.a.length)
    {
      a.a locala1 = new a.a();
      int[] arrayOfInt1 = this.a;
      int n = m + 1;
      locala1.a = arrayOfInt1[m];
      int i1 = n + 1;
      int i2 = arrayOfInt1[n];
      if (i2 >= 0)
        locala1.b = ((Fragment)paramh.f.get(i2));
      else
        locala1.b = null;
      int[] arrayOfInt2 = this.a;
      int i3 = i1 + 1;
      locala1.c = arrayOfInt2[i1];
      int i4 = i3 + 1;
      locala1.d = arrayOfInt2[i3];
      int i5 = i4 + 1;
      locala1.e = arrayOfInt2[i4];
      m = i5 + 1;
      locala1.f = arrayOfInt2[i5];
      locala.c = locala1.c;
      locala.d = locala1.d;
      locala.e = locala1.e;
      locala.f = locala1.f;
      locala.a(locala1);
    }
    locala.g = this.b;
    locala.h = this.c;
    locala.k = this.d;
    locala.m = this.e;
    locala.i = true;
    locala.n = this.f;
    locala.o = this.g;
    locala.p = this.h;
    locala.q = this.i;
    locala.r = this.j;
    locala.s = this.k;
    locala.t = this.l;
    locala.a(1);
    return locala;
  }

  public final int describeContents()
  {
    return 0;
  }

  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeIntArray(this.a);
    paramParcel.writeInt(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeString(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeInt(this.f);
    TextUtils.writeToParcel(this.g, paramParcel, 0);
    paramParcel.writeInt(this.h);
    TextUtils.writeToParcel(this.i, paramParcel, 0);
    paramParcel.writeStringList(this.j);
    paramParcel.writeStringList(this.k);
    paramParcel.writeInt(this.l);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.BackStackState
 * JD-Core Version:    0.6.2
 */