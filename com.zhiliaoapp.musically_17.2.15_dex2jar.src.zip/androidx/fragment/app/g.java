package androidx.fragment.app;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class g
{
  static
  {
    CoverageLogger.Log(80371712);
  }

  public static boolean a(f paramf)
  {
    if (!(paramf instanceof h))
      return false;
    return ((h)paramf).c;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.g
 * JD-Core Version:    0.6.2
 */