package androidx.fragment.app;

import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class r
  implements View.OnAttachStateChangeListener, ViewTreeObserver.OnPreDrawListener
{
  private final View a;
  private ViewTreeObserver b;
  private final Runnable c;

  static
  {
    CoverageLogger.Log(16373760);
  }

  private r(View paramView, Runnable paramRunnable)
  {
    this.a = paramView;
    this.b = paramView.getViewTreeObserver();
    this.c = paramRunnable;
  }

  public static r a(View paramView, Runnable paramRunnable)
  {
    r localr = new r(paramView, paramRunnable);
    paramView.getViewTreeObserver().addOnPreDrawListener(localr);
    paramView.addOnAttachStateChangeListener(localr);
    return localr;
  }

  private void a()
  {
    if (this.b.isAlive())
      this.b.removeOnPreDrawListener(this);
    else
      this.a.getViewTreeObserver().removeOnPreDrawListener(this);
    this.a.removeOnAttachStateChangeListener(this);
  }

  public final boolean onPreDraw()
  {
    a();
    this.c.run();
    return true;
  }

  public final void onViewAttachedToWindow(View paramView)
  {
    this.b = paramView.getViewTreeObserver();
  }

  public final void onViewDetachedFromWindow(View paramView)
  {
    a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.r
 * JD-Core Version:    0.6.2
 */