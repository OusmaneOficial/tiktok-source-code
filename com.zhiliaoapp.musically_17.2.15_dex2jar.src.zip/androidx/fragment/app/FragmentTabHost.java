package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.view.View.BaseSavedState;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;

public final class FragmentTabHost extends TabHost
  implements TabHost.OnTabChangeListener
{
  private final ArrayList<a> a;
  private Context b;
  private f c;
  private int d;
  private TabHost.OnTabChangeListener e;
  private a f;
  private boolean g;

  static
  {
    CoverageLogger.Log(16166912);
  }

  private a a(String paramString)
  {
    int i = this.a.size();
    for (int j = 0; j < i; j++)
    {
      a locala = (a)this.a.get(j);
      if (locala.a.equals(paramString))
        return locala;
    }
    return null;
  }

  private m a(String paramString, m paramm)
  {
    a locala1 = a(paramString);
    if (this.f != locala1)
    {
      if (paramm == null)
        paramm = this.c.a();
      a locala2 = this.f;
      if ((locala2 != null) && (locala2.d != null))
        paramm.d(this.f.d);
      if (locala1 != null)
        if (locala1.d == null)
        {
          locala1.d = Fragment.instantiate(this.b, locala1.b.getName(), locala1.c);
          paramm.a(this.d, locala1.d, locala1.a);
        }
        else
        {
          paramm.e(locala1.d);
        }
      this.f = locala1;
    }
    return paramm;
  }

  protected final void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    String str = getCurrentTabTag();
    int i = this.a.size();
    m localm1 = null;
    for (int j = 0; j < i; j++)
    {
      a locala = (a)this.a.get(j);
      locala.d = this.c.a(locala.a);
      if ((locala.d != null) && (!locala.d.isDetached()))
        if (locala.a.equals(str))
        {
          this.f = locala;
        }
        else
        {
          if (localm1 == null)
            localm1 = this.c.a();
          localm1.d(locala.d);
        }
    }
    this.g = true;
    m localm2 = a(str, localm1);
    if (localm2 != null)
    {
      localm2.b();
      this.c.b();
    }
  }

  protected final void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.g = false;
  }

  protected final void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.getSuperState());
    setCurrentTabByTag(localSavedState.a);
  }

  protected final Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    localSavedState.a = getCurrentTabTag();
    return localSavedState;
  }

  public final void onTabChanged(String paramString)
  {
    if (this.g)
    {
      m localm = a(paramString, null);
      if (localm != null)
        localm.b();
    }
    TabHost.OnTabChangeListener localOnTabChangeListener = this.e;
    if (localOnTabChangeListener != null)
      localOnTabChangeListener.onTabChanged(paramString);
  }

  public final void setOnTabChangedListener(TabHost.OnTabChangeListener paramOnTabChangeListener)
  {
    this.e = paramOnTabChangeListener;
  }

  public final void setup()
  {
    throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
  }

  static class SavedState extends View.BaseSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
      static
      {
        CoverageLogger.Log(16173056);
      }
    };
    String a;

    static
    {
      CoverageLogger.Log(16345088);
    }

    SavedState(Parcel paramParcel)
    {
      super();
      this.a = paramParcel.readString();
    }

    SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("FragmentTabHost.SavedState{");
      localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      localStringBuilder.append(" curTab=");
      localStringBuilder.append(this.a);
      localStringBuilder.append("}");
      return localStringBuilder.toString();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeString(this.a);
    }
  }

  static final class a
  {
    final String a;
    final Class<?> b;
    final Bundle c;
    Fragment d;

    static
    {
      CoverageLogger.Log(16347136);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.FragmentTabHost
 * JD-Core Version:    0.6.2
 */