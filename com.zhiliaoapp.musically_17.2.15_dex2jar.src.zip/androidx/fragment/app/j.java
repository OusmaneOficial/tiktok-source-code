package androidx.fragment.app;

import androidx.lifecycle.aa;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.List;

public final class j
{
  public final List<Fragment> a;
  public final List<j> b;
  public final List<aa> c;

  static
  {
    CoverageLogger.Log(16328704);
  }

  j(List<Fragment> paramList, List<j> paramList1, List<aa> paramList2)
  {
    this.a = paramList;
    this.b = paramList1;
    this.c = paramList2;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.j
 * JD-Core Version:    0.6.2
 */