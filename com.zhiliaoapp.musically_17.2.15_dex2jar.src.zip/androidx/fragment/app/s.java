package androidx.fragment.app;

import android.util.AndroidRuntimeException;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class s extends AndroidRuntimeException
{
  static
  {
    CoverageLogger.Log(16377856);
  }

  public s(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.s
 * JD-Core Version:    0.6.2
 */