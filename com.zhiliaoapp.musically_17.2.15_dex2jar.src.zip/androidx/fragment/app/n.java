package androidx.fragment.app;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.app.m;
import androidx.core.h.t;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

final class n
{
  private static final int[] a;
  private static final q b = localp;
  private static final q c = a();

  static
  {
    CoverageLogger.Log(16171008);
    a = new int[] { 0, 3, 0, 1, 5, 4, 7, 6, 9, 8 };
    p localp;
    if (Build.VERSION.SDK_INT >= 21)
      localp = new p();
    else
      localp = null;
  }

  static View a(androidx.c.a<String, View> parama, a parama1, Object paramObject, boolean paramBoolean)
  {
    a locala = parama1.c;
    if ((paramObject != null) && (parama != null) && (locala.r != null) && (!locala.r.isEmpty()))
    {
      String str;
      if (paramBoolean)
        str = (String)locala.r.get(0);
      else
        str = (String)locala.s.get(0);
      return (View)parama.get(str);
    }
    return null;
  }

  private static androidx.c.a<String, String> a(int paramInt1, ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt2, int paramInt3)
  {
    androidx.c.a locala = new androidx.c.a();
    for (int i = paramInt3 - 1; i >= paramInt2; i--)
    {
      a locala1 = (a)paramArrayList.get(i);
      if (locala1.b(paramInt1))
      {
        boolean bool = ((Boolean)paramArrayList1.get(i)).booleanValue();
        if (locala1.r != null)
        {
          int j = locala1.r.size();
          ArrayList localArrayList2;
          Object localObject;
          if (bool)
          {
            localArrayList2 = locala1.r;
            localObject = locala1.s;
          }
          else
          {
            ArrayList localArrayList1 = locala1.r;
            localArrayList2 = locala1.s;
            localObject = localArrayList1;
          }
          for (int k = 0; k < j; k++)
          {
            String str1 = (String)((ArrayList)localObject).get(k);
            String str2 = (String)localArrayList2.get(k);
            String str3 = (String)locala.remove(str2);
            if (str3 != null)
              locala.put(str1, str3);
            else
              locala.put(str1, str2);
          }
        }
      }
    }
    return locala;
  }

  static androidx.c.a<String, View> a(q paramq, androidx.c.a<String, String> parama, Object paramObject, a parama1)
  {
    Fragment localFragment = parama1.a;
    View localView1 = localFragment.getView();
    if ((!parama.isEmpty()) && (paramObject != null) && (localView1 != null))
    {
      androidx.c.a locala = new androidx.c.a();
      paramq.a(locala, localView1);
      a locala1 = parama1.c;
      m localm;
      ArrayList localArrayList;
      if (parama1.b)
      {
        localm = localFragment.getExitTransitionCallback();
        localArrayList = locala1.r;
      }
      else
      {
        localm = localFragment.getEnterTransitionCallback();
        localArrayList = locala1.s;
      }
      if (localArrayList != null)
      {
        locala.a(localArrayList);
        locala.a(parama.values());
      }
      if (localm != null)
        for (int i = -1 + localArrayList.size(); i >= 0; i--)
        {
          String str1 = (String)localArrayList.get(i);
          View localView2 = (View)locala.get(str1);
          if (localView2 == null)
          {
            String str3 = a(parama, str1);
            if (str3 != null)
              parama.remove(str3);
          }
          else if (!str1.equals(t.p(localView2)))
          {
            String str2 = a(parama, str1);
            if (str2 != null)
              parama.put(str2, t.p(localView2));
          }
        }
      a(parama, locala);
      return locala;
    }
    parama.clear();
    return null;
  }

  private static a a(a parama, SparseArray<a> paramSparseArray, int paramInt)
  {
    if (parama == null)
    {
      parama = new a();
      paramSparseArray.put(paramInt, parama);
    }
    return parama;
  }

  // ERROR //
  private static q a()
  {
    // Byte code:
    //   0: ldc 156
    //   2: invokestatic 162	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   5: iconst_0
    //   6: anewarray 158	java/lang/Class
    //   9: invokevirtual 166	java/lang/Class:getDeclaredConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   12: iconst_0
    //   13: anewarray 4	java/lang/Object
    //   16: invokevirtual 172	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast 106	androidx/fragment/app/q
    //   22: astore_0
    //   23: aload_0
    //   24: areturn
    //   25: aconst_null
    //   26: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	23	25	java/lang/Exception
  }

  private static q a(Fragment paramFragment1, Fragment paramFragment2)
  {
    ArrayList localArrayList = new ArrayList();
    if (paramFragment1 != null)
    {
      Object localObject4 = paramFragment1.getExitTransition();
      if (localObject4 != null)
        localArrayList.add(localObject4);
      Object localObject5 = paramFragment1.getReturnTransition();
      if (localObject5 != null)
        localArrayList.add(localObject5);
      Object localObject6 = paramFragment1.getSharedElementReturnTransition();
      if (localObject6 != null)
        localArrayList.add(localObject6);
    }
    if (paramFragment2 != null)
    {
      Object localObject1 = paramFragment2.getEnterTransition();
      if (localObject1 != null)
        localArrayList.add(localObject1);
      Object localObject2 = paramFragment2.getReenterTransition();
      if (localObject2 != null)
        localArrayList.add(localObject2);
      Object localObject3 = paramFragment2.getSharedElementEnterTransition();
      if (localObject3 != null)
        localArrayList.add(localObject3);
    }
    if (localArrayList.isEmpty())
      return null;
    q localq1 = b;
    if ((localq1 != null) && (a(localq1, localArrayList)))
      return b;
    q localq2 = c;
    if ((localq2 != null) && (a(localq2, localArrayList)))
      return c;
    if ((b == null) && (c == null))
      return null;
    throw new IllegalArgumentException("Invalid Transition types");
  }

  private static Object a(q paramq, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean)
  {
    if ((paramFragment1 != null) && (paramFragment2 != null))
    {
      Object localObject;
      if (paramBoolean)
        localObject = paramFragment2.getSharedElementReturnTransition();
      else
        localObject = paramFragment1.getSharedElementEnterTransition();
      return paramq.c(paramq.b(localObject));
    }
    return null;
  }

  private static Object a(q paramq, Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null)
      return null;
    Object localObject;
    if (paramBoolean)
      localObject = paramFragment.getReenterTransition();
    else
      localObject = paramFragment.getEnterTransition();
    return paramq.b(localObject);
  }

  private static Object a(q paramq, Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean)
  {
    boolean bool;
    if ((paramObject1 != null) && (paramObject2 != null) && (paramFragment != null))
    {
      if (paramBoolean)
        bool = paramFragment.getAllowReturnTransitionOverlap();
      else
        bool = paramFragment.getAllowEnterTransitionOverlap();
    }
    else
      bool = true;
    if (bool)
      return paramq.a(paramObject2, paramObject1, paramObject3);
    return paramq.b(paramObject2, paramObject1, paramObject3);
  }

  private static String a(androidx.c.a<String, String> parama, String paramString)
  {
    int i = parama.size();
    for (int j = 0; j < i; j++)
      if (paramString.equals(parama.c(j)))
        return (String)parama.b(j);
    return null;
  }

  static ArrayList<View> a(q paramq, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList, View paramView)
  {
    ArrayList localArrayList;
    if (paramObject != null)
    {
      localArrayList = new ArrayList();
      View localView = paramFragment.getView();
      if (localView != null)
        paramq.a(localArrayList, localView);
      if (paramArrayList != null)
        localArrayList.removeAll(paramArrayList);
      if (!localArrayList.isEmpty())
      {
        localArrayList.add(paramView);
        paramq.a(paramObject, localArrayList);
        return localArrayList;
      }
    }
    else
    {
      localArrayList = null;
    }
    return localArrayList;
  }

  private static void a(androidx.c.a<String, String> parama, androidx.c.a<String, View> parama1)
  {
    for (int i = -1 + parama.size(); i >= 0; i--)
      if (!parama1.containsKey((String)parama.c(i)))
        parama.d(i);
  }

  static void a(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, androidx.c.a<String, View> parama, boolean paramBoolean2)
  {
    m localm;
    if (paramBoolean1)
      localm = paramFragment2.getEnterTransitionCallback();
    else
      localm = paramFragment1.getEnterTransitionCallback();
    if (localm != null)
    {
      ArrayList localArrayList1 = new ArrayList();
      ArrayList localArrayList2 = new ArrayList();
      int i = 0;
      int j;
      if (parama == null)
      {
        i = 0;
        j = 0;
      }
      else
      {
        j = parama.size();
      }
      while (i < j)
      {
        localArrayList2.add(parama.b(i));
        localArrayList1.add(parama.c(i));
        i++;
      }
    }
  }

  private static void a(a parama, SparseArray<a> paramSparseArray, boolean paramBoolean)
  {
    int i = parama.b.size();
    for (int j = 0; j < i; j++)
      a(parama, (a.a)parama.b.get(j), paramSparseArray, false, paramBoolean);
  }

  private static void a(a parama, a.a parama1, SparseArray<a> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2)
  {
    Fragment localFragment = parama1.b;
    if (localFragment == null)
      return;
    int i = localFragment.mContainerId;
    if (i == 0)
      return;
    int j;
    if (paramBoolean1)
      j = a[parama1.a];
    else
      j = parama1.a;
    int k = 0;
    int m = 1;
    if (j != m)
      if (j != 3)
        if (j != 4)
          if (j != 5)
          {
            if (j == 6)
              break label198;
            if (j == 7)
              break label287;
            m = 0;
          }
    int n;
    int i1;
    while (true)
    {
      n = 0;
      i1 = 0;
      break;
      if (paramBoolean2)
      {
        if ((!localFragment.mHiddenChanged) || (localFragment.mHidden) || (!localFragment.mAdded))
          break label324;
      }
      else
      {
        bool = localFragment.mHidden;
        break label327;
        if (paramBoolean2)
        {
          if ((!localFragment.mHiddenChanged) || (!localFragment.mAdded) || (!localFragment.mHidden));
        }
        else
          while (true)
          {
            break;
            if ((!localFragment.mAdded) || (localFragment.mHidden))
              break label246;
            continue;
            label198: if (!paramBoolean2)
              break label252;
            if ((localFragment.mAdded) || (localFragment.mView == null) || (localFragment.mView.getVisibility() != 0) || (localFragment.mPostponedAlpha < 0.0F))
              break label246;
          }
        int i2;
        while (true)
        {
          i2 = 1;
          break;
          label246: label252: 
          do
          {
            i2 = 0;
            break;
          }
          while ((!localFragment.mAdded) || (localFragment.mHidden));
        }
        n = i2;
        i1 = 1;
        k = 0;
        m = 0;
        break;
        label287: if (paramBoolean2)
        {
          bool = localFragment.mIsNewlyAdded;
          break label327;
        }
        if ((localFragment.mAdded) || (localFragment.mHidden))
          break label324;
      }
      boolean bool = true;
      break label327;
      label324: bool = false;
      label327: k = bool;
    }
    a locala1 = (a)paramSparseArray.get(i);
    if (k != 0)
    {
      locala1 = a(locala1, paramSparseArray, i);
      locala1.a = localFragment;
      locala1.b = paramBoolean1;
      locala1.c = parama;
    }
    a locala2 = locala1;
    if ((!paramBoolean2) && (m != 0))
    {
      if ((locala2 != null) && (locala2.d == localFragment))
        locala2.d = null;
      h localh = parama.a;
      if ((localFragment.mState <= 0) && (localh.l > 0) && (!parama.t))
      {
        localh.d(localFragment);
        o.a(localh, localFragment, 1, 0, 0, false);
      }
    }
    if ((n != 0) && ((locala2 == null) || (locala2.d == null)))
    {
      locala2 = a(locala2, paramSparseArray, i);
      locala2.d = localFragment;
      locala2.e = paramBoolean1;
      locala2.f = parama;
    }
    if ((!paramBoolean2) && (i1 != 0) && (locala2 != null) && (locala2.a == localFragment))
      locala2.a = null;
  }

  static void a(h paramh, ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    h localh1 = paramh;
    ArrayList<a> localArrayList = paramArrayList;
    ArrayList<Boolean> localArrayList1 = paramArrayList1;
    int i = paramInt2;
    boolean bool1 = paramBoolean;
    if (localh1.l <= 0)
      return;
    Object localObject1 = new SparseArray();
    for (int j = paramInt1; j < i; j++)
    {
      a locala13 = (a)localArrayList.get(j);
      if (((Boolean)localArrayList1.get(j)).booleanValue())
        b(locala13, (SparseArray)localObject1, bool1);
      else
        a(locala13, (SparseArray)localObject1, bool1);
    }
    if (((SparseArray)localObject1).size() != 0)
    {
      final View localView1 = new View(localh1.m.c);
      int k = ((SparseArray)localObject1).size();
      int m = 0;
      while (m < k)
      {
        int n = ((SparseArray)localObject1).keyAt(m);
        final androidx.c.a locala1 = a(n, localArrayList, localArrayList1, paramInt1, i);
        a locala2 = (a)((SparseArray)localObject1).valueAt(m);
        Object localObject2;
        int i1;
        int i2;
        if (bool1)
        {
          ViewGroup localViewGroup2;
          if (localh1.n.a())
            localViewGroup2 = (ViewGroup)localh1.n.a(n);
          else
            localViewGroup2 = null;
          if (localViewGroup2 != null)
          {
            Fragment localFragment6 = locala2.a;
            Fragment localFragment7 = locala2.d;
            final q localq2 = a(localFragment7, localFragment6);
            if (localq2 != null)
            {
              boolean bool8 = locala2.b;
              boolean bool9 = locala2.e;
              ArrayList localArrayList9 = new ArrayList();
              ArrayList localArrayList10 = new ArrayList();
              localObject2 = localObject1;
              Object localObject15 = a(localq2, localFragment6, bool8);
              Object localObject16 = b(localq2, localFragment7, bool9);
              Fragment localFragment8 = locala2.a;
              i1 = m;
              final Fragment localFragment9 = locala2.d;
              i2 = k;
              if (localFragment8 != null)
                localFragment8.getView().setVisibility(0);
              final boolean bool11;
              boolean bool10;
              androidx.c.a locala10;
              Fragment localFragment10;
              final androidx.c.a locala11;
              ArrayList localArrayList11;
              if ((localFragment8 != null) && (localFragment9 != null))
              {
                bool11 = locala2.b;
                Object localObject19;
                if (locala1.isEmpty())
                {
                  bool10 = bool8;
                  localObject19 = null;
                }
                else
                {
                  localObject19 = a(localq2, localFragment8, localFragment9, bool11);
                  bool10 = bool8;
                }
                locala10 = b(localq2, locala1, localObject19, locala2);
                localFragment10 = localFragment6;
                locala11 = a(localq2, locala1, localObject19, locala2);
                if (locala1.isEmpty())
                {
                  if (locala10 != null)
                    locala10.clear();
                  if (locala11 != null)
                    locala11.clear();
                  localObject17 = null;
                }
                else
                {
                  Object localObject20 = localObject19;
                  a(localArrayList10, locala10, locala1.keySet());
                  a(localArrayList9, locala11, locala1.values());
                  localObject17 = localObject20;
                }
                if ((localObject15 == null) && (localObject16 == null) && (localObject17 == null))
                  localArrayList11 = localArrayList9;
              }
              androidx.c.a locala9;
              while (true)
              {
                locala9 = locala1;
                break;
                locala9 = locala1;
                a(localFragment8, localFragment9, bool11, locala10, true);
                final Rect localRect3;
                final View localView2;
                if (localObject17 != null)
                {
                  localArrayList9.add(localView1);
                  localq2.a(localObject17, localView1, localArrayList10);
                  boolean bool12 = locala2.e;
                  localArrayList11 = localArrayList9;
                  a locala12 = locala2.f;
                  a(localq2, localObject17, localObject16, locala10, bool12, locala12);
                  Rect localRect4 = new Rect();
                  View localView3 = a(locala11, locala2, localObject15, bool11);
                  if (localView3 != null)
                    localq2.a(localObject15, localRect4);
                  localRect3 = localRect4;
                  localView2 = localView3;
                }
                else
                {
                  localArrayList11 = localArrayList9;
                  localView2 = null;
                  localRect3 = null;
                }
                Runnable local3 = new Runnable()
                {
                  static
                  {
                    CoverageLogger.Log(16353280);
                  }

                  public final void run()
                  {
                    n.a(this.a, localFragment9, bool11, locala11, false);
                    View localView = localView2;
                    if (localView != null)
                      q.a(localView, localRect3);
                  }
                };
                r.a(localViewGroup2, local3);
                break label700;
                bool10 = bool8;
                localArrayList11 = localArrayList9;
                localFragment10 = localFragment6;
              }
              Object localObject17 = null;
              label700: if ((localObject15 == null) && (localObject17 == null) && (localObject16 == null))
                break label935;
              ArrayList localArrayList12 = a(localq2, localObject16, localFragment7, localArrayList10, localView1);
              Fragment localFragment11 = localFragment10;
              ArrayList localArrayList13 = localArrayList11;
              ArrayList localArrayList14 = a(localq2, localObject15, localFragment11, localArrayList13, localView1);
              a(localArrayList14, 4);
              Object localObject18 = a(localq2, localObject15, localObject16, localObject17, localFragment11, bool10);
              if (localObject18 == null)
                break label935;
              if ((localFragment7 != null) && (localObject16 != null) && (localFragment7.mAdded) && (localFragment7.mHidden) && (localFragment7.mHiddenChanged))
              {
                localFragment7.setHideReplaced(true);
                localq2.b(localObject16, localFragment7.getView(), localArrayList12);
                r.a(localFragment7.mContainer, new Runnable()
                {
                  static
                  {
                    CoverageLogger.Log(16160768);
                  }

                  public final void run()
                  {
                    n.a(this.a, 4);
                  }
                });
              }
              ArrayList localArrayList15 = q.a(localArrayList13);
              localq2.a(localObject18, localObject15, localArrayList14, localObject16, localArrayList12, localObject17, localArrayList13);
              localq2.a(localViewGroup2, localObject18);
              localq2.a(localViewGroup2, localArrayList10, localArrayList13, localArrayList15, locala9);
              a(localArrayList14, 0);
              localq2.a(localObject17, localArrayList10, localArrayList13);
              break label1649;
            }
          }
          localObject2 = localObject1;
          i1 = m;
          i2 = k;
        }
        else
        {
          label935: h localh2 = localh1;
          localObject2 = localObject1;
          i1 = m;
          i2 = k;
          ViewGroup localViewGroup1;
          if (localh2.n.a())
            localViewGroup1 = (ViewGroup)localh2.n.a(n);
          else
            localViewGroup1 = null;
          if (localViewGroup1 != null)
          {
            final Fragment localFragment1 = locala2.a;
            Fragment localFragment2 = locala2.d;
            final q localq1 = a(localFragment2, localFragment1);
            if (localq1 != null)
            {
              boolean bool2 = locala2.b;
              boolean bool3 = locala2.e;
              Object localObject3 = a(localq1, localFragment1, bool2);
              Object localObject4 = b(localq1, localFragment2, bool3);
              ArrayList localArrayList2 = new ArrayList();
              final ArrayList localArrayList3 = new ArrayList();
              final Fragment localFragment3 = locala2.a;
              Fragment localFragment4 = locala2.d;
              androidx.c.a locala4;
              a locala3;
              final ArrayList localArrayList5;
              final ArrayList localArrayList4;
              final Object localObject5;
              Object localObject7;
              final Object localObject6;
              if ((localFragment3 != null) && (localFragment4 != null))
              {
                boolean bool5 = locala2.b;
                Object localObject10;
                if (locala1.isEmpty())
                  localObject10 = null;
                else
                  localObject10 = a(localq1, localFragment3, localFragment4, bool5);
                androidx.c.a locala6 = b(localq1, locala1, localObject10, locala2);
                Object localObject11;
                if (locala1.isEmpty())
                {
                  localObject11 = null;
                }
                else
                {
                  Object localObject14 = localObject10;
                  localArrayList2.addAll(locala6.values());
                  localObject11 = localObject14;
                }
                if ((localObject3 == null) && (localObject4 == null) && (localObject11 == null))
                {
                  locala4 = locala1;
                  locala3 = locala2;
                  localArrayList5 = localArrayList3;
                  localArrayList4 = localArrayList2;
                  localObject5 = localObject4;
                  localObject8 = localObject3;
                  localObject7 = null;
                  break label1446;
                }
                a(localFragment3, localFragment4, bool5, locala6, true);
                final boolean bool6;
                final Fragment localFragment5;
                final Rect localRect2;
                if (localObject11 != null)
                {
                  Rect localRect1 = new Rect();
                  localq1.a(localObject11, localView1, localArrayList2);
                  bool6 = bool5;
                  boolean bool7 = locala2.e;
                  localFragment5 = localFragment4;
                  a locala7 = locala2.f;
                  a(localq1, localObject11, localObject4, locala6, bool7, locala7);
                  if (localObject3 != null)
                    localq1.a(localObject3, localRect1);
                  localRect2 = localRect1;
                }
                else
                {
                  bool6 = bool5;
                  localFragment5 = localFragment4;
                  localRect2 = null;
                }
                locala3 = locala2;
                final Object localObject12 = localObject11;
                Object localObject13 = localObject11;
                final a locala8 = locala3;
                localArrayList5 = localArrayList3;
                localArrayList4 = localArrayList2;
                locala4 = locala1;
                localObject5 = localObject4;
                localObject6 = localObject3;
                Runnable local4 = new Runnable()
                {
                  static
                  {
                    CoverageLogger.Log(16154624);
                  }

                  public final void run()
                  {
                    androidx.c.a locala = n.a(this.a, locala1, localObject12, locala8);
                    if (locala != null)
                    {
                      localArrayList3.addAll(locala.values());
                      localArrayList3.add(localView1);
                    }
                    n.a(localFragment3, localFragment5, bool6, locala, false);
                    Object localObject = localObject12;
                    if (localObject != null)
                    {
                      this.a.a(localObject, localArrayList4, localArrayList3);
                      View localView = n.a(locala, locala8, localObject6, bool6);
                      if (localView != null)
                        q.a(localView, localRect2);
                    }
                  }
                };
                r.a(localViewGroup1, local4);
                localObject7 = localObject13;
              }
              else
              {
                locala3 = locala2;
                localArrayList4 = localArrayList2;
                localObject5 = localObject4;
                localObject6 = localObject3;
                locala4 = locala1;
                localArrayList5 = localArrayList3;
                localObject7 = null;
              }
              Object localObject8 = localObject6;
              label1446: if ((localObject8 != null) || (localObject7 != null) || (localObject5 != null))
              {
                final ArrayList localArrayList6 = a(localq1, localObject5, localFragment2, localArrayList4, localView1);
                if ((localArrayList6 == null) || (localArrayList6.isEmpty()))
                  localObject5 = null;
                localq1.b(localObject8, localView1);
                boolean bool4 = locala3.b;
                Object localObject9 = a(localq1, localObject8, localObject5, localObject7, localFragment1, bool4);
                if (localObject9 != null)
                {
                  final ArrayList localArrayList7 = new ArrayList();
                  localq1.a(localObject9, localObject8, localArrayList7, localObject5, localArrayList6, localObject7, localArrayList5);
                  Runnable local2 = new Runnable()
                  {
                    static
                    {
                      CoverageLogger.Log(16158720);
                    }

                    public final void run()
                    {
                      Object localObject = this.a;
                      if (localObject != null)
                      {
                        localq1.c(localObject, localView1);
                        ArrayList localArrayList2 = n.a(localq1, this.a, localFragment1, localArrayList5, localView1);
                        localArrayList7.addAll(localArrayList2);
                      }
                      if (localArrayList6 != null)
                      {
                        if (localObject5 != null)
                        {
                          ArrayList localArrayList1 = new ArrayList();
                          localArrayList1.add(localView1);
                          localq1.b(localObject5, localArrayList6, localArrayList1);
                        }
                        localArrayList6.clear();
                        localArrayList6.add(localView1);
                      }
                    }
                  };
                  r.a(localViewGroup1, local2);
                  ArrayList localArrayList8 = localArrayList5;
                  androidx.c.a locala5 = locala4;
                  r.a(localViewGroup1, new q.2(localq1, localArrayList8, locala5));
                  localq1.a(localViewGroup1, localObject9);
                  r.a(localViewGroup1, new q.3(localq1, localArrayList8, locala5));
                }
              }
            }
          }
        }
        label1649: m = i1 + 1;
        localh1 = paramh;
        localArrayList = paramArrayList;
        localArrayList1 = paramArrayList1;
        i = paramInt2;
        bool1 = paramBoolean;
        localObject1 = localObject2;
        k = i2;
      }
    }
  }

  private static void a(q paramq, Object paramObject1, Object paramObject2, androidx.c.a<String, View> parama, boolean paramBoolean, a parama1)
  {
    if ((parama1.r != null) && (!parama1.r.isEmpty()))
    {
      String str;
      if (paramBoolean)
        str = (String)parama1.s.get(0);
      else
        str = (String)parama1.r.get(0);
      View localView = (View)parama.get(str);
      paramq.a(paramObject1, localView);
      if (paramObject2 != null)
        paramq.a(paramObject2, localView);
    }
  }

  static void a(ArrayList<View> paramArrayList, int paramInt)
  {
    if (paramArrayList == null)
      return;
    for (int i = -1 + paramArrayList.size(); i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt);
  }

  private static void a(ArrayList<View> paramArrayList, androidx.c.a<String, View> parama, Collection<String> paramCollection)
  {
    for (int i = -1 + parama.size(); i >= 0; i--)
    {
      View localView = (View)parama.c(i);
      if (paramCollection.contains(t.p(localView)))
        paramArrayList.add(localView);
    }
  }

  private static boolean a(q paramq, List<Object> paramList)
  {
    int i = paramList.size();
    for (int j = 0; j < i; j++)
      if (!paramq.a(paramList.get(j)))
        return false;
    return true;
  }

  private static androidx.c.a<String, View> b(q paramq, androidx.c.a<String, String> parama, Object paramObject, a parama1)
  {
    if ((!parama.isEmpty()) && (paramObject != null))
    {
      Fragment localFragment = parama1.d;
      androidx.c.a locala = new androidx.c.a();
      paramq.a(locala, localFragment.getView());
      a locala1 = parama1.f;
      m localm;
      ArrayList localArrayList;
      if (parama1.e)
      {
        localm = localFragment.getEnterTransitionCallback();
        localArrayList = locala1.s;
      }
      else
      {
        localm = localFragment.getExitTransitionCallback();
        localArrayList = locala1.r;
      }
      locala.a(localArrayList);
      if (localm != null)
        for (int i = -1 + localArrayList.size(); i >= 0; i--)
        {
          String str1 = (String)localArrayList.get(i);
          View localView = (View)locala.get(str1);
          if (localView == null)
          {
            parama.remove(str1);
          }
          else if (!str1.equals(t.p(localView)))
          {
            String str2 = (String)parama.remove(str1);
            parama.put(t.p(localView), str2);
          }
        }
      parama.a(locala.keySet());
      return locala;
    }
    parama.clear();
    return null;
  }

  private static Object b(q paramq, Fragment paramFragment, boolean paramBoolean)
  {
    if (paramFragment == null)
      return null;
    Object localObject;
    if (paramBoolean)
      localObject = paramFragment.getReturnTransition();
    else
      localObject = paramFragment.getExitTransition();
    return paramq.b(localObject);
  }

  private static void b(a parama, SparseArray<a> paramSparseArray, boolean paramBoolean)
  {
    if (!parama.a.n.a())
      return;
    for (int i = parama.b.size() - 1; i >= 0; i--)
      a(parama, (a.a)parama.b.get(i), paramSparseArray, true, paramBoolean);
  }

  static final class a
  {
    public Fragment a;
    public boolean b;
    public a c;
    public Fragment d;
    public boolean e;
    public a f;

    static
    {
      CoverageLogger.Log(16152576);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.n
 * JD-Core Version:    0.6.2
 */