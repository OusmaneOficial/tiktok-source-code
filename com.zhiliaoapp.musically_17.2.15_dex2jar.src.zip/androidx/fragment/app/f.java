package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class f
{
  static
  {
    CoverageLogger.Log(16224256);
  }

  public abstract Fragment.SavedState a(Fragment paramFragment);

  public abstract Fragment a(int paramInt);

  public abstract Fragment a(Bundle paramBundle, String paramString);

  public abstract Fragment a(String paramString);

  public abstract m a();

  public abstract void a(int paramInt1, int paramInt2);

  public abstract void a(Bundle paramBundle, String paramString, Fragment paramFragment);

  public abstract void a(a parama);

  public abstract void a(a parama, boolean paramBoolean);

  public abstract void a(b paramb);

  public abstract void a(String paramString, int paramInt);

  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);

  public abstract void b(b paramb);

  public abstract boolean b();

  public abstract void c();

  public abstract boolean d();

  public abstract int e();

  public abstract List<Fragment> f();

  public abstract boolean g();

  public abstract boolean h();

  public static abstract class a
  {
    static
    {
      CoverageLogger.Log(16226304);
    }

    public void onFragmentActivityCreated(f paramf, Fragment paramFragment, Bundle paramBundle)
    {
    }

    public void onFragmentAttached(f paramf, Fragment paramFragment, Context paramContext)
    {
    }

    public void onFragmentCreated(f paramf, Fragment paramFragment, Bundle paramBundle)
    {
    }

    public void onFragmentDestroyed(f paramf, Fragment paramFragment)
    {
    }

    public void onFragmentDetached(f paramf, Fragment paramFragment)
    {
    }

    public void onFragmentPaused(f paramf, Fragment paramFragment)
    {
    }

    public void onFragmentPreAttached(f paramf, Fragment paramFragment, Context paramContext)
    {
    }

    public void onFragmentPreCreated(f paramf, Fragment paramFragment, Bundle paramBundle)
    {
    }

    public void onFragmentResumed(f paramf, Fragment paramFragment)
    {
    }

    public void onFragmentSaveInstanceState(f paramf, Fragment paramFragment, Bundle paramBundle)
    {
    }

    public void onFragmentStarted(f paramf, Fragment paramFragment)
    {
    }

    public void onFragmentStopped(f paramf, Fragment paramFragment)
    {
    }

    public void onFragmentViewCreated(f paramf, Fragment paramFragment, View paramView, Bundle paramBundle)
    {
    }

    public void onFragmentViewDestroyed(f paramf, Fragment paramFragment)
    {
    }
  }

  public static abstract interface b
  {
    static
    {
      CoverageLogger.Log(16287744);
    }

    public abstract void a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.f
 * JD-Core Version:    0.6.2
 */