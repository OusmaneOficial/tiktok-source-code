package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class c
{
  static
  {
    CoverageLogger.Log(16271360);
  }

  public abstract View a(int paramInt);

  public Fragment a(Context paramContext, String paramString, Bundle paramBundle)
  {
    return Fragment.instantiate(paramContext, paramString, paramBundle);
  }

  public abstract boolean a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.c
 * JD-Core Version:    0.6.2
 */