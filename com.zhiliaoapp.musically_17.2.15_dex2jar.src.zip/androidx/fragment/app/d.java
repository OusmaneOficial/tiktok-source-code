package androidx.fragment.app;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class d
{
  final e<?> a;

  static
  {
    CoverageLogger.Log(16283648);
  }

  d(e<?> parame)
  {
    this.a = parame;
  }

  public final Fragment a(String paramString)
  {
    return this.a.e.b(paramString);
  }

  public final f a()
  {
    return this.a.e;
  }

  public final void b()
  {
    this.a.e.l();
  }

  public final boolean c()
  {
    return this.a.e.j();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.d
 * JD-Core Version:    0.6.2
 */