package androidx.fragment.app;

import android.app.Activity;
import android.util.Log;
import com.bytedance.ies.ugc.a.e;
import com.ss.android.ugc.aweme.app.f.c;
import com.ss.android.ugc.aweme.app.q;
import com.ss.android.ugc.aweme.commercialize.views.b;
import com.ss.android.ugc.aweme.commercialize.views.cards.ab;
import com.ss.android.ugc.aweme.commercialize.views.form.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import org.json.JSONObject;

public final class o
{
  static
  {
    CoverageLogger.Log(1187840);
  }

  static void a(h paramh, Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int i;
    try
    {
      paramh.a(paramFragment, 1, 0, 0, false);
      return;
    }
    catch (Exception localException1)
    {
      i = 0;
      if (paramFragment == null);
    }
    while (true)
    {
      try
      {
        str1 = paramFragment.getClass().getName();
        Activity localActivity = e.i();
        if (localActivity == null)
          break label218;
        str2 = localActivity.getClass().getName();
        JSONObject localJSONObject = c.a().a("fragmentname", str1).a("newState", Integer.valueOf(1)).a("transit", Integer.valueOf(0)).a("transitionStyle", Integer.valueOf(0)).a("keepActive", Boolean.valueOf(false)).a("currentActivity", str2).a("errorMsg", Log.getStackTraceString(localException1)).b();
        q.a("fragment_crash_log", "", c.a().a("errorDesc", localJSONObject.toString()).a("fragment_name", str1).b());
      }
      catch (Exception localException2)
      {
      }
      Class[] arrayOfClass = { b.class, ab.class, a.class };
      while (i < 3)
      {
        if (arrayOfClass[i].isInstance(paramFragment))
          return;
        i++;
      }
      while (true)
        throw localException1;
      String str1 = "";
      continue;
      label218: String str2 = "";
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.o
 * JD-Core Version:    0.6.2
 */