package androidx.fragment.app;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class m
{
  static
  {
    CoverageLogger.Log(16349184);
  }

  public abstract m a(int paramInt1, int paramInt2);

  public abstract m a(int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract m a(int paramInt, Fragment paramFragment);

  public abstract m a(int paramInt, Fragment paramFragment, String paramString);

  public abstract m a(Fragment paramFragment);

  public abstract m a(Fragment paramFragment, String paramString);

  public abstract m a(String paramString);

  public abstract int b();

  public abstract m b(int paramInt, Fragment paramFragment);

  public abstract m b(int paramInt, Fragment paramFragment, String paramString);

  public abstract m b(Fragment paramFragment);

  public abstract int c();

  public abstract m c(Fragment paramFragment);

  public abstract m d(Fragment paramFragment);

  public abstract void d();

  public abstract m e(Fragment paramFragment);

  public abstract void e();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.m
 * JD-Core Version:    0.6.2
 */