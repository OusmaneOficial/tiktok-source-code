package androidx.fragment.app;

import android.app.Activity;
import android.util.Log;
import com.bytedance.ies.ugc.a.e;
import com.ss.android.ugc.aweme.app.f.c;
import com.ss.android.ugc.aweme.app.q;
import com.ss.android.ugc.aweme.commercialize.views.b;
import com.ss.android.ugc.aweme.commercialize.views.cards.ab;
import com.ss.android.ugc.aweme.commercialize.views.form.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import org.json.JSONObject;

public final class i
{
  static
  {
    CoverageLogger.Log(1320960);
  }

  static void a(h paramh, Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    try
    {
      paramh.a(paramFragment, paramInt1, paramInt2, paramInt3, paramBoolean);
      return;
    }
    catch (Exception localException1)
    {
      if (paramFragment == null);
    }
    while (true)
    {
      try
      {
        str1 = paramFragment.getClass().getName();
        Activity localActivity = e.i();
        if (localActivity == null)
          break label225;
        str2 = localActivity.getClass().getName();
        JSONObject localJSONObject = c.a().a("fragmentname", str1).a("newState", Integer.valueOf(paramInt1)).a("transit", Integer.valueOf(paramInt2)).a("transitionStyle", Integer.valueOf(paramInt3)).a("keepActive", Boolean.valueOf(paramBoolean)).a("currentActivity", str2).a("errorMsg", Log.getStackTraceString(localException1)).b();
        q.a("fragment_crash_log", "", c.a().a("errorDesc", localJSONObject.toString()).a("fragment_name", str1).b());
      }
      catch (Exception localException2)
      {
      }
      Class[] arrayOfClass = new Class[3];
      int i = 0;
      arrayOfClass[0] = b.class;
      arrayOfClass[1] = ab.class;
      arrayOfClass[2] = a.class;
      while (i < 3)
      {
        if (arrayOfClass[i].isInstance(paramFragment))
          return;
        i++;
      }
      while (true)
        throw localException1;
      String str1 = "";
      continue;
      label225: String str2 = "";
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.fragment.app.i
 * JD-Core Version:    0.6.2
 */