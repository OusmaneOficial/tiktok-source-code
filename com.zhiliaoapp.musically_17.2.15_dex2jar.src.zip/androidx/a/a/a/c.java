package androidx.a.a.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class c
{
  static
  {
    CoverageLogger.Log(73613312);
  }

  public abstract void a(Runnable paramRunnable);

  public abstract void b(Runnable paramRunnable);

  public abstract boolean d();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.a.a.a.c
 * JD-Core Version:    0.6.2
 */