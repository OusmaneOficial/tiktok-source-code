package androidx.a.a.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;

public class b<K, V>
  implements Iterable<Map.Entry<K, V>>
{
  public c<K, V> b;
  public c<K, V> c;
  public WeakHashMap<f<K, V>, Boolean> d = new WeakHashMap();
  public int e = 0;

  static
  {
    CoverageLogger.Log(27527168);
  }

  protected c<K, V> a(K paramK)
  {
    for (c localc = this.b; (localc != null) && (!localc.a.equals(paramK)); localc = localc.c);
    return localc;
  }

  public final b<K, V>.d a()
  {
    d locald = new d();
    this.d.put(locald, Boolean.valueOf(false));
    return locald;
  }

  public V a(K paramK, V paramV)
  {
    c localc = a(paramK);
    if (localc != null)
      return localc.b;
    b(paramK, paramV);
    return null;
  }

  protected final c<K, V> b(K paramK, V paramV)
  {
    c localc1 = new c(paramK, paramV);
    this.e = (1 + this.e);
    c localc2 = this.c;
    if (localc2 == null)
    {
      this.b = localc1;
      this.c = this.b;
      return localc1;
    }
    localc2.c = localc1;
    localc1.d = localc2;
    this.c = localc1;
    return localc1;
  }

  public V b(K paramK)
  {
    c localc = a(paramK);
    if (localc == null)
      return null;
    this.e = (-1 + this.e);
    if (!this.d.isEmpty())
    {
      Iterator localIterator = this.d.keySet().iterator();
      while (localIterator.hasNext())
        ((f)localIterator.next()).a_(localc);
    }
    if (localc.d != null)
      localc.d.c = localc.c;
    else
      this.b = localc.c;
    if (localc.c != null)
      localc.c.d = localc.d;
    else
      this.c = localc.d;
    localc.c = null;
    localc.d = null;
    return localc.b;
  }

  public boolean equals(Object paramObject)
  {
    if (paramObject == this)
      return true;
    if (!(paramObject instanceof b))
      return false;
    b localb = (b)paramObject;
    if (this.e != localb.e)
      return false;
    Iterator localIterator1 = iterator();
    Iterator localIterator2 = localb.iterator();
    while ((localIterator1.hasNext()) && (localIterator2.hasNext()))
    {
      Map.Entry localEntry = (Map.Entry)localIterator1.next();
      Object localObject = localIterator2.next();
      if (((localEntry == null) && (localObject != null)) || ((localEntry != null) && (!localEntry.equals(localObject))))
        return false;
    }
    return (!localIterator1.hasNext()) && (!localIterator2.hasNext());
  }

  public int hashCode()
  {
    Iterator localIterator = iterator();
    int i = 0;
    while (localIterator.hasNext())
      i += ((Map.Entry)localIterator.next()).hashCode();
    return i;
  }

  public Iterator<Map.Entry<K, V>> iterator()
  {
    a locala = new a(this.b, this.c);
    this.d.put(locala, Boolean.valueOf(false));
    return locala;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("[");
    Iterator localIterator = iterator();
    while (localIterator.hasNext())
    {
      localStringBuilder.append(((Map.Entry)localIterator.next()).toString());
      if (localIterator.hasNext())
        localStringBuilder.append(", ");
    }
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }

  static final class a<K, V> extends b.e<K, V>
  {
    static
    {
      CoverageLogger.Log(27533312);
    }

    a(b.c<K, V> paramc1, b.c<K, V> paramc2)
    {
      super(paramc2);
    }

    final b.c<K, V> a(b.c<K, V> paramc)
    {
      return paramc.c;
    }

    final b.c<K, V> b(b.c<K, V> paramc)
    {
      return paramc.d;
    }
  }

  public static final class b<K, V> extends b.e<K, V>
  {
    static
    {
      CoverageLogger.Log(27691008);
    }

    public b(b.c<K, V> paramc1, b.c<K, V> paramc2)
    {
      super(paramc2);
    }

    final b.c<K, V> a(b.c<K, V> paramc)
    {
      return paramc.d;
    }

    final b.c<K, V> b(b.c<K, V> paramc)
    {
      return paramc.c;
    }
  }

  public static final class c<K, V>
    implements Map.Entry<K, V>
  {
    final K a;
    final V b;
    c<K, V> c;
    public c<K, V> d;

    static
    {
      CoverageLogger.Log(27686912);
    }

    c(K paramK, V paramV)
    {
      this.a = paramK;
      this.b = paramV;
    }

    public final boolean equals(Object paramObject)
    {
      if (paramObject == this)
        return true;
      if (!(paramObject instanceof c))
        return false;
      c localc = (c)paramObject;
      return (this.a.equals(localc.a)) && (this.b.equals(localc.b));
    }

    public final K getKey()
    {
      return this.a;
    }

    public final V getValue()
    {
      return this.b;
    }

    public final int hashCode()
    {
      return this.a.hashCode() ^ this.b.hashCode();
    }

    public final V setValue(V paramV)
    {
      throw new UnsupportedOperationException("An entry modification is not supported");
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(this.a);
      localStringBuilder.append("=");
      localStringBuilder.append(this.b);
      return localStringBuilder.toString();
    }
  }

  public final class d
    implements b.f<K, V>, Iterator<Map.Entry<K, V>>
  {
    private b.c<K, V> b;
    private boolean c = true;

    static
    {
      CoverageLogger.Log(27693056);
    }

    d()
    {
    }

    public final void a_(b.c<K, V> paramc)
    {
      b.c localc = this.b;
      if (paramc == localc)
      {
        this.b = localc.d;
        boolean bool;
        if (this.b == null)
          bool = true;
        else
          bool = false;
        this.c = bool;
      }
    }

    public final boolean hasNext()
    {
      if (this.c)
        return b.this.b != null;
      b.c localc = this.b;
      return (localc != null) && (localc.c != null);
    }
  }

  static abstract class e<K, V>
    implements b.f<K, V>, Iterator<Map.Entry<K, V>>
  {
    b.c<K, V> a;
    b.c<K, V> b;

    static
    {
      CoverageLogger.Log(27697152);
    }

    e(b.c<K, V> paramc1, b.c<K, V> paramc2)
    {
      this.a = paramc2;
      this.b = paramc1;
    }

    private b.c<K, V> a()
    {
      b.c localc1 = this.b;
      b.c localc2 = this.a;
      if ((localc1 != localc2) && (localc2 != null))
        return a(localc1);
      return null;
    }

    abstract b.c<K, V> a(b.c<K, V> paramc);

    public final void a_(b.c<K, V> paramc)
    {
      if ((this.a == paramc) && (paramc == this.b))
      {
        this.b = null;
        this.a = null;
      }
      b.c localc = this.a;
      if (localc == paramc)
        this.a = b(localc);
      if (this.b == paramc)
        this.b = a();
    }

    abstract b.c<K, V> b(b.c<K, V> paramc);

    public boolean hasNext()
    {
      return this.b != null;
    }
  }

  static abstract interface f<K, V>
  {
    static
    {
      CoverageLogger.Log(27523072);
    }

    public abstract void a_(b.c<K, V> paramc);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.a.a.b.b
 * JD-Core Version:    0.6.2
 */