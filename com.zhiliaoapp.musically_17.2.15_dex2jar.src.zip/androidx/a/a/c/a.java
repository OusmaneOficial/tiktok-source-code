package androidx.a.a.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a<I, O>
{
  static
  {
    CoverageLogger.Log(27518976);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.a.a.c.a
 * JD-Core Version:    0.6.2
 */