package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

abstract interface e
{
  static
  {
    CoverageLogger.Log(64460800);
  }

  public abstract float a(d paramd);

  public abstract void a();

  public abstract void a(d paramd, float paramFloat);

  public abstract void a(d paramd, Context paramContext, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3);

  public abstract void a(d paramd, ColorStateList paramColorStateList);

  public abstract float b(d paramd);

  public abstract void b(d paramd, float paramFloat);

  public abstract float c(d paramd);

  public abstract void c(d paramd, float paramFloat);

  public abstract float d(d paramd);

  public abstract float e(d paramd);

  public abstract void f(d paramd);

  public abstract void g(d paramd);

  public abstract ColorStateList h(d paramd);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.cardview.widget.e
 * JD-Core Version:    0.6.2
 */