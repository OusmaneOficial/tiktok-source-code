package androidx.cardview.widget;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.FillType;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class g extends Drawable
{
  static a a;
  private static final double g = Math.cos(Math.toRadians(45.0D));
  public float b;
  public float c;
  public float d;
  public ColorStateList e;
  boolean f = true;
  private final int h;
  private Paint i;
  private Paint j;
  private Paint k;
  private final RectF l;
  private Path m;
  private float n;
  private final int o;
  private final int p;
  private boolean q = true;
  private boolean r;

  static
  {
    CoverageLogger.Log(64157696);
  }

  g(Resources paramResources, ColorStateList paramColorStateList, float paramFloat1, float paramFloat2, float paramFloat3)
  {
    this.o = paramResources.getColor(2131100000);
    this.p = paramResources.getColor(2131099999);
    this.h = paramResources.getDimensionPixelSize(2131165376);
    this.i = new Paint(5);
    a(paramColorStateList);
    this.j = new Paint(5);
    this.j.setStyle(Paint.Style.FILL);
    this.b = ((int)(paramFloat1 + 0.5F));
    this.l = new RectF();
    this.k = new Paint(this.j);
    this.k.setAntiAlias(false);
    a(paramFloat2, paramFloat3);
  }

  static float a(float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      double d1 = paramFloat1 * 1.5F;
      double d2 = 1.0D - g;
      double d3 = paramFloat2;
      Double.isNaN(d3);
      double d4 = d2 * d3;
      Double.isNaN(d1);
      return (float)(d1 + d4);
    }
    return paramFloat1 * 1.5F;
  }

  private static int a(float paramFloat)
  {
    int i1 = (int)(paramFloat + 0.5F);
    if (i1 % 2 == 1)
      i1--;
    return i1;
  }

  static float b(float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      double d1 = paramFloat1;
      double d2 = 1.0D - g;
      double d3 = paramFloat2;
      Double.isNaN(d3);
      double d4 = d2 * d3;
      Double.isNaN(d1);
      paramFloat1 = (float)(d1 + d4);
    }
    return paramFloat1;
  }

  final float a()
  {
    float f1 = this.c;
    return 2.0F * Math.max(f1, this.b + this.h + f1 / 2.0F) + 2.0F * (this.c + this.h);
  }

  void a(float paramFloat1, float paramFloat2)
  {
    if (paramFloat1 >= 0.0F)
    {
      if (paramFloat2 >= 0.0F)
      {
        float f1 = a(paramFloat1);
        float f2 = a(paramFloat2);
        if (f1 > f2)
        {
          if (!this.r)
            this.r = true;
          f1 = f2;
        }
        if ((this.d == f1) && (this.c == f2))
          return;
        this.d = f1;
        this.c = f2;
        this.n = ((int)(0.5F + (f1 * 1.5F + this.h)));
        this.f = true;
        invalidateSelf();
        return;
      }
      StringBuilder localStringBuilder2 = new StringBuilder("Invalid max shadow size ");
      localStringBuilder2.append(paramFloat2);
      localStringBuilder2.append(". Must be >= 0");
      throw new IllegalArgumentException(localStringBuilder2.toString());
    }
    StringBuilder localStringBuilder1 = new StringBuilder("Invalid shadow size ");
    localStringBuilder1.append(paramFloat1);
    localStringBuilder1.append(". Must be >= 0");
    throw new IllegalArgumentException(localStringBuilder1.toString());
  }

  void a(ColorStateList paramColorStateList)
  {
    if (paramColorStateList == null)
      paramColorStateList = ColorStateList.valueOf(0);
    this.e = paramColorStateList;
    this.i.setColor(this.e.getColorForState(getState(), this.e.getDefaultColor()));
  }

  final void a(Rect paramRect)
  {
    getPadding(paramRect);
  }

  final void a(boolean paramBoolean)
  {
    this.q = paramBoolean;
    invalidateSelf();
  }

  final float b()
  {
    float f1 = this.c;
    return 2.0F * Math.max(f1, this.b + this.h + f1 * 1.5F / 2.0F) + 2.0F * (1.5F * this.c + this.h);
  }

  public final void draw(Canvas paramCanvas)
  {
    if (this.f)
    {
      Rect localRect = getBounds();
      float f8 = 1.5F * this.c;
      this.l.set(localRect.left + this.c, f8 + localRect.top, localRect.right - this.c, localRect.bottom - f8);
      float f9 = this.b;
      RectF localRectF1 = new RectF(-f9, -f9, f9, f9);
      RectF localRectF2 = new RectF(localRectF1);
      float f10 = this.n;
      localRectF2.inset(-f10, -f10);
      Path localPath = this.m;
      if (localPath == null)
        this.m = new Path();
      else
        localPath.reset();
      this.m.setFillType(Path.FillType.EVEN_ODD);
      this.m.moveTo(-this.b, 0.0F);
      this.m.rLineTo(-this.n, 0.0F);
      this.m.arcTo(localRectF2, 180.0F, 90.0F, false);
      this.m.arcTo(localRectF1, 270.0F, -90.0F, false);
      this.m.close();
      float f11 = this.b;
      float f12 = this.n;
      float f13 = f11 / (f11 + f12);
      Paint localPaint2 = this.j;
      float f14 = f11 + f12;
      int[] arrayOfInt1 = new int[3];
      int i8 = this.o;
      arrayOfInt1[0] = i8;
      arrayOfInt1[1] = i8;
      arrayOfInt1[2] = this.p;
      RadialGradient localRadialGradient = new RadialGradient(0.0F, 0.0F, f14, arrayOfInt1, new float[] { 0.0F, f13, 1.0F }, Shader.TileMode.CLAMP);
      localPaint2.setShader(localRadialGradient);
      Paint localPaint3 = this.k;
      float f15 = this.b;
      float f16 = -f15;
      float f17 = this.n;
      float f18 = f16 + f17;
      float f19 = -f15 - f17;
      int[] arrayOfInt2 = new int[3];
      int i9 = this.o;
      arrayOfInt2[0] = i9;
      arrayOfInt2[1] = i9;
      arrayOfInt2[2] = this.p;
      LinearGradient localLinearGradient = new LinearGradient(0.0F, f18, 0.0F, f19, arrayOfInt2, new float[] { 0.0F, 0.5F, 1.0F }, Shader.TileMode.CLAMP);
      localPaint3.setShader(localLinearGradient);
      this.k.setAntiAlias(false);
      this.f = false;
    }
    paramCanvas.translate(0.0F, this.d / 2.0F);
    float f1 = this.b;
    float f2 = -f1 - this.n;
    float f3 = f1 + this.h + this.d / 2.0F;
    float f4 = this.l.width();
    float f5 = f3 * 2.0F;
    int i1;
    if (f4 - f5 > 0.0F)
      i1 = 1;
    else
      i1 = 0;
    int i2;
    if (this.l.height() - f5 > 0.0F)
      i2 = 1;
    else
      i2 = 0;
    int i3 = paramCanvas.save();
    paramCanvas.translate(f3 + this.l.left, f3 + this.l.top);
    paramCanvas.drawPath(this.m, this.j);
    int i4;
    if (i1 != 0)
    {
      float f6 = this.l.width() - f5;
      float f7 = -this.b;
      Paint localPaint1 = this.k;
      i4 = i3;
      paramCanvas.drawRect(0.0F, f2, f6, f7, localPaint1);
    }
    else
    {
      i4 = i3;
    }
    paramCanvas.restoreToCount(i4);
    int i5 = paramCanvas.save();
    paramCanvas.translate(this.l.right - f3, this.l.bottom - f3);
    paramCanvas.rotate(180.0F);
    paramCanvas.drawPath(this.m, this.j);
    if (i1 != 0)
      paramCanvas.drawRect(0.0F, f2, this.l.width() - f5, -this.b + this.n, this.k);
    paramCanvas.restoreToCount(i5);
    int i6 = paramCanvas.save();
    paramCanvas.translate(f3 + this.l.left, this.l.bottom - f3);
    paramCanvas.rotate(270.0F);
    paramCanvas.drawPath(this.m, this.j);
    if (i2 != 0)
      paramCanvas.drawRect(0.0F, f2, this.l.height() - f5, -this.b, this.k);
    paramCanvas.restoreToCount(i6);
    int i7 = paramCanvas.save();
    paramCanvas.translate(this.l.right - f3, f3 + this.l.top);
    paramCanvas.rotate(90.0F);
    paramCanvas.drawPath(this.m, this.j);
    if (i2 != 0)
      paramCanvas.drawRect(0.0F, f2, this.l.height() - f5, -this.b, this.k);
    paramCanvas.restoreToCount(i7);
    paramCanvas.translate(0.0F, -this.d / 2.0F);
    a.a(paramCanvas, this.l, this.b, this.i);
  }

  public final int getOpacity()
  {
    return -3;
  }

  public final boolean getPadding(Rect paramRect)
  {
    int i1 = (int)Math.ceil(a(this.c, this.b, this.q));
    int i2 = (int)Math.ceil(b(this.c, this.b, this.q));
    paramRect.set(i2, i1, i2, i1);
    return true;
  }

  public final boolean isStateful()
  {
    ColorStateList localColorStateList = this.e;
    return ((localColorStateList != null) && (localColorStateList.isStateful())) || (super.isStateful());
  }

  protected final void onBoundsChange(Rect paramRect)
  {
    super.onBoundsChange(paramRect);
    this.f = true;
  }

  protected final boolean onStateChange(int[] paramArrayOfInt)
  {
    ColorStateList localColorStateList = this.e;
    int i1 = localColorStateList.getColorForState(paramArrayOfInt, localColorStateList.getDefaultColor());
    if (this.i.getColor() == i1)
      return false;
    this.i.setColor(i1);
    this.f = true;
    invalidateSelf();
    return true;
  }

  public final void setAlpha(int paramInt)
  {
    this.i.setAlpha(paramInt);
    this.j.setAlpha(paramInt);
    this.k.setAlpha(paramInt);
  }

  public final void setColorFilter(ColorFilter paramColorFilter)
  {
    this.i.setColorFilter(paramColorFilter);
  }

  static abstract interface a
  {
    static
    {
      CoverageLogger.Log(64462848);
    }

    public abstract void a(Canvas paramCanvas, RectF paramRectF, float paramFloat, Paint paramPaint);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.cardview.widget.g
 * JD-Core Version:    0.6.2
 */