package androidx.cardview.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

final class f extends Drawable
{
  public float a;
  public float b;
  public ColorStateList c;
  private final Paint d;
  private final RectF e;
  private final Rect f;
  private boolean g;
  private boolean h = true;
  private PorterDuffColorFilter i;
  private ColorStateList j;
  private PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;

  static
  {
    CoverageLogger.Log(64454656);
  }

  f(ColorStateList paramColorStateList, float paramFloat)
  {
    this.a = paramFloat;
    this.d = new Paint(5);
    a(paramColorStateList);
    this.e = new RectF();
    this.f = new Rect();
  }

  private PorterDuffColorFilter a(ColorStateList paramColorStateList, PorterDuff.Mode paramMode)
  {
    if ((paramColorStateList != null) && (paramMode != null))
      return new PorterDuffColorFilter(paramColorStateList.getColorForState(getState(), 0), paramMode);
    return null;
  }

  final void a(float paramFloat, boolean paramBoolean1, boolean paramBoolean2)
  {
    if ((paramFloat == this.b) && (this.g == paramBoolean1) && (this.h == paramBoolean2))
      return;
    this.b = paramFloat;
    this.g = paramBoolean1;
    this.h = paramBoolean2;
    a(null);
    invalidateSelf();
  }

  void a(ColorStateList paramColorStateList)
  {
    if (paramColorStateList == null)
      paramColorStateList = ColorStateList.valueOf(0);
    this.c = paramColorStateList;
    this.d.setColor(this.c.getColorForState(getState(), this.c.getDefaultColor()));
  }

  void a(Rect paramRect)
  {
    if (paramRect == null)
      paramRect = getBounds();
    this.e.set(paramRect.left, paramRect.top, paramRect.right, paramRect.bottom);
    this.f.set(paramRect);
    if (this.g)
    {
      float f1 = g.a(this.b, this.a, this.h);
      float f2 = g.b(this.b, this.a, this.h);
      this.f.inset((int)Math.ceil(f2), (int)Math.ceil(f1));
      this.e.set(this.f);
    }
  }

  public final void draw(Canvas paramCanvas)
  {
    Paint localPaint = this.d;
    int m;
    if ((this.i != null) && (localPaint.getColorFilter() == null))
    {
      localPaint.setColorFilter(this.i);
      m = 1;
    }
    else
    {
      m = 0;
    }
    RectF localRectF = this.e;
    float f1 = this.a;
    paramCanvas.drawRoundRect(localRectF, f1, f1, localPaint);
    if (m != 0)
      localPaint.setColorFilter(null);
  }

  public final int getOpacity()
  {
    return -3;
  }

  public final void getOutline(Outline paramOutline)
  {
    paramOutline.setRoundRect(this.f, this.a);
  }

  public final boolean isStateful()
  {
    ColorStateList localColorStateList1 = this.j;
    ColorStateList localColorStateList2;
    if ((localColorStateList1 == null) || (!localColorStateList1.isStateful()))
      localColorStateList2 = this.c;
    return ((localColorStateList2 != null) && (localColorStateList2.isStateful())) || (super.isStateful());
  }

  protected final void onBoundsChange(Rect paramRect)
  {
    super.onBoundsChange(paramRect);
    a(paramRect);
  }

  protected final boolean onStateChange(int[] paramArrayOfInt)
  {
    ColorStateList localColorStateList1 = this.c;
    int m = localColorStateList1.getColorForState(paramArrayOfInt, localColorStateList1.getDefaultColor());
    boolean bool;
    if (m != this.d.getColor())
      bool = true;
    else
      bool = false;
    if (bool)
      this.d.setColor(m);
    ColorStateList localColorStateList2 = this.j;
    if (localColorStateList2 != null)
    {
      PorterDuff.Mode localMode = this.k;
      if (localMode != null)
      {
        this.i = a(localColorStateList2, localMode);
        return true;
      }
    }
    return bool;
  }

  public final void setAlpha(int paramInt)
  {
    this.d.setAlpha(paramInt);
  }

  public final void setColorFilter(ColorFilter paramColorFilter)
  {
    this.d.setColorFilter(paramColorFilter);
  }

  public final void setTintList(ColorStateList paramColorStateList)
  {
    this.j = paramColorStateList;
    this.i = a(this.j, this.k);
    invalidateSelf();
  }

  public final void setTintMode(PorterDuff.Mode paramMode)
  {
    this.k = paramMode;
    this.i = a(this.j, this.k);
    invalidateSelf();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.cardview.widget.f
 * JD-Core Version:    0.6.2
 */