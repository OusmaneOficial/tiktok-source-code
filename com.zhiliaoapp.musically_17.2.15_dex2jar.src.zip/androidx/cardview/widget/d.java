package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
import android.view.View;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

abstract interface d
{
  static
  {
    CoverageLogger.Log(64458752);
  }

  public abstract void a(int paramInt1, int paramInt2);

  public abstract void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract void a(Drawable paramDrawable);

  public abstract boolean a();

  public abstract boolean b();

  public abstract Drawable c();

  public abstract View d();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.cardview.widget.d
 * JD-Core Version:    0.6.2
 */