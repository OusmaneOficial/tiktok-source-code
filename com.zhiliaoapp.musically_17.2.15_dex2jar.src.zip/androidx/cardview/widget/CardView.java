package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class CardView extends FrameLayout
{
  private static final int[] e;
  private static final e f;
  int a;
  int b;
  final Rect c = new Rect();
  final Rect d = new Rect();
  private boolean g;
  private boolean h;
  private final d i = new d()
  {
    private Drawable b;

    static
    {
      CoverageLogger.Log(64174080);
    }

    public final void a(int paramAnonymousInt1, int paramAnonymousInt2)
    {
      if (paramAnonymousInt1 > CardView.this.a)
        CardView.a(CardView.this, paramAnonymousInt1);
      if (paramAnonymousInt2 > CardView.this.b)
        CardView.b(CardView.this, paramAnonymousInt2);
    }

    public final void a(int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3, int paramAnonymousInt4)
    {
      CardView.this.d.set(paramAnonymousInt1, paramAnonymousInt2, paramAnonymousInt3, paramAnonymousInt4);
      CardView localCardView = CardView.this;
      CardView.a(localCardView, paramAnonymousInt1 + localCardView.c.left, paramAnonymousInt2 + CardView.this.c.top, paramAnonymousInt3 + CardView.this.c.right, paramAnonymousInt4 + CardView.this.c.bottom);
    }

    public final void a(Drawable paramAnonymousDrawable)
    {
      this.b = paramAnonymousDrawable;
      CardView.this.setBackgroundDrawable(paramAnonymousDrawable);
    }

    public final boolean a()
    {
      return CardView.this.getUseCompatPadding();
    }

    public final boolean b()
    {
      return CardView.this.getPreventCornerOverlap();
    }

    public final Drawable c()
    {
      return this.b;
    }

    public final View d()
    {
      return CardView.this;
    }
  };

  static
  {
    CoverageLogger.Log(64440320);
    e = new int[] { 16842801 };
    if (Build.VERSION.SDK_INT >= 21)
      f = new b();
    else if (Build.VERSION.SDK_INT >= 17)
      f = new a();
    else
      f = new c();
    f.a();
  }

  public CardView(Context paramContext)
  {
    this(paramContext, null);
  }

  public CardView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 2130968859);
  }

  public CardView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray localTypedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16843071, 16843072, 2130968853, 2130968854, 2130968855, 2130968856, 2130968857, 2130968858, 2130968967, 2130968968, 2130968969, 2130968970, 2130968971 }, paramInt, 2131886311);
    if (localTypedArray1.hasValue(2));
    ColorStateList localColorStateList2;
    int k;
    for (ColorStateList localColorStateList1 = localTypedArray1.getColorStateList(2); ; localColorStateList1 = ColorStateList.valueOf(k))
    {
      localColorStateList2 = localColorStateList1;
      break;
      TypedArray localTypedArray2 = getContext().obtainStyledAttributes(e);
      int j = localTypedArray2.getColor(0, 0);
      localTypedArray2.recycle();
      float[] arrayOfFloat = new float[3];
      Color.colorToHSV(j, arrayOfFloat);
      if (arrayOfFloat[2] > 0.5F)
        k = getResources().getColor(2131099998);
      else
        k = getResources().getColor(2131099997);
    }
    float f1 = localTypedArray1.getDimension(3, 0.0F);
    float f2 = localTypedArray1.getDimension(4, 0.0F);
    float f3 = localTypedArray1.getDimension(5, 0.0F);
    this.g = localTypedArray1.getBoolean(7, false);
    this.h = localTypedArray1.getBoolean(6, true);
    int m = localTypedArray1.getDimensionPixelSize(8, 0);
    this.c.left = localTypedArray1.getDimensionPixelSize(10, m);
    this.c.top = localTypedArray1.getDimensionPixelSize(12, m);
    this.c.right = localTypedArray1.getDimensionPixelSize(11, m);
    this.c.bottom = localTypedArray1.getDimensionPixelSize(9, m);
    float f4;
    if (f2 > f3)
      f4 = f2;
    else
      f4 = f3;
    this.a = localTypedArray1.getDimensionPixelSize(0, 0);
    this.b = localTypedArray1.getDimensionPixelSize(1, 0);
    localTypedArray1.recycle();
    f.a(this.i, paramContext, localColorStateList2, f1, f2, f4);
  }

  public ColorStateList getCardBackgroundColor()
  {
    return f.h(this.i);
  }

  public float getCardElevation()
  {
    return f.e(this.i);
  }

  public int getContentPaddingBottom()
  {
    return this.c.bottom;
  }

  public int getContentPaddingLeft()
  {
    return this.c.left;
  }

  public int getContentPaddingRight()
  {
    return this.c.right;
  }

  public int getContentPaddingTop()
  {
    return this.c.top;
  }

  public float getMaxCardElevation()
  {
    return f.a(this.i);
  }

  public boolean getPreventCornerOverlap()
  {
    return this.h;
  }

  public float getRadius()
  {
    return f.d(this.i);
  }

  public boolean getUseCompatPadding()
  {
    return this.g;
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    if (!(f instanceof b))
    {
      int j = View.MeasureSpec.getMode(paramInt1);
      if ((j == -2147483648) || (j == 1073741824))
        paramInt1 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(f.b(this.i)), View.MeasureSpec.getSize(paramInt1)), j);
      int k = View.MeasureSpec.getMode(paramInt2);
      if ((k == -2147483648) || (k == 1073741824))
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.max((int)Math.ceil(f.c(this.i)), View.MeasureSpec.getSize(paramInt2)), k);
      super.onMeasure(paramInt1, paramInt2);
      return;
    }
    super.onMeasure(paramInt1, paramInt2);
  }

  public void setCardBackgroundColor(int paramInt)
  {
    f.a(this.i, ColorStateList.valueOf(paramInt));
  }

  public void setCardBackgroundColor(ColorStateList paramColorStateList)
  {
    f.a(this.i, paramColorStateList);
  }

  public void setCardElevation(float paramFloat)
  {
    f.c(this.i, paramFloat);
  }

  public void setMaxCardElevation(float paramFloat)
  {
    f.b(this.i, paramFloat);
  }

  public void setMinimumHeight(int paramInt)
  {
    this.b = paramInt;
    super.setMinimumHeight(paramInt);
  }

  public void setMinimumWidth(int paramInt)
  {
    this.a = paramInt;
    super.setMinimumWidth(paramInt);
  }

  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
  }

  public void setPaddingRelative(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
  }

  public void setPreventCornerOverlap(boolean paramBoolean)
  {
    if (paramBoolean != this.h)
    {
      this.h = paramBoolean;
      f.g(this.i);
    }
  }

  public void setRadius(float paramFloat)
  {
    f.a(this.i, paramFloat);
  }

  public void setUseCompatPadding(boolean paramBoolean)
  {
    if (this.g != paramBoolean)
    {
      this.g = paramBoolean;
      f.f(this.i);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.cardview.widget.CardView
 * JD-Core Version:    0.6.2
 */