package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class ParcelImpl
  implements Parcelable
{
  public static final Parcelable.Creator<ParcelImpl> CREATOR = new Parcelable.Creator()
  {
    static
    {
      CoverageLogger.Log(2152448);
    }
  };
  public final c a;

  static
  {
    CoverageLogger.Log(2148352);
  }

  protected ParcelImpl(Parcel paramParcel)
  {
    this.a = new b(paramParcel).g();
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    new b(paramParcel).a(this.a);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     androidx.versionedparcelable.ParcelImpl
 * JD-Core Version:    0.6.2
 */