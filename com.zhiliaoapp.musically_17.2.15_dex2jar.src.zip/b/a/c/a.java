package b.a.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.a.g;
import e.f.b.l;

public final class a
{
  static
  {
    CoverageLogger.Log(63875072);
  }

  public static final byte[] a(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
  {
    l.b(paramArrayOfByte1, "src");
    l.b(paramArrayOfByte2, "dst");
    return g.a(paramArrayOfByte1, paramArrayOfByte2, paramInt2, paramInt1, paramInt3 + paramInt1);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.c.a
 * JD-Core Version:    0.6.2
 */