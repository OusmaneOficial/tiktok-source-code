package b.a.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;

public abstract class c
{
  public final int a = 64;
  public final int b = 16;
  private final byte[] c = new byte[this.a];
  private int d;
  private long e;

  static
  {
    CoverageLogger.Log(63764480);
  }

  public c(int paramInt1, int paramInt2)
  {
  }

  public final c a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    l.b(paramArrayOfByte, "data");
    int i = paramInt2;
    int j = 0;
    while (i > 0)
    {
      int k = Math.min(this.a - this.d, i);
      a.a(paramArrayOfByte, j, this.c, this.d, k);
      i -= k;
      j += k;
      this.d = (k + this.d);
      int m = this.d;
      int n = this.a;
      if (m >= n)
      {
        this.d = (m - n);
        a(this.c);
      }
    }
    this.e += paramInt2;
    return this;
  }

  protected abstract void a();

  protected abstract void a(byte[] paramArrayOfByte);

  protected abstract byte[] a(long paramLong);

  protected abstract void b(byte[] paramArrayOfByte);

  public final byte[] b()
  {
    byte[] arrayOfByte1 = new byte[this.b];
    l.b(arrayOfByte1, "out");
    byte[] arrayOfByte2 = a(this.e);
    int i = 0;
    while (i < arrayOfByte2.length)
    {
      int j = this.a;
      int k = this.d;
      int m = j - k;
      a.a(arrayOfByte2, i, this.c, k, m);
      a(this.c);
      this.d = 0;
      i += m;
    }
    b(arrayOfByte1);
    a();
    l.b(arrayOfByte1, "bytes");
    return arrayOfByte1;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.c.c
 * JD-Core Version:    0.6.2
 */