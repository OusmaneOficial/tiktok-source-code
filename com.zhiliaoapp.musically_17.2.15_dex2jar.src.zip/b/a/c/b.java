package b.a.c;

import b.a.c.a.a;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;
import java.util.Arrays;

public final class b
{
  public static final a b = new a(null);
  public final byte[] a;

  static
  {
    CoverageLogger.Log(63766528);
  }

  public static final String a(byte[] paramArrayOfByte)
  {
    l.b(paramArrayOfByte, "src");
    String str1 = a.a;
    StringBuilder localStringBuilder = new StringBuilder(2 * paramArrayOfByte.length);
    int i = paramArrayOfByte.length;
    for (int j = 0; j < i; j++)
    {
      int k = 0xFF & paramArrayOfByte[j];
      localStringBuilder.append(str1.charAt(0xF & k >>> 4));
      localStringBuilder.append(str1.charAt(0xF & k >>> 0));
    }
    String str2 = localStringBuilder.toString();
    l.a(str2, "StringBuilder(capacity).…builderAction).toString()");
    return str2;
  }

  public final boolean equals(Object paramObject)
  {
    byte[] arrayOfByte = this.a;
    return ((paramObject instanceof b)) && (l.a(arrayOfByte, ((b)paramObject).a));
  }

  public final int hashCode()
  {
    byte[] arrayOfByte = this.a;
    if (arrayOfByte != null)
      return Arrays.hashCode(arrayOfByte);
    return 0;
  }

  public final String toString()
  {
    byte[] arrayOfByte = this.a;
    StringBuilder localStringBuilder = new StringBuilder("Hash(bytes=");
    localStringBuilder.append(Arrays.toString(arrayOfByte));
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }

  public static final class a
  {
    static
    {
      CoverageLogger.Log(63877120);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.c.b
 * JD-Core Version:    0.6.2
 */