package b.a.c.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;
import e.u;

public final class a
{
  public static final String a;
  public static final a b;
  private static final String c = "0123456789ABCDEF";
  private static final String d;

  static
  {
    CoverageLogger.Log(63752192);
    b = new a();
    c = "0123456789ABCDEF";
    String str1 = "0123456789ABCDEF".toUpperCase();
    l.a(str1, "(this as java.lang.String).toUpperCase()");
    d = str1;
    String str2 = c;
    if (str2 != null)
    {
      String str3 = str2.toLowerCase();
      l.a(str3, "(this as java.lang.String).toLowerCase()");
      a = str3;
      return;
    }
    throw new u("null cannot be cast to non-null type java.lang.String");
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.c.a.a
 * JD-Core Version:    0.6.2
 */