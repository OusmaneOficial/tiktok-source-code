package b.a.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.a.a;

public class d
{
  public final a<c> a;

  static
  {
    CoverageLogger.Log(63883264);
  }

  public d(a<? extends c> parama)
  {
    this.a = parama;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.c.d
 * JD-Core Version:    0.6.2
 */