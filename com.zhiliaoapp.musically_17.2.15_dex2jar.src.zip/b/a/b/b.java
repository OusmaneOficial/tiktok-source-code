package b.a.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class b<V>
{
  public V a;

  static
  {
    CoverageLogger.Log(63846400);
  }

  public b(V paramV)
  {
    this.a = paramV;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.b
 * JD-Core Version:    0.6.2
 */