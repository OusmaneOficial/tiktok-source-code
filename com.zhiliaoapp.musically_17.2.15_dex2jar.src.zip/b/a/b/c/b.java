package b.a.b.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;

public final class b
{
  static
  {
    CoverageLogger.Log(63830016);
  }

  public static final <T> T a(a<T> parama)
  {
    l.b(parama, "$this$value");
    return parama.a();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.c.b
 * JD-Core Version:    0.6.2
 */