package b.a.b.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.locks.ReentrantLock;

public final class c
{
  private final ReentrantLock a = new ReentrantLock();

  static
  {
    CoverageLogger.Log(63827968);
  }

  public final void a()
  {
    this.a.lock();
  }

  public final void b()
  {
    this.a.unlock();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.c.c
 * JD-Core Version:    0.6.2
 */