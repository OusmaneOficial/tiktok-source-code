package b.a.b.c;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.atomic.AtomicReference;

public final class a<V>
{
  private final AtomicReference<V> a;

  static
  {
    CoverageLogger.Log(63832064);
  }

  public a(V paramV)
  {
    this.a = new AtomicReference(paramV);
  }

  public final V a()
  {
    return this.a.get();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.c.a
 * JD-Core Version:    0.6.2
 */