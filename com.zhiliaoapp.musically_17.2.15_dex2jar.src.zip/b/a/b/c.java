package b.a.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;

public final class c
{
  static
  {
    CoverageLogger.Log(63844352);
  }

  public static final <T> T a(b<T> paramb)
  {
    l.b(paramb, "$this$value");
    return paramb.a;
  }

  public static final <T> void a(b<T> paramb, T paramT)
  {
    l.b(paramb, "$this$value");
    paramb.a = paramT;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.c
 * JD-Core Version:    0.6.2
 */