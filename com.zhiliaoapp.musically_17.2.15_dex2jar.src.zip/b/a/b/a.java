package b.a.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;

public final class a
{
  static
  {
    CoverageLogger.Log(63848448);
  }

  public static final long a()
  {
    Thread localThread = Thread.currentThread();
    l.a(localThread, "Thread.currentThread()");
    return localThread.getId();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.a
 * JD-Core Version:    0.6.2
 */