package b.a.b.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.TimeUnit;

public final class a
{
  public static final a a = new a();

  static
  {
    CoverageLogger.Log(63842304);
  }

  public static long a()
  {
    return System.currentTimeMillis();
  }

  public static long b()
  {
    return TimeUnit.NANOSECONDS.toMillis(System.nanoTime());
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.a.a
 * JD-Core Version:    0.6.2
 */