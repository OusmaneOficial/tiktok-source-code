package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.ScheduledExecutorService;

public abstract interface g
{
  static
  {
    CoverageLogger.Log(63803392);
  }

  public abstract ScheduledExecutorService a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.g
 * JD-Core Version:    0.6.2
 */