package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f;
import e.g;
import e.k.d;

public final class l
{
  public static final b.a.b.c.a<f<k>> a = new b.a.b.c.a(g.a((e.f.a.a)b.a));
  public static final b.a.b.c.a<f<k>> b = new b.a.b.c.a(g.a((e.f.a.a)a.a));

  static
  {
    CoverageLogger.Log(63868928);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.l
 * JD-Core Version:    0.6.2
 */