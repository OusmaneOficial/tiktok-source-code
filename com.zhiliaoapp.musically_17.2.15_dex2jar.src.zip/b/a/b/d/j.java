package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.a.a;

public final class j
  implements Runnable
{
  static
  {
    CoverageLogger.Log(63838208);
  }

  public j(a parama)
  {
    this.a = parama;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.j
 * JD-Core Version:    0.6.2
 */