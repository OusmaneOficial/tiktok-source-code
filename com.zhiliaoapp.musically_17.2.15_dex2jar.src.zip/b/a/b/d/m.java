package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f;
import e.f.a.a;
import e.f.b.l;
import e.g;
import java.util.concurrent.ThreadFactory;

public final class m
  implements ThreadFactory
{
  public static final f a = g.a((a)b.a);
  public static final a b;
  private final String c;

  static
  {
    CoverageLogger.Log(63873024);
    b = new a(null);
  }

  public m(String paramString)
  {
    this.c = paramString;
  }

  public final Thread newThread(Runnable paramRunnable)
  {
    l.b(paramRunnable, "runnable");
    Thread localThread = ((ThreadFactory)a.getValue()).newThread(paramRunnable);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.c);
    localStringBuilder.append(", ");
    localStringBuilder.append(localThread.getName());
    localThread.setName(localStringBuilder.toString());
    localThread.setDaemon(true);
    l.a(localThread, "factory\n            .new…emon = true\n            }");
    return localThread;
  }

  static final class a
  {
    static
    {
      CoverageLogger.Log(63774720);
    }
  }

  static final class b extends e.f.b.m
    implements a<ThreadFactory>
  {
    public static final b a = new b();

    static
    {
      CoverageLogger.Log(63866880);
    }

    b()
    {
      super();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.m
 * JD-Core Version:    0.6.2
 */