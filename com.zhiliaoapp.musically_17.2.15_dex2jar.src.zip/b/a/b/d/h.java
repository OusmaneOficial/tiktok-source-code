package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.a.b;
import e.x;

public final class h<T>
{
  final e<T> a = new e();
  private final a<T> b;

  static
  {
    CoverageLogger.Log(63799296);
  }

  public h(b<? super T, x> paramb)
  {
    this.b = new a(this.a, paramb);
    this.b.start();
  }

  static final class a<T> extends Thread
  {
    private final e<T> a;
    private final b<T, x> b;

    static
    {
      CoverageLogger.Log(63834112);
    }

    public a(e<T> parame, b<? super T, x> paramb)
    {
      this.a = parame;
      this.b = paramb;
      setDaemon(true);
    }

    // ERROR //
    public final void run()
    {
      // Byte code:
      //   0: aload_0
      //   1: invokespecial 46	java/lang/Thread:run	()V
      //   4: aload_0
      //   5: invokevirtual 50	b/a/b/d/h$a:isInterrupted	()Z
      //   8: ifne +74 -> 82
      //   11: aload_0
      //   12: getfield 35	b/a/b/d/h$a:a	Lb/a/b/d/e;
      //   15: astore_1
      //   16: aload_1
      //   17: getfield 55	b/a/b/d/e:a	Ljava/util/concurrent/DelayQueue;
      //   20: invokevirtual 61	java/util/concurrent/DelayQueue:take	()Ljava/util/concurrent/Delayed;
      //   23: astore_2
      //   24: aload_1
      //   25: getfield 64	b/a/b/d/e:b	Ljava/util/Set;
      //   28: aload_2
      //   29: checkcast 66	b/a/b/d/e$a
      //   32: invokeinterface 72 2 0
      //   37: ifeq +46 -> 83
      //   40: goto +3 -> 43
      //   43: aload_2
      //   44: checkcast 66	b/a/b/d/e$a
      //   47: astore_3
      //   48: aload_3
      //   49: ifnull -33 -> 16
      //   52: aload_3
      //   53: getfield 75	b/a/b/d/e$a:a	Ljava/lang/Object;
      //   56: astore 4
      //   58: aload 4
      //   60: ifnull -44 -> 16
      //   63: aload_0
      //   64: getfield 37	b/a/b/d/h$a:b	Le/f/a/b;
      //   67: aload 4
      //   69: invokeinterface 81 2 0
      //   74: pop
      //   75: goto -71 -> 4
      //   78: aload_0
      //   79: invokevirtual 84	b/a/b/d/h$a:interrupt	()V
      //   82: return
      //   83: aconst_null
      //   84: astore_2
      //   85: goto -42 -> 43
      //
      // Exception table:
      //   from	to	target	type
      //   11	16	78	java/lang/InterruptedException
      //   16	40	78	java/lang/InterruptedException
      //   43	48	78	java/lang/InterruptedException
      //   52	58	78	java/lang/InterruptedException
      //   63	75	78	java/lang/InterruptedException
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.h
 * JD-Core Version:    0.6.2
 */