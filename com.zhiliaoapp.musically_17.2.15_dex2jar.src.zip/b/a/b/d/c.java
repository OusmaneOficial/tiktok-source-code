package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class c
{
  static
  {
    CoverageLogger.Log(63817728);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.c
 * JD-Core Version:    0.6.2
 */