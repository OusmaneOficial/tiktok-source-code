package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public final class e<T>
{
  final DelayQueue<a<T>> a = new DelayQueue();
  final Set<a<T>> b;

  static
  {
    CoverageLogger.Log(63809536);
  }

  public e()
  {
    Set localSet = Collections.newSetFromMap((Map)new ConcurrentHashMap());
    l.a(localSet, "Collections.newSetFromMa…Map<Entry<T>, Boolean>())");
    this.b = localSet;
  }

  static final class a<T>
    implements Delayed
  {
    public static final a c = new a(null);
    private static final AtomicLong e = new AtomicLong();
    public final T a;
    public final long b;
    private final long d;

    static
    {
      CoverageLogger.Log(64143360);
    }

    public final long getDelay(TimeUnit paramTimeUnit)
    {
      l.b(paramTimeUnit, "timeUnit");
      return paramTimeUnit.convert(this.b - System.nanoTime(), TimeUnit.NANOSECONDS);
    }

    static final class a
    {
      static
      {
        CoverageLogger.Log(63813632);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.e
 * JD-Core Version:    0.6.2
 */