package b.a.b.d;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.a.a;
import e.x;

public abstract interface k
{
  static
  {
    CoverageLogger.Log(63856640);
  }

  public abstract a a();

  public static abstract interface a
  {
    static
    {
      CoverageLogger.Log(63784960);
    }

    public abstract void a();

    public abstract void a(long paramLong, a<x> parama);

    public static final class a
    {
      static
      {
        CoverageLogger.Log(63854592);
      }
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.k
 * JD-Core Version:    0.6.2
 */