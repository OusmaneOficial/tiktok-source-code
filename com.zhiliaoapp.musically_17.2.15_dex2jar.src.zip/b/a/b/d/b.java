package b.a.b.d;

import com.ss.android.ugc.aweme.bn.g;
import com.ss.android.ugc.aweme.bn.l;
import com.ss.android.ugc.aweme.bn.l.a;
import com.ss.android.ugc.aweme.bn.o;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;

public final class b
{
  static
  {
    CoverageLogger.Log(1294336);
  }

  static ScheduledExecutorService a(ThreadFactory paramThreadFactory)
  {
    return (ScheduledExecutorService)g.a(l.a(o.SCHEDULED).a(1).a(paramThreadFactory).a());
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.d.b
 * JD-Core Version:    0.6.2
 */