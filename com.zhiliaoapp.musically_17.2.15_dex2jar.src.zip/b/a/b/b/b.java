package b.a.b.b;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import java.util.concurrent.Executor;

public abstract interface b extends Executor
{
  static
  {
    CoverageLogger.Log(64135168);
  }

  public abstract void a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.b.b.b
 * JD-Core Version:    0.6.2
 */