package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;
import java.io.File;

public final class h
{
  public final String a;
  private final File b;

  static
  {
    CoverageLogger.Log(16664576);
  }

  public h(String paramString)
  {
    this.a = paramString;
    String str = this.a;
    File localFile;
    if (str != null)
      localFile = new File(str).getAbsoluteFile();
    else
      localFile = null;
    this.b = localFile;
  }

  public final h a(String paramString)
  {
    l.b(paramString, "component");
    File localFile1 = this.b;
    if (localFile1 == null)
      return null;
    File localFile2 = new File(localFile1.getAbsolutePath(), paramString).getAbsoluteFile();
    l.a(localFile2, "File(file.absolutePath, component).absoluteFile");
    return new h(localFile2.getAbsolutePath());
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("[component=");
    localStringBuilder.append(this.a);
    localStringBuilder.append(", canonicalPath=");
    File localFile1 = this.b;
    String str1;
    if (localFile1 != null)
      str1 = localFile1.getCanonicalPath();
    else
      str1 = null;
    localStringBuilder.append(str1);
    localStringBuilder.append(", absolutePath=");
    File localFile2 = this.b;
    String str2 = null;
    if (localFile2 != null)
      str2 = localFile2.getAbsolutePath();
    localStringBuilder.append(str2);
    localStringBuilder.append(']');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.h
 * JD-Core Version:    0.6.2
 */