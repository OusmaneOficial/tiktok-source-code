package b.a.d.a;

import android.os.Environment;
import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.a.a;
import e.f.b.l;
import e.f.b.m;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.nio.charset.Charset;

public final class d
{
  public static final d a;
  private static final String b;
  private static final String c = str2;

  static
  {
    CoverageLogger.Log(16742400);
    a = new d();
    String str1 = File.separator;
    l.a(str1, "File.separator");
    b = str1;
    File localFile = Environment.getExternalStorageDirectory();
    l.a(localFile, "Environment.getExternalStorageDirectory()");
    String str2 = localFile.getAbsolutePath();
    l.a(str2, "Environment.getExternalS…eDirectory().absolutePath");
  }

  public static f a(File paramFile)
  {
    i locali = (i)((a)new a(paramFile)).invoke();
    String str = paramFile.getName();
    l.a(str, "file.name");
    f localf = new f(str, new h(paramFile.getAbsolutePath()), new h(paramFile.getCanonicalPath()), Double.valueOf(0.0D), Double.valueOf(paramFile.lastModified()), Long.valueOf(paramFile.length()), locali);
    return localf;
  }

  public static String a()
  {
    return b;
  }

  private String a(c paramc, b paramb)
  {
    l.b(paramc, "inputStream");
    l.b(paramb, "contentEncoding");
    InputStream localInputStream = paramc.a;
    if (localInputStream == null)
      l.a("inputStream");
    Closeable localCloseable = (Closeable)new InputStreamReader(localInputStream, ((Charset)((a)new b(paramb)).invoke()).name());
    try
    {
      InputStreamReader localInputStreamReader = (InputStreamReader)localCloseable;
      StringWriter localStringWriter = new StringWriter();
      char[] arrayOfChar = new char[1024];
      for (int i = localInputStreamReader.read(arrayOfChar); i != -1; i = localInputStreamReader.read(arrayOfChar))
        localStringWriter.write(arrayOfChar, 0, i);
      String str = localStringWriter.toString();
      l.a(str, "writer.toString()");
      e.e.c.a(localCloseable, null);
      return str;
    }
    finally
    {
      try
      {
        throw localThrowable;
      }
      finally
      {
        e.e.c.a(localCloseable, localThrowable);
      }
    }
    while (true)
      throw localObject;
  }

  public static void a(k paramk)
  {
    l.b(paramk, "closeable");
    try
    {
      paramk.a();
    }
    catch (Exception localException)
    {
    }
  }

  public static boolean a(String paramString, boolean paramBoolean)
  {
    l.b(paramString, "path");
    return new File(paramString).getAbsoluteFile().mkdirs();
  }

  public static g b(String paramString, boolean paramBoolean)
  {
    l.b(paramString, "path");
    FileOutputStream localFileOutputStream = new FileOutputStream(new File(paramString).getAbsoluteFile(), paramBoolean);
    g localg = new g();
    localg.a(localFileOutputStream);
    return localg;
  }

  public static boolean b(String paramString)
  {
    if (paramString == null)
      return false;
    return new File(paramString).getAbsoluteFile().exists();
  }

  public static boolean c(String paramString)
  {
    l.b(paramString, "path");
    File localFile = new File(paramString).getAbsoluteFile();
    l.a(localFile, "File(path).absoluteFile");
    return e.e.i.d(localFile);
  }

  public static c d(String paramString)
  {
    l.b(paramString, "path");
    FileInputStream localFileInputStream = new FileInputStream(new File(paramString).getAbsoluteFile());
    c localc = new c();
    localc.a((InputStream)localFileInputStream);
    return localc;
  }

  // ERROR //
  public final long a(String paramString1, String paramString2, boolean paramBoolean1, b paramb, boolean paramBoolean2)
  {
    // Byte code:
    //   0: new 25	java/io/File
    //   3: dup
    //   4: aload_1
    //   5: invokespecial 182	java/io/File:<init>	(Ljava/lang/String;)V
    //   8: invokevirtual 185	java/io/File:getAbsoluteFile	()Ljava/io/File;
    //   11: astore 6
    //   13: aload 6
    //   15: invokevirtual 205	java/io/File:exists	()Z
    //   18: istore 7
    //   20: lconst_0
    //   21: lstore 8
    //   23: iload 7
    //   25: ifne +16 -> 41
    //   28: iload_3
    //   29: ifne +6 -> 35
    //   32: lload 8
    //   34: lreturn
    //   35: aload 6
    //   37: invokevirtual 227	java/io/File:createNewFile	()Z
    //   40: pop
    //   41: aload 4
    //   43: getstatic 230	b/a/d/a/b:Base64	Lb/a/d/a/b;
    //   46: if_acmpne +55 -> 101
    //   49: getstatic 235	e/m/d:a	Ljava/nio/charset/Charset;
    //   52: astore 22
    //   54: aload_2
    //   55: ifnull +36 -> 91
    //   58: aload_2
    //   59: aload 22
    //   61: invokevirtual 241	java/lang/String:getBytes	(Ljava/nio/charset/Charset;)[B
    //   64: astore 23
    //   66: aload 23
    //   68: ldc 243
    //   70: invokestatic 35	e/f/b/l:a	(Ljava/lang/Object;Ljava/lang/String;)V
    //   73: aload 23
    //   75: iconst_0
    //   76: invokestatic 249	android/util/Base64:encodeToString	([BI)Ljava/lang/String;
    //   79: astore 13
    //   81: aload 13
    //   83: ldc 251
    //   85: invokestatic 35	e/f/b/l:a	(Ljava/lang/Object;Ljava/lang/String;)V
    //   88: goto +72 -> 160
    //   91: new 253	e/u
    //   94: dup
    //   95: ldc 255
    //   97: invokespecial 256	e/u:<init>	(Ljava/lang/String;)V
    //   100: athrow
    //   101: new 258	b/a/d/a/d$c
    //   104: dup
    //   105: aload 4
    //   107: invokespecial 259	b/a/d/a/d$c:<init>	(Lb/a/d/a/b;)V
    //   110: checkcast 62	e/f/a/a
    //   113: invokeinterface 66 1 0
    //   118: checkcast 131	java/nio/charset/Charset
    //   121: astore 10
    //   123: getstatic 235	e/m/d:a	Ljava/nio/charset/Charset;
    //   126: astore 11
    //   128: aload_2
    //   129: ifnull +163 -> 292
    //   132: aload_2
    //   133: aload 11
    //   135: invokevirtual 241	java/lang/String:getBytes	(Ljava/nio/charset/Charset;)[B
    //   138: astore 12
    //   140: aload 12
    //   142: ldc 243
    //   144: invokestatic 35	e/f/b/l:a	(Ljava/lang/Object;Ljava/lang/String;)V
    //   147: new 237	java/lang/String
    //   150: dup
    //   151: aload 12
    //   153: aload 10
    //   155: invokespecial 262	java/lang/String:<init>	([BLjava/nio/charset/Charset;)V
    //   158: astore 13
    //   160: aconst_null
    //   161: astore 14
    //   163: new 192	java/io/FileOutputStream
    //   166: dup
    //   167: aload 6
    //   169: iconst_0
    //   170: invokespecial 195	java/io/FileOutputStream:<init>	(Ljava/io/File;Z)V
    //   173: astore 15
    //   175: getstatic 235	e/m/d:a	Ljava/nio/charset/Charset;
    //   178: astore 19
    //   180: aload 13
    //   182: ifnull +49 -> 231
    //   185: aload 13
    //   187: aload 19
    //   189: invokevirtual 241	java/lang/String:getBytes	(Ljava/nio/charset/Charset;)[B
    //   192: astore 20
    //   194: aload 20
    //   196: ldc 243
    //   198: invokestatic 35	e/f/b/l:a	(Ljava/lang/Object;Ljava/lang/String;)V
    //   201: aload 15
    //   203: aload 20
    //   205: invokevirtual 265	java/io/FileOutputStream:write	([B)V
    //   208: aload 15
    //   210: invokevirtual 268	java/io/FileOutputStream:flush	()V
    //   213: aload 20
    //   215: arraylength
    //   216: istore 21
    //   218: iload 21
    //   220: i2l
    //   221: lstore 8
    //   223: aload 15
    //   225: invokevirtual 271	java/io/FileOutputStream:close	()V
    //   228: lload 8
    //   230: lreturn
    //   231: new 253	e/u
    //   234: dup
    //   235: ldc 255
    //   237: invokespecial 256	e/u:<init>	(Ljava/lang/String;)V
    //   240: athrow
    //   241: astore 17
    //   243: goto +15 -> 258
    //   246: aload 15
    //   248: astore 14
    //   250: goto +25 -> 275
    //   253: astore 17
    //   255: aconst_null
    //   256: astore 15
    //   258: aload 15
    //   260: ifnull +11 -> 271
    //   263: aload 15
    //   265: invokevirtual 271	java/io/FileOutputStream:close	()V
    //   268: goto +4 -> 272
    //   271: pop
    //   272: aload 17
    //   274: athrow
    //   275: aload 14
    //   277: ifnull +11 -> 288
    //   280: aload 14
    //   282: invokevirtual 271	java/io/FileOutputStream:close	()V
    //   285: goto +4 -> 289
    //   288: pop
    //   289: lload 8
    //   291: lreturn
    //   292: new 253	e/u
    //   295: dup
    //   296: ldc 255
    //   298: invokespecial 256	e/u:<init>	(Ljava/lang/String;)V
    //   301: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   175	180	241	finally
    //   185	218	241	finally
    //   231	241	241	finally
    //   175	180	246	java/lang/Exception
    //   185	218	246	java/lang/Exception
    //   231	241	246	java/lang/Exception
    //   163	175	253	finally
    //   263	268	271	java/lang/Exception
    //   163	175	275	java/lang/Exception
    //   223	228	288	java/lang/Exception
    //   280	285	288	java/lang/Exception
  }

  public final f a(h paramh)
  {
    if (paramh == null)
      return null;
    String str = paramh.a;
    if (str == null)
      return null;
    return a(str);
  }

  public final f a(String paramString)
  {
    l.b(paramString, "path");
    return a(new File(paramString));
  }

  public final g a(h paramh, boolean paramBoolean)
  {
    if (paramh == null)
      return null;
    String str = paramh.a;
    if (str == null)
      return null;
    return b(str, paramBoolean);
  }

  public final boolean a(h paramh1, h paramh2)
  {
    if (paramh1 == null)
      return false;
    if (paramh2 == null)
      return false;
    if (b(paramh2))
      c(paramh2);
    File localFile1 = new File(paramh1.a);
    File localFile2 = new File(paramh2.a);
    if (!localFile1.exists())
      return false;
    return localFile1.renameTo(localFile2);
  }

  // ERROR //
  public final boolean a(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: aload_1
    //   1: ldc_w 295
    //   4: invokestatic 113	e/f/b/l:b	(Ljava/lang/Object;Ljava/lang/String;)V
    //   7: aload_2
    //   8: ldc_w 297
    //   11: invokestatic 113	e/f/b/l:b	(Ljava/lang/Object;Ljava/lang/String;)V
    //   14: new 25	java/io/File
    //   17: dup
    //   18: aload_2
    //   19: invokespecial 182	java/io/File:<init>	(Ljava/lang/String;)V
    //   22: astore_3
    //   23: aload_3
    //   24: invokevirtual 205	java/io/File:exists	()Z
    //   27: ifeq +23 -> 50
    //   30: aload_3
    //   31: invokevirtual 49	java/io/File:getAbsolutePath	()Ljava/lang/String;
    //   34: astore 25
    //   36: aload 25
    //   38: ldc_w 299
    //   41: invokestatic 35	e/f/b/l:a	(Ljava/lang/Object;Ljava/lang/String;)V
    //   44: aload 25
    //   46: invokestatic 301	b/a/d/a/d:c	(Ljava/lang/String;)Z
    //   49: pop
    //   50: aconst_null
    //   51: astore 4
    //   53: aload_3
    //   54: invokevirtual 83	java/io/File:getCanonicalPath	()Ljava/lang/String;
    //   57: astore 10
    //   59: new 303	java/util/zip/ZipInputStream
    //   62: dup
    //   63: new 305	java/io/BufferedInputStream
    //   66: dup
    //   67: new 216	java/io/FileInputStream
    //   70: dup
    //   71: aload_1
    //   72: invokespecial 306	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   75: checkcast 220	java/io/InputStream
    //   78: invokespecial 308	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   81: checkcast 220	java/io/InputStream
    //   84: invokespecial 309	java/util/zip/ZipInputStream:<init>	(Ljava/io/InputStream;)V
    //   87: astore 8
    //   89: aload 8
    //   91: invokevirtual 313	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
    //   94: astore 11
    //   96: aload 11
    //   98: ifnull +260 -> 358
    //   101: new 25	java/io/File
    //   104: dup
    //   105: aload_3
    //   106: aload 11
    //   108: invokevirtual 316	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   111: invokespecial 319	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   114: astore 12
    //   116: aload 12
    //   118: invokevirtual 83	java/io/File:getCanonicalPath	()Ljava/lang/String;
    //   121: astore 13
    //   123: aload 13
    //   125: ldc_w 321
    //   128: invokestatic 35	e/f/b/l:a	(Ljava/lang/Object;Ljava/lang/String;)V
    //   131: aload 10
    //   133: ldc_w 323
    //   136: invokestatic 35	e/f/b/l:a	(Ljava/lang/Object;Ljava/lang/String;)V
    //   139: aload 13
    //   141: aload 10
    //   143: iconst_0
    //   144: iconst_2
    //   145: aconst_null
    //   146: invokestatic 328	e/m/p:b	(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z
    //   149: ifeq +170 -> 319
    //   152: aload 11
    //   154: invokevirtual 331	java/util/zip/ZipEntry:isDirectory	()Z
    //   157: ifeq +19 -> 176
    //   160: aload 12
    //   162: invokevirtual 189	java/io/File:mkdirs	()Z
    //   165: pop
    //   166: aload 8
    //   168: invokevirtual 313	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
    //   171: astore 11
    //   173: goto -77 -> 96
    //   176: aload 12
    //   178: invokevirtual 334	java/io/File:getParentFile	()Ljava/io/File;
    //   181: astore 16
    //   183: aload 16
    //   185: ifnull +20 -> 205
    //   188: aload 16
    //   190: invokevirtual 205	java/io/File:exists	()Z
    //   193: ifne +12 -> 205
    //   196: aload 16
    //   198: invokevirtual 189	java/io/File:mkdirs	()Z
    //   201: pop
    //   202: goto +17 -> 219
    //   205: aload 12
    //   207: invokevirtual 205	java/io/File:exists	()Z
    //   210: ifeq +9 -> 219
    //   213: aload 12
    //   215: invokevirtual 337	java/io/File:delete	()Z
    //   218: pop
    //   219: new 339	java/io/BufferedOutputStream
    //   222: dup
    //   223: new 192	java/io/FileOutputStream
    //   226: dup
    //   227: aload 12
    //   229: invokespecial 340	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   232: checkcast 342	java/io/OutputStream
    //   235: invokespecial 345	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   238: astore 17
    //   240: new 347	e/f/b/y$c
    //   243: dup
    //   244: invokespecial 348	e/f/b/y$c:<init>	()V
    //   247: astore 18
    //   249: sipush 8192
    //   252: newarray byte
    //   254: astore 19
    //   256: aload 8
    //   258: aload 19
    //   260: invokevirtual 351	java/util/zip/ZipInputStream:read	([B)I
    //   263: istore 20
    //   265: aload 18
    //   267: iload 20
    //   269: putfield 355	e/f/b/y$c:element	I
    //   272: iload 20
    //   274: iconst_m1
    //   275: if_icmpeq +19 -> 294
    //   278: aload 17
    //   280: aload 19
    //   282: iconst_0
    //   283: aload 18
    //   285: getfield 355	e/f/b/y$c:element	I
    //   288: invokevirtual 358	java/io/BufferedOutputStream:write	([BII)V
    //   291: goto -35 -> 256
    //   294: aload 17
    //   296: invokevirtual 359	java/io/BufferedOutputStream:flush	()V
    //   299: aload 17
    //   301: invokevirtual 360	java/io/BufferedOutputStream:close	()V
    //   304: aload 8
    //   306: invokevirtual 363	java/util/zip/ZipInputStream:closeEntry	()V
    //   309: aload 8
    //   311: invokevirtual 313	java/util/zip/ZipInputStream:getNextEntry	()Ljava/util/zip/ZipEntry;
    //   314: astore 11
    //   316: goto -220 -> 96
    //   319: new 365	java/lang/StringBuilder
    //   322: dup
    //   323: ldc_w 367
    //   326: invokespecial 368	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   329: astore 14
    //   331: aload 14
    //   333: aload 11
    //   335: invokevirtual 316	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   338: invokevirtual 372	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: pop
    //   342: new 374	b/a/d/a/o
    //   345: dup
    //   346: aload 14
    //   348: invokevirtual 375	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   351: invokespecial 376	b/a/d/a/o:<init>	(Ljava/lang/String;)V
    //   354: checkcast 378	java/lang/Throwable
    //   357: athrow
    //   358: aload 8
    //   360: invokevirtual 379	java/util/zip/ZipInputStream:close	()V
    //   363: goto +4 -> 367
    //   366: pop
    //   367: iconst_1
    //   368: ireturn
    //   369: astore 7
    //   371: goto +53 -> 424
    //   374: astore 5
    //   376: aload 8
    //   378: astore 4
    //   380: goto +14 -> 394
    //   383: astore 7
    //   385: aload 4
    //   387: astore 8
    //   389: goto +35 -> 424
    //   392: astore 5
    //   394: aload 5
    //   396: invokevirtual 382	b/a/d/a/j:getMessage	()Ljava/lang/String;
    //   399: astore 6
    //   401: aload 6
    //   403: ifnonnull +8 -> 411
    //   406: ldc_w 384
    //   409: astore 6
    //   411: new 374	b/a/d/a/o
    //   414: dup
    //   415: aload 6
    //   417: invokespecial 376	b/a/d/a/o:<init>	(Ljava/lang/String;)V
    //   420: checkcast 378	java/lang/Throwable
    //   423: athrow
    //   424: aload 8
    //   426: ifnull +11 -> 437
    //   429: aload 8
    //   431: invokevirtual 379	java/util/zip/ZipInputStream:close	()V
    //   434: goto +4 -> 438
    //   437: pop
    //   438: goto +6 -> 444
    //   441: aload 7
    //   443: athrow
    //   444: goto -3 -> 441
    //
    // Exception table:
    //   from	to	target	type
    //   358	363	366	java/lang/Exception
    //   89	96	369	finally
    //   101	173	369	finally
    //   176	183	369	finally
    //   188	202	369	finally
    //   205	219	369	finally
    //   219	256	369	finally
    //   256	272	369	finally
    //   278	291	369	finally
    //   294	316	369	finally
    //   319	358	369	finally
    //   89	96	374	b/a/d/a/j
    //   101	173	374	b/a/d/a/j
    //   176	183	374	b/a/d/a/j
    //   188	202	374	b/a/d/a/j
    //   205	219	374	b/a/d/a/j
    //   219	256	374	b/a/d/a/j
    //   256	272	374	b/a/d/a/j
    //   278	291	374	b/a/d/a/j
    //   294	316	374	b/a/d/a/j
    //   319	358	374	b/a/d/a/j
    //   53	89	383	finally
    //   394	401	383	finally
    //   411	424	383	finally
    //   53	89	392	b/a/d/a/j
    //   429	434	437	java/lang/Exception
  }

  public final boolean b(h paramh)
  {
    if (paramh == null)
      return false;
    String str = paramh.a;
    if (str == null)
      return false;
    return b(str);
  }

  public final boolean c(h paramh)
  {
    if (paramh != null)
    {
      String str = paramh.a;
      if (str != null)
        return c(str);
    }
    return false;
  }

  public final c d(h paramh)
  {
    if (paramh == null)
      return null;
    String str = paramh.a;
    if (str == null)
      return null;
    return d(str);
  }

  static final class a extends m
    implements a<i>
  {
    static
    {
      CoverageLogger.Log(16748544);
    }

    a(File paramFile)
    {
      super();
    }
  }

  static final class b extends m
    implements a<Charset>
  {
    static
    {
      CoverageLogger.Log(16750592);
    }

    b(b paramb)
    {
      super();
    }
  }

  static final class c extends m
    implements a<Charset>
  {
    static
    {
      CoverageLogger.Log(16670720);
    }

    c(b paramb)
    {
      super();
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.d
 * JD-Core Version:    0.6.2
 */