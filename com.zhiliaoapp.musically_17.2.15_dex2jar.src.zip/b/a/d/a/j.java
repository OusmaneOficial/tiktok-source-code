package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class j extends Exception
{
  static
  {
    CoverageLogger.Log(16656384);
  }

  public j(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.j
 * JD-Core Version:    0.6.2
 */