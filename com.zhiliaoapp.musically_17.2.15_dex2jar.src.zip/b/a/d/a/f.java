package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;

public final class f
{
  public final String a;
  public final h b;
  public final h c;
  public final Double d;
  public final Double e;
  public final Long f;
  public final i g;

  static
  {
    CoverageLogger.Log(16668672);
  }

  public f(String paramString, h paramh1, h paramh2, Double paramDouble1, Double paramDouble2, Long paramLong, i parami)
  {
    this.a = paramString;
    this.b = paramh1;
    this.c = paramh2;
    this.d = paramDouble1;
    this.e = paramDouble2;
    this.f = paramLong;
    this.g = parami;
  }

  public final boolean equals(Object paramObject)
  {
    if (this != paramObject)
      if ((paramObject instanceof f))
      {
        f localf = (f)paramObject;
        if ((l.a(this.a, localf.a)) && (l.a(this.b, localf.b)) && (l.a(this.c, localf.c)) && (l.a(this.d, localf.d)) && (l.a(this.e, localf.e)) && (l.a(this.f, localf.f)) && (l.a(this.g, localf.g)));
      }
      else
      {
        return false;
      }
    return true;
  }

  public final int hashCode()
  {
    String str = this.a;
    int i;
    if (str != null)
      i = str.hashCode();
    else
      i = 0;
    int j = i * 31;
    h localh1 = this.b;
    int k;
    if (localh1 != null)
      k = localh1.hashCode();
    else
      k = 0;
    int m = 31 * (j + k);
    h localh2 = this.c;
    int n;
    if (localh2 != null)
      n = localh2.hashCode();
    else
      n = 0;
    int i1 = 31 * (m + n);
    Double localDouble1 = this.d;
    int i2;
    if (localDouble1 != null)
      i2 = localDouble1.hashCode();
    else
      i2 = 0;
    int i3 = 31 * (i1 + i2);
    Double localDouble2 = this.e;
    int i4;
    if (localDouble2 != null)
      i4 = localDouble2.hashCode();
    else
      i4 = 0;
    int i5 = 31 * (i3 + i4);
    Long localLong = this.f;
    int i6;
    if (localLong != null)
      i6 = localLong.hashCode();
    else
      i6 = 0;
    int i7 = 31 * (i5 + i6);
    i locali = this.g;
    int i8 = 0;
    if (locali != null)
      i8 = locali.hashCode();
    return i7 + i8;
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("FileMeta(name=");
    localStringBuilder.append(this.a);
    localStringBuilder.append(", absolutePath=");
    localStringBuilder.append(this.b);
    localStringBuilder.append(", canonicalPath=");
    localStringBuilder.append(this.c);
    localStringBuilder.append(", createdAt=");
    localStringBuilder.append(this.d);
    localStringBuilder.append(", modifiedAt=");
    localStringBuilder.append(this.e);
    localStringBuilder.append(", size=");
    localStringBuilder.append(this.f);
    localStringBuilder.append(", type=");
    localStringBuilder.append(this.g);
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.f
 * JD-Core Version:    0.6.2
 */