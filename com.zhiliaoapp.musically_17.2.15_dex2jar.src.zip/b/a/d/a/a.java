package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.a.g;
import e.f.b.l;
import java.util.Arrays;

public class a
{
  public static final int c = 2147483639;
  public static final a d;
  public byte[] a;
  public int b;

  static
  {
    CoverageLogger.Log(16736256);
    d = new a(null);
  }

  public a()
  {
    this(0, 1, null);
  }

  public a(int paramInt)
  {
    int i;
    if (paramInt >= 0)
      i = 1;
    else
      i = 0;
    if (i != 0)
    {
      this.a = new byte[paramInt];
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder("Negative initial size: ");
    localStringBuilder.append(paramInt);
    throw ((Throwable)new IllegalArgumentException(localStringBuilder.toString().toString()));
  }

  public final void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    l.b(paramArrayOfByte, "b");
    if ((paramInt1 >= 0) && (paramInt1 <= paramArrayOfByte.length) && (paramInt2 >= 0))
    {
      int i = paramInt1 + paramInt2;
      if (i - paramArrayOfByte.length <= 0)
      {
        int j = paramInt2 + this.b;
        byte[] arrayOfByte1 = this.a;
        if (j - arrayOfByte1.length > 0)
        {
          int k = arrayOfByte1.length;
          int m = 1;
          int n = k << m;
          if (n - j < 0)
            n = j;
          if (n - c > 0)
          {
            if (j < 0)
              m = 0;
            if (m != 0)
            {
              n = c;
              if (j > n)
                n = 2147483647;
            }
            else
            {
              throw ((Throwable)new IllegalStateException("out of memory!".toString()));
            }
          }
          byte[] arrayOfByte2 = Arrays.copyOf(this.a, n);
          l.a(arrayOfByte2, "java.util.Arrays.copyOf(this, newSize)");
          this.a = arrayOfByte2;
        }
        g.a(paramArrayOfByte, this.a, this.b, paramInt1, i);
        this.b = (paramInt2 + this.b);
        return;
      }
    }
    throw ((Throwable)new IndexOutOfBoundsException());
  }

  public String toString()
  {
    return this.a.toString();
  }

  public static final class a
  {
    static
    {
      CoverageLogger.Log(16732160);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.a
 * JD-Core Version:    0.6.2
 */