package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public enum b
{
  static
  {
    CoverageLogger.Log(16678912);
    b[] arrayOfb = new b[3];
    b localb1 = new b("Utf8", 0);
    Utf8 = localb1;
    arrayOfb[0] = localb1;
    b localb2 = new b("Ascii", 1);
    Ascii = localb2;
    arrayOfb[1] = localb2;
    b localb3 = new b("Base64", 2);
    Base64 = localb3;
    arrayOfb[2] = localb3;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.b
 * JD-Core Version:    0.6.2
 */