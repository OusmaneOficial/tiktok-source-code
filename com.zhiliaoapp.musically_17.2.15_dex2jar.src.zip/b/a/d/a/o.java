package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public final class o extends Exception
{
  static
  {
    CoverageLogger.Log(16764928);
  }

  public o(Exception paramException)
  {
    super((Throwable)paramException);
  }

  public o(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.o
 * JD-Core Version:    0.6.2
 */