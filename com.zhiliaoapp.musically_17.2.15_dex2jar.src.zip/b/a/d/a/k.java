package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface k
{
  static
  {
    CoverageLogger.Log(16754688);
  }

  public abstract void a();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.k
 * JD-Core Version:    0.6.2
 */