package b.a.d.a;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public enum i
{
  static
  {
    CoverageLogger.Log(16660480);
    i[] arrayOfi = new i[3];
    i locali1 = new i("Regular", 0);
    Regular = locali1;
    arrayOfi[0] = locali1;
    i locali2 = new i("Directory", 1);
    Directory = locali2;
    arrayOfi[1] = locali2;
    i locali3 = new i("Unknown", 2);
    Unknown = locali3;
    arrayOfi[2] = locali3;
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.d.a.i
 * JD-Core Version:    0.6.2
 */