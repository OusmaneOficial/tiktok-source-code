package b.a.e;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface a
{
  static
  {
    CoverageLogger.Log(63750144);
  }

  public abstract void a(String paramString1, String paramString2);

  public abstract void a(String paramString1, String paramString2, Throwable paramThrowable);

  public abstract boolean a();

  public abstract void b(String paramString1, String paramString2);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.e.a
 * JD-Core Version:    0.6.2
 */