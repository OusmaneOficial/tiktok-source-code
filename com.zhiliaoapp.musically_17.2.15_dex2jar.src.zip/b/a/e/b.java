package b.a.e;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;

public final class b
{
  public static final b a = new b();
  private static a b = (a)new c();

  static
  {
    CoverageLogger.Log(63746048);
  }

  private static boolean a()
  {
    return b.a();
  }

  public final void a(a parama)
  {
    l.b(parama, "logger");
    if (a())
      b = parama;
  }

  public final void a(String paramString1, String paramString2)
  {
    l.b(paramString1, "tag");
    l.b(paramString2, "message");
    if (a())
      b.a(paramString1, paramString2);
  }

  public final void a(String paramString1, String paramString2, Throwable paramThrowable)
  {
    l.b(paramString1, "tag");
    l.b(paramString2, "message");
    if (a())
    {
      if (paramThrowable != null)
      {
        b.a(paramString1, paramString2, paramThrowable);
        return;
      }
      b.b(paramString1, paramString2);
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.e.b
 * JD-Core Version:    0.6.2
 */