package b.a.f;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract class a
{
  static
  {
    CoverageLogger.Log(63741952);
  }

  public abstract boolean a(c paramc);
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.f.a
 * JD-Core Version:    0.6.2
 */