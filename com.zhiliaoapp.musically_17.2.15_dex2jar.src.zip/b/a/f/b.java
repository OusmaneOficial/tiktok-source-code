package b.a.f;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public class b
{
  static
  {
    CoverageLogger.Log(63907840);
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.f.b
 * JD-Core Version:    0.6.2
 */