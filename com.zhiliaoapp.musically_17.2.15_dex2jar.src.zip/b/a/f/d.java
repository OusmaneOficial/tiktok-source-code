package b.a.f;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;
import e.f.b.l;
import java.util.Iterator;
import java.util.Map;

public final class d
{
  public static final b d = new b(null);
  public final b.a.a.b<String, c> a;
  public boolean b;
  public b.a.b.b.b c;
  private final b.a.a.b<String, a> e;

  static
  {
    CoverageLogger.Log(63924224);
  }

  private d(boolean paramBoolean, b.a.b.b.b paramb)
  {
    this.b = paramBoolean;
    this.c = paramb;
    this.e = new b.a.a.b(false, 1, null);
    this.a = new b.a.a.b(false, 1, null);
  }

  public final void a(final c paramc)
  {
    l.b(paramc, "task");
    Iterator localIterator = ((Iterable)this.e.values()).iterator();
    int i = 0;
    while (localIterator.hasNext())
      if (((a)localIterator.next()).a(paramc))
        i = 1;
    if (i == 0)
      this.c.execute((Runnable)new c(this, paramc));
  }

  public static final class a
  {
    public boolean a;
    public b.a.b.b.b b = (b.a.b.b.b)new b.a.b.b.a();

    static
    {
      CoverageLogger.Log(63911936);
    }

    public final a a(b.a.b.b.b paramb)
    {
      l.b(paramb, "executor");
      a locala = (a)this;
      locala.b = paramb;
      return locala;
    }

    public final d a()
    {
      return new d(this.a, this.b, null);
    }
  }

  public static final class b
  {
    static
    {
      CoverageLogger.Log(63735808);
    }
  }

  public static final class c
    implements Runnable
  {
    static
    {
      CoverageLogger.Log(63918080);
    }

    c(c paramc)
    {
    }

    public final void run()
    {
      ((Map)this.a.a).put(paramc.a(), paramc);
      paramc.b();
      this.a.a.remove(paramc.a());
    }
  }
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.f.d
 * JD-Core Version:    0.6.2
 */