package b.a.f;

import com.ss.android.ugc.bytex.coverage_lib.CoverageLogger;

public abstract interface c
{
  static
  {
    CoverageLogger.Log(63916032);
  }

  public abstract String a();

  public abstract void b();

  public abstract void c();
}

/* Location:           C:\Users\ousma\Downloads\com.zhiliaoapp.musically_17.2.15_dex2jar.jar
 * Qualified Name:     b.a.f.c
 * JD-Core Version:    0.6.2
 */